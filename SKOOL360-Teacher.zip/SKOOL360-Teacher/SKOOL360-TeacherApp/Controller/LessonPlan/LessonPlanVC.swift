//
//  LessonPlanVC.swift
//  Skool360Teacher
//
//  Created by ADMS on 26/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class LessonPlanVC: CustomViewController {
    
    var dropDown: UIDropDown!
    @IBOutlet var tblLessonPlan:UITableView!
    var dicLessonPlanData:NSMutableDictionary = [:]
    var arrLessonPlanData = [LessonPlanModel]()
    var arrStdSub:[String] = []
    
    var localUrl:URL!
    var documentController : UIDocumentInteractionController!
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblLessonPlan.estimatedRowHeight = 45.0
        tblLessonPlan.rowHeight = UITableViewAutomaticDimension
        tblLessonPlan.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        self.callLessonPlanApi()
    }
    
    
    // MARK: - API Calling
    
    func callLessonPlanApi()
    {
        let params = ["StaffID":staffID!]
        
        Functions.callApi(api: teacherLessonPlanApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for values in arrData! {
                    
                    let arrData:[JSON] = values["Data"].array!
                    self.dicLessonPlanData.setValue(arrData, forKey: "\(values["Standard"]) → \(values["Subject"])")
                }
                
                self.arrStdSub = self.dicLessonPlanData.sortedDictionary(self.dicLessonPlanData).0
                
                self.addDropDown()
                self.getLessonPlanData(self.arrStdSub[0])
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callLessonPlanApi()
                })
            }
        }
    }
    
    func getLessonPlanData(_ key:String)
    {
        arrLessonPlanData = []
        
        let array:[JSON] = self.dicLessonPlanData[key] as! [JSON]
        if(array.count > 0) {
            
            for values in array {
                
                let lessonPlanModal = LessonPlanModel.init(id: values["ID"].numberValue, chapterNo: values["ChapterNo"].stringValue, chapterName: values["ChapterName"].stringValue)
                
                arrLessonPlanData.append(lessonPlanModal)
            }
        }
        self.tblLessonPlan.reloadData()
    }
    
    
    // MARK: - Function for Choose Standard & Subject
    
    func addDropDown()
    {
        dropDown = UIDropDown(frame: CGRect(x:15, y: isIpad ? 150:view.subviews[0].frame.size.height + 20, width: isIpad ? 180:150, height: isIpad ? 40:35))
        dropDown.placeholder = "-Please Select-"
        dropDown.options = self.arrStdSub
        dropDown.tableHeight = self.arrStdSub.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrStdSub.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = self.arrStdSub[0]
        dropDown.didSelect { (option, index) in
            self.dropDown.hideTable()
            self.getLessonPlanData(option)
        }
        self.view.addSubview(dropDown)
    }
    
    //    func pdfWordDownload(_ urlString:String)
    //    {
    //        ZVProgressHUD.show(title: "0 %", progress: 0)
    //        Functions.downloadFileApi(url: URL.init(string: urlString)!) { (url) in
    //            //webUrl = url
    //            self.add(asChildViewController: self.lessonPlanVC)
    //        }
    //    }
    
    func downloadPdfWord(_ sender:UIButton)
    {
        //        switch sender.tag {
        //        case 1:
        //            //self.pdfWordDownload("\(pdf)\(sender.accessibilityValue!)")
        //            webUrl = "\(pdf)\(sender.accessibilityValue!)"
        //        default:
        //self.pdfWordDownload("\(word)\(sender.accessibilityValue!)")
        webUrl = "\(wordApi)\(sender.accessibilityValue!)"
        //        }
        add(asChildViewController: self.lessonPlanVC, self)
    }
    
    private lazy var lessonPlanVC: LessonPlanPopupVC = {
        
        var viewController:LessonPlanPopupVC = storyBoard.instantiateViewController(withIdentifier: "LessonPlanPopupVC") as! LessonPlanPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension LessonPlanVC:UITableViewDataSource,UITableViewDelegate,LessonPlanCellDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.row == 0 ? 45 : UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrLessonPlanData.count > 0 ? arrLessonPlanData.count + 1 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if(indexPath.row == 0) {
            strIdentifier = "LessonPlanHeaderCell"
        }
        else {
            strIdentifier = "LessonPlanCell"
        }
        
        let cell:LessonPlanCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! LessonPlanCell
        
        if(indexPath.row > 0) {
            cell.delegate = self
            cell.displayData(lessonPlanData: arrLessonPlanData[indexPath.row - 1])
        }
        return cell
    }
}










//            if(url != nil){
//
//
//                if let path = Bundle.main.path(forResource: "test", ofType: "pdf") {
//                    //                    if let targetURL = URL.init(fileURLWithPath: path) {
//                    self.documentController = UIDocumentInteractionController(url: URL.init(fileURLWithPath: path))
//                    let url1 = NSURL(string:"ibooks://file:///var/mobile/Containers/Data/Application/94EFB44C-50B6-4CBC-AF77-6C0C47C22C1F/Documents");
//                    if UIApplication.shared.canOpenURL(url1! as URL) {
//                        //self.documentController!.presentOpenInMenu(from: .zero, in: self.view, animated: true)
//                        //println("iBooks is installed")
//                    }else{
//                        //println("iBooks is not installed")
//                    }
//                    //                    }
//                }
//
//                //                self.documentController = UIDocumentInteractionController.init(url: URL.init(fileURLWithPath: url.absoluteString))
//                //                let url = NSURL(string:"itms-books:");
//                //                if UIApplication.shared.canOpenURL(url! as URL) {
//                //                    self.documentController!.presentOpenInMenu(from: .zero, in: self.view, animated: true)
//                //                    print("iBooks is installed")
//                //                }else{
//                //                    print("iBooks is not installed")
//                //                }
//
//                //self.documentController.presentOptionsMenu(from: self.view.frame, in: self.view, animated: true)
//                //UIApplication.shared.openURL(URL.init(string: "ibooks://\(url.absoluteString)")!)
//            }
