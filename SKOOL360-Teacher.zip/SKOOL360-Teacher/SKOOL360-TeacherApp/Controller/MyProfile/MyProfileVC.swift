//
//  MyProfileVC.swift
//  Bhadaj (Teacher)
//
//  Created by Sweta on 06/09/18.
//  Copyright © 2018 Sweta. All rights reserved.
//

import UIKit

class MyProfileVC: CustomViewController {
    
    @IBOutlet var tblProfile:UITableView!
    var isCheck:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func resetData(_ sender:UIButton)
    {
        isCheck = !isCheck
        for txtfld in (sender.superview?.superview?.subviews.flatMap{$0 as? UITextField})! {
            txtfld.text = nil
        }
        self.tblProfile.isScrollEnabled = true
        self.tblProfile.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MyProfileVC
{
    @IBAction func btnChangeAction(_ sender:UIButton)
    {
        self.resetData(sender)
    }
    
    @IBAction func btnChangePasswordAction(_ sender:UIButton)
    {
        var strNPwd:String!
        var strCPPwd:String!
        
        for txtfld in (sender.superview?.superview?.subviews.flatMap{$0 as? UITextField})! {
            switch(txtfld.tag)
            {
            case 1:
                if(txtfld.text?.trimmingCharacters(in: .whitespacesAndNewlines).count == 0) {
                    Functions.showAlert(false, Message.currentPwdError)
                    return
                }else if(txtfld.text != staffData.password!) {
                    Functions.showAlert(false, Message.currentPwdNotMatchError)
                    return
                }
            case 2:
                if(txtfld.text?.trimmingCharacters(in: .whitespacesAndNewlines).count == 0) {
                    Functions.showAlert(false, Message.newPwdError)
                    return
                }else if ((txtfld.text?.count)! < 3 || (txtfld.text?.count)! > 12) {
                    Functions.showAlert(false, Message.passwordError)
                    return
                }
                strNPwd = txtfld.text!
            case 3:
                if(txtfld.text?.trimmingCharacters(in: .whitespacesAndNewlines).count == 0) {
                    Functions.showAlert(false, Message.newCPwdError)
                    return
                }else if (txtfld.text != strNPwd) {
                    Functions.showAlert(false, Message.newCCPwdError)
                    return
                }
                strCPPwd = strNPwd
            default:
                break
            }
        }
        
        if(strCPPwd != nil) {
            let params = ["StaffID" : staffID!,
                          "NewPassword" : strNPwd!]
            
            Functions.callApi(vc: self, api: API.staffProfileCPwdApi, params: params, completionHandler: { (json, error) in
                if(json != nil){
                    Functions.showAlert(false, (json!["Message"].stringValue))
                    staffData.password = strNPwd
                    self.resetData(sender)
                }
            })
        }
    }
}

extension MyProfileVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return staffData != nil ? 3 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var strIdentifier:String!
        switch indexPath.row {
        case 0:
            strIdentifier = "ProfilePCell"
        case 1:
            strIdentifier = "ProfileOCell"
        case 2:
            strIdentifier = isCheck ? "ProfileCPCell" : "ProfileLCell"
        default:
            break
        }
        
        let cell:ProfileCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! ProfileCell
        cell.contentView.subviews[0].addShadowWithRadius(2, 5)
        
        var array:[String] = []
        switch indexPath.row {
        case 0:
            array = [staffData.staffName!, staffData.staffEmailID!, staffData.staffDOB!, staffData.staffMobile!, staffData.staffAddress!]
        case 1:
            array = [staffData.staffDepartment!, staffData.staffDesignation!]
        case 2:
            array = [staffData.userName!, String(staffData.password!.characters.map { _ in return "•" })]
        default:
            break
        }
        cell.displayProfileData(array)
        return cell
    }
}
