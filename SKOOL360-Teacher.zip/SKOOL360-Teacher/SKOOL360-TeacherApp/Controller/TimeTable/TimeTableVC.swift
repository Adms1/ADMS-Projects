//
//  ScheduleVC.swift
//  Skool360Teacher
//
//  Created by Sweta on 18/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class TimeTableVC: CustomViewController, TimeTableCellDelegate {
    
    @IBOutlet var tblTimeTable:UITableView!
    
    var arrScheduleData = [ScheduleModel]()
    var dicTimeTable:NSMutableDictionary = [:]
    let arrayDays:Array = DateFormatter().weekdaySymbols
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblTimeTable.tableFooterView = UIView()
        self.callTimeTableApi()
    }
    
    
    // MARK: - API Calling
    
    func callTimeTableApi()
    {
        let params = ["StaffID":staffID!]
        
        self.dicTimeTable = [:]
        
        Functions.callApi(vc: self, api: API.teacherGetTimeTableApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrTimeTbl = json!["FinalArray"].array
                
                for values in arrTimeTbl! {
                    let array = values["Data"].array
                    
                    var arrTimeTable = [TimeTableModel]()
                    for arrValue in array! {
                        let timetblModal:TimeTableModel = TimeTableModel.init(lecture: arrValue["Lecture"].stringValue, lectureId:arrValue["TimetableID"].stringValue ,subject: arrValue["Subject"].stringValue, stdClass: arrValue["StandardClass"].stringValue)
                        
                        arrTimeTable.append(timetblModal)
                    }
                    self.dicTimeTable.setValue(arrTimeTable, forKey: values["Day"].stringValue)
                }
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callTimeTableApi()
                })
            }
            self.tblTimeTable.reloadData()
        }
    }
    
    func callDeleteLectureApi(_ sender:UIButton)
    {
        let params = ["TimetableID":sender.accessibilityValue!]
        
        Functions.callApi(vc: self, api: API.deleteTimetableApi, params: params) { (json,error) in
            
            if(json != nil){
                /*var arrTimeTable:[TimeTableModel] = self.dicTimeTable.keyedOrValueExist(key: self.arrayDays[sender.superview!.tag+1]) as! [TimeTableModel]
                 
                 let idx:NSInteger = (sender.superview?.superview?.tag)!-1
                 let ttModal:TimeTableModel = arrTimeTable[idx]
                 
                 let dict = result!["FinalArray"].array?.first
                 let timeTableModal:TimeTableModel = TimeTableModel.init(lecture: ttModal.Lecture!, lectureId: dict!["timetableid"].stringValue, subject: dict!["Subject"].stringValue, stdClass: dict!["Class"].stringValue)
                 
                 arrTimeTable.remove(at: idx)
                 arrTimeTable.insert(timeTableModal, at: idx)
                 
                 self.dicTimeTable.setValue(arrTimeTable, forKey: self.arrayDays[sender.superview!.tag+1])
                 self.tblTimeTable.reloadData()*/
                self.callTimeTableApi()
                
            }else if (error != nil){
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callDeleteLectureApi(sender)
                })
            }
        }
    }
    
    
    // MARK: - Delegate
    
    func addDeleteTimeTable(_ sender:UIButton)
    {
        if sender.accessibilityValue == "0" {
            var array:[TimeTableModel] = self.dicTimeTable.keyedOrValueExist(key: arrayDays[sender.superview!.tag+1]) as! [TimeTableModel]
            //strLectureName = (array[(sender.superview?.superview?.tag)!-1]).Lecture!
            //add(asChildViewController: timeTablePopupVC, self)
        }else {
            self.callDeleteLectureApi(sender)
        }
    }
    
//    private lazy var timeTablePopupVC: TimeTablePopupVC = {
//
//        var viewController:TimeTablePopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "TimeTablePopupVC") as! TimeTablePopupVC
//        viewController.delegate = self
//        add(asChildViewController: viewController, self)
//        return viewController
//    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension TimeTableVC:UITableViewDelegate,UITableViewDataSource
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:TimeTableCell = tableView.dequeueReusableCell(withIdentifier: "TimeTableHeaderCell") as! TimeTableCell
        
        headerView.contentView.subviews[0].addShadowWithRadius(2, 0)
        let keys = self.dicTimeTable.allKeys as! [String]
        headerView.lblDay.text = keys[keys.index(of: arrayDays[section+1])!]
        
        if(section == selectedIndex) {
            //strDayName = headerView.lblDay.text!
            headerView.lblDay.textColor = GetColor.green
        }else {
            headerView.lblDay.textColor = GetColor.orange
        }
        
        headerView.lblDay.font = FontHelper.medium(size: DeviceType.isIpad ? 22 : 18)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSections(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.dicTimeTable.allKeys.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let keys = self.dicTimeTable.allKeys as! [String]
        return (dicTimeTable.keyedOrValueExist(key: keys[keys.index(of: arrayDays[section+1])!]) as! [TimeTableModel]).count + 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return DeviceType.isIpad ? 50 : 40
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if(indexPath.row == 0) {
            strIdentifier = "TimeTableCellHeader"
        }
        else {
            strIdentifier = "TimeTableCell"
        }
        
        let cell:TimeTableCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! TimeTableCell
        
        if(indexPath.row > 0) {
            let keys = self.dicTimeTable.allKeys as! [String]
            let tblModal:TimeTableModel = (dicTimeTable.keyedOrValueExist(key: keys[keys.index(of: arrayDays[indexPath.section + 1])!]) as! [TimeTableModel])[indexPath.row-1]
            cell.delegate = self
            cell.tag = indexPath.row
            cell.contentView.tag = indexPath.section
            cell.displayData(timeTblData: tblModal)
        }
        return cell
    }
    
    @objc func expandCollapseSections(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblTimeTable.beginUpdates()
        tblTimeTable.reloadData()
        tblTimeTable.endUpdates()
        
        if(selectedIndex != -1){
            self.tblTimeTable.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .top, animated: true)
        }
    }
}
