//
//  TimeTablePopupVC.swift
//  Shilaj (Teacher)
//
//  Created by ADMS on 06/11/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UIDropDown

protocol TimeTablePopupVCDelagate {
    func callTimeTableApi()
}

var strLectureName:String = ""
var strDayName:String = ""

class TimeTablePopupVC: UIViewController {
    
    @IBOutlet var collectionSection:UICollectionView!
    @IBOutlet var collectionHeight:NSLayoutConstraint!
    @IBOutlet var popUpHeight:NSLayoutConstraint!
    var delegate:TimeTablePopupVCDelagate!
    
    var dicStdSections:NSMutableDictionary = [:]
    var dicStandards:NSMutableDictionary = [:]
    var dicSubjects:NSMutableDictionary = [:]
    
    var arrStandards:[String] = []
    var arrSections:[String] = []
    var arrSectionIds:[String] = []
    var arrSubjects:[String] = []
    
    var strStd:String = ""
    var strStdID:String = ""
    var strSubID:String = ""
    var strStartLTime:String = ""
    var strStartMTime:String = ""
    var strEndLTime:String = ""
    var strEndMTime:String = ""
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetSectionsApi()
    }
    
    
    // MARK: - API Calling
    
    func callGetSectionsApi()
    {
        resetData()
        
        Functions.callApi(vc: self, api: API.getStandardSectionApi, params: [:]) { (json, error) in
            
            if(json != nil) {
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStandards.setValue(value["StandardID"].stringValue, forKey: "\(value["StandardID"].stringValue)-\(value["Standard"].stringValue)")
                    
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                
                self.arrStandards = self.dicStandards.sortedDictionary(self.dicStandards).1
                
                let dict:NSMutableDictionary = [:]
                self.dicStandards.forEach { dict[$0] = $1 }
                
                for (key,value) in dict {
                    self.dicStandards.setValue(value, forKey: (key as! String).components(separatedBy: "-").last!)
                    self.dicStandards.removeObject(forKey: key)
                }
                
                self.addDropDown()
                self.callAssignSubjectsApi()
                
            }else if (error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetSectionsApi()
                })
            }
        }
    }
    
    func callAssignSubjectsApi()
    {
        let params = ["StaffID":staffID!]
        
        Functions.callApi(vc: self, api: API.getAssignedSubjectApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrSchedule = json!["FinalArray"].array
                
                for values in arrSchedule! {
                    self.dicSubjects.setValue(values["SubjectID"].stringValue, forKey: values["Subject"].stringValue)
                }
                self.arrSubjects = self.dicSubjects.sortedDictionary(self.dicSubjects).0
                self.addSubjectsDropDown()
                self.callGetLectureTimingApi()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callAssignSubjectsApi()
                })
            }
        }
    }
    
    func callGetLectureTimingApi()
    {
        let params = ["LectureID":strLectureName,
                      "StandardID":strStdID]
        
        Functions.callApi(vc: self, api: API.getLectureDetailsApi, params: params) { (json,error) in
            if(json != nil){
                
                let dicLectureTiming = json!["FinalArray"].array?.first
                
                self.strStartLTime = dicLectureTiming!["StartTimeHour"].stringValue
                self.strStartMTime = dicLectureTiming!["StartTimeMin"].stringValue
                self.strEndLTime = dicLectureTiming!["EndTimeHour"].stringValue
                self.strEndMTime = dicLectureTiming!["EndTimeMin"].stringValue
                
                let array = [self.strStartLTime, self.strEndMTime, self.strEndLTime, self.strEndMTime]
                
                var i = 0
                for view in self.view.subviews[0].subviews[0].subviews {
                    if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+5){
                        let lblLectureTiming:UILabel = view as! UILabel
                        lblLectureTiming.text = array[i]
                        
                        i += 1
                    }
                }
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetLectureTimingApi()
                })
            }
        }
    }
    
    func callAddLectureApi()
    {
        let params = ["StaffID":staffID!,
                      "ClassID":(self.arrSectionIds.map{String(describing: $0)}).joined(separator: ","),
                      "StandardID":strStdID,
                      "SubjectID":strSubID,
                      "DayName":strDayName,
                      "LectureName":strLectureName,
                      "Strttimehour":strStartLTime,
                      "StrttimeMin":strStartMTime,
                      "Endtimehour":strEndLTime,
                      "EndtimeMin":strEndMTime]
        
        print(params)
        
        Functions.callApi(vc: self, api: API.insertTimetableApi, params: params) { (json,error) in
            
            if(json != nil){
                
                self.delegate.callTimeTableApi()
                self.btnClose()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callAddLectureApi()
                })
            }
        }
    }
    
    // MARK: - Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews[0].subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    strStd = arrStandards[0]
                    self.addStandardDropDown()
                    
                case 3:
                    let lblDayName:UILabel = view as! UILabel
                    lblDayName.text = strDayName
                    
                case 4:
                    let lblLectureName:UILabel = view as! UILabel
                    lblLectureName.text = strLectureName
                    
                default:
                    //self.addMinutesHoursDropDown(i)
                    break
                }
                i += 1
                
            }else if(view.isKind(of: UICollectionView.classForCoder())){
                self.addSectionsDropDown()
                i += 1
            }
        }
    }
    
    func addStandardDropDown()
    {
        for dd in (self.view.subviews[0].subviews[0].subviews.flatMap{$0 as? UIDropDown}) {
            if(dd.table != nil){
                dd.hideTable()
            }
            dd.removeFromSuperview()
        }
        
        let dropDown:UIDropDown = UIDropDown(frame: self.view.viewWithTag(1)!.frame)
        dropDown.tag = 10
        dropDown.placeholder = "-Select-"
        dropDown.options = arrStandards
        dropDown.tableHeight = arrStandards.count > 5 ? CGFloat(5 * 35) : CGFloat(arrStandards.count * 35)
        dropDown.title.text = strStd
        dropDown.selectedIndex = arrStandards.index(of: strStd)
        strStdID = dicStandards[strStd] as! String
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strStdID = self.dicStandards[option] as! String
            self.strStd = option
            self.arrSectionIds = []
            
            self.addSectionsDropDown()
            //for j in 5...8 {
                //self.addMinutesHoursDropDown(j)
                self.callGetLectureTimingApi()
            //}
        }
        self.view.subviews[0].subviews[0].addSubview(dropDown)
    }
    
    func addSectionsDropDown()
    {
        let dicData = dicStdSections.keyedOrValueExist(key: strStd) as! NSMutableDictionary
        arrSections = dicData.sortedDictionary(dicData).0
        let height:CGFloat = CGFloat((arrSections.count/2) + (arrSections.count%2 != 0 ? 1 : 0)) * (arrSections.count < 4 ? 35 : 30)
        
        popUpHeight.constant = 415 + height
        collectionHeight.constant = height
        self.view.subviews[0].subviews[0].layoutIfNeeded()
        
        self.collectionSection.reloadData()
        self.addSubjectsDropDown()
    }
    
    func addSubjectsDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(2)?.frame)!)
        dropDown.placeholder = "-Select-"
        dropDown.tag = 20
        
        dropDown.options = arrSubjects
        dropDown.tableHeight = arrSubjects.count > 5 ? CGFloat(5 * 35) : CGFloat(arrSubjects.count * 35)
        
        if self.strSubID != "" {
            dropDown.title.text = self.dicSubjects.allKeys(for: self.strSubID).first as? String
            dropDown.selectedIndex = arrSubjects.index(of: dropDown.title.text!)
        }
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strSubID = self.dicSubjects[option] as! String
        }
        
        if self.view.subviews[0].subviews[0].viewWithTag(20) != nil {
            self.view.subviews[0].subviews[0].viewWithTag(20)?.removeFromSuperview()
        }
        self.view.subviews[0].subviews[0].addSubview(dropDown)
    }
    
    func addMinutesHoursDropDown(_ cnt:Int)
    {
        var arrMinuteHours:[String] = []
        for i in 0..<((cnt == 5 || cnt == 7) ? 24 : 60){
            arrMinuteHours.append("\(i < 10 ? "0" : "")\(i)")
        }
        
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(cnt)?.frame)!)
        dropDown.placeholder = "-Select-"
        dropDown.tag = cnt*10
        
        dropDown.options = arrMinuteHours
        dropDown.tableHeight = 130
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            switch(dropDown.tag)
            {
            case 50:
                self.strStartLTime = option
                
            case 60:
                self.strStartMTime = option
                
            case 70:
                self.strEndLTime = option
                
            case 80:
                self.strEndMTime = option
                
            default:
                break
            }
        }
        if self.view.subviews[0].subviews[0].viewWithTag(cnt*10) != nil {
            self.view.subviews[0].subviews[0].viewWithTag(cnt*10)?.removeFromSuperview()
            switch(cnt)
            {
            case 5:
                dropDown.title.text = self.strStartLTime.isEmpty ? "-Select-" : self.strStartLTime
            case 6:
                dropDown.title.text = self.strStartMTime.isEmpty ? "-Select-" : self.strStartMTime
            case 7:
                dropDown.title.text = self.strEndLTime.isEmpty ? "-Select-" : self.strEndLTime
            case 8:
                dropDown.title.text = self.strEndMTime.isEmpty ? "-Select-" : self.strEndMTime
                
            default:
                break
            }
        }
        self.view.subviews[0].subviews[0].addSubview(dropDown)
    }
    
    func resetData()
    {
        strStd = ""
        strStdID = ""
        strSubID = ""
        strStartLTime = ""
        strStartMTime = ""
        strEndLTime = ""
        strEndMTime = ""
        
        dicStdSections = [:]
        dicStandards = [:]
        dicSubjects = [:]
        
        arrSectionIds = []
    }
    
    
    // MARK: - Button Click Action
    
    @IBAction func btnAddLectureAction(_ sender:UIButton)
    {
        let values:AddTimeTableData = AddTimeTableData.init(stdId: strStd, clsId: (self.arrSectionIds.map{String(describing: $0)}).joined(separator: ","), subId: strSubID, strL: strStartLTime, strM: strStartMTime, endM: strEndLTime, endL: strEndMTime)
        if(ValidationFunctions.timeTableAddValidation(tblData: values)){
            self.callAddLectureApi()
        }
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension TimeTablePopupVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let item:CGFloat = (bundleName.contains("Shilaj") ? 3 : 2)
        return CGSize(width: collectionView.frame.size.width/item, height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrSections.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:StudentAssignedSubjectCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StudentAssignedSubjectCell", for: indexPath) as! StudentAssignedSubjectCell
        
        cell.lblSection.text = arrSections[indexPath.row]
        cell.checkBox.setOn(false, animated: false)
        return cell
    }
    
    // MARK: - - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let cell:StudentAssignedSubjectCell = collectionView.cellForItem(at: indexPath) as! StudentAssignedSubjectCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        let dicData = dicStdSections.keyedOrValueExist(key: strStd) as! NSMutableDictionary
        let strValue = dicData.value(forKey: arrSections[indexPath.row])
        
        if(cell.checkBox.isOn()){
            self.arrSectionIds.append(strValue as! String)
        }else{
            let idx:NSInteger = self.arrSectionIds.index(of: strValue as! String)!
            self.arrSectionIds.remove(at: idx)
        }
    }
}
