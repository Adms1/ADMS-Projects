//
//  RequestVC.swift
//  Skool360Teacher
//
//  Created by ADMS on 29/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

var arrStudentIDS:[NSNumber] = []

class RequestVC: UIViewController {
    
    @IBOutlet var tblRequest:UITableView!
    var dropDown: UIDropDown!
    var dicStudentData:NSMutableDictionary = [:]
    var arrStudentData = [StudentModel]()
    var arrStdSub:[String] = []
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblRequest.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        arrStudentIDS = []
        self.view.subviews[2].isHidden = true
        
        self.callGetStudentApi()
    }
    
    
    // MARK: - API Calling
    
    func callGetStudentApi()
    {
        let params = ["StaffID":staffID!]
        
        Functions.callApi(api: teacherGetClassSubjectWiseStudentApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for values in arrData! {
                    
                    let arrStuData:[JSON] = values["StudentData"].array!
                    self.dicStudentData.setValue(arrStuData, forKey: "\(values["Standard"])-\(values["classname"]) → \(values["Subject"])")
                }
                self.arrStdSub = self.dicStudentData.sortedDictionary(self.dicStudentData).0
                
                self.addDropDown()
                self.getStudentData(self.arrStdSub[0])
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetStudentApi()
                })
            }
        }
    }
    
    // MARK: - Function for Choose Class
    
    func addDropDown()
    {
        dropDown = UIDropDown(frame: CGRect(x:15, y:15, width:isIpad ? 250 : 200, height:isIpad ? 40 : 35))
        dropDown.placeholder = "-Please Select-"
        dropDown.options = self.arrStdSub
        dropDown.tableHeight = self.arrStdSub.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrStdSub.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = self.arrStdSub[0]
        dropDown.didSelect { (option, index) in
            self.dropDown.hideTable()
            self.getStudentData(option)
        }
        
        for _ in (self.view.subviews.flatMap{$0 as? UIDropDown}) {
            return
        }
        self.view.addSubview(dropDown)
    }
    
    func getStudentData(_ key:String)
    {
        arrStudentData = []
        
        let array:[JSON] = self.dicStudentData[key] as! [JSON]
        if(array.count > 0) {
            
            self.view.subviews[1].isHidden = true
            for values in array {
                
                let studentModel = StudentModel.init(stuID: values["StudentID"].numberValue, stuName: values["StudentName"].stringValue, grno: values["GRNO"].stringValue, status:false)
                
                arrStudentData.append(studentModel)
            }
        }else{
            self.view.subviews[1].isHidden = false
        }
        self.tblRequest.reloadData()
    }
    
    
    // MARK: - Button Click Action
    
    @IBAction func btnDone()
    {
        add(asChildViewController: requestPopupVC, self)
    }
    
    private lazy var requestPopupVC: RequestPopupVC = {
        
        var viewController:RequestPopupVC = storyBoard.instantiateViewController(withIdentifier: "RequestPopupVC") as! RequestPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension RequestVC:UITableViewDataSource,UITableViewDelegate,RequestCellDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrStudentData.count > 0 ? arrStudentData.count + 1 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if(indexPath.row == 0) {
            strIdentifier = "RequestHeaderCell"
        }
        else {
            strIdentifier = "RequestCell"
        }
        
        let cell:RequestCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! RequestCell
        
        if(indexPath.row > 0){
            cell.delegate = self
            cell.checkBox.tag = indexPath.row - 1
            cell.displayData(stuData: arrStudentData[indexPath.row - 1])
        }
        return cell
    }
    
    // MARK: - TableCell Delegate
    
    func addStudentIds(_ modal:StudentModel, _ sender:VKCheckbox, _ previousID:NSNumber)
    {
        arrStudentData.remove(at: sender.tag)
        arrStudentData.insert(modal, at: sender.tag)
        
        if(sender.isOn()){
            arrStudentIDS.append(modal.StudentID!)
        }else{
            let idx:NSInteger = arrStudentIDS.index(of: previousID)!
            arrStudentIDS.remove(at: idx)
        }
        self.view.subviews[2].isHidden = arrStudentIDS.count > 0 ? false : true
    }
}
