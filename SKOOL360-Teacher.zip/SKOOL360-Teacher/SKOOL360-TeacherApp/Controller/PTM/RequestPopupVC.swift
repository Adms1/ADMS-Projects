//
//  RequestPopupVC.swift
//  Skool360Teacher
//
//  Created by Sweta on 29/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class RequestPopupVC: UIViewController {
    
    @IBOutlet var btnClose:UIButton!
    @IBOutlet var btnDate:UIButton!
    @IBOutlet var txtSubject:UITextField!
    @IBOutlet var txtMsg:UITextView!
    @IBOutlet var popupView:UIView!
    
    var popupY:CGFloat = 0
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnDate.titleLabel?.font = FontType.regularFont
        btnDate.setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        txtSubject.text  = nil
        txtMsg.text      = "Message"
        txtMsg.textColor = UIColor.gray.withAlphaComponent(0.5)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        popupY = popupView.frame.origin.y
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        popupView.frame.origin.y = popupY
        btnClose.frame.origin.y  = popupY - 20
        self.btnCloseClicked()
    }
    
    
    // MARK: - API Calling
    
    func callRequestSendApi(_ requestData:RequestData)
    {
        let params = ["MessageID":"0",
                      "Flag":"Staff",
                      "FromID":"0",
                      "ToID":(arrStudentIDS.map{String(describing: $0)}).joined(separator: ","),
                      "MeetingDate":(btnDate.titleLabel?.text)!,
                      "SubjectLine":requestData.txtSubject!,
                      "Description":requestData.txtDescription!
        ]
        
        print(params)
        
        Functions.callApi(vc: self, api: API.ptmTeacherStudentInsertDetailApi, params: params) { (json, error) in
            
            if(json != nil) {
                
                Functions.showAlert(false, Message.requestSentSuccess)
                self.btnCloseClicked()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callRequestSendApi(requestData)
                })
            }
        }
    }
    
    // MARK: - Button Click Action
    
    @IBAction func btnSendClicked()
    {
        let requestValues = RequestData.init(txtSub: txtSubject.text!, txtDes: txtMsg.text)
        
        if(ValidationFunctions.requestValidation(requestData: requestValues).0)
        {
            self.callRequestSendApi(requestValues)
        }
    }
    
    @IBAction func btnCloseClicked()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    @IBAction func chooseDate(_ sender:UIButton)
    {
        self.view.endEditing(true)
        //isFromPTM = true
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        let currentDate:Date = (sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDate = currentDate
        selector.optionCurrentDateRange.setStartDate(currentDate)
        selector.optionCurrentDateRange.setEndDate(currentDate)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    func dynamicPopupSize(cnt:CGFloat) {
        UIView.animate(withDuration: 0.5) {
            self.popupView.frame = self.popupView.frame.offsetBy(dx: 0, dy: cnt)
            self.btnClose.frame = self.btnClose.frame.offsetBy(dx: 0, dy: cnt)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension RequestPopupVC:UITextFieldDelegate
{
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.dynamicPopupSize(cnt: popupView.frame.origin.y < popupY ? 0 : -50)
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtSubject.resignFirstResponder()
        self.dynamicPopupSize(cnt: 50)
        return true
    }
}

extension RequestPopupVC:UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        if(textView.text == "Message"){
            textView.text = nil
            textView.textColor = .black
        }
        
        self.dynamicPopupSize(cnt: popupView.frame.origin.y < popupY ? 0 : -50)
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(text == "\n") {
            if(textView.text.characters.count == 0){
                textView.text = "Message"
                textView.textColor = UIColor.gray.withAlphaComponent(0.5)
            }
            textView.resignFirstResponder()
            self.dynamicPopupSize(cnt: 50)
            return false
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text.count == 0){
            textView.text = "Message"
            textView.textColor = UIColor.gray.withAlphaComponent(0.3)
        }
    }
}

extension RequestPopupVC:WWCalendarTimeSelectorProtocol
{
    // MARK: - Calender Delegate
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}
