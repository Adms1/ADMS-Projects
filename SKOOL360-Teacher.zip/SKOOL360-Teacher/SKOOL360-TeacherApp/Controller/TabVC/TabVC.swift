//
//  TabVC.swift
//  Skool360Teacher
//
//  Created by ADMS on 12/10/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var tabBarTitle = [""]
var classes = [ClassModel]()

class TabVC: CustomViewController, UIScrollViewDelegate {
    
    @IBOutlet var tabCollection: UICollectionView!
    @IBOutlet var constantViewWidth: NSLayoutConstraint!
    @IBOutlet var constantViewLeft: NSLayoutConstraint!
    
    var pageController: UIPageViewController!
    var arrVC:[UIViewController] = []
    var currentPage: Int = 0
    var tab_collectionView: UICollectionView!
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = self.navigationController?.title
        
        switch (self.title)! {
        case "Today Schedule":
            tabBarTitle = ["Today Schedule", "Lesson Plan Schedule"]
            arrVC = self.scheduleViewControllers()
            
        case "Subjects":
            tabBarTitle = ["My Subject", "Student Subject"]
            arrVC = self.subjectsViewControllers()
            
        case "Attendance":
            tabBarTitle = []
            for data in classes {
                let classModal = data
                tabBarTitle.append("\(classModal.Standard!)-\(classModal.Class!)")
            }
            arrVC = self.attendenceViewControllers()
            
        case "Test/Syllabus":
            tabBarTitle = ["Edit Test", "Add Test"]
            arrVC = self.syllabusViewControllers()
           
        case "Marks":
            tabBarTitle = ["Add Marks", "View Marks"]
            arrVC = self.marksViewControllers()
            
        case "PTM":
            tabBarTitle = ["Inbox", "Sent", "Create"]
            arrVC = self.ptmViewControllers()
            
        default:
            tabBarTitle = DateFormatter().weekdaySymbols
            arrVC = self.timeTableViewControllers()
        }
        
        constantViewWidth.constant = self.view.bounds.size.width/CGFloat(tabBarTitle.count)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        let pointY:CGFloat = self.view.subviews[1].frame.size.height + self.view.subviews[1].frame.origin.y + 5.0
        self.view.subviews[1].addShadowWithRadius(2, 0)
        
        createPageViewController(pointY)
    }
    
    
    // MARK: - ViewController Actions
    
    func scheduleViewControllers()->[UIViewController]
    {
        let TodayScheduleVC = self.storyboard?.instantiateViewController(withIdentifier: "TodayScheduleVC")
        TodayScheduleVC?.title = tabBarTitle[0]
        
        let LessonPlanScheduleVC = self.storyboard?.instantiateViewController(withIdentifier: "LessonPlanScheduleVC")
        LessonPlanScheduleVC?.title = tabBarTitle[1]
        
        return [TodayScheduleVC!,LessonPlanScheduleVC!]
    }
    
    func subjectsViewControllers()->[UIViewController]
    {
        let TodaySubjectVC = self.storyboard?.instantiateViewController(withIdentifier: "TodayScheduleVC")
        TodaySubjectVC?.title = tabBarTitle[0]
        
        let StudentAssignedSubjectVC = self.storyboard?.instantiateViewController(withIdentifier: "StudentAssignedSubjectVC")
        arrClassDetails = classes
        return [TodaySubjectVC!,StudentAssignedSubjectVC!]
    }
    
    func timeTableViewControllers()->[UIViewController]
    {
        var viewControllers:[UIViewController] = []
        for _ in 0..<tabBarTitle.count {
            //let TVC:TimeTableVC1 = self.storyBoard?.instantiateViewController(withIdentifier: "TimeTableVC1") as! TimeTableVC1
            //viewControllers.append(TVC)
        }
        return viewControllers
    }
    
    func attendenceViewControllers()->[UIViewController]
    {
        var viewControllers:[UIViewController] = []
        for i in 0..<tabBarTitle.count {
            let AVC:AttendenceVC = self.storyboard?.instantiateViewController(withIdentifier: "AttendenceVC") as! AttendenceVC
            AVC.strID = "\(classes[i].StandardID!)-\(classes[i].ClassID!)"
            viewControllers.append(AVC)
        }
        return viewControllers
    }
    
    func syllabusViewControllers()->[UIViewController]
    {
        let EditVC = self.storyboard?.instantiateViewController(withIdentifier: "EditSyllabusVC")
        
        let AddVC = self.storyboard?.instantiateViewController(withIdentifier: "AddTestVC")
        
        return [EditVC!,AddVC!]
    }
    
    func marksViewControllers()->[UIViewController]
    {
        let AddMarksVC = self.storyboard?.instantiateViewController(withIdentifier: "AddMarksVC")
        
        let ViewMarksVC = self.storyboard?.instantiateViewController(withIdentifier: "MarksVC")
        
        return [AddMarksVC!,ViewMarksVC!]
    }
    
    func ptmViewControllers()->[UIViewController]
    {
        let RequestVC = self.storyboard?.instantiateViewController(withIdentifier: "RequestVC")
        
        var viewControllers:[UIViewController] = []
        for i in 0..<tabBarTitle.count-1 {
            let sentInboxVC:SentInboxVC = self.storyboard?.instantiateViewController(withIdentifier: "SentInboxVC") as! SentInboxVC
            sentInboxVC.title = tabBarTitle[i]
            viewControllers.append(sentInboxVC)
        }
        viewControllers.append(RequestVC!)
        return viewControllers
    }
    
    
    // MARK: - CreatePagination
    
    func createPageViewController(_ pointY:CGFloat) {
        
        pageController = UIPageViewController.init(transitionStyle: UIPageViewControllerTransitionStyle.scroll, navigationOrientation: UIPageViewControllerNavigationOrientation.horizontal, options: nil)
        
        pageController.view.backgroundColor = UIColor.clear
        pageController.delegate = self
        pageController.dataSource = self
        
        for svScroll in pageController.view.subviews as! [UIScrollView] {
            svScroll.delegate = self
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.pageController.view.frame = CGRect(x: 0, y: pointY, width: self.view.frame.size.width, height: self.view.frame.size.height-pointY)
        }
        
        pageController.setViewControllers([arrVC[0]], direction: UIPageViewControllerNavigationDirection.forward, animated: false, completion: nil)
        
        self.addChildViewController(pageController)
        self.view.addSubview(pageController.view)
        pageController.didMove(toParentViewController: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension TabVC:UIPageViewControllerDataSource, UIPageViewControllerDelegate
{
    func indexofviewController(viewController: UIViewController) -> Int {
        if(arrVC.contains(viewController)) {
            return arrVC.index(of: viewController)!
        }
        return -1
    }
    
    //MARK: - Pagination Delegate Methods
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        var index = indexofviewController(viewController: viewController)
        
        if(index != -1) {
            index = index - 1
        }
        
        if(index < 0) {
            return nil
        }
        else {
            return arrVC[index]
        }
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        var index = indexofviewController(viewController: viewController)
        
        if(index != -1) {
            index = index + 1
        }
        
        if(index >= arrVC.count) {
            return nil
        }
        else {
            return arrVC[index]
        }
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        
        if(completed) {
            currentPage = arrVC.index(of: (pageViewController.viewControllers?.last)!)!
        }
    }
}

extension TabVC:UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width:constantViewWidth.constant , height:collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tabBarTitle.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TabCell", for: indexPath) as! TabCell
        cell.lblTitle.text = tabBarTitle[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        var direction = UIPageViewControllerNavigationDirection(rawValue: 0)
        if(self.currentPage > indexPath.row){
            direction = UIPageViewControllerNavigationDirection.reverse
        }
        pageController.setViewControllers([arrVC[indexPath.row]], direction: direction!, animated: true, completion: {(Bool) -> Void in
            self.currentPage = indexPath.row
        })
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let xFromCenter: CGFloat = self.view.frame.size.width-scrollView.contentOffset.x
        let xCoor: CGFloat = CGFloat(self.view.bounds.size.width/CGFloat(tabBarTitle.count)) * CGFloat(currentPage)
        let xPosition: CGFloat = xCoor - xFromCenter/CGFloat(arrVC.count)
        constantViewLeft.constant = xPosition
    }
}

//TabBarCell Class
class TabCell: UICollectionViewCell {
    @IBOutlet weak var lblTitle: UILabel!
}

