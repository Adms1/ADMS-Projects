//
//  MarksVC.swift
//  Skool360Teacher
//
//  Created by ADMS on 21/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class MarksVC: CustomViewController {
    
    @IBOutlet var tblMarks:UITableView!
    @IBOutlet var tblTopConstant:NSLayoutConstraint!
    
    var dropDown: UIDropDown!
    var searchBar:INSSearchBar!
    
    var flags:[Bool] = []
    var dicStudentData:NSMutableDictionary = [:]
    var arrStudentData:[String] = []
    var arrStudentSubjectMarksData = [MarksModel]()
    var arrStudentSubjectMarksDataSearch = [MarksModel]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblMarks.tableFooterView = UIView()
        self.callStudentMarksApi()
    }
    
    
    // MARK: - API Calling
    
    func callStudentMarksApi()
    {
        let params = ["StaffID":staffID!]
        
        Functions.callApi(vc: self, api: API.teacherGetTestMarksApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for values in arrData! {
                    
                    let arrStuData:[JSON] = values["StudentData"].array!
                    self.dicStudentData.setValue(arrStuData, forKey: "\(values["StandardClass"]) → \(values["TestName"])")
                }
                self.arrStudentData = self.dicStudentData.sortedDictionary(self.dicStudentData).0
                self.addDropDown()
                self.getMarksData(self.arrStudentData[0])
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callStudentMarksApi()
                })
            }
        }
    }
    
    func getMarksData(_ key:String)
    {
        selectedIndex = -1
        arrStudentSubjectMarksData = []
        arrStudentSubjectMarksDataSearch = []
        
        let array:[JSON] = self.dicStudentData[key] as! [JSON]
        if(array.count > 0) {
            
            if self.searchBar == nil {
                self.addSearchBar()
            }
            
            for values in array {
                
                let arrSubjectMarks:[JSON] = values["SubjectMarks"].array!
                
                var arrModalData = [MarksModel]()
                
                if(arrSubjectMarks.count > 0) {
                    for values in arrSubjectMarks {
                        
                        let subMarksModel = MarksModel.init(marks: values["Marks"].stringValue, subject: values["Subject"].stringValue)
                        
                        arrModalData.append(subMarksModel)
                    }
                }
                
                let StudentModel = MarksModel.init(stuID: values["StudentID"].numberValue, stuName: values["StudentName"].stringValue, grno: values["GRNO"].stringValue, per: values["Percentage"].stringValue, outOff: values["TotalGainedMarks"].numberValue, total: values["TotalMarks"].numberValue,subjectData:arrModalData)
                
                arrStudentSubjectMarksData.append(StudentModel)
                arrStudentSubjectMarksDataSearch.append(StudentModel)
            }
        }else{
            if searchBar != nil {
                searchBar.removeFromSuperview()
                searchBar = nil
            }
        }
        self.tblMarks.reloadData()
    }
    
    
    // MARK: - Function for Choose Class
    
    func addDropDown()
    {
        dropDown = UIDropDown(frame: CGRect(x:15, y:DeviceType.isIpad ? 150 : view.subviews[0].frame.size.height + 20, width:DeviceType.isIpad ? 270 : 220, height:DeviceType.isIpad ? 40 : 35))
        dropDown.placeholder = "-Please Select-"
        dropDown.options = self.arrStudentData
        dropDown.tableHeight = self.arrStudentData.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrStudentData.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = self.arrStudentData[0]
        dropDown.didSelect { (option, index) in
            self.dropDown.hideTable()
            self.getMarksData(option)
        }
        self.view.addSubview(dropDown)
    }
    
    func addSearchBar()
    {
        searchBar = INSSearchBar.init(frame: CGRect(x:UIScreen.main.bounds.width - 60, y:DeviceType.isIpad ? 150 : view.subviews[0].frame.size.height + 20, width:44, height:DeviceType.isIpad ? 39 : 34))
        searchBar.delegate = self
        self.view.addSubview(searchBar)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MarksVC:INSSearchBarDelegate
{
    // MARK: - SearchBar Delegate
    
    func originalFrame(for searchBar: INSSearchBar!) {
        tblTopConstant.constant = DeviceType.isIpad ? 70 : 60
        UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
        }
    }
    
    func destinationFrame(for searchBar: INSSearchBar!) -> CGRect {
        tblTopConstant.constant = 105
        UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
        }
        return CGRect(x:20, y:DeviceType.isIpad ? 200 : view.subviews[0].frame.size.height + 70, width:self.view.frame.size.width - 40, height:DeviceType.isIpad ? 39 : 34)
    }
    
    func searchBarTextDidChange(_ searchBar: INSSearchBar!) {
        let filtered = arrStudentSubjectMarksDataSearch.filter { $0.StudentName?.range(of: searchBar.searchField.text!, options: .caseInsensitive) != nil }
        arrStudentSubjectMarksData = searchBar.searchField.text == "" ? arrStudentSubjectMarksDataSearch : filtered
        tblMarks.reloadData()
    }
    
    func searchBarDidTapReturn(_ searchBar: INSSearchBar!) {
        searchBar.searchField.resignFirstResponder()
    }
}

extension MarksVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:MarksCell = tableView.dequeueReusableCell(withIdentifier: "MarksHeaderCell") as! MarksCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0)
        
        var attributedString:NSMutableAttributedString! = NSMutableAttributedString()
        let str:String = headerView.lblView.text!
        var attributes = [NSAttributedStringKey : Any]()
        
        if(section == selectedIndex) {
            attributes = [NSAttributedStringKey(rawValue: NSAttributedStringKey.foregroundColor.rawValue): GetColor.green,NSAttributedStringKey.underlineStyle:NSUnderlineStyle.styleSingle.rawValue,NSAttributedStringKey.font:FontHelper.medium(size: DeviceType.isIpad ? 16 : 13)]
        }else {
            attributes = [NSAttributedStringKey(rawValue: NSAttributedStringKey.foregroundColor.rawValue): GetColor.red,NSAttributedStringKey.underlineStyle:NSUnderlineStyle.styleSingle.rawValue,NSAttributedStringKey.font:FontHelper.medium(size: DeviceType.isIpad ? 16 : 13)]
        }
        
        attributedString = NSMutableAttributedString(string: str, attributes: attributes)
        headerView.lblView.attributedText = attributedString
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblView.tag = section
        headerView.lblView.addGestureRecognizer(tapGesture)
        
        headerView.displayStudentData(arrStudentSubjectMarksData[section])
        return arrStudentSubjectMarksData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50))
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrStudentSubjectMarksData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return DeviceType.isIpad ? 50 : 40
        }
        return 0
        //return flags[indexPath.section] == true ? (indexPath.row == arrStudentSubjectMarksData[indexPath.section].SubjectData.count ? 50 : 40) : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblMarks.rowHeight == 0 ? 0 : arrStudentSubjectMarksData[section].SubjectData.count + 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MarksCell = tableView.dequeueReusableCell(withIdentifier: "MarksCell", for: indexPath) as! MarksCell
        cell.contentView.subviews[0].layer.borderColor = UIColor.lightGray.withAlphaComponent(0.5).cgColor
        cell.contentView.subviews[0].layer.borderWidth = 0.3
        
        for view in cell.contentView.subviews[0].subviews{
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                
                if(indexPath.row == 0) {
                    lbl.textColor = GetColor.orange
                    lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 17 : 14)
                    
                    cell.lblSubjectName.text = "Subject"
                    cell.lblMarks.text = "Marks"
                    
                    cell.contentView.subviews[0].backgroundColor = UIColor.white
                    
                }
                else if(indexPath.row > 0 && indexPath.row < tblMarks.numberOfRows(inSection: indexPath.section) - 1){
                    lbl.textColor = .black
                    lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 17 : 14)
                    
                    cell.displayData(arrStudentSubjectMarksData[indexPath.section].SubjectData[indexPath.row-1])
                    
                }else {
                    lbl.textColor = GetColor.green
                    lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 17 : 14)
                    
                    cell.lblSubjectName.text = "Total"
                    cell.displayTotal(arrStudentSubjectMarksData[indexPath.section])
                }
            }
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblMarks.reloadSections(IndexSet(integersIn: 0...arrStudentSubjectMarksData.count - 1) as IndexSet, with: .automatic)
        
        if(selectedIndex != -1){
            tblMarks.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: true)
        }
    }
}
