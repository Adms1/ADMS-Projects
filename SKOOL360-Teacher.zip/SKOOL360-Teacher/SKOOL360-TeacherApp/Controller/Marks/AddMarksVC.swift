//
//  AddMarksVC.swift
//  Bhadaj (Teacher)
//
//  Created by Sweta on 04/09/18.
//  Copyright © 2018 Sweta. All rights reserved.
//

import UIKit
import UIDropDown

class AddMarksVC: UIViewController {
    
    @IBOutlet var tblMarks:UITableView!
    @IBOutlet var btnAdd:UIButton!
    
    var dicTerms:[String:String] = [:]
    var dicStdSections:[String:String] = [:]
    var dicSubjects:[String:String] = [:]
    
    var arrStudentMarksData = [StudentModel]()
    var strTermID:String!
    var strClassID:String!
    var strSubjectID:String!
    var strTotalMarks:String!
    
    var i = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMarks.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi {
            self.callGetStdSectionApi {
                self.addDropDown()
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AddMarksVC
{
    func callGetTermApi(_ completion:@escaping () -> ())
    {
        dicTerms = [:]
        
        Functions.callApi(vc: self, api: API.getTermApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                self.strTermID = json!["TermID"].stringValue
                
                for values in arrData! {
                    self.dicTerms[values["Term"].stringValue] = values["TermId"].stringValue
                }
                completion()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetTermApi {
                        self.callGetStdSectionApi {
                            self.addDropDown()
                        }
                    }
                })
            }
        }
    }
    
    func callGetStdSectionApi(_ completion:@escaping () -> ())
    {
        dicStdSections = [:]
        
        let params = ["StaffID" : staffID!,
                      "TermID" : strTermID!]
        
        Functions.callApi(vc: self, api: API.getStandardSectionForMarksApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for values in arrData! {
                    self.dicStdSections[values["ClassName"].stringValue] = values["ClassID"].stringValue
                }
                completion()
                
            }else if(json == nil && error == nil) {
                completion()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetStdSectionApi {
                        self.addDropDown()
                    }
                })
            }
        }
    }
    
    func callGetSubjectForMarksApi(_ completion:@escaping () -> ())
    {
        dicSubjects = [:]
        
        let params = ["StaffID" : staffID!,
                      "TermID" : strTermID!,
                      "ClassID" : strClassID!]
        
        Functions.callApi(vc: self, api: API.getTestForMarksApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for values in arrData! {
                    self.dicSubjects[values["SubjectName"].stringValue] = values["SubjectID"].stringValue
                }
                completion()
                
            }else if(json == nil && error == nil) {
                completion()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetSubjectForMarksApi {
                        self.addDropDown()
                    }
                })
            }
        }
    }
    
    func callGetStudentMarksApi()
    {
        arrStudentMarksData = []
        
        let params = ["TermID" : strTermID!,
                      "ClassID" : strClassID!,
                      "SubjectID" : strSubjectID!]
        
        Functions.callApi(vc: self, api: API.getMarksApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                self.strTotalMarks = json!["TotalMarks"].stringValue
                
                for values in arrData! {
                    
                    let studentMarksModel:StudentModel = StudentModel(stuID: values["StudentID"].stringValue, stuName: values["StudentName"].stringValue, grno: values["GRNO"].stringValue, markId: values["MarkID"].stringValue, mark: values["Mark"].stringValue)
                    
                    self.arrStudentMarksData.append(studentMarksModel)
                }
                self.tblMarks.reloadData()
                self.i = 4
                self.addDropDown()
                self.btnAdd.isHidden = false
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetStudentMarksApi()
                })
            }
        }
    }
    
    func callInsertMarksApi(_ strDetailID:String)
    {
        let params = ["TermID" : strTermID!,
                      "ClassID" : strClassID!,
                      "SubjectID" : strSubjectID!,
                      "DetailID" : strDetailID,
                      "SubjectName" : (dicSubjects as NSDictionary).allKeys(for: strSubjectID).first as! String,
                      "TotalMarks" : strTotalMarks!]
        
        Functions.callApi(vc: self, api: API.insertMarksApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(true, (json!["FinalArray"].array?.first!["Message"].stringValue)!)
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callInsertMarksApi(strDetailID)
                })
            }
        }
    }
}

extension AddMarksVC
{
    // MARK: - Function for Marks
    
    func addDropDown()
    {
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.tag = i*10
                dropDown.placeholder = "-Please Select-"
                dropDown.tableHeight = 0.0
                
                if(i == 1)
                {
                    dropDown.options = dicTerms.keys.map{$0}.sorted(by: <)
                    dropDown.tableHeight = CGFloat(dicTerms.count * 35)
                    dropDown.title.text = ((dicTerms as NSDictionary).allKeys(for: strTermID).first as! String)
                    dropDown.selectedIndex = dropDown.options.index(of: dropDown.title.text!)
                }
                else if(i == 2)
                {
                    strClassID = nil
                    dropDown.options = dicStdSections.keys.map{$0}.sorted(by: <)
                    dropDown.tableHeight = dicStdSections.count < 5 ? CGFloat(dicStdSections.count * 35) : (35 * 5)
                }
                else if(i == 3)
                {
                    strSubjectID = nil
                    dropDown.options = dicSubjects.keys.map{$0}.sorted(by: <)
                    dropDown.tableHeight = dicSubjects.count < 5 ? CGFloat(dicSubjects.count * 35) : (35 * 5)
                }
                else
                {
                    let lblTotalMarks:UILabel = view as! UILabel
                    lblTotalMarks.text = strTotalMarks
                    return
                }
                
                dropDown.didSelect { (option, index) in
                    dropDown.hideTable()
                    
                    if(dropDown.tag == 10){
                        self.strTermID = self.dicTerms[option]
                        self.callGetStdSectionApi({
                            if let dropDown = self.view.viewWithTag(20) as? UIDropDown {
                                if dropDown.table != nil {
                                    dropDown.hideTable()
                                }
                                dropDown.removeFromSuperview()
                            }
                            if let dropDown = self.view.viewWithTag(30) as? UIDropDown {
                                if dropDown.table != nil {
                                    dropDown.hideTable()
                                }
                                dropDown.removeFromSuperview()
                            }
                            self.i = 2
                            self.addDropDown()
                        })
                    }else if(dropDown.tag == 20) {
                        self.strClassID = self.dicStdSections[option]
                        self.callGetSubjectForMarksApi({
                            if let dropDown = self.view.viewWithTag(30) as? UIDropDown {
                                if dropDown.table != nil {
                                    dropDown.hideTable()
                                }
                                dropDown.removeFromSuperview()
                            }
                            self.i = 3
                            self.addDropDown()
                        })
                    }else {
                        self.strSubjectID = self.dicSubjects[option]
                    }
                }
                self.view.addSubview(dropDown)
                i += 1
            }
        }
    }
}

extension AddMarksVC
{
    @IBAction func btnViewStudents(_ sender:UIButton)
    {
        guard strClassID != nil else {
            Functions.showAlert(false, Message.sectionError)
            return
        }
        
        guard strSubjectID != nil else {
            Functions.showAlert(false, Message.testError)
            return
        }
        
        self.callGetStudentMarksApi()
    }
    
    @IBAction func btnAddMarks(_ sender:UIButton)
    {
        var arrDetailIds:[String] = []
        for item in arrStudentMarksData {
            arrDetailIds.append("\(item.StudentID!),\(item.MarkID!),\(item.Mark!),\(item.GRNO!)")
        }
        self.callInsertMarksApi(arrDetailIds.joined(separator: "|"))
    }
}

// MARK: - Table view data source

extension AddMarksVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell:MarksCell = tableView.dequeueReusableCell(withIdentifier: "MarksHeaderCell") as! MarksCell
        cell.contentView.subviews.flatMap{$0 as? UILabel}.forEach{$0.font = FontHelper.medium(size: DeviceType.isIpad ? 16 : 13)}
        return arrStudentMarksData.count > 0 ? cell : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {  
        return arrStudentMarksData.count > 0 ? 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrStudentMarksData.count > 0 ? arrStudentMarksData.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MarksCell = tableView.dequeueReusableCell(withIdentifier: "MarksCell", for: indexPath) as! MarksCell
        cell.displayStudentMarksData(arrStudentMarksData[indexPath.row])
        
        cell.marksUpdateBlock = { txtfld in
            txtfld.text = txtfld.text?.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if((txtfld.text?.count)! > 0)
            {
                guard Double(txtfld.text!)! <= Double(self.strTotalMarks!)! else {
                    txtfld.text = nil
                    return
                }
            }
            self.arrStudentMarksData.filter{$0.StudentID == self.arrStudentMarksData[indexPath.row].StudentID}.first?.Mark = txtfld.text
        }
        
        cell.addMarksBlock = { (isOpen, txtfld) in
            self.tblMarks.frame.origin.y -= isOpen ? 50 : -50
            let offSetY:CGFloat = (txtfld.superview?.superview?.frame.origin.y)! - 45
            self.tblMarks.setContentOffset(CGPoint(x:0, y:isOpen ? offSetY : 0), animated: true)
        }
        return cell
    }
}
