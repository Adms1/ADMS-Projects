//
//  ForgotPasswordVC.swift
//  Search Classes
//
//  Created by Sweta on 12/04/18.
//  Copyright © 2018 Sweta. All rights reserved.
//

import UIKit

class ForgotPasswordVC: UIViewController {
    
    @IBOutlet var mainView:UIView!
    @IBOutlet var txtPhoneNo:UITextField!
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.reset
    }
    
    var reset:Void
    {
        for txtFld in (mainView.subviews.flatMap{$0 as? UITextField}){
            txtFld.text = nil
        }
    }
    
    func forgotPassword()
    {
        let forgotPasswordModel = ForgotPasswordModel.init(pno: txtPhoneNo.text!)
        
        if ForgotPasswordModel.forgotPasswordValidation(forgotPasswordModel.strPhoneNo!)
        {
            let params = ["MobileNo" : forgotPasswordModel.strPhoneNo!]
            
            Functions.callApi(vc: self, api: API.forgotPasswordApi, params: params, completionHandler: { (json, error) in
                if(json != nil) {
                    Functions.showAlert(true, (json!["Message"].stringValue))
                    self.view.removeFromSuperview()
                    self.removeFromParentViewController()
                }
            })
        }
        else {
            txtPhoneNo.shake()
        }
    }
    
    @IBAction func btnAction(_ sender:UIButton)
    {
        if sender.tag == 1 {
            self.forgotPassword()
        }else{
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
        }
    }
}

extension ForgotPasswordVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.resignFirstResponder()
        return true
    }
}
