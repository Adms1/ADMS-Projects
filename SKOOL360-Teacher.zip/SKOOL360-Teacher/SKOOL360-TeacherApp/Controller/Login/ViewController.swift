//
//  ViewController.swift
//  Skool360Teacher
//
//  Created by ADMS on 13/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import TransitionButton
import RaisePlaceholder

class ViewController: UIViewController {
    
    @IBOutlet var btnRememberMe:UIButton!
    @IBOutlet var loginUserNameField:RaisePlaceholder!
    @IBOutlet var loginPasswordField:RaisePlaceholder!
    
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(bundleName)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        let btn:AnimatedButton = AnimatedButton.init(frame: (loginUserNameField.superview?.subviews.last?.frame)!)
        btn.addTarget(self, action: #selector(login(_:)), for: .touchUpInside)
        loginUserNameField.superview?.addSubview(btn)
    }
    
    
    // MARK: - API Calling
    
    func loginTeacher(_ loginData:LoginData,sender:TransitionButton)
    {
        sender.startAnimation()
        
        let params = ["UserID":loginData.userName!,
                      "Password":loginData.password!]
        
        print(params)
        
        Functions.callApi(vc: self, api: API.loginApi, params: params) { (json,error) in
            if(json != nil){
                let dic = json!["FinalArray"].array?.first
                
                UserDefaults.standard.set(dic?["StaffID"].stringValue, forKey: "StaffID")
                
                if(self.btnRememberMe.isSelected){
                    UserDefaults.standard.set(self.btnRememberMe.isSelected, forKey: "RememberMe")
                }else {
                    UserDefaults.standard.removeObject(forKey: "RememberMe")
                }
                sender.stopAnimation(animationStyle: .expand, completion: {
                    Constants.appDelegate.rootViewController("DeshboardVC")
                })
                
            }else {
                sender.stopAnimation(animationStyle: .normal, completion: {
                    if(error != nil) {
                        Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                            self.loginTeacher(loginData, sender: sender)
                        })
                    }
                })
            }
        }
    }
    
    
    // MARK: - Button Click Actions
    
    @IBAction func login(_ sender: TransitionButton)
    {
        self.resignTextField()
        
        let loginValues = LoginData.init(userName: self.loginUserNameField.text!, password: self.loginPasswordField.text!)
        
        let result = ValidationFunctions.loginValidation(loginData: loginValues)
        
        if(result.0)
        {
            self.loginTeacher(loginValues, sender: sender)
        }
        else{
            switch result.1! {
            case .userName:
                loginUserNameField.shake()
            case .password:
                loginPasswordField.shake()
            default:
                break
            }
        }
    }
    
    @IBAction func rememberMe(_ sender: UIButton)
    {
        sender.isSelected = !sender.isSelected
    }
    
    func resignTextField()
    {
        for txtfld in (self.view.subviews.flatMap{$0 as? UITextField}) {
            txtfld.resignFirstResponder()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

