//
//  DeshboardVC.swift
//  Skool360staff
//
//  Created by Sweta on 13/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import SDWebImage

var staffData:LoginData!
class DeshboardVC: CustomViewController {
    
    @IBOutlet var collectionDeshboard:UICollectionView!
    @IBOutlet var tblBirthday:UITableView!
    @IBOutlet var superView:UIView!
    @IBOutlet var imgTeacher:UIImageView!
    @IBOutlet var btnMenu:UIButton!
    @IBOutlet var collectionHeightConstant:NSLayoutConstraint!
    @IBOutlet var heightConstant:NSLayoutConstraint!
    @IBOutlet var lblCount:UILabel!
    
    var headerTitle:String!
    let arrDeshboardData = Functions.getDeshBoardCategory()
    var arrBirthdayData = [BirthdayData]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getDynamicFont()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //heightConstant.constant = DeviceType.isIpad ? 210 : 0
        lblCount.layer.cornerRadius = 9
        lblCount.isHidden = true
        
        Functions.callApi(vc: self, api: API.mainUrl, params: [:]) { (json,error) in
            if(json != nil){
                UserDefaults.standard.set(json!["appsUrl"].stringValue, forKey: "HostUrl")
                self.callStaffProfileApi {
                    if isTerminate && isFromPush {
                        self.setNotificationViewController()
                    }
                }
            }
        }
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        self.view.subviews[3].viewWithTag(1)?.layer.cornerRadius  = (self.view.subviews[3].viewWithTag(1)?.frame.size.width)! / 2
        self.view.subviews[3].viewWithTag(1)?.layer.masksToBounds = true
        
        collectionHeightConstant.constant = collectionDeshboard.frame.size.width + (DeviceType.isIpad ? -45 : 30)
        
        imgTeacher.layer.cornerRadius = imgTeacher.frame.size.width/2
        imgTeacher.clipsToBounds      = true
        
        btnMenu.makeSemiCircle()
        superView.roundCorners([.topLeft, .topRight], radius: 10)
        
        for i in 1...3{
            self.view.subviews[i].addShadowWithRadius(3, 0)
        }
        
        //self.collectionDeshboard.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if(pushData.count > 0) {
            isFromPush = (pushData["category"] as! String).caseInsensitiveCompare("StaffLeave") == .orderedSame
            isTerminate = false
        }
    }
    
    // MARK: - API Calling
    
    func callStaffProfileApi(completion:@escaping() -> ())
    {
        let params = ["StaffID":staffID!]
        
        classes = []
        arrBirthdayData = []
        
        Functions.callApi(vc: self, api: API.staffProfileApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dic = json!["FinalArray"].array?.first
                
                staffData = LoginData.init(staffName: ("\((dic?["Emp_Name"].stringValue)!) (\((dic?["Emp_Code"].stringValue)!))"), staffDesignation: (dic?["Designation"].stringValue)!, staffProfile: (dic?["Image"].stringValue)!, staffEid:(dic?["EmailID"].stringValue)!, staffMobile:(dic?["Mobile"].stringValue)!, staffAddress:("\((dic?["Address"].stringValue)!), \((dic?["City"].stringValue)!)"), staffDob:(dic?["DOB"].stringValue)!, staffDepartment:(dic?["Depratment"].stringValue)!, userName:(dic?["UserName"].stringValue)!, password:(dic?["Password"].stringValue)!)
                
                UserDefaults.standard.setValue((dic?["DOB"].stringValue)!, forKey: "DOB")
                Constants.appDelegate.birthday()
                
                let arrClassDetails = json!["ClassDetail"].array
                for details in arrClassDetails! {
                    
                    let classDic = details
                    let classModal = ClassModel.init(standardID: classDic["StandardID"].stringValue, classID: classDic["ClassID"].stringValue, standard:classDic["Standard"].stringValue, cls: classDic["Class"].stringValue)
                    classes.append(classModal)
                }
                
                let arrBDetails = json!["BirthdayDetail"].array
                for details in arrBDetails! {
                    
                    let bDic = details
                    let birthdayModal = BirthdayData.init(Id: bDic["ID"].stringValue, name: bDic["Name"].stringValue, uType: bDic["Type"].stringValue, designation: bDic["Department"].stringValue, flag: bDic["Flag"].boolValue)
                    self.arrBirthdayData.append(birthdayModal)
                }
                
                self.lblCount.text = "\(self.arrBirthdayData.filter{$0.Flag == false}.count)"
                self.lblCount.isHidden = self.lblCount.text == "0"
                
                self.tblBirthday.reloadData()
                self.displayStaffData()
                completion()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callStaffProfileApi {}
                })
                completion()
            }
        }
    }
    
    func callBirthdayWishApi(_ idx:NSInteger)
    {
        let params = ["StaffID":staffID!,
                      "Type" : arrBirthdayData[idx].UserType!,
                      "ReceiverID" : arrBirthdayData[idx].ID!]
        
        Functions.callApi(vc: self, api: API.birthdayWishApi, params: params) { (json,error) in
            
            if(json != nil){
                let birthdayModel = self.arrBirthdayData[idx]
                birthdayModel.Flag = true
                self.arrBirthdayData.remove(at: idx)
                self.arrBirthdayData.insert(birthdayModel, at: idx)
                self.tblBirthday.reloadData()
                self.lblCount.text = "\(self.arrBirthdayData.filter{$0.Flag == false}.count)"
                self.lblCount.isHidden = self.lblCount.text == "0"
            }
        }
    }
    
    func displayStaffData()
    {
        let arrData = [staffData.staffProfile,staffData.staffName,staffData.staffDesignation]
        
        var i = 0
        for view in self.view.subviews[0].subviews {
            if view.isKind(of: UILabel.classForCoder()) {
                let lbl:UILabel = (view as! UILabel)
                lbl.text = arrData[i]
            }else {
                let img:UIImageView = (view as! UIImageView)
                if(arrData[i] != ""){
                    img.setImageWithFadeFromURL(url: URL.init(string: arrData[i]!.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!)!, placeholderImage: Constants.teacherPlaceholder, animationDuration: 0.5){ (finish) in}
                }else{
                    img.image = Constants.teacherPlaceholder
                }
            }
            i += 1
        }
        self.collectionDeshboard.reloadData()
    }
    
    func setNotificationViewController()
    {
        if((pushData["category"] as! String).caseInsensitiveCompare("StaffLeave") == .orderedSame){
            self.performSegue(withIdentifier: "Leave Details", sender: self)
        }else if((pushData["category"] as! String).caseInsensitiveCompare("Birthday") == .orderedSame){
            Constants.appDelegate.openWishView()
        }
    }
    
    // MARK: - Button Click Actions
    
    @IBAction func btnNotificationAction(_ sender:UIButton)
    {
        guard arrBirthdayData.count > 0 else {
            return
        }
        
        //heightConstant.constant = heightConstant.constant != -900 ? -900 : DeviceType.isIpad ? 210 : 0
        UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension DeshboardVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrBirthdayData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:BirthdayCell = tableView.dequeueReusableCell(withIdentifier: "BirthdayCell", for: indexPath) as! BirthdayCell
        
        cell.displayBirthdayData(arrBirthdayData[indexPath.row])
        cell.btnWishAction = { sender in
            self.callBirthdayWishApi(indexPath.row)
        }
        return cell
    }
}

extension DeshboardVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let itemSize:CGFloat = DeviceType.isIpad ? collectionView.frame.size.height/3 : collectionView.frame.size.width/3
        return CGSize(width: itemSize, height: itemSize);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrDeshboardData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:DeshBoardCell = collectionView.dequeueReusableCell(withReuseIdentifier: "DeshBoardCell", for: indexPath) as! DeshBoardCell
        cell.displayData(arrDeshboardData[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        cell.scaleWithBounceAnimation()
    }
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if indexPath.row == 3 && classes.count == 0 {
            Functions.showAlert(false, Message.noClassDetailFound)
            return
        }
        
        headerTitle = arrDeshboardData[indexPath.row]
        switch indexPath.row {
        case 0:
            if(bundleName.contains("Shilaj")){
                self.performSegue(withIdentifier: "NavigationVC", sender: self)
            }else {
                self.performSegue(withIdentifier: headerTitle, sender: self)
            }
        case 1,3,5,6:
            self.performSegue(withIdentifier: "NavigationVC", sender: self)
        default:
            self.performSegue(withIdentifier: headerTitle, sender: self)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "NavigationVC" || segue.identifier == "Marks"  || segue.identifier == "Time Table"  || segue.identifier == "Lesson Plan" || segue.identifier == "Home Work" || segue.identifier == "Work Plan" || segue.identifier == "Daily Work" || segue.identifier == "Schedule" || segue.identifier == "Leave Details" || segue.identifier == "Settings" {
            let vc = segue.destination
            vc.title = headerTitle == "Schedule" ? "Today Schedule" : headerTitle
            vc.customModalTransition = FashionTransition()
        }
    }
}
