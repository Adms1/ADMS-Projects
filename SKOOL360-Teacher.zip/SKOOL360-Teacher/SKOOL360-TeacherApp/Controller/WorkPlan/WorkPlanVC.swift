//
//  WorkPlanVC.swift
//  BhadajTeacher
//
//  Created by Sweta on 09/11/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON
import DialogBox

class WorkPlanVC: CustomViewController {
    
    @IBOutlet var tblWorkPlan:UITableView!
    
    var strFrom:String!
    var strTo:String!
    
    var arrWorkPlanAllData = [WorkPlanModel]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblWorkPlan.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        addDropDown()
        callWorkPlanApi(strFrom.components(separatedBy: " → "), strTo.components(separatedBy: " → "))
    }
    
    
    // MARK: - Add DropDown
    
    func addDropDown()
    {
        for view in (self.view.subviews.flatMap{$0 as? UILabel}) {
            
            let dropDown:UIDropDown = UIDropDown(frame: view.frame)
            dropDown.tag = view.tag * 10
            dropDown.placeholder = "-Select-"
            dropDown.tableHeight = 0.0
            
            let calendar = NSCalendar.init(calendarIdentifier: NSCalendar.Identifier.gregorian)
            
            //------Months-------
            let arrMonths:[String] = DateFormatter().shortMonthSymbols
            let currentMonthInt = (calendar?.component(NSCalendar.Unit.month, from: Date()))!
            
            //------Years-------
            let currentYearInt = (calendar?.component(NSCalendar.Unit.year, from: Date()))!
            let years:[Int] = [currentYearInt-1, currentYearInt, currentYearInt+1]
            let arrYears = years.map
            {
                String($0)
            }
            
            var arrMonthYear:[String] = []
            for year in arrYears {
                for month in arrMonths {
                    arrMonthYear.append("\(month) → \(year)")
                }
            }
            
            dropDown.options = arrMonthYear
            dropDown.tableHeight = CGFloat(8 * 35)
            
            let strValue = "\(arrMonths[currentMonthInt - 1]) → \(currentYearInt)"
            dropDown.selectedIndex = arrMonthYear.index(of: strValue)
            dropDown.title.text = strValue
            
            strFrom = strValue; strTo = strValue
            dropDown.didSelect { (option, index) in
                dropDown.hideTable()
                if(dropDown.tag == 10){
                    self.strFrom = option
                }else{
                    self.strTo = option
                }
            }
            self.view.addSubview(dropDown)
        }
    }
    
    
    // MARK: - API Calling
    
    func callWorkPlanApi(_ arrFrom:[String], _ arrTo:[String])
    {
        let params = ["StaffID":staffID!,
                      "fromMonth":arrFrom.first!,
                      "fromYear":arrFrom.last!,
                      "ToMonth":arrTo.first!,
                      "ToYear":arrTo.last!]
        
        print(params)
        
        arrWorkPlanAllData = []
        
        Functions.callApi(vc: self, api: API.teacherWorkPlanApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for values in arrData! {
                    
                    let arrWorkData:[JSON] = values["Data"].array!
                    
                    var arrWorkPlanData = [WorkPlanModel]()
                    for data in arrWorkData {
                        let workPlanDataModal:WorkPlanModel = WorkPlanModel.init(work: data["Work"].stringValue, fromDate: data["FromDate"].stringValue, toDate: data["ToDate"].stringValue, status: data["Status"].intValue, remarks:data["Remarks"].stringValue, workId:data["FK_WorkID"].stringValue, workPlanId:data["PK_TeacherworkID"].stringValue)
                        arrWorkPlanData.append(workPlanDataModal)
                    }
                    
                    let workPlanDataModal:WorkPlanModel = WorkPlanModel.init(std: values["Standard"].stringValue, clsName: values["Class"].stringValue, sub: values["Subject"].stringValue, month: values["Month"].stringValue, arrWorkPlan: arrWorkPlanData)
                    self.arrWorkPlanAllData.append(workPlanDataModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callWorkPlanApi(arrFrom, arrTo)
                })
            }
            self.tblWorkPlan.reloadData()
        }
    }
    
    func callWorkPlanCompletionApi(_ idx:NSInteger, _ superViewTag:NSInteger, _ subViewTag:NSInteger)
    {
        let wpModal:WorkPlanModel = self.arrWorkPlanAllData[superViewTag].ArrWorkPlan![subViewTag]
        wpModal.Status = idx
        
        let params = ["WorkID":wpModal.WorkID!,
                      "WorkPlanID":wpModal.WorkPlanID!,
                      "TeacherWork":wpModal.Work!,
                      "CompleteStatus":"\(wpModal.Status!)",
            "FromDate":wpModal.FromDate!,
            "ToDate":wpModal.ToDate!,
            "Remark":wpModal.Remarks!]
        
        print(params)
        
        Functions.callApi(vc: self, api: API.teacherUpdateWorkPlanCompletionApi, params: params) { (json,error) in
            
            if(json != nil){
                self.arrWorkPlanAllData[superViewTag].ArrWorkPlan?.remove(at: subViewTag)
                self.arrWorkPlanAllData[superViewTag].ArrWorkPlan?.insert(wpModal, at: subViewTag)
                
                self.tblWorkPlan.reloadRows(at: [IndexPath.init(row: subViewTag, section: superViewTag)], with: .automatic)
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callWorkPlanCompletionApi(idx, superViewTag, subViewTag)
                })
            }
        }
    }
    
    // MARK: - Button Click Action
    
    @IBAction func btnFilterAction(_ sender:UIButton)
    {
        self.callWorkPlanApi(self.strFrom.components(separatedBy: " → "), self.strTo.components(separatedBy: " → "))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension WorkPlanVC:UITableViewDelegate,UITableViewDataSource,WorkPlanCellDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:WorkPlanCell = tableView.dequeueReusableCell(withIdentifier: "WorkPlanHeaderCell") as! WorkPlanCell
        
        headerView.contentView.subviews[1].addShadowWithRadius(2, 0)
        
        if(section == selectedIndex) {
            headerView.lblView.textColor = GetColor.green
        }else {
            headerView.lblView.textColor = GetColor.red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblView.tag = section
        headerView.lblView.addGestureRecognizer(tapGesture)
        
        headerView.displayHeaderData(arrWorkPlanAllData[section])
        
        return arrWorkPlanAllData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50))
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrWorkPlanAllData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            tblWorkPlan.estimatedRowHeight = DeviceType.isIpad ? 60 : 50
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (arrWorkPlanAllData[section].ArrWorkPlan?.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:WorkPlanCell = tableView.dequeueReusableCell(withIdentifier: "WorkPlanCell", for: indexPath) as! WorkPlanCell
        
        cell.delegate = self
        cell.tag = indexPath.section
        cell.contentView.tag = indexPath.row
        cell.displayData(arrWorkPlanAllData[indexPath.section].ArrWorkPlan![indexPath.row])
        return cell
    }
    
    func workPlanStatusUpdate(_ idx: NSInteger, _ cell: WorkPlanCell)
    {
        Functions.showCustomAlert("Update", Message.statusUpdate) { (_) in
            self.callWorkPlanCompletionApi(idx, cell.tag, cell.contentView.tag)
        }
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblWorkPlan.reloadSections(IndexSet(integersIn: 0...arrWorkPlanAllData.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblWorkPlan.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}
