//
//  AttendenceVC.swift
//
//
//  Created by ADMS on 14/09/17.
//
//

import UIKit
import SwiftyJSON

class AttendenceVC: UIViewController {
    
    @IBOutlet var tblAttendence:UITableView!
    @IBOutlet var tblHeaderSView:UIView!
    @IBOutlet var tblHeaderBView:UIView!
    @IBOutlet var btnFooter:UIButton!
    
    var btnDate:UIButton!
    var previousScrollViewYOffset:CGFloat = CGFloat()
    var arrAttendenceData = [StudentAttendenceModel]()
    var dictData:[String:JSON] = [:]
    var dictSelectedData:NSMutableDictionary = [:]
    var todayDate: Date = Date()
    var status:Int = 0
    var strID:String!
    var tblHeaderView:UIView!
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblHeaderView = bundleName.contains("Bhadaj") ? tblHeaderBView : tblHeaderSView
        for view in tblHeaderView.subviews[0].subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag == 1){
                let btn = view as! UIButton
                btn.titleLabel!.font = FontHelper.medium(size: 13)
            }
        }
        
        btnDate = tblHeaderView.subviews[0].viewWithTag(100) as! UIButton
        btnDate.setTitle(todayDate.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.callAttendenceApi(selectedDate: (btnDate.titleLabel?.text)!)
    }
    
    
    // MARK: - API Calling
    
    func callAttendenceApi(selectedDate:String)
    {
        let params = ["StaffID":staffID!,
                      "AttDate":selectedDate,
                      "StdID":(strID.components(separatedBy: "-").first)!,
                      "ClsID":(strID.components(separatedBy: "-").last)!]
        
        print(params)
        
        self.arrAttendenceData = []
        self.dictSelectedData = [:]
        
        Functions.callApi(vc: self, api: API.attendenceApi, params: params) { (json,error) in
            if(json != nil){
                
                self.dictData = ((json!["FinalArray"].array?.first)?.dictionaryValue)!
                
                let finalResults = self.dictData["StudentDetail"]?.array
                
                var i = 0
                for values in finalResults! {
                    
                    let stuID = values["StudentID"].numberValue
                    let attID = values["AttendanceID"].numberValue
                    
                    let attendenceData = StudentAttendenceModel.init(attendenceStatus: values["AttendenceStatus"].stringValue, studentID: stuID, studentName: values["StudentName"].stringValue, attendenceID: attID, studentImage: values["StudentImage"].stringValue)
                    
                    self.status = Int(attendenceData.AttendenceStatus!)!
                    if(self.status == -2){
                        self.status = 1
                        self.dictSelectedData.setValue([stuID,attID,1], forKey: "\(i)")
                        self.status = -2
                    }
                    i += 1
                    self.arrAttendenceData.append(attendenceData)
                }
                
                let attendenceModal:ShilajStudentAttendenceModel = ShilajStudentAttendenceModel.init(Total: self.dictData["Total"]!.numberValue, TotalAbsent: self.dictData["TotalAbsent"]!.numberValue, TotalPresent: self.dictData["TotalPresent"]!.numberValue, TotalLeave: self.dictData["TotalLeave"]!.numberValue)
                
                if(bundleName.contains("Shilaj")){
                    self.displayStudentData(StudentAttendenceModel.init(ShilajModal: attendenceModal, TotalOnDuty: self.dictData["TotalOnDuty"]!.numberValue))
                }else {
                    self.displayStudentData(StudentAttendenceModel.init(ShilajModal: attendenceModal))
                }
                self.btnFooter.isHidden = false
                
            }else {
                self.btnFooter.isHidden = true
                
                if(error != nil){
                    Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                        self.callAttendenceApi(selectedDate: selectedDate)
                    })
                }
            }
            self.tblAttendence.reloadData()
        }
    }
    
    
    // MARK: - Display Function
    
    func displayStudentData(_ studentData:StudentAttendenceModel)
    {
        if(status == -2){
            btnFooter.loadIconsFromLocal("Submit")
        } else {
            btnFooter.loadIconsFromLocal("Update")
        }
        
        //let presentCount:NSNumber = ((status == -2) ? studentData.Total : studentData.TotalPresent)!
        let arrData = [studentData.ShilajModalValue?.Total,studentData.ShilajModalValue?.TotalPresent,studentData.ShilajModalValue?.TotalAbsent,studentData.ShilajModalValue?.TotalLeave,studentData.TotalOnDuty]
        let arrColor = [GetColor.blue,GetColor.green,GetColor.red,GetColor.orange,GetColor.yellow]
        
        var i = 1
        for view in tblHeaderView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i) {
                let lbl = view as! UILabel
                lbl.text = "\((lbl.text?.components(separatedBy: " : ").first)!) : \(arrData[i-1]!)"
                
                let attributedString = NSMutableAttributedString(
                    string: lbl.text!,
                    attributes: [:])
                
                let strSub:String = (lbl.text?.components(separatedBy: " : ").last)!
                
                attributedString.addAttribute(
                    NSAttributedStringKey.foregroundColor,
                    value: arrColor[i-1],
                    range: (lbl.text! as NSString).range(of: strSub))
                
                attributedString.addAttribute(
                    NSAttributedStringKey.font,
                    value: FontHelper.bold(size: 14),
                    range: (lbl.text! as NSString).range(of: strSub))
                
                lbl.attributedText = attributedString
                
                i += 1
            }
        }
    }
    
    
    // MARK: - Button Click Actions
    
    @IBAction func insertUpdateAttendence()
    {
        let attendenceData = StudentAttendenceModel.init(standardID: (dictData["StandardID"]?.numberValue)!, classID: (dictData["ClassID"]?.numberValue)!, Date: (btnDate.titleLabel?.text)!)
        
        if(self.dictSelectedData != nil)
        {
            let arrStudentIds:NSMutableArray = []
            let arrAttendenceIds:NSMutableArray = []
            let arrAttendenceStatus:NSMutableArray = []
            
            for values in dictSelectedData.allValues {
                
                let data:NSArray = values as! NSArray
                arrStudentIds.add(data[0])
                arrAttendenceIds.add(data[1])
                arrAttendenceStatus.add(data[2])
            }
            
            let params = ["StaffID":staffID!,
                          "CurrantDate":todayDate.toString(dateFormat: "dd/MM/yyyy"),
                          "StandardID":(attendenceData.StandardID?.stringValue)!,
                          "ClassID":(attendenceData.ClassID?.stringValue)!,
                          "Date":attendenceData.Date!,
                          "AttendanceID":arrAttendenceIds.componentsJoined(by: ","),
                          "StudentID":arrStudentIds.componentsJoined(by: ","),
                          "AttendacneStatus":arrAttendenceStatus.componentsJoined(by: ","),
                          "Comment":""]
            
            print(params)
            
            Functions.callApi(vc: self, api: API.attendenceInsertUpdateApi, params: params) { (json,error) in
                
                if(json != nil) {
                    
                    self.status = 0
                    
                    Functions.showAlert(true, self.status == -2 ? Message.attendenceAddSuccess : Message.attendenceUpdateSuccess)
                    
                    self.dictData = ((json!["FinalArray"].array?.first)?.dictionaryValue)!
                    
                    let attendenceModal:ShilajStudentAttendenceModel = ShilajStudentAttendenceModel.init(Total: self.dictData["Total"]!.numberValue, TotalAbsent: self.dictData["TotalAbsent"]!.numberValue, TotalPresent: self.dictData["TotalPresent"]!.numberValue, TotalLeave: self.dictData["TotalLeave"]!.numberValue)
                    
                    if(bundleName.contains("Shilaj")){
                        self.displayStudentData(StudentAttendenceModel.init(ShilajModal: attendenceModal, TotalOnDuty: self.dictData["TotalOnDuty"]!.numberValue))
                    }else {
                        self.displayStudentData(StudentAttendenceModel.init(ShilajModal: attendenceModal))
                    }
                    
                }else if(error != nil) {
                    Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                        self.insertUpdateAttendence()
                    })
                }
            }
        }
    }
    
    @IBAction func chooseDate()
    {
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (btnDate.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDateRange.setStartDate((btnDate.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        selector.optionCurrentDateRange.setEndDate((btnDate.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AttendenceVC:UITableViewDataSource,UITableViewDelegate,TableCellDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        for view in tblHeaderView.subviews[0].subviews {
            if(view.tag != 100){
                view.isHidden = arrAttendenceData.count > 0 ? false : true
            }
        }
        return tblHeaderView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return DeviceType.isIpad ? 150 : 120
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAttendenceData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AttendenceCell = tableView.dequeueReusableCell(withIdentifier: bundleName.contains("Bhadaj") ? "AttendenceBCell" : "AttendenceSCell", for: indexPath) as! AttendenceCell
        
        cell.cellDelegate = self
        cell.displayData(attendenceData: arrAttendenceData[indexPath.row])
        cell.contentView.tag = arrAttendenceData.count + indexPath.row
        return cell
    }
    
    // MARK: - TableView Cell Delegate
    
    func insertUpdateData(_ sender:AnyObject)
    {
        let index:NSInteger = (sender.superview??.tag)!-self.arrAttendenceData.count
        
        let stuID:NSNumber = arrAttendenceData[index].StudentID!
        let attID:NSNumber = arrAttendenceData[index].AttendanceID!
        
        self.dictSelectedData.setValue([stuID,attID,sender.tag], forKey: "\(index)")
        
        let attendenceData:StudentAttendenceModel = self.arrAttendenceData[index]
        attendenceData.AttendenceStatus = "\((sender.tag)!)"
        
        self.arrAttendenceData.remove(at: index)
        self.arrAttendenceData.insert(attendenceData, at: index)
        
        self.tblAttendence.reloadRows(at: [NSIndexPath.init(row: index, section: 0) as IndexPath], with: .none)
    }
}

extension AttendenceVC:WWCalendarTimeSelectorProtocol
{
    // MARK: Calender Delegate
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        
        self.callAttendenceApi(selectedDate: date.toString(dateFormat: "dd/MM/yyyy"))
    }
}


//self.displayStudentData(StudentAttendenceModel.init(Total: self.dictData["Total"]!.numberValue, TotalAbsent: self.dictData["TotalAbsent"]!.numberValue, TotalPresent: self.dictData["TotalPresent"]!.numberValue, TotalLeave: self.dictData["TotalLeave"]!.numberValue, TotalOnDuty:self.dictData["TotalOnDuty"]!.numberValue))
