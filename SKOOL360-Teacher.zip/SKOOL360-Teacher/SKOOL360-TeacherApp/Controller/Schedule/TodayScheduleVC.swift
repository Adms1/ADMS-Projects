//
//  ScheduleVC.swift
//  Skool360Teacher
//
//  Created by Sweta on 18/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class TodayScheduleVC: CustomViewController {
    
    @IBOutlet var tblScheduleSubject:UITableView!
    
    var arrScheduleData = [ScheduleModel]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblScheduleSubject.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("Schedule Subject")
        
        self.callTodayScheduleSubjectApi(webApi:(self.title?.contains("Schedule"))! ?  API.teacherTodayScheduleApi : API.teacherAssignedSubjectApi)
        
        if(bundleName == "Shilaj (Teacher)" || !(self.title?.contains("Schedule"))!){
            view.subviews[0].addConstraint(NSLayoutConstraint.init(item: view.subviews[0], attribute: .height, relatedBy: .equal, toItem: view.subviews[0], attribute: .width, multiplier: 0, constant: 0))
            self.view.layoutIfNeeded()
            view.subviews[0].subviews.forEach { $0.isHidden = true }
            return
        }
        view.subviews[0].subviews.forEach { $0.isHidden = false }
    }
    
    
    // MARK: - API Calling
    
    func callTodayScheduleSubjectApi(webApi:String)
    {
        let params = ["StaffID":staffID!]
        
        self.arrScheduleData = []
        
        Functions.callApi(vc: self, api: webApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrSchedule = json!["FinalArray"].array
                
                for values in arrSchedule! {
                    var scheduleData:ScheduleModel!
                    if (self.title?.contains("Schedule"))! {
                        scheduleData = ScheduleModel.init(lecture: values["Lecture"].numberValue, standard: values["Standard"].stringValue, classname: values["classname"].stringValue, subject: values["Subject"].stringValue, timing: values["Timing"].stringValue)
                    }
                    else {
                        scheduleData = ScheduleModel.init(standard: values["Standard"].stringValue, classname: values["classname"].stringValue, subject: values["Subject"].stringValue)
                    }
                    self.arrScheduleData.append(scheduleData)
                }
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callTodayScheduleSubjectApi(webApi: webApi)
                })
            }
            self.tblScheduleSubject.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension TodayScheduleVC:UITableViewDataSource, UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrScheduleData.count > 0 ? self.arrScheduleData.count + 1 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        
        if (self.title?.contains("Schedule"))! {
            if(indexPath.row == 0) {
                strIdentifier = "ScheduleCellHeader"
            }
            else {
                strIdentifier = "ScheduleCell"
            }
        } else {
            if(indexPath.row == 0) {
                strIdentifier = "SubjectCellHeader"
            }
            else {
                strIdentifier = "SubjectCell"
            }
        }
        
        let cell:ScheduleSubjectCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! ScheduleSubjectCell
        
        if(indexPath.row > 0) {
            cell.displayData(scheduleData: arrScheduleData[indexPath.row-1], isSchedule: (self.title?.contains("Schedule"))! ? true : false)
        }
        return cell
    }
}
