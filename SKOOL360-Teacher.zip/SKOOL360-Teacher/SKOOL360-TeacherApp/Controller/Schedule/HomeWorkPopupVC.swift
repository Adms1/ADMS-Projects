//
//  HomeWorkPopupVC.swift
//  Shilaj (Teacher)
//
//  Created by Sweta on 07/11/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var lessonPlanScheduleModal:LessonPlanScheduleModel!
var dailyWorkModal:DailyWorkModel!

class HomeWorkPopupVC: UIViewController {
    
    @IBOutlet var tblHomeWorkStatus:UITableView!
    var arrHomeWorkStatus = [HomeWorkStatusModel]()
    var arrHomeWorkStatusChanges:[String] = []
    var strHomeWorkStatus = 0
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        callHomeWorkStatusApi()
    }
    
    
    // MARK: - API Calling
    
    func callHomeWorkStatusApi()
    {
        var params:[String:String] = [:]
        
        if bundleName.contains("Shilaj") {
            params = ["TermID":lessonPlanScheduleModal.TermID!,
                      "Date":lessonPlanScheduleModal.Date!,
                      "StandardID":lessonPlanScheduleModal.StandardID!,
                      "ClassID":lessonPlanScheduleModal.ClassID!,
                      "SubjectID":lessonPlanScheduleModal.SubjectID!]
        } else {
            params = ["TermID":dailyWorkModal.TermID!,
                      "Date":dailyWorkModal.Date!,
                      "StandardID":dailyWorkModal.StandardID!,
                      "ClassID":dailyWorkModal.ClassID!,
                      "SubjectID":dailyWorkModal.SubjectID!,
                      "TeacherID" : staffID!]
        }
        print(params)
        
        self.arrHomeWorkStatus = []
        self.arrHomeWorkStatusChanges = []
        
        Functions.callApi(vc: self, api: API.teacherStudentHomeworkStatusApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrHWStatus = json!["FinalArray"].array
                
                var i = 0
                for values in arrHWStatus! {
                    let homeWorkStatusModal:HomeWorkStatusModel = HomeWorkStatusModel.init(stuId: values["StudentID"].stringValue, stuName: values["StudentName"].stringValue, homeWorkId: values["HomeWorkID"].stringValue, homeWorkDetailId:values["HomeWorkDetailID"].stringValue,  homeWorkStatus: values["HomeWorkStatus"].intValue)
                    
                    if(i == 0){
                        let btn:UIButton = self.view.subviews[0].subviews[0].subviews.last as! UIButton
                        btn.isHidden = false
                        //btn.setImage(values["HomeWorkStatus"].intValue == -1 ? imgSubmit : imgUpdate, for: .normal)
                        btn.loadIconsFromLocal(values["HomeWorkStatus"].intValue == -1 ? "Submit" : "Update")
                        self.strHomeWorkStatus = values["HomeWorkStatus"].intValue == -1 ? values["HomeWorkStatus"].intValue : self.strHomeWorkStatus
                    }
                    
                    self.arrHomeWorkStatusChanges.append("\(homeWorkStatusModal.HomeWorkDetailID!),\(homeWorkStatusModal.StudentID!),\(homeWorkStatusModal.HomeWorkStatus == -1 ? 1 : homeWorkStatusModal.HomeWorkStatus!)")
                    self.arrHomeWorkStatus.append(homeWorkStatusModal)
                    i += 1
                }
                
            }else {
                if(error != nil){
                    Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                        self.callHomeWorkStatusApi()
                    })
                }
                self.btnClose()
            }
            self.tblHomeWorkStatus.reloadData()
        }
    }
    
    func callInsertUpdateHomeWorkStatusApi()
    {
        var params:[String:String] = [:]
        
        if bundleName.contains("Shilaj") {
            params = ["Date":lessonPlanScheduleModal.Date!,
                      "StandardID":lessonPlanScheduleModal.StandardID!,
                      "ClassID":lessonPlanScheduleModal.ClassID!,
                      "SubjectID":lessonPlanScheduleModal.SubjectID!]
        } else {
            params = ["Date":dailyWorkModal.Date!,
                      "StandardID":dailyWorkModal.StandardID!,
                      "ClassID":dailyWorkModal.ClassID!,
                      "SubjectID":dailyWorkModal.SubjectID!]
        }
        
        params.updateValue(arrHomeWorkStatus[0].HomeWorkID!, forKey: "HomeWorkID")
        params.updateValue(arrHomeWorkStatusChanges.joined(separator: "|"), forKey: "HomeWorkDetailID")
        
        print(params)
        
        Functions.callApi(vc: self, api: API.teacherStudentHomeworkStatusInsertUpdateApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(true, self.strHomeWorkStatus == -1 ? Message.homeworkStatusAddSuccess : Message.homeworkStatusUpdateSuccess)
                self.btnClose()
            
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callInsertUpdateHomeWorkStatusApi()
                })
            }
        }
    }
    
    
    // MARK: - Button Click Actions
    
    @IBAction func btnStudentHomeWorkStatusChangeAction(_ sender:UIButton)
    {
        self.callInsertUpdateHomeWorkStatusApi()
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension HomeWorkPopupVC:UITableViewDelegate,UITableViewDataSource,HomeWorkStatusCellDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrHomeWorkStatus.count > 0 ? arrHomeWorkStatus.count + 1 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if(indexPath.row == 0) {
            strIdentifier = "HomeWorkStatusHeaderCell"
        }
        else {
            strIdentifier = "HomeWorkStatusCell"
        }
        
        let cell:HomeWorkStatusCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! HomeWorkStatusCell
        
        if(indexPath.row > 0) {
            cell.delegate = self
            cell.tag = indexPath.row*100
            cell.displayData(arrHomeWorkStatus[indexPath.row-1])
        }
        return cell
    }
    
    func studentHomeWorkStatusUpdate(_ idx:NSInteger, _ superViewTag:NSInteger)
    {
        let hwModal:HomeWorkStatusModel = arrHomeWorkStatus[superViewTag]
        hwModal.HomeWorkStatus = idx
        
        self.arrHomeWorkStatus.remove(at: superViewTag)
        self.arrHomeWorkStatus.insert(hwModal, at: superViewTag)
        
        self.arrHomeWorkStatusChanges.remove(at: superViewTag)
        self.arrHomeWorkStatusChanges.insert("\(hwModal.HomeWorkDetailID!),\(hwModal.StudentID!),\(idx)", at: superViewTag)
        
        self.tblHomeWorkStatus.reloadRows(at: [IndexPath.init(row: superViewTag, section: 0)], with: .automatic)
    }
}
