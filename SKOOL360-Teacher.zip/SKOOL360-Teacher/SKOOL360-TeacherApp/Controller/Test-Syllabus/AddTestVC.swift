//
//  AddTestVC.swift
//  Skool360Teacher
//
//  Created by Sweta on 27/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UIDropDown

class AddTestVC: UIViewController {
    
    @IBOutlet var collectionSection:UICollectionView!
    @IBOutlet var btnAddTest:UIButton!
    
    var dicStdSubject:NSMutableDictionary = [:]
    var dicSubData:NSMutableDictionary = [:]
    var dicClassData:NSMutableDictionary = [:]
    var dicStdData:NSMutableDictionary = [:]
    
    var arrTestModel = [SyllabusModel]()
    var arrSections:[String] = []
    
    var strSubjectName:String!
    var strSubjectID:NSNumber!
    
    var strStandard:String!
    var strClass:String!
    var strSectionID:NSNumber!
    
    var strTestName:String!
    var strTestID:NSNumber!
    
    var arrClasses:NSMutableArray = []
    var arrSectionsIds:[NSNumber] = []
    var arrStdSub:[String] = []
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetSubjectsApi()
    }
    
    
    // MARK: - API Calling
    
    func callGetSubjectsApi()
    {
        let params = ["StaffID":staffID!]
        
        self.resetData()
        
        Functions.callApi(vc: self, api: API.teacherAssignedSubjectApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrSchedule = json!["FinalArray"].array
                
                for values in arrSchedule! {
                    
                    let key:String = "\(values["Standard"].stringValue) → \(values["Subject"].stringValue)"
                    
                    var str:String = values["classname"].stringValue
                    if(self.dicStdSubject[key] != nil)
                    {
                        let oldStr:String = self.dicStdSubject[key] as! String
                        str = "\(oldStr),\(str)"
                    }
                    self.dicStdSubject.setValue(str, forKey: "\(values["Standard"].stringValue) → \(values["Subject"].stringValue)")
                    
                    self.arrStdSub = self.dicStdSubject.sortedDictionary(self.dicStdSubject).0
                    self.dicStdData.setValue(values["StandardID"].stringValue, forKey: values["Standard"].stringValue)
                    self.dicClassData.setValue(values["ClassID"].stringValue, forKey: "\(values["Standard"].stringValue)-\(values["classname"].stringValue)")
                    self.dicSubData.setValue(values["SubjectID"].stringValue, forKey: values["Subject"].stringValue)
                }
                
                for dd in (self.view.subviews.flatMap{$0 as? UIDropDown}) {
                    if(dd.table != nil){
                        dd.hideTable()
                    }
                    dd.removeFromSuperview()
                }
                self.addDropDown()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetSubjectsApi()
                })
            }
        }
    }
    
    func callTestNameApi(stdID:String)
    {
        strStdID = stdID
        let params = ["StandardID":stdID]
        
        self.arrTestModel = []
        
        Functions.callApi(vc: self, api: API.teacherGetTestNameGradeWiseApi, params: params, completionHandler: { (json, error) in
            
            if(json != nil) {
                let array = json!["FinalArray"].array
                
                for value in array! {
                    
                    let testModal:SyllabusModel = SyllabusModel.init(testName: value["TestName"].stringValue, testID: value["TestID"].numberValue)
                    
                    self.arrTestModel.append(testModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callTestNameApi(stdID: stdID)
                })
            }
            self.addTest(data: self.arrTestModel)
        })
    }
    
    
    // MARK: - Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.tag = i*10
                dropDown.placeholder = "-Please Select-"
                dropDown.tableHeight = 0.0
                
                if(i == 1)
                {
                    let strValue:String = self.arrStdSub[0]
                    self.strSubjectName = strValue.components(separatedBy: " → ").last!
                    self.strSubjectID = NSNumber.init(value: Int(self.dicSubData.keyedOrValueExist(key: self.strSubjectName) as! String)!)
                    self.strStandard = strValue.components(separatedBy: " → ").first!
                    
                    dropDown.options = self.arrStdSub
                    dropDown.tableHeight = self.arrStdSub.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrStdSub.count * 35)
                    dropDown.selectedIndex = 0
                    dropDown.title.text = strValue
                }
                dropDown.didSelect { (option, index) in
                    dropDown.hideTable()
                    
                    if(dropDown.tag == 10){
                        
                        self.strSubjectName = option.components(separatedBy: " → ").last!
                        self.strSubjectID = NSNumber.init(value: Int(self.dicSubData.keyedOrValueExist(key: self.strSubjectName) as! String)!)
                        self.strStandard = option.components(separatedBy: " → ").first!
                        
                        //                        self.addSections(values: self.dicStdSubject.value(forKey: option) as! String)
                        
                        self.callTestNameApi(stdID: self.dicStdData.keyedOrValueExist(key: option.components(separatedBy: " → ").first!) as! String)
                        
                        self.arrSectionsIds = []
                        self.arrClasses = []
                        self.arrSections = []
                        
                        let strSection:String = self.dicStdSubject.keyedOrValueExist(key: option) as! String
                        self.arrSections = strSection.components(separatedBy: ",")
                        
                        self.strClass = self.arrSections[0]
                        self.strSectionID = NSNumber.init(value: Int(self.dicClassData.keyedOrValueExist(key: "\(self.strStandard!)-\(self.strClass!)") as! String)!)
                        
                        self.arrClasses.add(self.strClass)
                        self.arrSectionsIds.append(self.strSectionID)
                        
                        self.collectionSection.reloadData()
                        
                    }else if(dropDown.tag == 20) {
                        
                        self.strTestName = self.arrTestModel[index].TestName
                        self.strTestID = self.arrTestModel[index].TestID
                    }else {
                        self.strClass = option
                        self.strSectionID = NSNumber.init(value: Int(self.dicClassData.keyedOrValueExist(key: "\(self.strStandard!)-\(self.strClass!)") as! String)!)
                    }
                }
                
                self.view.addSubview(dropDown)
                
                let key:String = arrStdSub[0]
                if(i == 2)
                {
                    self.callTestNameApi(stdID: dicStdData.keyedOrValueExist(key: key.components(separatedBy: " → ").first!) as! String)
                    
                    let strSection:String = self.dicStdSubject.keyedOrValueExist(key: key) as! String
                    self.arrSections = strSection.components(separatedBy: ",")
                    
                    self.strClass = self.arrSections[0]
                    self.strSectionID = NSNumber.init(value: Int(self.dicClassData.keyedOrValueExist(key: "\(self.strStandard!)-\(self.strClass!)") as! String)!)
                    
                    self.arrClasses.add(self.strClass)
                    self.arrSectionsIds.append(self.strSectionID)
                    
                    self.collectionSection.reloadData()
                }
                
                i += 1
                
            } else if(view.tag == 100){
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
    }
    
    // MARK: - DropDown - 2
    
    func addSections(values:String)
    {
        let arraySections : [String] = values.components(separatedBy: ",")
        let dropDown:UIDropDown = self.view.viewWithTag(20) as! UIDropDown
        dropDown.options = arraySections
        dropDown.tableHeight = arraySections.count > 5 ? CGFloat(5 * 35) : CGFloat(arraySections.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = arraySections[0]
        
        strClass = arraySections[0]
        strSectionID = NSNumber.init(value: Int(dicClassData.keyedOrValueExist(key: "\(strStandard!)-\(strClass!)") as! String)!)
    }
    
    // MARK: - DropDown - 2
    
    func addTest(data:[SyllabusModel])
    {
        let dropDown:UIDropDown = self.view.viewWithTag(20) as! UIDropDown
        
        if(data.count > 0) {
            
            strTestName = data[0].TestName
            strTestID = data[0].TestID
            
            var arrTestName:[String] = []
            for value in data {
                arrTestName.append(value.TestName!)
            }
            
            dropDown.options = arrTestName
            dropDown.tableHeight = arrTestName.count > 5 ? CGFloat(5 * 35) : CGFloat(arrTestName.count * 35)
            dropDown.selectedIndex = 0
            dropDown.title.text = arrTestName[0]
        } else {
            
            strTestName = ""
            strTestID = 0
            
            dropDown.placeholder = "-Please Select-"
            dropDown.tableHeight = 0.0
        }
        self.checkAvailability()
    }
    
    func checkAvailability()
    {
        btnAddTest.isEnabled = strTestID == 0 ? false : true
        btnAddTest.alpha = btnAddTest.isEnabled ? 1.0 : 0.5
    }
    
    func resetData()
    {
        arrSectionsIds = []
        arrClasses = []
        arrSections = []
        
        dicSubData = [:]
        dicStdData = [:]
        dicStdSubject = [:]
        dicClassData = [:]
    }
    
    
    // MARK: - Choose Date
    
    @IBAction func chooseDate()
    {
        let btnDate:UIButton = self.view.viewWithTag(100) as! UIButton
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (btnDate.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDateRange.setStartDate((btnDate.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        selector.optionCurrentDateRange.setEndDate((btnDate.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    @IBAction func btnAddTestClicked(_ sender:UIButton)
    {
        let btnDate:UIButton = self.view.viewWithTag(100) as! UIButton
        let Date = btnDate.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy")
        let strDate:String = (Date?.toString(dateFormat: "yyyy-MM-dd'T'HH:mm:ss"))!
        
        let syllabusModal:SyllabusModel = SyllabusModel.init(testName: strTestName, TSmasterID: 0, stdClass: "\(strStandard!)-\(arrClasses.componentsJoined(by: ","))", sectionID: 0, subject: strSubjectName, subjectID: strSubjectID, testDate: strDate, testID: strTestID, sectionIDS:(arrSectionsIds.map{String(describing: $0)}).joined(separator: "|"), standardID: strStdID)
        syllabusModalData = syllabusModal
        add(asChildViewController: syllabusVC, self)
    }
    
    private lazy var syllabusVC: SyllabusPopupVC = {
        
        var viewController:SyllabusPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "SyllabusPopupVC") as! SyllabusPopupVC
        viewController.view.tag = 100
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AddTestVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let item:CGFloat = (bundleName.contains("Shilaj") ? 3 : 2)
        return CGSize(width: collectionView.frame.size.width/item, height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrSections.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:StudentAssignedSubjectCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StudentAssignedSubjectCell", for: indexPath) as! StudentAssignedSubjectCell
        
        cell.lblSection.text = arrSections[indexPath.row]
        if (bundleName.contains("Bhadaj")) {
            cell.lblSection.adjustsFontSizeToFitWidth = true
        }
        
        if(indexPath.row == 0) {
            cell.checkBox.setOn(true, animated: true)
        }else {
            cell.checkBox.setOn(false, animated: false)
        }
        return cell
    }
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let cell:StudentAssignedSubjectCell = collectionView.cellForItem(at: indexPath) as! StudentAssignedSubjectCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        self.strClass = self.arrSections[indexPath.row]
        self.strSectionID = NSNumber.init(value: Int(self.dicClassData.keyedOrValueExist(key: "\(self.strStandard!)-\(self.strClass!)") as! String)!)
        
        if(cell.checkBox.isOn()){
            self.arrClasses.add(self.strClass)
            self.arrSectionsIds.append(self.strSectionID)
            
        }else{
            let idx:NSInteger = self.arrClasses.index(of: self.strClass)
            self.arrClasses.remove(self.strClass)
            self.arrSectionsIds.remove(at: idx)
        }
    }
}

extension AddTestVC:WWCalendarTimeSelectorProtocol
{
    // MARK: - Calender Delegate
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        let btn:UIButton = self.view.viewWithTag(100) as! UIButton
        btn.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}
