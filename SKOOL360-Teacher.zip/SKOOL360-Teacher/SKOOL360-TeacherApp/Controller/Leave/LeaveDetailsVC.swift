//
//  LeaveDetailsVC.swift
//  Bhadaj (Teacher)
//
//  Created by ADMS on 30/08/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class LeaveDetailsVC: CustomViewController {
    
    @IBOutlet var tblLeaveData:UITableView!
    @IBOutlet var tblLeaveDetails:UITableView!
    
    var arrLeaveData = [LeaveModel]()
    var arrLeaveDetails = [LeaveModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblLeaveDetails.tableFooterView = UIView()
        tblLeaveData.tableFooterView = UIView()
        
        NotificationCenter.default.addObserver(self, selector: #selector(callGetLeaveDetailsApi), name: .refreshData, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Leave Details"
        self.callGetLeaveDetailsApi()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        isFromPush = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension LeaveDetailsVC
{
    @objc func callGetLeaveDetailsApi()
    {
        arrLeaveData = []
        arrLeaveDetails = []
        
        let params = ["StaffID":staffID!]
        
        Functions.callApi(vc: self, api: API.getStaffLeaveRequestApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrLDetails = json!["FinalArray"].array
                
                for (i,values) in arrLDetails!.enumerated() {
                    let leaveLDModel:LeaveModel = LeaveModel.init(leaveId: values["LeaveID"].stringValue, createDate: values["CreateDate"].stringValue, leaveStartDate: values["LeaveStartDate"].stringValue, leaveEndDate: values["LeaveEndDate"].stringValue, leaveDays: values["LeaveDays"].stringValue, status: values["Status"].stringValue, arDate: "\(values["ARStartDate"].stringValue) - \(values["AREndDate"].stringValue)", arDays: values["ARDays"].stringValue, arBy: values["ARBy"].stringValue, cl: values["CL"].stringValue, pl: values["PL"].stringValue, reason: values["Reason"].stringValue, headName: values["HeadName"].stringValue)
                    
                    if(isFromPush){
                        let date = (pushData["alert"] as! String).components(separatedBy: " - ").last?.replacingOccurrences(of: "-", with: " - ")
                        if (leaveLDModel.ApproveRejectDate == date) {
                            self.selectedIndex = i;
                        }
                    }
                    self.arrLeaveDetails.append(leaveLDModel)
                }
                self.tblLeaveDetails.reloadData()
                if(self.selectedIndex != -1){
                    self.tblLeaveDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: self.selectedIndex) as IndexPath, at: .none, animated: false)
                }
                
                let arrLData = json!["LeaveDetails"].array
                
                for values in arrLData! {
                    let leaveLModel:LeaveModel = LeaveModel.init(category: values["Category"].stringValue, total: values["Total"].stringValue, used: values["Used"].stringValue, remaining: values["Remaining"].stringValue)
                    self.arrLeaveData.append(leaveLModel)
                }
                self.tblLeaveData.reloadData()
                self.tblLeaveData.layer.cornerRadius = 5.0
                self.tblLeaveData.layer.borderColor  = GetColor.blue.cgColor
                self.tblLeaveData.layer.borderWidth  = 0.5
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetLeaveDetailsApi()
                })
            }
        }
    }
    
    func callDeleteLeaveDetailsApi(_ index:NSInteger)
    {
        let params = ["LeaveID":arrLeaveDetails[index].LeaveID!]
        
        Functions.callApi(vc: self, api: API.deleteStaffLeaveApi, params: params) { (json,error) in
            if(json != nil){
                Functions.showAlert(true, Message.leaveDeleteSuccess)
                self.arrLeaveDetails.remove(at: index)
                self.tblLeaveDetails.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callDeleteLeaveDetailsApi(index)
                })
            }
        }
    }
}

extension LeaveDetailsVC
{
    @IBAction func btnAddAction(_ sender:UIButton)
    {
        self.performSegue(withIdentifier: "Apple Leave", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination
        vc.title = segue.identifier
        vc.customModalTransition = FashionTransition()
    }
}

extension LeaveDetailsVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if(tableView == tblLeaveDetails) {
            let headerView:LeaveCell = tableView.dequeueReusableCell(withIdentifier: "LeaveHeaderCell") as! LeaveCell
            
            headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0)
            
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
            headerView.contentView.tag = section
            headerView.contentView.addGestureRecognizer(tapGesture)
            
            headerView.btnExpand.transform = .identity
            if section == selectedIndex {
                UIView.animate(withDuration: 0.5, animations: {
                    headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
                })
            };
            headerView.img.isHidden = section != 0
            headerView.displayLeaveHeaderDetails(arrLeaveDetails[section])
            return arrLeaveDetails.count > 0 ? headerView.contentView : nil
        }else {
            //            let headerView:LeaveCell = tableView.dequeueReusableCell(withIdentifier: "LeaveHeaderDCell") as! LeaveCell
            //            for lbl in (headerView.contentView.subviews.flatMap{$0 as? UILabel}) {
            //                lbl.font = FontType.mediumFont
            //            }
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return tableView == tblLeaveData ? 0 : arrLeaveDetails.count > 0 ? (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50)) : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return tableView == tblLeaveData ? 1 : arrLeaveDetails.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return UITableViewAutomaticDimension
        }else if(tableView == tblLeaveData) {
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == tblLeaveData ? arrLeaveData.count > 0 ? (arrLeaveData.count + 1) : 0 : tblLeaveDetails.rowHeight == 0 ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:LeaveCell = tableView.dequeueReusableCell(withIdentifier: tableView == tblLeaveData ? indexPath.row == 0 ? "LeaveHeaderDCell" : "LeaveDCell" : arrLeaveDetails[indexPath.section].Status.capitalized == "Pending" ? "LeavePCell" : "LeaveARCell", for: indexPath) as! LeaveCell
        
        if(tableView == tblLeaveDetails){
            if(arrLeaveDetails[indexPath.section].Status.capitalized == "Pending") {
                cell.btnEdit.tag = indexPath.section
                cell.btnDelete.tag = indexPath.section
                
                cell.editDeleteBlock = { sender in
                    if(sender == cell.btnDelete) {
                        Functions.showCustomAlert("Delete", Message.deleteLeave) { (_) in
                            self.callDeleteLeaveDetailsApi(sender.tag)
                        }
                    }else{
                        selectedLeaveModel = self.arrLeaveDetails[indexPath.section]
                        self.performSegue(withIdentifier: "Apple Leave", sender: self)
                    }
                }
            }
            cell.displayLeaveDetails(arrLeaveDetails[indexPath.section])
        }else{
            if(indexPath.row == 0){
                for lbl in (cell.contentView.subviews.flatMap{$0 as? UILabel}) {
                    lbl.font = FontType.mediumFont
                }
            }else {
                cell.displayLeaveData(arrLeaveData[indexPath.row-1])
            }
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblLeaveDetails.reloadSections(IndexSet(integersIn: 0...arrLeaveDetails.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblLeaveDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}
