//
//  CreateLeaveVC.swift
//  Bhadaj (Teacher)
//
//  Created by Sweta on 30/08/18.
//  Copyright © 2018 Sweta. All rights reserved.
//

import UIKit
import UIDropDown

var selectedLeaveModel:LeaveModel!
class CreateLeaveVC: CustomViewController {
    
    @IBOutlet var btnSend:UIButton!
    @IBOutlet var btnStartDate:UIButton!
    @IBOutlet var btnEndDate:UIButton!
    @IBOutlet var txtReason:UITextView!
    
    var dicHeadData:[String:String] = [:]
    var arrHeadNames:[String] = []
    var arrLeaveDays:[Double] = []
    
    var leaveDays:Double = 0.6
    var strHeadID:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                if(selectedLeaveModel != nil) {
                    (view as! UIButton).setTitle(view.tag == 100 ? selectedLeaveModel.LeaveStartDate! : selectedLeaveModel.LeaveEndDate!, for: .normal)
                }else {
                    (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                }
            }
        }
        if(selectedLeaveModel != nil){
            txtReason.text = selectedLeaveModel.Reason
        }
        btnSend.setTitle(selectedLeaveModel != nil ? "UPDATE" : "SEND", for: .normal)
        self.callGetLeaveDaysApi()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        selectedLeaveModel = nil
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension CreateLeaveVC
{
    func callGetLeaveDaysApi()
    {
        arrLeaveDays = []
        
        Functions.callApi(vc: self, api: API.getLeaveDaysApi, params: ["UserID" : staffID!]) { (json,error) in
            if(json != nil){
                
                let arrLeaveDays = json!["FinalArray"].array
                
                for values in arrLeaveDays! {
                    self.arrLeaveDays.append(values["Days"].doubleValue)
                }
                self.callGetHeadApi()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetLeaveDaysApi()
                })
            }
        }
    }
    
    func callGetHeadApi()
    {
        arrHeadNames = []
        dicHeadData = [:]
        
        Functions.callApi(vc: self, api: API.getHeadApi, params: [:]) { (json,error) in
            if(json != nil){
                
                let arrHeads = json!["FinalArray"].array
                
                for values in arrHeads! {
                    self.dicHeadData[values["EmployeeName"].stringValue] = values["EmployeeID"].stringValue
                    self.arrHeadNames.append(values["EmployeeName"].stringValue)
                }
                self.addDropDown()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callGetHeadApi()
                })
            }
        }
    }
    
    func callSendLeaveRequestApi()
    {
        let params = ["LeaveID" : selectedLeaveModel != nil ? selectedLeaveModel.LeaveID! : "0",
                      "FromDate" : btnStartDate.title(for: .normal)!,
                      "ToDate" : btnEndDate.title(for: .normal)!,
                      "StaffID" : staffID!,
                      "HeadID" : strHeadID!,
                      "LeaveDays" : "\(leaveDays)",
            "Reason" : txtReason.text!]
        
        Functions.callApi(vc: self, api: API.insertStaffLeaveRequestApi, params: params) { (json,error) in
            if(json != nil){
                Functions.showAlert(true, (json!["FinalArray"].array?.first!["Message"].stringValue)!)
                self.dismiss(animated: true, completion: nil)
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callSendLeaveRequestApi()
                })
            }
        }
    }
}

extension CreateLeaveVC
{
    // MARK: - Add DropDown
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.placeholder = "-Please Select-"
                dropDown.tableHeight = CGFloat(5 * 35)
                dropDown.tag = i * 10
                
                switch(i)
                {
                case 1:
                    var array:[Double] = self.arrLeaveDays
//                    for i in 0..<30 {
//                        array.append(Double(Double(i)+0.5))
//                        array.append(Double(i+1))
//                    }
                    dropDown.options = array.map{String($0)}
                    if(selectedLeaveModel != nil){
                        dropDown.title.text = selectedLeaveModel.LeaveDays
                        dropDown.selectedIndex = array.index(of: Double(selectedLeaveModel.LeaveDays)!)
                        leaveDays = Double(selectedLeaveModel.LeaveDays)!
                    }
                case 2:
                    dropDown.options = arrHeadNames
                    dropDown.tableHeight = arrHeadNames.count < 5 ? CGFloat(arrHeadNames.count * 35) : CGFloat(5 * 35)
                    if(selectedLeaveModel != nil){
                        dropDown.title.text = selectedLeaveModel.HeadName!
                        dropDown.selectedIndex = arrHeadNames.index(of: selectedLeaveModel.HeadName!)
                        strHeadID = self.dicHeadData[dropDown.title.text!]
                    }
                default:
                    break
                }
                
                dropDown.didSelect { (option, index) in
                    dropDown.hideTable()
                    if(dropDown.tag == 10){
                        self.leaveDays = Double(option)!
                        self.btnEndDate.setTitle(Calendar.current.date(byAdding: .day, value: Int(round(Double(option)!))-1, to: (self.btnStartDate.title(for: .normal)?.toDate(dateFormat: "dd/MM/yyyy"))!)?.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                    }else{
                        self.strHeadID = self.dicHeadData[option]
                    }
                }
                self.view.addSubview(dropDown)
                i += 1
            }
        }
    }
    
    @IBAction func btnChooseDateAction(_ sender:UIButton)
    {
        btnDate = sender
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDateRange.setStartDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        selector.optionCurrentDateRange.setEndDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    @IBAction func btnSendAction(_ sender:UIButton)
    {
        guard leaveDays != 0.6 else {
            Functions.showAlert(false, Message.leaveDaysError)
            return
        }
        
        guard strHeadID != nil else {
            Functions.showAlert(false, Message.headNameError)
            return
        }
        
        guard txtReason.text.count != 0 else {
            Functions.showAlert(false, Message.reasonError)
            return
        }
        
        self.callSendLeaveRequestApi()
    }
}

extension CreateLeaveVC:UITextViewDelegate
{
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
}

extension CreateLeaveVC:WWCalendarTimeSelectorProtocol
{
    // MARK: - Calender Delegate
    
    func WWCalendarTimeSelectorShouldSelectDate(_ selector: WWCalendarTimeSelector, date: Date) -> Bool {
        return date > Date()
    }
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        btnEndDate.setTitle(Calendar.current.date(byAdding: .day, value: Int(round(Double(leaveDays)))-1, to: date)?.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}
