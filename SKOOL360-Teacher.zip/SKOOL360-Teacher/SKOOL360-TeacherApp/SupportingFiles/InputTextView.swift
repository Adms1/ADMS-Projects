//
//  InputText.swift
//  Skool360Teacher
//
//  Created by ADMS on 27/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class InputTextView: UITextView {
    
    override func awakeFromNib() {
        
        addBorder(self)
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(InputTextView.dismissPicker))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let leftButton = UIBarButtonItem(image: UIImage(named: "left"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(InputTextView.nextPreviousView(sender:)))
        leftButton.tag = -1
        let rightButton = UIBarButtonItem(image: UIImage(named: "right"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(InputTextView.nextPreviousView(sender:)))
        rightButton.tag = -2
        
        toolBar.setItems([leftButton, rightButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        self.inputAccessoryView = toolBar
    }
    
    // MARK: -  Textview InputAccessoryView Events
    
    @objc func nextPreviousView(sender:UIBarButtonItem)
    {
        NotificationCenter.default.post(name: Notification.Name("NextPrevious"), object: nil, userInfo: ["Tag":"\(self.tag)|\(sender.tag)"])
    }
    
    @objc func dismissPicker(){
        NotificationCenter.default.post(name: Notification.Name("dismiss"), object: nil, userInfo: ["Tag":self.tag])
    }
}
