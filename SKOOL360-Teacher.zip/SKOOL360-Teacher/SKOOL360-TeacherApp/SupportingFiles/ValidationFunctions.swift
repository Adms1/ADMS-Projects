//
//  Validations.swift
//  FirebaseChat
//
//  Created by Sweta on 25/08/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class ValidationFunctions: NSObject {
    
    class func loginValidation(loginData:LoginData) -> (Bool,ErrorType?)
    {
        if (loginData.userName?.isEmpty)! {
            return (Functions.showAlert(false, Message.userNameError),.userName)
            
        }else if (loginData.password?.isEmpty)! {
            return (Functions.showAlert(false, Message.passwordError),.password)
            
        }else if ((loginData.password?.count)! < 3 || (loginData.password?.count)! > 12) {
            return (Functions.showAlert(false, Message.passwordValidationError),.password)
        }
        return (true,nil)
    }
    
    class func requestValidation(requestData:RequestData) -> (Bool,ErrorType?)
    {
        if (requestData.txtSubject?.isEmpty)! {
            return (Functions.showAlert(false, Message.subjectError),.subject)
            
        }else if (requestData.txtDescription?.isEmpty)! {
            return (Functions.showAlert(false, Message.descriptionError),.description)
        }
        return (true,nil)
    }
    
    class func timeTableAddValidation(tblData:AddTimeTableData) -> Bool
    {
        if (tblData.StdId?.isEmpty)! {
            return Functions.showAlert(false, Message.standardError)
            
        }else if (tblData.ClassID?.isEmpty)! {
            return Functions.showAlert(false, Message.classError)
            
        }else if (tblData.SubjectID?.isEmpty)! {
            return Functions.showAlert(false, Message.subjectIdError)
            
        }else if (tblData.StartLTime?.isEmpty)! {
            return Functions.showAlert(false, Message.startTimeHourError)
            
        }else if (tblData.StartMTime?.isEmpty)! {
            return Functions.showAlert(false, Message.startTimeMinuteError)
            
        }else if (tblData.EndLTime?.isEmpty)! {
            return Functions.showAlert(false, Message.endTimeHourError)
            
        }else if (tblData.EndMTime?.isEmpty)! {
            return Functions.showAlert(false, Message.endTimeMinuteError)
        }
        return true
    }
}
