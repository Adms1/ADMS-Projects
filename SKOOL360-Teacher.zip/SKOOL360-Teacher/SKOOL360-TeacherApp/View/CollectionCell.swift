//
//  CollectionCell.swift
//  Skool360Teacher
//
//  Created by Sweta on 13/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class DeshBoardCell: UICollectionViewCell {
    
    @IBOutlet var imgIcon:UIImageView!
    @IBOutlet var lblTitle:UILabel!
    
    func displayData(_ strData:String) {
        
        if(UIScreen.main.bounds.width == 320){
            lblTitle.font = FontHelper.medium(size: 12)
        }
        
        imgIcon.getImagesfromLocal(strData)
        lblTitle.text = strData
    }
}

protocol StudentAssignedSubjectDelegate {
    //    func changeSubjectStatus(_ chkBox:VKCheckbox, _ modal:AssignedSubjectModel)
    func addCheckedValue(_ chkBox:VKCheckbox, _ modal:AssignedSubjectModel)
}

class StudentAssignedSubjectCell: UICollectionViewCell {
    
    @IBOutlet var lblSubject:UILabel!
    @IBOutlet var lblSection:UILabel!
    @IBOutlet var checkBox:VKCheckbox!
    var stuDelegate:StudentAssignedSubjectDelegate!
    
    override func awakeFromNib() {
        self.checkBox.line             = .normal
        self.checkBox.bgColorSelected  = GetColor.blue
        self.checkBox.color            = .white
        self.checkBox.borderColor      = GetColor.blue
        self.checkBox.borderWidth      = 1.0
        self.checkBox.cornerRadius     = 5.0
    }
    
    func displayData(subjectData:AssignedSubjectModel)
    {
        
        lblSubject.text = subjectData.Subject
        if(subjectData.CheckedStatus == "1"){
            self.stuDelegate.addCheckedValue(self.checkBox, subjectData)
            self.checkBox.setOn(true, animated: true)
        }else{
            self.checkBox.setOn(false, animated: false)
        }
        
        //        self.checkBox.checkboxValueChangedBlock = {
        //            isOn in
        //            print("Custom checkbox is \(isOn ? "ON" : "OFF")")
        //            let modal:AssignedSubjectModel!
        //            modal = subjectData
        //            modal.CheckedStatus = isOn ? "1" : "0"
        //            self.stuDelegate.changeSubjectStatus(self.checkBox, modal)
        //        }
    }
}
