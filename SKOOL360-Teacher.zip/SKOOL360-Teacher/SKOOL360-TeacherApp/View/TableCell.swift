//
//  TableCell.swift
//  Skool360Teacher
//
//  Created by ADMS on 14/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import SDWebImage
import AIFlatSwitch

protocol TableCellDelegate {
    func insertUpdateData(_ sender:AnyObject)
}

// MARK: - AttendenceCell

class AttendenceCell: UITableViewCell {
    
    @IBOutlet var btnCheckBox:SquareButton!
    @IBOutlet var imgProfile:UIImageView!
    @IBOutlet var lblTeacherName:UILabel!
    var cellDelegate:TableCellDelegate!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        lblTeacherName.font = FontHelper.regular(size: isIpad ? 17 : 14)
    }
    
    func displayData(attendenceData:StudentAttendenceModel) {
        
        self.layoutIfNeeded()
        
        lblTeacherName.text = attendenceData.StudentName?.capitalized
        imgProfile.setImageWithFadeFromURL(url: URL.init(string: (attendenceData.StudentImage)!.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!)!, placeholderImage: teacherPlaceholder, animationDuration: 0.5){ (finish) in}
        
        var status:Int = Int(attendenceData.AttendenceStatus!)!
        if status == -2 {
            status = 1
        }
        
        for view in self.contentView.subviews {
            if(view.isKind(of: UIControl.classForCoder()) && view.tag != status){
                let control = view as! UIControl
                control.isSelected = false
            }else if(view.isKind(of: UIControl.classForCoder()) && view.tag == status) {
                let control = view as! UIControl
                control.isSelected = true
            }
        }
    }
    
    @IBAction func onSwitchValueChange(_ sender: AnyObject) {
        
        for control in (self.contentView.subviews.flatMap{$0 as? UIControl}) {
            if control != sender as! UIControl {
                control.isSelected = false
            }else{
                control.isSelected = true
            }
        }
        self.cellDelegate.insertUpdateData(sender)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

// MARK: - ScheduleSubjectCell

class ScheduleSubjectCell: UITableViewCell {
    
    func displayData(scheduleData:ScheduleModel,isSchedule:Bool) {
        
        var arrData:[String] = []
        if isSchedule {
            arrData = [(scheduleData.Lecture?.stringValue)!,scheduleData.Timing!,scheduleData.Standard!,scheduleData.ClassName!,scheduleData.Subject!]
        } else {
            arrData = [scheduleData.Standard!,scheduleData.ClassName!,scheduleData.Subject!]
        }
        
        var i = 0
        for lbls in self.contentView.subviews {
            let lbl:UILabel = lbls as! UILabel
            lbl.text = arrData[i]
            
            i += 1
        }
    }
}

// MARK: - AssignedSubjectCell

protocol AssignedSubjectDelegate {
    func changeBtnStatus()
}

class AssignedSubjectCell: UITableViewCell {
    
    @IBOutlet var lblStudentName:UILabel!
    @IBOutlet var collectionSubjects:UICollectionView!
    var arrStudentSubjectsDetails = [AssignedSubjectModel]()
    var arrayCount:NSInteger = 0
    var delegate:AssignedSubjectDelegate!
    
    override func awakeFromNib() {
        collectionSubjects.dataSource = self
        collectionSubjects.delegate = self
    }
    
    func displayData(subjectData:AssignedSubjectModel)
    {
        lblStudentName.text = subjectData.StudentName
        lblStudentName.accessibilityValue = subjectData.StudentID?.stringValue
        
        arrStudentSubjectsDetails = []
        if(dicSelectedSubjects.keyedOrValueExist(key: lblStudentName.text!) != nil)
        {
            let arrSelectedSubject:NSArray = dicSelectedSubjects.keyedOrValueExist(key: lblStudentName.text!)! as! NSArray
            
            for values in arrSelectedSubject {
                let subjectModal:AssignedSubjectModel = values as! AssignedSubjectModel
                arrStudentSubjectsDetails.append(subjectModal)
            }
        }
        else
        {
            for values in subjectData.StudentSubject! {
                let dic:NSDictionary = values as! NSDictionary
                
                let subjectModal = AssignedSubjectModel.init(chkStatus: dic["CheckedStatus"] as! String, subject: dic["Subject"] as! String, subjectID: dic["SubjectID"] as! NSNumber)
                
                arrStudentSubjectsDetails.append(subjectModal)
            }
        }
        self.collectionSubjects.reloadData()
    }
    
    func addCheckedValue(_ chkBox:VKCheckbox, _ modal:AssignedSubjectModel)
    {
        let strSubID:String = (modal.SubjectID?.stringValue)!
        arrSelectedSubjects.add("\(lblStudentName.accessibilityValue!),\(strSubID)")
    }
    
    func changeSubjectStatus(_ chkBox:VKCheckbox, _ modal:AssignedSubjectModel)
    {
        arrStudentSubjectsDetails.remove(at: chkBox.tag)
        arrStudentSubjectsDetails.insert(modal, at: chkBox.tag)
        
        dicSelectedSubjects.setValue(arrStudentSubjectsDetails, forKey: lblStudentName.text!)
        
        let strSubID:String = (modal.SubjectID?.stringValue)!
        
        if(modal.CheckedStatus == "1") {
            arrSelectedSubjects.add("\(lblStudentName.accessibilityValue!),\(strSubID)")
        }else {
            arrSelectedSubjects.remove("\(lblStudentName.accessibilityValue!),\(strSubID)")
        }
        delegate.changeBtnStatus()
    }
}

extension AssignedSubjectCell:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,StudentAssignedSubjectDelegate
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/3, height: 35);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrStudentSubjectsDetails.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:StudentAssignedSubjectCell = collectionView.dequeueReusableCell(withReuseIdentifier: "StudentAssignedSubjectCell", for: indexPath) as! StudentAssignedSubjectCell
        
        cell.stuDelegate = self
        cell.checkBox.tag = indexPath.row
        
        cell.displayData(subjectData: arrStudentSubjectsDetails[indexPath.row])
        return cell
    }
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let cell:StudentAssignedSubjectCell = collectionView.cellForItem(at: indexPath) as! StudentAssignedSubjectCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        let modal:AssignedSubjectModel = arrStudentSubjectsDetails[indexPath.row]
        modal.CheckedStatus = cell.checkBox.isOn() ? "1" : "0"
        self.changeSubjectStatus(cell.checkBox, modal)
    }
}

// MARK: - MarksCell

class MarksCell: UITableViewCell {
    
    @IBOutlet var lblStudentName:UILabel!
    @IBOutlet var lblGrno:UILabel!
    @IBOutlet var lblPercentage:UILabel!
    @IBOutlet var lblView:UILabel!
    
    @IBOutlet var lblSubjectName:UILabel!
    @IBOutlet var lblMarks:UILabel!
    
    func displayStudentData(_ marksModel:MarksModel)
    {
        var i = 0
        while i < 2 {
            for lbl in (self.contentView.subviews[0].subviews[i].subviews.flatMap{$0 as? UILabel}) {
                lbl.font = i == 0 ? FontHelper.medium(size: isIpad ? 16 : 13) : FontHelper.regular(size: isIpad ? 16 : 13)
            }
            i += 1
        }
        
        lblStudentName.text = marksModel.StudentName
        lblGrno.text = marksModel.GRNO
        lblPercentage.text = "\((marksModel.Percentage)!) %"
    }
    
    func displayData(_ marksModel:MarksModel)
    {
        self.contentView.subviews[0].backgroundColor = UIColor.groupTableViewBackground.withAlphaComponent(0.5)
        lblSubjectName.text = marksModel.Subject
        lblMarks.text = marksModel.Marks
    }
    
    func displayTotal(_ marksModel:MarksModel)
    {
        self.contentView.subviews[0].backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        lblMarks.text = "\((marksModel.TotalGained?.stringValue)!)/\((marksModel.Total?.stringValue)!)"
    }
}

// MARK: - TimeTableCell

protocol TimeTableCellDelegate {
    func addDeleteTimeTable(_ sender:UIButton)
}

class TimeTableCell: UITableViewCell {
    
    @IBOutlet var lblDay:UILabel!
    var delegate:TimeTableCellDelegate!
    
    func displayData(timeTblData:TimeTableModel) {
        
        var arrData = [timeTblData.Lecture,
                       timeTblData.Subject == "" ? "-" : timeTblData.Subject,
                       timeTblData.StandardClass == "" ? "-" :timeTblData.StandardClass]
        
        var i = 0
        for view in self.contentView.subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                
                i += 1
            }else{
                let btn:UIButton = view as! UIButton
                btn.accessibilityValue = timeTblData.LectureID
                
                btn.setBackgroundImage(UIImage.init(named: "NavBarIconSearchCircle_blue")?.withRenderingMode(.alwaysTemplate), for: .normal)
                if(timeTblData.LectureID == "0"){
                    btn.tintColor = getcolor.blue
                    btn.setTitleColor(getcolor.blue, for: .normal)
                    btn.setTitle("+", for: .normal)
                }else{
                    btn.tintColor = .red
                    btn.setTitleColor(.red, for: .normal)
                    btn.setTitle("×", for: .normal)
                }
            }
        }
    }
    
    @IBAction func btnAddDeleteClicked(_ sender:UIButton)
    {
        delegate.addDeleteTimeTable(sender)
    }
}

// MARK: - SyllabusCell

protocol SyllabusCellDelegate {
    func editSyllabus(_ sender:UIButton)
}

class SyllabusCell: UITableViewCell {
    
    @IBOutlet var btnEdit:UIButton!
    var delegate:SyllabusCellDelegate!
    
    func displayData(syllabusData:SyllabusModel,row:NSInteger) {
        
        var arrData = ["\(row)",syllabusData.TestName,syllabusData.StandardClass,syllabusData.Subject]
        
        var i = 0
        for lbl in (self.contentView.subviews.flatMap{$0 as? UILabel}) {
            lbl.text = arrData[i]
            
            i += 1
        }
    }
    
    @IBAction func btnEditClicked(_ sender:UIButton)
    {
        delegate.editSyllabus(sender)
    }
}

// MARK: - SyllabusPopupCell

var btnChooseDate:UIButton!
class SyllabusPopupCell: UITableViewCell {
    
    @IBOutlet var btnDate:UIButton!
    
    override func awakeFromNib() {
        
        for txtView in (self.contentView.subviews.flatMap{$0 as? UITextView}) {
            txtView.font = FontHelper.regular(size: isIpad ? 16 : 13)
        }
    }
    
    func displayHeaderData(syllabusData:SyllabusModel) {
        
        var arrData = [syllabusData.TestName,syllabusData.TestDate,syllabusData.StandardClass,syllabusData.Subject]
        
        var i = 0
        for view in self.contentView.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1) {
                
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontHelper.regular(size: isIpad ? 15 : 12)
                
                i += 1
                
            }else if(view.isKind(of: UIButton.classForCoder()) && view.tag == i+1) {
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
                let myDate = dateFormatter.date(from: arrData[i]!)!
                
                dateFormatter.dateFormat = "dd/MM/yyyy"
                let somedateString = dateFormatter.string(from: myDate)
                
                (view as! UIButton).titleLabel?.font = FontHelper.regular(size: isIpad ? 15 : 12)
                (view as! UIButton).setTitle(somedateString, for: .normal)
                i += 1
            }else{
                (view as! UILabel).font = FontHelper.medium(size: isIpad ? 15 : 12)
            }
        }
    }
}

// MARK: - LessonPlanCell

protocol LessonPlanCellDelegate {
    func downloadPdfWord(_ sender:UIButton)
}

class LessonPlanCell: UITableViewCell {
    
    var delegate:LessonPlanCellDelegate!
    
    func displayData(lessonPlanData:LessonPlanModel) {
        
        var arrData = [lessonPlanData.ChapterNo,
                       lessonPlanData.ChapterName]
        
        var i = 0
        for view in self.contentView.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag != -1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]?.removeHtmlFromString(inPutString: arrData[i]!)
                
                i += 1
            }else{
                view.accessibilityValue = lessonPlanData.ID?.stringValue
            }
        }
    }
    
    @IBAction func btnDownloadPdfWord(_ sender:UIButton){
        delegate.downloadPdfWord(sender)
    }
}

// MARK: - RequestCell

protocol RequestCellDelegate {
    func addStudentIds(_ modal:StudentModel, _ sender:VKCheckbox, _ previousID:NSNumber)
}

class RequestCell: UITableViewCell {
    
    @IBOutlet var checkBox:VKCheckbox!
    @IBOutlet var lblStudentName:UILabel!
    @IBOutlet var lblGRNO:UILabel!
    
    var delegate:RequestCellDelegate!
    
    override func awakeFromNib() {
        self.checkBox.line             = .normal
        self.checkBox.bgColorSelected  = getcolor.blue
        self.checkBox.color            = .white
        self.checkBox.borderColor      = getcolor.blue
        self.checkBox.borderWidth      = 1.0
        self.checkBox.cornerRadius     = 5.0
    }
    
    func displayData(stuData:StudentModel) {
        
        var arrData:[String] = [stuData.StudentName!,stuData.GRNO!]
        
        var i = 0
        for lbl in (self.contentView.subviews.flatMap{$0 as? UILabel}) {
            lbl.text = arrData[i]
            
            i += 1
        }
        
        if(stuData.Status == true){
            self.checkBox.setOn(true, animated: true)
        } else{
            self.checkBox.setOn(false, animated: false)
        }
        
        self.checkBox.checkboxValueChangedBlock = {
            isOn in
            print("Custom checkbox is \(isOn ? "ON" : "OFF")")
            let modal:StudentModel!
            modal = stuData
            modal.Status = isOn ? true : false
            self.delegate.addStudentIds(modal, self.checkBox, modal.StudentID!)
        }
    }
}

// MARK: - SentInboxCell

protocol SentInboxCellDelegate {
    func deleteRequest(_ sender:UIButton)
}

class SentInboxCell: UITableViewCell {
    
    @IBOutlet var lblUserName:UILabel!
    @IBOutlet var lblSubjectLine:UILabel!
    @IBOutlet var lblMeetingDate:UILabel!
    @IBOutlet var lblView:UILabel!
    @IBOutlet var viewHeight:NSLayoutConstraint!
    
    @IBOutlet var lblDescription:UILabel!
    @IBOutlet var btnDelete:UIButton!
    
    var delegate:SentInboxCellDelegate!
    
    func displayHeaderData(inboxSentModal:InboxSentModel) {
        
        lblUserName.text = inboxSentModal.UserName
        lblSubjectLine.text = inboxSentModal.SubjectLine
        lblMeetingDate.text = inboxSentModal.MeetingDate
        
        for lbls in self.contentView.subviews[0].subviews[0].subviews{
            let lbl:UILabel = lbls as! UILabel
            lbl.font = FontHelper.medium(size: isIpad ? 16 : 13)
        }
        
        for lbls in self.contentView.subviews[0].subviews[1].subviews{
            let lbl:UILabel = lbls as! UILabel
            if(lbl.tag != 1) {
                if(inboxSentModal.ReadStatus == "Pending"){
                    lbl.font = FontHelper.medium(size: isIpad ? 16 : 13)
                }else{
                    lbl.font = FontHelper.regular(size: isIpad ? 16 : 13)
                }
            }
        }
    }
    
    func displayData(inboxSentModal:InboxSentModel) {
        lblDescription.text = inboxSentModal.Description
    }
    
    @IBAction func btnDeleteClicked(_ sender:UIButton)
    {
        delegate.deleteRequest(sender)
    }
}

protocol LessonPlanScheduleCellDelegate {
    func studentHomeWorkStatus(_ sender:UIButton)
}

class LessonPlanScheduleCell: UITableViewCell {
    
    @IBOutlet var btnExpand:UIButton!
    var delegate:LessonPlanScheduleCellDelegate!
    
    func displayLessonPlanScheduleHeaderData(_ lpScheduleData:LessonPlanScheduleModel)
    {
        var arrData:[String] = [lpScheduleData.Date!, lpScheduleData.Standard!, lpScheduleData.ClassName!, lpScheduleData.Subject!]
        
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontHelper.medium(size: isIpad ? 16 : 13)
        }
        
        var i = 0
        for lbl in (self.contentView.subviews[0].subviews[1].subviews.flatMap{$0 as? UILabel}) {
            lbl.text = arrData[i]
            lbl.font = FontHelper.regular(size: isIpad ? 16 : 13)
            
            i += 1
        }
    }
    
    func displayLessonPlanScheduleData(_ lpScheduleData:LessonPlanScheduleModel)
    {
        var arrData:[NSAttributedString] = [lpScheduleData.ChapterName!, lpScheduleData.HomeWork!, lpScheduleData.Objective!, lpScheduleData.AssessmentQue!]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.attributedText = arrData[i].string == "" ? NSAttributedString.init(string: "-") : arrData[i]
                
                i += 1
            }
        }
    }
    
    @IBAction func btnStudentHomeWorkStatusAction(_ sender:UIButton)
    {
        delegate.studentHomeWorkStatus(sender)
    }
}

protocol HomeWorkStatusCellDelegate {
    func studentHomeWorkStatusUpdate(_ idx:NSInteger, _ superViewTag:NSInteger)
}

class HomeWorkStatusCell: UITableViewCell {
    
    var delegate:HomeWorkStatusCellDelegate!
    
    func displayData(_ homeWorkStatusModal:HomeWorkStatusModel)
    {
        var homeWorkStatus = homeWorkStatusModal.HomeWorkStatus
        if homeWorkStatus == -1 {
            homeWorkStatus = 2
        }else{
            homeWorkStatus = homeWorkStatusModal.HomeWorkStatus! + 1
        }
        
        for view in self.contentView.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == -2){
                let lbl:UILabel = view as! UILabel
                lbl.text = homeWorkStatusModal.StudentName?.capitalized
                lbl.font = FontHelper.regular(size: 14)
                
            }else if(view.isKind(of: LTHRadioButton.classForCoder())){
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = getcolor.blue
                radioButton.deselectedColor = .lightGray
                
                if(radioButton.tag == homeWorkStatus){
                    radioButton.select(animated: true)
                }else{
                    radioButton.deselect(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            }else{
                let lbl:UILabel = view as! UILabel
                lbl.font = FontHelper.regular(size: 14)
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.addGestureRecognizer(tapGesture)
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in self.contentView.subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.font = FontHelper.regular(size: 14)
                
            }else if(view.isKind(of: LTHRadioButton.classForCoder())){
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.deselect(animated: true)
            }
        }
        
        let tag:NSInteger = gesture.view!.tag - 10 > 0 ? gesture.view!.tag - 10 : gesture.view!.tag
        let radioButton:LTHRadioButton = self.contentView.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        (self.contentView.viewWithTag(tag + 10) as! UILabel).font = FontHelper.medium(size: 14)
        
        delegate.studentHomeWorkStatusUpdate(tag-1, (self.tag/100) - 1)
    }
}

// MARK: - WorkPlanCell

protocol WorkPlanCellDelegate {
    func workPlanStatusUpdate(_ idx:NSInteger, _ cell:WorkPlanCell)
}

class WorkPlanCell: UITableViewCell {
    
    @IBOutlet var lblView:UILabel!
    var delegate:WorkPlanCellDelegate!
    
    func displayHeaderData(_ workPlanData:WorkPlanModel) {
        
        var arrData:[String] = [workPlanData.Standard!, workPlanData.ClassName!, workPlanData.Subject!, workPlanData.Month!]
        
        for lbl in (self.contentView.subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontHelper.medium(size: isIpad ? 16 : 13)
        }
        
        var i = 0
        for view in self.contentView.subviews[1].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == -1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontHelper.regular(size: isIpad ? 16 : 13)
                
                i += 1
            }else{
                lblView.font = FontHelper.regular(size: isIpad ? 16 : 13)
            }
        }
    }
    
    func displayData(_ workPlanData:WorkPlanModel) {
        
        var arrData = [workPlanData.Work!, workPlanData.FromDate!, workPlanData.ToDate!, workPlanData.Status!] as [Any]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i] as? String
                
                i += 1
            }else if(view.isKind(of: LTHRadioButton.classForCoder())){
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = getcolor.blue
                radioButton.deselectedColor = .lightGray
                
                let tag = workPlanData.Status! + 10
                if(radioButton.tag == tag){
                    radioButton.select(animated: true)
                }else{
                    radioButton.deselect(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.addGestureRecognizer(tapGesture)
            }else{
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.addGestureRecognizer(tapGesture)
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        let tag:NSInteger = gesture.view!.tag - 100 > 0 ? gesture.view!.tag - 100 : gesture.view!.tag
        
        delegate.workPlanStatusUpdate(tag - 10, self)
    }
}

// MARK: - DailyWorkCell

protocol DailyWorkCellDelegate {
    func studentHomeWorkStatus(_ sender:UIButton)
}

class DailyWorkCell: UITableViewCell {
    
    @IBOutlet var btnExpand:UIButton!
    var delegate:DailyWorkCellDelegate!
    
    func displayWorkPlanHeaderData(_ dailyWorkData:DailyWorkModel)
    {
        var arrData:[String] = [dailyWorkData.Date!, dailyWorkData.Standard!, dailyWorkData.ClassName!, dailyWorkData.Subject!]
        
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontHelper.medium(size: isIpad ? 16 : 13)
        }
        
        var i = 0
        for lbl in (self.contentView.subviews[0].subviews[1].subviews.flatMap{$0 as? UILabel}) {
            lbl.text = arrData[i]
            lbl.font = FontHelper.regular(size: isIpad ? 16 : 13)
            
            i += 1
        }
    }
    
    func displayWorkPlanData(_ dailyWorkData:DailyWorkModel)
    {
        var arrData:[NSAttributedString] = [dailyWorkData.WorkPlan!, dailyWorkData.HomeWork!, dailyWorkData.ClassWork!]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.attributedText = arrData[i]
                
                i += 1
            }
        }
    }
    
    @IBAction func btnStudentHomeWorkStatusAction(_ sender:UIButton)
    {
        delegate.studentHomeWorkStatus(sender)
    }
}
