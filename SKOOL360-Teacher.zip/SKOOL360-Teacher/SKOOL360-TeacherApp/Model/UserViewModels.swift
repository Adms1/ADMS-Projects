//
//  UserViewModels.swift
//  Chatt
//
//  Created by ADMS on 11/08/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class LoginData: NSObject {
    
    var userName:String?
    var password:String?
    
    var staffName:String?
    var staffDesignation:String?
    var staffProfile:String?
    
    init(userName:String, password:String)
    {
        self.userName = userName
        self.password = password
    }
    
    init(staffName:String, staffDesignation:String, staffProfile:String)
    {
        self.staffName = staffName
        self.staffDesignation = staffDesignation
        self.staffProfile = staffProfile
    }
}

class RequestData: NSObject {
    
    var txtSubject:String?
    var txtDescription:String?
    
    init(txtSub:String, txtDes:String)
    {
        self.txtSubject = txtSub
        self.txtDescription = txtDes
    }
}

class AddTimeTableData: NSObject {
    
    var StdId:String!
    var ClassID:String!
    var SubjectID:String!
    var StartLTime:String!
    var StartMTime:String!
    var EndLTime:String!
    var EndMTime:String!

    init(stdId:String, clsId:String, subId:String, strL:String, strM:String, endM:String, endL:String)
    {
        self.StdId = stdId
        self.ClassID = clsId
        self.SubjectID = subId
        self.StartLTime = strL
        self.StartMTime = strM
        self.EndLTime = endM
        self.EndMTime = endL
    }
}

