//
//  AppDelegate.m
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "AppDelegate.h"
#import "ADTransitionController.h"
#import "ADNavigationControllerDelegate.h"
#import <UserNotifications/UserNotifications.h>

#define SYSTEM_VERSION_GRATERTHAN_OR_EQUALTO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

NSString *pushDate;
BOOL isFromPush;

@interface AppDelegate ()<UNUserNotificationCenterDelegate>
{
    ADNavigationControllerDelegate * _navigationDelegate;
}
@end

@implementation AppDelegate

@synthesize window;
@synthesize viewLogin;

+(AppDelegate*)sharedAppDelegate
{
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    /* Create Direcory */
    NSString *catchDir  = [self applicationCacheDirectory];
    NSString *dataPath = [catchDir stringByAppendingPathComponent:@"/DownloadPapers"];
    NSLog(@"FilePath %@",dataPath);
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath]){
        [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:NO attributes:nil error:nil];
    }
    
    if([[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID] != nil && [[[NSUserDefaults standardUserDefaults] objectForKey:@"ISLOGIN"] boolValue]) {
        [self createAccountOrLogin];
    }
    else {
        [self setLoginview];
    }
    
    //    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"ISLOGIN"] isEqualToString:@"YES"]) {
    //        if ([[[NSUserDefaults standardUserDefaults]objectForKey:REMEMBERME] isEqualToString:@"YES"]) {
    //            [self createAccountOrLogin];
    //        }else{
    //            [self setLoginview];
    //        }
    //    }else{
    //        [self setLoginview];
    //    }
    
    [FIRApp configure];
    [[Fabric sharedSDK]setDebug:YES];
    
    //
    //    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_9_x_Max) {
    //        UIUserNotificationType allNotificationTypes =
    //        (UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge);
    //        UIUserNotificationSettings *settings =
    //        [UIUserNotificationSettings settingsForTypes:allNotificationTypes categories:nil];
    //        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    //    } else {
    //        // iOS 10 or later
    //#if defined(__IPHONE_10_0) && __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_10_0
    //        // For iOS 10 display notification (sent via APNS)
    //        [UNUserNotificationCenter currentNotificationCenter].delegate = self;
    //        UNAuthorizationOptions authOptions =
    //        UNAuthorizationOptionAlert
    //        | UNAuthorizationOptionSound
    //        | UNAuthorizationOptionBadge;
    //        [[UNUserNotificationCenter currentNotificationCenter] requestAuthorizationWithOptions:authOptions completionHandler:^(BOOL granted, NSError * _Nullable error) {
    //        }];
    //#endif
    //    }
    //
    //    [[UIApplication sharedApplication] registerForRemoteNotifications];
    [self needsUpdate];
    NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);    // Normal launch stuff
    
    return YES;
}

-(void)registerForPushNotification:(BOOL)isRegister
{
    if(isRegister)
    {
        if(SYSTEM_VERSION_GRATERTHAN_OR_EQUALTO(@"10.0")){
            UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
            center.delegate = self;
            [center requestAuthorizationWithOptions:(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error){
                if(!error){
                    [[UIApplication sharedApplication] registerForRemoteNotifications];
                }
            }];
        }
        else {
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
            {
                [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
                [[UIApplication sharedApplication] registerForRemoteNotifications];
            }
            else
            {
                [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
                 (UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert)];
            }
        }
    }
    else
    {
        [[UIApplication sharedApplication] unregisterForRemoteNotifications];
    }
    //[UIApplication sharedApplication].applicationIconBadgeNumber = 0;
}

-(BOOL) needsUpdate{
    NSDictionary* infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString* appID = infoDictionary[@"CFBundleIdentifier"];
    NSString *prodName = infoDictionary[@"CFBundleDisplayName"];
    NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"http://itunes.apple.com/lookup?bundleId=%@", appID]];
    NSData* data = [NSData dataWithContentsOfURL:url];
    NSDictionary* lookup = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    
    if ([lookup[@"resultCount"] integerValue] == 1){
        NSString* appStoreVersion = lookup[@"results"][0][@"version"];
        NSString* currentVersion = infoDictionary[@"CFBundleShortVersionString"];
        //        if (![appStoreVersion isEqualToString:currentVersion]){
        //            NSLog(@"Need to update [%@ != %@]", appStoreVersion, currentVersion);
        //            //[self setupForUpdate:appStoreVersion :prodName];
        //            return YES;
        //        }
        if([currentVersion floatValue] < [appStoreVersion floatValue]){
            [self setupForUpdate:appStoreVersion :prodName];
            return YES;
        }
    }
    return NO;
}
-(void)setupForUpdate:(NSString *)strAppversion :(NSString *)strAppName
{
    UIAlertController * alert=[UIAlertController alertControllerWithTitle:appUpdateTitle
                                                                  message:[[appUpdateMsg stringByReplacingOccurrencesOfString:@"{}" withString:strAppName]stringByReplacingOccurrencesOfString:@"()" withString:strAppversion]
                                                           preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Later"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
                                {
                                    exit(0);
                                }];
    
    UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"Update"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action)
                               {
                                   NSString *iTunesLink = @"itms://itunes.apple.com/us/app/apple-store/id1280927478?mt=8";
                                   [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    self.window.windowLevel = UIWindowLevelAlert + 1;
    [self.window makeKeyAndVisible];
    [self.window.rootViewController presentViewController:alert animated:YES completion:nil];
    
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    //[UIApplication sharedApplication].applicationIconBadgeNumber += 1;
}

- (void)applicationWillTerminate:(UIApplication *)application {
    //    if (![[[NSUserDefaults standardUserDefaults]objectForKey:REMEMBERME] isEqualToString:@"YES"]) {
    //        NSLog(@"Terminate App...");
    //        [self registerForPushNotification:NO];
    //    }
}

void uncaughtExceptionHandler(NSException *exception) {
    NSLog(@"CRASH: %@", exception);
    NSLog(@"Stack Trace: %@", [exception callStackSymbols]);
    // Internal error reporting
    
    //[[[UIAlertView alloc]initWithTitle:provideAlert message:@"Test" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
}

//- (void)readPlist
//{
//    NSString *localizedPath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"plist"];
//    NSMutableDictionary* plistDict = [[NSMutableDictionary alloc] initWithContentsOfFile:localizedPath];
//    
//    NSString *crashed;
//    crashed = [plistDict objectForKey:@"Crashed"];
//}
//
//- (void)writeToPlist
//{
//    NSMutableDictionary* plistDict = [[NSMutableDictionary alloc] initWithContentsOfFile:filePath];
//    
//    [plistDict setValue:@"YES" forKey:@"Crashed"];
//    [plistDict writeToFile:filePath atomically: YES];
//}

#pragma mark - FCM Push Notification Delegates

//- (void)messaging:(nonnull FIRMessaging *)messaging didRefreshRegistrationToken:(nonnull NSString *)fcmToken {
//
//    NSLog(@"FCM registration token: %@", fcmToken);
//}
//
//- (void)application:(UIApplication *)application
//didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
//    [FIRMessaging messaging].APNSToken = deviceToken;
//}

//- (void)applicationReceivedRemoteMessage:(nonnull FIRMessagingRemoteMessage *)remoteMessage
//{
//    NSLog(@"%@",remoteMessage.appData);
//}

#pragma mark - Push Notification Delegates

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings // NS_AVAILABLE_IOS(8_0);
{
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    UIDevice *device = [UIDevice currentDevice];
    NSString  *currentDeviceId = [[device identifierForVendor]UUIDString];
    
    NSString * deviceTokenString = [[[[deviceToken description]
                                      stringByReplacingOccurrencesOfString: @"<" withString: @""]
                                     stringByReplacingOccurrencesOfString: @">" withString: @""]
                                    stringByReplacingOccurrencesOfString: @" " withString: @""];
    
    NSLog(@"Current device ID string is : %@",currentDeviceId);
    NSLog(@"The generated device token string is : %@",deviceTokenString);
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault setObject:currentDeviceId forKey:DeviceID];
    [userDefault setObject:deviceTokenString forKey:DeviceToken];
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
    NSLog(@"Error: %@",error.description);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification: (NSDictionary *)userInfo
{
    NSLog(@"Received notification: %@", userInfo);
    //[UIApplication sharedApplication].applicationIconBadgeNumber += 1;
    
    if(application.applicationState == UIApplicationStateActive)
    {
        NSLog(@"AS");
        //        UILocalNotification *localNotification = [[UILocalNotification alloc] init];
        //        localNotification.userInfo = userInfo;
        //        localNotification.soundName = UILocalNotificationDefaultSoundName;
        //        localNotification.alertBody = @"Skool360";
        //        localNotification.fireDate = [[NSDate alloc]initWithTimeInterval:5 sinceDate:[NSDate date]];
        //        [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
        //        [[UIApplication sharedApplication]presentLocalNotificationNow:localNotification];
        //        UILocalNotification *localNotification = [[UILocalNotification alloc] init];
        //        localNotification.userInfo = userInfo;
        //        localNotification.soundName = UILocalNotificationDefaultSoundName;
        //        localNotification.alertBody = @"Test";
        //        localNotification.fireDate = [NSDate date];
        //        [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
        
        GLNotificationBar *notificationBar = [[GLNotificationBar alloc]initWithTitle:@"" message:[[userInfo valueForKey:@"aps"]valueForKey:@"alert"] preferredStyle:GLNotificationStyleSimpleBanner handler:^(BOOL finish) {
            [self pushNavigation:[userInfo valueForKey:@"aps"]];
        }];
        [notificationBar notificationSound:@"solemn" ofType:@".mp3" vibrate:YES];
    }
    else
    {
        [self pushNavigation:[userInfo valueForKey:@"aps"]];
    }
}

////...........Handling delegate methods for UserNotifications........
//Called when a notification is delivered to a foreground app.

-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions options))completionHandler{
    NSLog(@"User Info : %@",notification.request.content.userInfo);
    completionHandler(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge);
}

//Called to let your app know which action was selected by the user for a given notification.

-(void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void(^)())completionHandler{
    NSLog(@"User Info : %@",response.notification.request.content.userInfo);
    [self pushNavigation:[response.notification.request.content.userInfo valueForKey:@"aps"]];
    completionHandler();
}

-(void)pushNavigation:(NSDictionary *)dict
{
    BOOL animated = NO;
    if (self.window.rootViewController.childViewControllers.count > 0)
    {
        if([dict[@"category"] isEqualToString:@"HW"]){
            animated = [self.window.rootViewController.childViewControllers.lastObject isKindOfClass:[HomeWorkViewController class]];
        }else if([dict[@"category"] isEqualToString:@"CW"]){
            animated = [self.window.rootViewController.childViewControllers.lastObject isKindOfClass:[ClassWorkViewController class]];
        }else if([dict[@"category"] isEqualToString:@"Attendance"]){
            animated = [self.window.rootViewController.childViewControllers.lastObject isKindOfClass:[AttendanceView class]];
        }else if([dict[@"category"] isEqualToString:@"Announcement"]){
            animated = [self.window.rootViewController.childViewControllers.lastObject isKindOfClass:[AnnouncementViewController class]];
        }else if([dict[@"category"] isEqualToString:@"Circular"]){
            animated = [self.window.rootViewController.childViewControllers.lastObject isKindOfClass:[CircularViewController class]];
        }
    }
    
    isFromPush = YES;
    pushDate = dict[@"Date"];
    if([dict[@"category"] isEqualToString:@"HW"]){
        [SHARED_APPDELEGATE setViewController:[HomeWorkViewController new] :YES :@"Home Work" :!animated];
    }else if([dict[@"category"] isEqualToString:@"CW"]){
        [SHARED_APPDELEGATE setViewController:[ClassWorkViewController new] :YES :@"Class Work" :!animated];
    }else if([dict[@"category"] isEqualToString:@"Attendance"]){
        [SHARED_APPDELEGATE setViewController:[AttendanceView new] :YES :@"Attendance" :!animated];
    }else if([dict[@"category"] isEqualToString:@"Announcement"]){
        [SHARED_APPDELEGATE setViewController:[AnnouncementViewController new] :YES :@"Announcement" :!animated];
    }else if([dict[@"category"] isEqualToString:@"Circular"]){
        [SHARED_APPDELEGATE setViewController:[CircularViewController new] :YES :@"Circular" :!animated];
    }
}

#pragma mark -
#pragma mark - LoginView Method

-(void)setLoginview
{
    [self registerForPushNotification:NO];
    viewLogin = [[LoginView alloc] initWithNibName:@"LoginView" bundle:nil];
    self.navigationController = [[UINavigationController alloc] initWithRootViewController:viewLogin];
    window.rootViewController = self.navigationController;
    
    [window makeKeyAndVisible];
}

#pragma mark -
#pragma mark - TextField Padding Method

-(UIView*)getTextFieldLeftAndRightView
{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(20, 0, 10, 10)];
    return paddingView;
}

#pragma mark -
#pragma mark - NavigationBarColor

-(UIImage *)imageFromColor:(UIColor *)color {
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

#pragma mark -
#pragma mark - SideMenu View NavigationBar Image

-(void)setDeshBoardNavigationImg
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [[UINavigationBar appearance]setBackgroundImage:[UIImage imageNamed:@"deshboardNavigation"]forBarMetrics:UIBarMetricsDefault];
}

#pragma mark -
#pragma mark - Create Account Or Login Methods

-(void)createAccountOrLogin
{
    [self registerForPushNotification:YES];
    [self setDeshBoardNavigationImg];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HomeView *homeView =  [storyBoard instantiateViewControllerWithIdentifier:@"HomeView"];
    self.navigationController = [[UINavigationController alloc] initWithRootViewController:homeView];
    _navigationDelegate = [[ADNavigationControllerDelegate alloc] init];
    ((UINavigationController *)self.navigationController).delegate = _navigationDelegate;
    self.window.rootViewController = self.navigationController;
}

#pragma mark -
#pragma mark - SideMenuViewController Methods

-(void)setDeshBoardViewController
{
    [self createAccountOrLogin];
}

-(void)rootViewControllerAnimation:(UIViewController *)viewController
{
    self.navigationController = [[UINavigationController alloc] initWithRootViewController:viewController];
    UIView *snapShot = [self.window snapshotViewAfterScreenUpdates:YES];
    [self.navigationController.view addSubview:snapShot];
    self.window.rootViewController = self.navigationController;
    [UIView animateWithDuration:0.5 animations:^{
        snapShot.layer.opacity = 0;
        snapShot.layer.transform = CATransform3DMakeScale(0.01, 0.01, 1.0);
    } completion:^(BOOL finished) {
        [snapShot removeFromSuperview];
    }];
}

-(void)setViewController:(ADTransitioningViewController *)viewController :(BOOL)isStroryBoard :(NSString *)headerTitle :(BOOL)animated
{
    ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:viewController.view.frame];
    if (isStroryBoard)
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        viewController = [storyBoard instantiateViewControllerWithIdentifier:NSStringFromClass([viewController class])];
    }
    else
    {
        viewController = [[[viewController class] alloc] initWithNibName:NSStringFromClass([viewController class]) bundle:nil];
    }
    viewController.title = headerTitle;
    viewController.transition = animation;
    [self.navigationController pushViewController:viewController animated:animated];
}

#pragma mark -
#pragma mark - Loading View

-(void)showLoadingView
{
    if (loadView == nil)
    {
        loadView = [[UIView alloc] initWithFrame:self.window.frame];
        loadView.opaque = NO;
        loadView.backgroundColor = [UIColor clearColor];
        //loadView.alpha = 0.7f;
        
        viewBack = [[UIView alloc] initWithFrame:CGRectMake(80, 230, 160, 50)];
        viewBack.backgroundColor = [UIColor blackColor];
        viewBack.alpha = 0.7f;
        viewBack.layer.masksToBounds = NO;
        viewBack.layer.cornerRadius = 5;
        
        lblLoading = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, 110, 50)];
        lblLoading.backgroundColor = [UIColor clearColor];
        lblLoading.textAlignment = NSTextAlignmentCenter;
        lblLoading.text = @"Please Wait...";
        lblLoading.numberOfLines = 2;
        
        spinningWheel = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(5.0, 10.0, 30.0, 30.0)];
        spinningWheel.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhite;
        lblLoading.textColor = [UIColor whiteColor];
        [spinningWheel startAnimating];
        [viewBack addSubview:spinningWheel];
        
        [viewBack addSubview:lblLoading];
        [loadView addSubview:viewBack];
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            
            float y = (loadView.frame.size.height/2 ) - (viewBack.frame.size.height/2);
            float x =(loadView.frame.size.width/2 ) - (viewBack.frame.size.width/2);
            viewBack.frame = CGRectMake(x , y, 160, 50);;
        }
        else{
            
            float y = (loadView.frame.size.height/2 ) - (viewBack.frame.size.height/2);
            float x =(loadView.frame.size.width/2 ) - (viewBack.frame.size.width/2);
            viewBack.frame = CGRectMake(x , y, 160, 50);;
        }
    }
    if(loadView.superview == nil)
        [self.window addSubview:loadView];
}

-(void) hideLoadingView
{
    [loadView removeFromSuperview];
    loadView=nil;
}

-(NSString *)applicationCacheDirectory
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

-(NSString *)getPapersPathFromURL:(NSString *)stringUrl
{
    NSString *videoName = [[stringUrl componentsSeparatedByString:@"/"] lastObject];
    
    NSString *catchDir  = [[AppDelegate sharedAppDelegate] applicationCacheDirectory];
    NSString *dataPath = [catchDir stringByAppendingPathComponent:@"/DownloadPapers"];
    dataPath = [dataPath stringByAppendingPathComponent:videoName];
    
    return dataPath;
}

#pragma mark - Application's Documents directory

// Returns the URL to the application's Documents directory.
- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

@end
