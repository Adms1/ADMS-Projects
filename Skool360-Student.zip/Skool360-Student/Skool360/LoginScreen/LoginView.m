//
//  LoginView.m
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "LoginView.h"
#import "CommonClass.h"
#import "HomeView.h"
#import "AppDelegate.h"
#import "ForgotPasswordVC.h"
#import "ParentVC.h"

@interface LoginView ()

@end

@implementation LoginView

AppDelegate *appDelegateLogin;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setZoneTitle:@"LOG IN" andZone:@"TO EXISTING ACCOUNT"];
    
    appDelegateLogin = [AppDelegate sharedAppDelegate];
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    txtUserName.leftView = [appDelegateLogin getTextFieldLeftAndRightView];
    txtUserName.rightView = [appDelegateLogin getTextFieldLeftAndRightView];
    txtUserName.leftViewMode = UITextFieldViewModeAlways;
    txtUserName.rightViewMode = UITextFieldViewModeAlways;
    
    txtPassword.leftView = [appDelegateLogin getTextFieldLeftAndRightView];
    txtPassword.rightView = [appDelegateLogin getTextFieldLeftAndRightView];
    txtPassword.leftViewMode = UITextFieldViewModeAlways;
    txtPassword.rightViewMode = UITextFieldViewModeAlways;
}

-(void)setZoneTitle:(NSString *)time andZone:(NSString *)zone
{
    NSString *strTotalString = [NSString stringWithFormat:@"%@ %@", time , zone];
    
    NSRange range1 = NSMakeRange(0, [time length]);
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:strTotalString];
    [attributedText setAttributes:@{NSFontAttributeName:FONT_Semibold(IS_IPAD ? 16: 14) , NSForegroundColorAttributeName:appColor} range:range1];
    
    NSRange range2 = NSMakeRange([time length]+1, [zone length]);
    [attributedText setAttributes:@{NSFontAttributeName:FONT_Semibold(IS_IPAD ? 16:14), NSForegroundColorAttributeName:txtFieldColor} range:range2];
    
    lblTitle.attributedText = attributedText;
}

#pragma mark -
#pragma mark - TextField Return Keyboard Method

-(void)hideallKeyBoard
{
    if([txtUserName isFirstResponder]){
        [txtUserName resignFirstResponder];
    }
    if([txtPassword isFirstResponder]){
        [txtPassword resignFirstResponder];
    }
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        return YES;
    }
    return NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGPoint point;
    
    if (textField == txtUserName) {
        point = CGPointMake(0, 0);
    }else if(textField == txtPassword){
        point = CGPointMake(0, 0);
    }
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

-(BOOL)loginValidate
{
    NSString *strLoginUserName  = [CommonClass trimString:txtUserName.text];
    NSString *strLoginPassword  = [CommonClass trimString:txtPassword.text];
    
    if ([strLoginUserName length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        return NO;
    }
    if ([strLoginPassword length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePassword delegate:self];
        return NO;
    }
    return  YES;
}

#pragma mark -
#pragma mark - REMEMBER_ME METHOD

- (IBAction)onClickRememberBtn:(id)sender {
    
    if ([btnRemember isSelected]) {
        btnRemember.selected = NO;
    }else{
        btnRemember.selected = YES;
    }
}

#pragma mark -
#pragma mark - LOGIN METHOD
- (IBAction)onClickLoginBtn:(id)sender {
    
    if ([self loginValidate]) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [params setObject:txtUserName.text forKey:@"UserID"];
        [params setObject:txtPassword.text forKey:@"Password"];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSLog(@"params>>> %@",params);
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        NSLog(@"Url %@",login_Url);
        
        [manager POST:login_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                NSMutableArray *arrLogin = [responseObject safeObjectForKey:@"FinalArray"];
                
                if ([arrLogin count] > 0) {
                    
                    NSDictionary *dict = [arrLogin firstObject];
                    
                    if (btnRemember.isSelected == YES) {
                        [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:REMEMBERME];
                    }else{
                        [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:REMEMBERME];
                    }
                    
                    [userDefault setObject:txtPassword.text forKey:CLASSID];
                    [userDefault setObject:[dict safeObjectForKey:@"ClassID"] forKey:PASSWORD];
                    [userDefault setObject:[dict safeObjectForKey:@"FamilyID"] forKey:FAMILYID];
                    [userDefault setObject:[dict safeObjectForKey:@"StandardID"] forKey:STANDARDID];
                    [userDefault setObject:[dict safeObjectForKey:@"StudentID"] forKey:STUDENTID];
                    [userDefault setObject:[dict safeObjectForKey:@"TermID"] forKey:TERMID];
                    [userDefault setObject:[dict safeObjectForKey:@"RegisterStatus"] forKey:ISREGISTER];
                    [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:@"ISLOGIN"];
                    
                    [userDefault synchronize];
                    [self addDevice];
                }
            }else{
//                [BunbleName isEqualToString:@"Skool360"] && 
                if ([[responseObject safeObjectForKey:@"Status"] isEqualToString:@"1"]) {
                    [[self view]endEditing:YES];
                    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    ParentVC *pvc = (ParentVC *)[storyBoard instantiateViewControllerWithIdentifier:@"ParentVC"];
                    [self addChildViewController:pvc];
                    [self.view addSubview:pvc.view];
                    [pvc.view setFrame:self.view.bounds];
                    [pvc didMoveToParentViewController:self];
                }else {
                    [CommonClass showAlertWithTitle:provideAlert andMessage:@"Invalid Username/Password" delegate:self];
                }
            }
            [SHARED_APPDELEGATE hideLoadingView];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [CommonClass errorAlert:error.code];
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

-(void)addDevice
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [params setObject:[userDefault valueForKey:STUDENTID] forKey:@"StudentID"];
    [params setObject:[userDefault valueForKey:DeviceID] forKey:@"DeviceID"];
    [params setObject:[userDefault valueForKey:DeviceToken] forKey:@"TokenID"];
    [params setObject:@"I" forKey:@"DeviceType"];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:AddDeviceDetail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE createAccountOrLogin];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(IBAction)btnForgotPassword:(UIButton *)sender
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ForgotPasswordVC *fpvc = (ForgotPasswordVC *)[storyBoard instantiateViewControllerWithIdentifier:@"Forgot Password"];
    [self addChildViewController:fpvc];
    [self.view addSubview:fpvc.view];
    [fpvc.view setFrame:self.view.bounds];
    [fpvc didMoveToParentViewController:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
