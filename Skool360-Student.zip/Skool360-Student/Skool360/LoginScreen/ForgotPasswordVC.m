//
//  ForgotPasswordVC.m
//  Bhadaj (Student)
//
//  Created by ADMS on 17/07/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "ForgotPasswordVC.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface ForgotPasswordVC ()

@end

@implementation ForgotPasswordVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 18, 20)];
    imgView.image = [[UIImage imageNamed:@"MobileNo"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    imgView.tintColor = detaultColor;
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
    [paddingView addSubview:imgView];
    [txtCommunicationNo setRightViewMode:UITextFieldViewModeAlways];
    [txtCommunicationNo setRightView:paddingView];
    btnClose.layer.cornerRadius = btnClose.frame.size.width/2;
    btnForgotPassword.layer.cornerRadius = 4.0f;
    [lblInfo setFont:FONT_Semibold(IS_IPAD ? 20 : isiPhone5 ? 14 : 16)];
    
    UIToolbar* numberToolbar = [[UIToolbar alloc]init];
    numberToolbar.barStyle = UIBarStyleDefault;
    numberToolbar.items = [NSArray arrayWithObjects:
                           [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                           [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(btnDone:)],
                           nil];
    [numberToolbar sizeToFit];
    txtCommunicationNo.inputAccessoryView = numberToolbar;
}

-(void)viewWillAppear:(BOOL)animated
{
    UIView *mainView = self.view.subviews[0].subviews[0];
    mainView.layer.cornerRadius = 10.0;
    mainView.transform = CGAffineTransformMakeScale(0.1, 0.1);
    mainView.layer.cornerRadius = 5.0;
    
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        mainView.transform = CGAffineTransformMakeScale(1.0, 1.0);
    } completion:nil];
    
    btnClose.transform = CGAffineTransformMakeScale(0.1, 0.1);
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        btnClose.transform = CGAffineTransformMakeScale(1.0, 1.0);
    } completion:nil];
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    [self performShakeAnimation:textField :[UIColor lightGrayColor]];
    if(range.location > 9){
        return NO;
    }
    return YES;
}

-(BOOL)forgotPasswordValidate
{
    NSString *strMobileNo  = [CommonClass trimString:txtCommunicationNo.text];
    
    if ([strMobileNo length] == 0) {
        [self performShakeAnimation:txtCommunicationNo :[UIColor redColor]];
        [[[UIAlertView alloc]initWithTitle:provideAlert message:provideCommunicationNo delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
        return NO;
    }
    else if ([strMobileNo length] < 10) {
        [self performShakeAnimation:txtCommunicationNo :[UIColor redColor]];
        [[[UIAlertView alloc]initWithTitle:provideAlert message:provideValidCommunicationNo delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
        return NO;
    }
    return YES;
}

-(void)performShakeAnimation:(UITextField *)txtfld :(UIColor *)color
{
    txtfld.superview.subviews[[txtfld.superview.subviews indexOfObject:txtfld]+1].backgroundColor = color;
    if(color != [UIColor redColor]) {
        return;
    }
    
    txtfld.transform = CGAffineTransformMakeTranslation(20, 0);
    [UIView animateWithDuration:0.4 delay:0.0 usingSpringWithDamping:0.2 initialSpringVelocity:1.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        txtfld.transform = CGAffineTransformIdentity;
    } completion:nil];
}

-(IBAction)btnSendAction:(id)sender
{
    if([self forgotPasswordValidate])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [params setObject:txtCommunicationNo.text forKey:@"MobileNo"];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSLog(@"params>>> %@",params);
        
        [manager POST:forgetIDPassword_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                [self btnClose:btnClose];
            }else{
                [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"Message"] delegate:self];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [CommonClass errorAlert:error.code];

            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

-(IBAction)btnDone:(id)sender
{
    [[self view]endEditing:NO];
}

-(IBAction)btnClose:(UIButton *)sender
{
    sender.transform = CGAffineTransformMakeScale(1.0, 1.0);
    
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        sender.transform = CGAffineTransformMakeScale(0.1, 0.1);
    } completion:nil];
    
    UIView *mainView = self.view.subviews[0].subviews[0];
    mainView.transform = CGAffineTransformMakeScale(1.0, 1.0);
    
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        mainView.transform = CGAffineTransformMakeScale(0.1, 0.1);
    } completion:^(BOOL finished) {
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
