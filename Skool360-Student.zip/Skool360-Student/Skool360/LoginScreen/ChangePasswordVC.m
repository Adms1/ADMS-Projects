//
//  ForgotPasswordVC.m
//  Bhadaj (Student)
//
//  Created by ADMS on 17/07/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "ChangePasswordVC.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface ChangePasswordVC ()

@end

@implementation ChangePasswordVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray<UITextField *> *arrTxtFlds = @[txtNewPassword, txtConfirmPassword];
    
    for (UITextField *txtField in arrTxtFlds)
    {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 18, 20)];
        imgView.image = [[UIImage imageNamed:@"Change Password"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        imgView.tintColor = detaultColor;
        
        UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
        [paddingView addSubview:imgView];
        [txtField setRightViewMode:UITextFieldViewModeAlways];
        [txtField setRightView:paddingView];
    }
    btnChangePassword.layer.cornerRadius = 4.0f;
}

-(void)viewWillAppear:(BOOL)animated
{
    UIView *mainView = self.view.subviews[0].subviews[0];
    mainView.layer.cornerRadius = 10.0;
    mainView.transform = CGAffineTransformMakeScale(0.1, 0.1);
    mainView.layer.cornerRadius = 5.0;
    
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        mainView.transform = CGAffineTransformMakeScale(1.0, 1.0);
    } completion:nil];
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        return YES;
    }
    return NO;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    [self performShakeAnimation:textField :[UIColor lightGrayColor]];
    return YES;
}

-(BOOL)changePasswordValidate
{
    NSString *strNewPassword  = [CommonClass trimString:txtNewPassword.text];
    NSString *strConfirmPassword  = [CommonClass trimString:txtConfirmPassword.text];
    
    if ([strNewPassword length] == 0) {
        [self performShakeAnimation:txtNewPassword :[UIColor redColor]];
        //        [CommonClass showAlertWithTitle:provideAlert andMessage:provideNewPassword delegate:self];
        [[[UIAlertView alloc]initWithTitle:provideAlert message:provideNewPassword delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
        return NO;
    }
    else if ([strNewPassword length] < 4 || [strNewPassword length] > 12) {
        [self performShakeAnimation:txtNewPassword :[UIColor redColor]];
        //        [CommonClass showAlertWithTitle:provideAlert andMessage:provideNewPassword delegate:self];
        [[[UIAlertView alloc]initWithTitle:provideAlert message:provideValidNewPassword delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
        return NO;
    }
    else if ([strConfirmPassword length] == 0) {
        [self performShakeAnimation:txtConfirmPassword :[UIColor redColor]];
        //        [CommonClass showAlertWithTitle:provideAlert andMessage:provideConfirmNewPassword delegate:self];
        [[[UIAlertView alloc]initWithTitle:provideAlert message:provideConfirmNewPassword delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
        return NO;
    }
    else if (![strNewPassword isEqualToString:strConfirmPassword]) {
        [self performShakeAnimation:txtConfirmPassword :[UIColor redColor]];
        //        [CommonClass showAlertWithTitle:provideAlert andMessage:providePasswordNotMatch delegate:self];
        [[[UIAlertView alloc]initWithTitle:provideAlert message:providePasswordNotMatch delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
        return NO;
    }
    return YES;
}

-(void)performShakeAnimation:(UITextField *)txtfld :(UIColor *)color
{
    txtfld.superview.subviews[[txtfld.superview.subviews indexOfObject:txtfld]+1].backgroundColor = color;
    if(color != [UIColor redColor]) {
        return;
    }
    
    txtfld.transform = CGAffineTransformMakeTranslation(20, 0);
    [UIView animateWithDuration:0.4 delay:0.0 usingSpringWithDamping:0.2 initialSpringVelocity:1.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        txtfld.transform = CGAffineTransformIdentity;
    } completion:nil];
}

-(IBAction)btnChangePasswordAction:(id)sender
{
    if([self changePasswordValidate])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
        NSString *strOldPassword = [[NSUserDefaults standardUserDefaults]objectForKey:PASSWORD];
        
        [params setObject:strStudentID forKey:@"StudentID"];
        [params setObject:strOldPassword forKey:@"OldPassword"];
        [params setObject:txtNewPassword.text forKey:@"NewPassword"];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSLog(@"params>>> %@",params);
        
        [manager POST:changePassword_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                //                [self addDevice];
                [CommonClass showAlertWithTitle:provideAlert andMessage:provideSuccess delegate:self];
                
                [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:ISREGISTER];
                
                UIView *mainView = self.view.subviews[0].subviews[0];
                mainView.transform = CGAffineTransformMakeScale(1.0, 1.0);
                
                [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
                    mainView.transform = CGAffineTransformMakeScale(0.1, 0.1);
                } completion:^(BOOL finished) {
                    [self.view removeFromSuperview];
                    [self removeFromParentViewController];
                }];
                
            }else{
                [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"data"] delegate:self];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [CommonClass errorAlert:error.code];

            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
