//
//  CanteenViewController.h
//  Skool360
//
//  Created by Darshan on 05/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "CanteenCell.h"

@interface CanteenViewController : MasterViewController

{
    IBOutlet UIView *viewtitle;
    IBOutlet UIView *viewDatePicker;
    IBOutlet UIView *viewToolBar;
    
    IBOutlet UITableView *tblCanteen;
    
    IBOutlet UILabel *lblNoFound;
    
    IBOutlet UIImageView *imgLogo;
    
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    IBOutlet UIButton *btnMonth;
    IBOutlet UIButton *btnYear;
    IBOutlet UIButton *btnFilter;
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnCancel;
    
    IBOutlet UIDatePicker *pickerClassWorkDate;
    
    NSMutableArray *arrCanteenList;
    
    BOOL btnSelected;
    
    NSString *strClassToDate;
    NSString *strClassFromDate;
}
@end
