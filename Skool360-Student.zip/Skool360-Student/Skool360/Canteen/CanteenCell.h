//
//  CanteenCell.h
//  Skool360
//
//  Created by Darshan on 05/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Canteen.h"

@interface CanteenCell : UITableViewCell

{
    float cellHeight;
    
    IBOutlet UIView *dateView;
    
    IBOutlet UIImageView *imgIcon;
    
    IBOutlet UILabel *lblDate;
    IBOutlet UILabel *lblDay;
    IBOutlet UILabel *lblBrackFast;
    IBOutlet UILabel *lblLunch;
}

-(CGFloat )getCellHeight;

-(void)setCanteenListData:(Canteen *)objCanteen;

@end
