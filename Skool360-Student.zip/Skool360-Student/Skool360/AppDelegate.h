//
//  AppDelegate.h
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginView.h"
#import "SkoolSideMenu.h"
#import "HomeView.h"
#import "MyProfileView.h"
#import "AttendanceView.h"
#import "HomeWorkViewController.h"
#import "TimeTableViewControlle.h"
#import "ImprestViewController.h"
//#import "MainViewController.h"
//#import "CanteenViewController.h"
#import "FeesViewController.h"
#import "UnitTestViewController.h"
#import "ResultViewController.h"
#import "ReportCardViewController.h"
#import "ClassWorkViewController.h"
//#import "PrincipalMessageViewController.h"
#import "CircularViewController.h"
#import "LeaveListViewController.h"
#import "GalleryViewController.h"
#import "MainViewController.h"
#import "HolidayViewController.h"
#import "AnnouncementViewController.h"
#import "PlannerViewController.h"
#import "RFRateMe.h"
#import "Skool360Bhadaj-Swift.h"
//#import "Skool360-Swift.h"

//#import <UserNotifications/UserNotifications.h>
#import <Firebase/Firebase.h>
//#import <FirebaseInstanceID/FirebaseInstanceID.h>
//#import <FirebaseMessaging/FirebaseMessaging.h>

extern NSString *pushDate;
extern BOOL isFromPush;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIView *loadView;
    UIView *viewBack;
    UILabel *lblLoading;
    UIActivityIndicatorView *spinningWheel;
}

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic , strong) LoginView *viewLogin;

+(AppDelegate*)sharedAppDelegate;
-(UIView*)getTextFieldLeftAndRightView;
-(void)createAccountOrLogin;
-(void)showLoadingView;
-(void) hideLoadingView;
-(NSString *)applicationCacheDirectory;
- (NSURL *)applicationDocumentsDirectory;
-(void)setDeshBoardNavigationImg;
-(NSString *)getPapersPathFromURL:(NSString *)stringUrl;
-(void)setLoginview;
-(void)registerForPushNotification:(BOOL)isRegister;

@property (nonatomic , strong) UINavigationController *navigationController;

@property (nonatomic , strong) HomeView *viewHome;
@property (nonatomic , strong) MyProfileView *viewMyprofile;
@property (nonatomic , strong) AttendanceView *viewAttendanceView;

-(void)setDeshBoardViewController;
-(void)setViewController:(ADTransitioningViewController *)viewController :(BOOL)isStroryBoard :(NSString *)headerTitle :(BOOL)animated;
@end

