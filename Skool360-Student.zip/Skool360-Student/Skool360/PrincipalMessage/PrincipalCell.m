
//
//  PrincipalCell.m
//  Skool360
//
//  Created by ADMS on 07/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "PrincipalCell.h"
#import "UIImageView+WebCache.h"
#import <CoreText/CoreText.h>

@implementation PrincipalCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    imgPrincipal.layer.cornerRadius = imgPrincipal.frame.size.width/2;
    imgPrincipal.layer.masksToBounds = YES;
    
    imgPrincipal.layer.borderColor = datePickerBoardColor.CGColor;
}

-(void)setData:(NSDictionary *)dic
{
    imgPrincipal.layer.borderWidth = 2.0f;
    
    [imgPrincipal sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",HostName, dic[@"Image"]]] placeholderImage:[UIImage imageNamed:@"Principal"]];
    [lblPrincipalName setText:dic[@"Name"]];
    [lblPrincipalPost setText:dic[@"Type"]];
    [_lblPrincipalDes setText:dic[@"Discription"]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
