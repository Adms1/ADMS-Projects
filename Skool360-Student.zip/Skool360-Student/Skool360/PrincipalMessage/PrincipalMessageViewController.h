//
//  PrincipalMessageViewController.h
//  Skool360
//
//  Created by ADMS on 07/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface PrincipalMessageViewController : MasterViewController
{
    IBOutlet UITableView *tblPricipalMessage;
}
@end
