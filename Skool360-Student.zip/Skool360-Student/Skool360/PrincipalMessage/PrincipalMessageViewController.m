//
//  PrincipalMessageViewController.m
//  Skool360
//
//  Created by ADMS on 07/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "PrincipalMessageViewController.h"
#import "PrincipalCell.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface PrincipalMessageViewController ()<TTTAttributedLabelDelegate>
{
    NSMutableArray *arrFinalResult;
    NSMutableArray *arrFlags;
}
@end

@implementation PrincipalMessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    tblPricipalMessage.estimatedRowHeight = 230;
    tblPricipalMessage.rowHeight = UITableViewAutomaticDimension;
    tblPricipalMessage.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
}

-(void)viewWillAppear:(BOOL)animated
{
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:self.title.uppercaseString forState:0];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:1]) addTarget:self action:@selector(onClickSideMenuBtn:) forControlEvents:UIControlEventTouchUpInside];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:2]) addTarget:self action:@selector(onClickBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:PrincipalData_Url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        arrFlags = [[NSMutableArray alloc]init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrFinalResult = [responseObject safeObjectForKey:@"FinalArray"];
            for (int i = 0; i < arrFinalResult.count; i++) {
                [arrFlags addObject:[NSNumber numberWithBool:NO]];
            }
            [tblPricipalMessage reloadData];
            
        }else{
            [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"data"] delegate:self];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - TableView Delegate Method

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return arrFinalResult.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdenti = @"cellPrincipal";
    
    PrincipalCell *cell = (PrincipalCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    NSDictionary *dic = [arrFinalResult objectAtIndex:indexPath.row];
    [cell setData:dic];
    
    cell.lblPrincipalDes.delegate = self;
    cell.lblPrincipalDes.tag = indexPath.row;
    
    if (arrFinalResult.count > 1)
    {
        NSInteger lineCount = 0;
        CGFloat fullHeight = [CommonClass getDynamicHeightOflbl:cell.lblPrincipalDes].height;
        cell.lblPrincipalDes.font = FONT_OpenSans(IS_IPAD ? 17 : 14);
        int charSize = lroundf(cell.lblPrincipalDes.font.lineHeight);
        int rHeight = lroundf(fullHeight);
        lineCount = rHeight/charSize;
        
        if (lineCount > 5) {
            
            BOOL flag = [[arrFlags objectAtIndex:indexPath.row] boolValue];
            if (!flag) {
                cell.lblPrincipalDes.numberOfLines = 2;
                
                NSAttributedString *strReadMore = [[NSAttributedString alloc] initWithString:@"... Read more" attributes:@{NSFontAttributeName:FONT_Semibold(IS_IPAD ? 17 : 14), NSForegroundColorAttributeName:detaultColor,NSLinkAttributeName : [NSURL URLWithString:[@" ...Read more" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]}];
                [cell.lblPrincipalDes setAttributedTruncationToken:strReadMore];
            } else {
                cell.lblPrincipalDes.numberOfLines = 0;
                
                NSString *strFullText = [NSString stringWithFormat:@"%@ ...Read less",dic[@"Discription"]];
                
                [cell.lblPrincipalDes setText:strFullText afterInheritingLabelAttributesAndConfiguringWithBlock:^NSMutableAttributedString *(NSMutableAttributedString *mutableAttributedString) {
                    
                    NSRange linkRange = [[mutableAttributedString string] rangeOfString:@" ...Read less" options:NSCaseInsensitiveSearch];
                    [mutableAttributedString addAttribute:NSForegroundColorAttributeName value:detaultColor range:linkRange];
                    [mutableAttributedString addAttribute:NSFontAttributeName value:FONT_Semibold(IS_IPAD ? 17 : 14) range:linkRange];
                    [mutableAttributedString addAttribute:NSLinkAttributeName value:[NSURL URLWithString:[@" ...Read less" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] range:linkRange];
                    
                    return mutableAttributedString;
                }];
            }
        }else{
            cell.lblPrincipalDes.numberOfLines = 0;
        }
    }else{
        cell.lblPrincipalDes.font = FONT_OpenSans(IS_IPAD ? 17 : 14);
        cell.lblPrincipalDes.numberOfLines = 0;
    }
    return cell;
}

- (void)attributedLabel:(__unused TTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)url
{
    BOOL flag = ![[arrFlags objectAtIndex:label.tag] boolValue];
    [arrFlags replaceObjectAtIndex:label.tag withObject:[NSNumber numberWithBool:flag]];
    [tblPricipalMessage reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:label.tag inSection:0]] withRowAnimation:UITableViewRowAnimationFade];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
