//
//  SentInboxCell.h
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InboxSent.h"

@protocol SentInboxCellDelegate
-(void)deleteRequest:(UIButton *)sender;
@end

@interface SentInboxCell : UITableViewCell
@property (nonatomic , strong)IBOutlet UILabel *lblUserName;
@property (nonatomic , strong)IBOutlet UILabel *lblSubjectLine;
@property (nonatomic , strong)IBOutlet UILabel *lblMeetingDate;
@property (nonatomic , strong)IBOutlet UILabel *lblView;
@property (nonatomic , strong)IBOutlet NSLayoutConstraint *viewHeight;

@property (nonatomic, weak) id <SentInboxCellDelegate> delegate;

@property (nonatomic , strong)IBOutlet UILabel *lblDescription;
@property (nonatomic , strong)IBOutlet UIButton *btnDelete;

-(void)displayHeaderData:(InboxSent *)data;
-(void)displayData:(InboxSent *)data;
@end
