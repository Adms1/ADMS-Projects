//
//  AppointmentViewController.m
//  Skool360
//
//  Created by Darshan on 02/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "AppointmentViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "InboxSentViewController.h"

@interface AppointmentViewController ()
{
    NSMutableDictionary *dicTeachers;
}
@end

@implementation AppointmentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (isiPhone6) {
        imgLogo.frame = CGRectMake(-66, 0, 140, 45);
    }else if (isiPhone6Plus){
        imgLogo.frame = CGRectMake(-86, 0, 140, 45);
    }
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.titleView = viewtitle;
    
    [btnSideMenu setAttributedTitle:nil forState:UIControlStateNormal];
    [[btnSideMenu titleLabel] setNumberOfLines:0];
    [[btnSideMenu titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    
    //    UIBarButtonItem *barBtnSide = [[UIBarButtonItem alloc] initWithCustomView:btnSideMenu];
    //    self.navigationItem.rightBarButtonItems = @[barBtnSide];
    //
    //    UIBarButtonItem *barBtnBack = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
    //    self.navigationItem.leftBarButtonItems = @[barBtnBack];
    
    btnRequest.layer.borderWidth = 0.5f;
    btnRequest.layer.borderColor = imgCircleColor.CGColor;
    
    btnSelectDate.layer.borderWidth = 0.5f;
    btnSelectDate.layer.borderColor = imgCircleColor.CGColor;
    
    viewDescription.layer.borderWidth = 0.5f;
    viewDescription.layer.borderColor = imgCircleColor.CGColor;
    
    txtPurpose.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"" attributes:@{NSForegroundColorAttributeName: txtFieldColor,NSFontAttributeName:FONT_OpenSans(IS_IPAD ? 15 : 12)}];
    txtPurpose.backgroundColor = [UIColor whiteColor];
    txtPurpose.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPurpose.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPurpose.leftViewMode = UITextFieldViewModeAlways;
    txtPurpose.rightViewMode = UITextFieldViewModeAlways;
    txtPurpose.layer.borderWidth = 0.5;
    txtPurpose.layer.borderColor = imgCircleColor.CGColor;
    
    btnSave.layer.cornerRadius = 4.0f;
    btnCancel.layer.cornerRadius = 4.0f;
    btnDone.layer.cornerRadius = 2.0f;
    btnPickerDateCancel.layer.cornerRadius = 2.0f;
    
    [scrollV setContentOffset:CGPointMake(0, 20) animated:YES];
    
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strCurrentDate = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
    
    [btnSelectDate setTitle:strCurrentDate forState:UIControlStateNormal];
    strAppointmentDate = btnSelectDate.titleLabel.text;
    
}

-(void)viewWillAppear:(BOOL)animated
{
    UIDatePicker *picker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 30, self.view.frame.size.width - 20, 200)];
    [picker setMinimumDate:[NSDate date]];
    [picker setDatePickerMode:UIDatePickerModeDate];
    [picker addTarget:self action:@selector(onClickPickDate:) forControlEvents:UIControlEventValueChanged];
    picker.tag = 100;
    if ([viewDatePicker viewWithTag:100] == nil) {
        [viewDatePicker addSubview:picker];
    }
    [self getSubjectWiseTeacher];
}

-(void)getSubjectWiseTeacher
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strStudentID forKey:@"StudentID"];

    NSLog(@"params>>> %@",params);
    
    dicTeachers = [[NSMutableDictionary alloc]init];
    
    [manager POST:PTMStudentWiseTeacher_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arrResult = [responseObject valueForKey:@"FinalArray"];
            for (NSDictionary *dicValue in arrResult) {
                if (strRequestID == nil) {
                    [btnRequest setTitle:dicValue[@"TeacherName"] forState:UIControlStateNormal];
                }
                if ([((NSString *)dicValue[@"TeacherName"]) containsString:@"ClassTeacher"]) {
                    [dicTeachers setValue:dicValue[@"StaffID"] forKey:dicValue[@"TeacherName"]];
                }else {
                    [dicTeachers setValue:dicValue[@"TeacherID"] forKey:dicValue[@"TeacherName"]];
                }
                if (strRequestID == nil) {
                    strRequestID = dicTeachers.allValues[0];
                }
            }
        }else{
            [btnSave setEnabled:NO];
            [btnSave setAlpha:0.5];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(BOOL)appointmentValidate
{
    NSString *strPurpose  = [CommonClass trimString:txtPurpose.text];
    NSString *strDescription  = [CommonClass trimString:txvDescription.text];
    
    if ([strPurpose length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePurposeAppointment delegate:self];
        return NO;
    }
    if ([strDescription length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideDiscribe delegate:self];
        return NO;
    }
    return  YES;
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [viewDatePicker setHidden:YES];

    CGPoint point;
    
    if (textField == txtPurpose) {
        point = CGPointMake(0, 0);
    }
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

#pragma mark -
#pragma mark - TEXT VIEW DELEGATE

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    [viewDatePicker setHidden:YES];
    
    if (!(IS_IPAD)) {
        [scrollV setContentOffset:CGPointMake(0,txvDescription.frame.origin.y + 100) animated:YES];
    }
}
- (void)textViewDidEndEditing:(UITextView *)textView
{
    [scrollV setContentOffset:CGPointMake(0, 0) animated:YES];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        [scrollV setContentOffset:CGPointMake(0,0) animated:YES];
        return NO;
    }
    return YES;
}

- (void) niDropDownDelegateMethod:(NIDropDown *)sender :(NSInteger)index {
    [self rel];
    strRequestID = dicTeachers[btnRequest.titleLabel.text];
    [btnRequest setTitle:btnRequest.titleLabel.text forState:UIControlStateNormal];
}

-(void)rel{
    //    [dropDown release];
    dropDown = nil;
}

#pragma mark -
#pragma mark - BUTTONCLICK Method

- (IBAction)onClickDateSelectBtn:(id)sender {
    
    [[self view]endEditing:YES];
    [scrollV setContentOffset:CGPointZero animated:YES];

    viewDatePicker.frame = CGRectMake(viewDatePicker.frame.origin.x, (SHARED_APPDELEGATE.window.frame.size.height - 200)/2, SHARED_APPDELEGATE.window.frame.size.width - 20, 230);

    viewDatePicker.hidden = NO;
}

- (IBAction)onClickRequestBtn:(id)sender {
    
    [txtPurpose isFirstResponder];
    
    if(dropDown == nil) {
        CGFloat f = IS_IPAD ? [[dicTeachers allKeys] count] * 30 : [[dicTeachers allKeys] count] > 5 ? 5 * 30 : [[dicTeachers allKeys] count] * 30;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :[dicTeachers allKeys] :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (IBAction)onClickSaveBtn:(id)sender {
    
    [txtPurpose resignFirstResponder];
    [txvDescription resignFirstResponder];
    [scrollV setContentOffset:CGPointZero animated:YES];
    
    if ([self appointmentValidate]) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
        
//        [params setObject:strStudentID forKey:@"StudentID"];
//        [params setObject:strAppointmentDate forKey:@"AppointmentDate"];
//        [params setObject:txtPurpose.text forKey:@"Purpose"];
//        [params setObject:strRequestID forKey:@"RequestFor"];
//        [params setObject:txvDescription.text forKey:@"Description"];
        
        [params setObject:@"Student" forKey:@"Flag"];
        [params setObject:@"0" forKey:@"MessageID"];
        [params setObject:strStudentID forKey:@"FromID"];
        [params setObject:strAppointmentDate forKey:@"MeetingDate"];
        [params setObject:txtPurpose.text forKey:@"SubjectLine"];
        [params setObject:strRequestID forKey:@"ToID"];
        [params setObject:txvDescription.text forKey:@"Description"];
        
        NSLog(@"params>>> %@",params);
        
        [manager POST:PTMTeacherStudentInsertDetail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                [CommonClass showAlertWithTitle:provideAlert andMessage:provideAppointmentBook delegate:self];
                //                InboxSentViewController *isvc = [self.storyboard instantiateViewControllerWithIdentifier:@"InboxSentViewController"];
                //                [isvc callInboxSentApi];
                [self onClickCancelBtn:nil];
            }else{
                [CommonClass showAlertWithTitle:provideAlert andMessage:provideAppointmentBookIssues delegate:self];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [CommonClass errorAlert:error.code];

            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

- (IBAction)onClickCancelBtn:(id)sender {
    
    txtPurpose.text = @"";
    txvDescription.text = @"";
    [txtPurpose resignFirstResponder];
    [txvDescription resignFirstResponder];
    [scrollV setContentOffset:CGPointZero animated:YES];
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strCurrentDate = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
    
    [btnSelectDate setTitle:strCurrentDate forState:UIControlStateNormal];
    strAppointmentDate = btnSelectDate.titleLabel.text;
    strRequestID = nil;
    [self getSubjectWiseTeacher];
}

- (IBAction)onClickDoneBtn:(id)sender {
    
    viewDatePicker.hidden = YES;
}

- (IBAction)onClickDatePickerCancelBtn:(id)sender {
    
    [btnSelectDate setTitle:strAppointmentDate forState:UIControlStateNormal];
    viewDatePicker.hidden = YES;
}

- (IBAction)onClickPickDate:(UIDatePicker *)datePicker {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strDate = [dateFormatter stringFromDate:datePicker.date];
    
    NSLog(@"%@",strDate);
    
    strAppointmentDate = strDate;
    [btnSelectDate setTitle:strDate forState:UIControlStateNormal];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

