//
//  InboxSentViewController.h
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InboxSentViewController : UIViewController
{
    IBOutlet UITableView *tblSentReceiveReq;
    IBOutlet UILabel *lblNoDataFound;
}
-(void)callInboxSentApi;
@end

