//
//  NIDropUpCell.h
//  Skool360
//
//  Created by Darshan on 29/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NIDropUpCell : UITableViewCell

@property (nonatomic , strong) IBOutlet UILabel *lblYearMonth;

@end
