
//
//  CustomButton.m
//  Skool360
//
//  Created by ADMS on 18/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "CustomButton.h"
#import "UIButton+GetLocalButtonImage.h"

@implementation CustomButton

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self getImagesfromLocal:self.strImageName];
}

@end
