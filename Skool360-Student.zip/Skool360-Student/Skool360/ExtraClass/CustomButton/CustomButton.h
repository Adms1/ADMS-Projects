//
//  CustomButton.h
//  Skool360
//
//  Created by ADMS on 18/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE

@interface CustomButton : UIButton

@property(nonatomic)IBInspectable NSString *strImageName;

@end
