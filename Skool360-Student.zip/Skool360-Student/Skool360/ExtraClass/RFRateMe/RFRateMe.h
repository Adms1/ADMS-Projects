//
//  RFRateMe.h
//  RFRateMeDemo
//
//  Created by Ricardo Funk on 1/2/14.
//  Copyright (c) 2014 Ricardo Funk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RFRateMe : NSObject

+(void)showRateAlert;
+(void)showRateAlertAfterTimesOpened:(int)times;
+(void)showRateAlertAfterDays:(int)days;

@end
