//
//  CustomLabel.m
//  Bhadaj (Student)
//
//  Created by ADMS on 24/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "CustomLabel.h"

@implementation CustomLabel

- (void)drawTextInRect:(CGRect)uiLabelRect {
    [super drawTextInRect:UIEdgeInsetsInsetRect(uiLabelRect, UIEdgeInsetsMake(8,8,8,8))];
}
@end
