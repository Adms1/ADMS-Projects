//
//  CustomLabel.h
//  Bhadaj (Student)
//
//  Created by ADMS on 24/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomLabel : UILabel
@property(readwrite, assign)float topInset;
@property(readwrite, assign)float leftInset;
@property(readwrite, assign)float bottomInset;
@property(readwrite, assign)float rightInset;
@end
