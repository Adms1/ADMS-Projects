//
//  CommonClass.h
//  Viewfoo
//
//  Created by MitulB on 22/05/15.
//  Copyright (c) 2015 com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface CommonClass : NSObject

//+(CommonClass *)shareObject;
+ (void)errorAlert:(NSInteger)errorCode;

+ (NSString *)timeAgoStringFromDate:(NSString *)strDate;

+ (NSString *)convertToDate:(NSString *)strDate :(NSString *)originalFormate :(NSString *)formate;

+(NSString *)trimString:(NSString *)string;

+(NSString *) removeNull:(NSString *) string;

+(NSString *) removeNull1:(NSString *) string;

+ (void) showAlertWithTitle:(NSString *)title message:(NSString *)message;
+ (BOOL)textIsValidEmailFormat:(NSString *)text;

+(NSString *)getStringDateFromDate:(NSDate *)date;

+ (NSString*)generateFileNameWithExtension:(NSString *)extensionString;
+(BOOL)complareTwoString:(NSString *)str1 :(NSString *)str2;
+ (NSString *)extractYoutubeIdFromLink:(NSString *)link;
+ (BOOL)validateUrl: (NSString *) candidate;
+(void)showAlertWithTitle:(NSString *)strTitle andMessage:(NSString *)strMessage delegate:(id)delegate;
+ (CGFloat)getLabelHeight:(NSString *)str :(CGFloat)width;
+ (CGSize)getDynamicHeightOflbl:(UILabel *)lbl;
+ (void)addShadow:(UIView *)view :(CGFloat)qty;
+ (NSAttributedString *)getHtmlString:(NSString *)htmlString;
+(NSDate *)getDateFromString:(NSString *)strDate :(NSString *)formate;
@end
