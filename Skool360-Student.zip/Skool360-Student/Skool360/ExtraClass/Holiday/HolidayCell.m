//
//  HolidayCell.m
//  Holiday
//
//  Created by Fernando Sproviero on 30/06/14.
//  Copyright (c) 2014 FS. All rights reserved.
//

#import "HolidayCell.h"

@implementation HolidayCell

-(void)parallaxTheImageViewScrollOffset:(CGPoint)offsetPoint
{
    CGFloat factor = 0.3;
    CGFloat parallaxFactorX = 0;
    CGFloat parallaxFactorY = factor;
    
    CGFloat finalX = (offsetPoint.x - self.frame.origin.x) * parallaxFactorX;
    CGFloat finalY = (offsetPoint.y - self.frame.origin.y) * parallaxFactorY;
    
    CGRect frame = self.cellImageView.bounds;
    CGRect offsetFame = CGRectOffset(frame, finalX + 10, finalY + 60);
    self.cellImageView.frame = offsetFame;
}
@end
