//
//  HolidayViewController.m
//  HolidayTableView
//
//  Created by Fernando Sproviero on 30/06/14.
//  Copyright (c) 2014 FS. All rights reserved.
//

#import "HolidayViewController.h"
#import "HolidayCell.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "Holiday.h"

@interface HolidayViewController()
{
    NSMutableArray *arrHolidayData;
}
@end

@implementation HolidayViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self callHolidayApi];
}

-(void)callHolidayApi
{
    arrHolidayData = [[NSMutableArray alloc]init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:GetHoliday_Url parameters:@{@"StandardID" : [[NSUserDefaults standardUserDefaults] valueForKey:STANDARDID]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrListHoliday = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dict in arrListHoliday) {
                
                [arrHolidayData addObject:[NSString stringWithFormat:@"%@ %@",[dict safeObjectForKey:@"MonthName"], [dict safeObjectForKey:@"Year"]]];
                [arrHolidayData addObject:@"No Event / Holiday Found"];
                
                BOOL flag = YES;
                for (NSDictionary *holidayDict in [dict safeObjectForKey:@"Data"]) {
                    
                    if(flag) {
                        [arrHolidayData removeLastObject];
                        flag = NO;
                    }
                    
                    Holiday *objHoliday = [[Holiday alloc] init];
                    
                    NSArray *arrHDate = [[holidayDict safeObjectForKey:@"HolidayDate"] componentsSeparatedByString:@"-"];
                    NSArray *arrEDate = [[holidayDict safeObjectForKey:@"EventDate"] componentsSeparatedByString:@"-"];
                    
                    NSString *strDate;
                    if(![[holidayDict safeObjectForKey:@"HolidayDate"] isEqualToString:@"-"]){
                        strDate = arrHDate[0];
                    }else{
                        strDate = arrEDate[0];
                    }
                    
                    NSDate *date = [CommonClass getDateFromString:strDate :@"dd/MM/yyyy"];
                    
                    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
                    [dateFormat setDateFormat:@"d"];
                    NSInteger day = [[dateFormat stringFromDate:date] intValue];
                    
                    NSCalendar* cal = [NSCalendar currentCalendar];
                    NSDateComponents* comp = [cal components:NSCalendarUnitWeekday fromDate:date];
                    NSString *weekDay = [dateFormat weekdaySymbols][[comp weekday] - 1];
                    
                    objHoliday.strDay = [NSString stringWithFormat:@"%ld", (long)day];
                    objHoliday.strWeekDay = [NSString stringWithFormat:@"%@",[weekDay substringToIndex:3]];
                    objHoliday.strHoliday = [holidayDict safeObjectForKey:@"Holiday"];
                    objHoliday.strEvent = [holidayDict safeObjectForKey:@"Event"];
                    objHoliday.strHolidayDate = @"";
                    objHoliday.strEventDate = @"";
                    
                    if(![arrHDate[0] isEqualToString:arrHDate[1]]) {
                        objHoliday.strHolidayDate = [NSString stringWithFormat:@"%@ - %@", [CommonClass convertToDate:arrHDate[0] :@"dd/MM/yyyy" :@"dd MMM"], [CommonClass convertToDate:arrHDate[1] :@"dd/MM/yyyy" :@"dd MMM"]];
                    }
                    
                    if(![arrEDate[0] isEqualToString:arrEDate[1]]) {
                        objHoliday.strEventDate = [NSString stringWithFormat:@"%@ - %@", [CommonClass convertToDate:arrEDate[0] :@"dd/MM/yyyy" :@"dd MMM"], [CommonClass convertToDate:arrEDate[1] :@"dd/MM/yyyy" :@"dd MMM"]];
                    }
                    [arrHolidayData addObject:objHoliday];
                }
                NSLog(@"%@", arrHolidayData);
            }
            [tblHoliday reloadData];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - UITableViewDatasourceDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Holiday *data = arrHolidayData[indexPath.row];
    if([data isKindOfClass:[Holiday classForCoder]])
    {
        return UITableViewAutomaticDimension;
    }
    else if([[[[NSDateFormatter alloc]init]monthSymbols] containsObject:[NSString stringWithFormat:@"%@",[[arrHolidayData[indexPath.row]componentsSeparatedByString:@" "]firstObject]]])
    {
        return IS_IPAD ? 200 : 130;
    }
    else
    {
        return 50;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrHolidayData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strIdentifier = @"NoHolidayCell";
    
    Holiday *data = arrHolidayData[indexPath.row];
    if([data isKindOfClass:[Holiday classForCoder]])
    {
        strIdentifier = @"HolidayEventDateCell";
    }
    else if([[[[NSDateFormatter alloc]init]monthSymbols] containsObject:[NSString stringWithFormat:@"%@",[[arrHolidayData[indexPath.row]componentsSeparatedByString:@" "]firstObject]]])
    {
        strIdentifier = @"HolidayHeaderCell";
    }
    
    HolidayCell *cell = (HolidayCell *)[tableView dequeueReusableCellWithIdentifier:strIdentifier];
    cell.tag = indexPath.row;
    
    if([data isKindOfClass:[Holiday classForCoder]])
    {
        cell.lblDate.text = data.strDay;
        cell.lblDay.text = data.strWeekDay;
        cell.lblName.text = data.strHoliday;
        cell.lblHolidayDate.text = data.strHolidayDate;
        cell.lblEventDate.text = data.strEventDate;
        
        cell.holidayheight.constant = 0;
        cell.eventHeight.constant = 0;
        cell.holidayEventCenter.constant = 10;
        cell.eventBottom.constant = 15;
        
        if (![data.strHoliday isEqualToString:@""] && ![data.strEvent isEqualToString:@""]) {
            cell.holidayheight.constant = [data.strHolidayDate isEqualToString:@""] ? (21 + 16) : 40;
            cell.eventHeight.constant = [data.strEventDate isEqualToString:@""] ? (21 + 16) : 40;
            cell.holidayEventCenter.constant = 10;
            cell.eventBottom.constant = 11;
        }
        else
        {
            if(![data.strHoliday isEqualToString:@""])
            {
                cell.holidayheight.constant = [data.strHolidayDate isEqualToString:@""] ? (21 + 16) : 40;
                cell.holidayEventCenter.constant = [data.strHolidayDate isEqualToString:@""] ? 15 : 5;
            }
            if(![data.strEvent isEqualToString:@""])
            {
                cell.eventHeight.constant = [data.strEventDate isEqualToString:@""] ? (21 + 16) : 40;
                cell.holidayEventCenter.constant = 0;
                cell.eventBottom.constant = [data.strEventDate isEqualToString:@""] ? 25 : 10;
            }
        }
        cell.lblEvent.text = [data.strEvent isEqualToString:@""] ? @"" : [NSString stringWithFormat:@"%@ Event",data.strEvent];
        
        if(![data.strEvent isEqualToString:@""]) {
            NSDictionary *attribs = @{
                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                      NSFontAttributeName: FONT_Semibold(16)
                                      };
            NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:cell.lblEvent.text attributes:attribs];
            
            UIFont *boldFont = FONT_OpenSans(10);
            NSRange range = [cell.lblEvent.text rangeOfString:@"Event"];
            [attributedText setAttributes:@{NSForegroundColorAttributeName: [UIColor whiteColor],
                                            NSFontAttributeName:boldFont} range:range];
            cell.lblEvent.attributedText = attributedText;
        }
    }
    else if(![arrHolidayData[indexPath.row] isEqualToString:@"No Event / Holiday Found"])
    {
        cell.lblName.text = arrHolidayData[indexPath.row];
        NSString *strImageName = [NSString stringWithFormat:@"%@%@",[[arrHolidayData[indexPath.row]componentsSeparatedByString:@" "]firstObject], IS_IPAD ? @"@2x" : @""];
        [cell.cellImageView getImagesfromLocal:strImageName];
        [cell.lblName setFont:FONT_Semibold(IS_IPAD ? 32 : isiPhone5 ? 20 : 25)];
        cell.clipsToBounds = YES;
    }
    else
    {
        cell.lblName.text = arrHolidayData[indexPath.row];
    }
    
    //if(![strIdentifier isEqualToString:@"HolidayDateCell"]) {
    [cell.lblName.superview.layer setShadowColor:[UIColor blackColor].CGColor];
    [cell.lblName.superview.layer setShadowOpacity:0.1f];
    [cell.lblName.superview.layer setShadowRadius:1.0f];
    [cell.lblName.superview.layer setShadowOffset:CGSizeMake(0.0f, 2.0f)];
    //}
    return cell;
}

#pragma mark - UIScrollViewdelegate methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    for (HolidayCell *cell in tblHoliday.visibleCells) {
        Holiday *data = arrHolidayData[cell.tag];
        if(![data isKindOfClass:[Holiday classForCoder]] && ![arrHolidayData[cell.tag] isEqualToString:@"No Event / Holiday Found"])
        {
            [cell parallaxTheImageViewScrollOffset: tblHoliday.contentOffset];
        }
    }
}
@end
