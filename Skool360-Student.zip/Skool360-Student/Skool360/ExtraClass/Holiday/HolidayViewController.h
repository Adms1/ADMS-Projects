//
//  HolidayViewController.h
//  HolidayTableView
//
//  Created by Fernando Sproviero on 30/06/14.
//  Copyright (c) 2014 FS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface HolidayViewController : MasterViewController
{
    IBOutlet UITableView *tblHoliday;
}
@end
