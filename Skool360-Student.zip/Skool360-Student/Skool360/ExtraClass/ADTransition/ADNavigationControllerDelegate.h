//
//  ADNavigationControllerDelegate.h
//  ADTransitionController
//
//  Created by Patrick Nollet on 09/10/13.
//  Copyright (c) 2013 Applidium. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ADNavigationControllerDelegate : NSObject <UINavigationControllerDelegate>

@end
