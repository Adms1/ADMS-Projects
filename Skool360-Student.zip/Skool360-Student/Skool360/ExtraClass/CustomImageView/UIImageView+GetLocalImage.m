//
//  UIImageView+GetLocalImage.m
//  Skool360
//
//  Created by ADMS on 18/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "UIImageView+GetLocalImage.h"
#import "UIImageView+WebCache.h"
#import "AFImageRequestOperation.h"

@implementation UIImageView (GetLocalImage)

- (void)getImagesfromLocal:(NSString *)strImageName
{
    NSString *documentsDirectoryURL = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    
    NSString *fileUrl = [documentsDirectoryURL stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",strImageName]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:fileUrl]){
        [self setImage:[UIImage imageWithContentsOfFile:fileUrl]];
    }else{
        [self storeImages:fileUrl :[NSString stringWithFormat:@"%@.png",strImageName]];
    }
}

- (void)getIconsfromLocal:(NSString *)strImageName :(BOOL)isTemplate
{
    NSString *documentsDirectoryURL = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    
    NSString *fileUrl = [documentsDirectoryURL stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",strImageName]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:fileUrl]){
        [self setImage:isTemplate ? [[UIImage imageWithContentsOfFile:fileUrl]imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] : [UIImage imageWithContentsOfFile:fileUrl]];
    }else{
        [self storeIcons:fileUrl :[NSString stringWithFormat:@"%@.png",strImageName] :isTemplate];
    }
}

-(void)storeIcons:(NSString *)imageUrl :(NSString *)imageName :(BOOL)isTemplate
{
    NSString *strImageUrlLink = [NSString stringWithFormat:@"%@%@",Icons_Url,[imageName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:strImageUrlLink]];
    
    AFImageRequestOperation *operation = [AFImageRequestOperation imageRequestOperationWithRequest:request imageProcessingBlock:nil success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
        
        [self setImage:isTemplate ? [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] : image];
        [UIImagePNGRepresentation(image) writeToFile:imageUrl atomically:YES];
        
    } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error) {
        NSLog(@"%@", [error localizedDescription]);
        
    }];
    
    [operation start];
}

-(void)storeImages:(NSString *)imageUrl :(NSString *)imageName
{
    NSString *strImageUrlLink = [NSString stringWithFormat:@"%@%@",Images_Url,[imageName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    [self sd_setImageWithURL:[NSURL URLWithString:strImageUrlLink] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        if (error != nil) {
            return;
        }
        
        [UIImagePNGRepresentation(image) writeToFile:imageUrl atomically:YES];
    }];
}

@end
