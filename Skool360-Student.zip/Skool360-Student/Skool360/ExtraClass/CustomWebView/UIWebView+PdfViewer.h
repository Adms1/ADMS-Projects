//
//  UIWebView+PdfViewer.h
//  Shilaj (Student)
//
//  Created by ADMS on 20/06/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWebView (PdfViewer)

-(void)downloadPdf:(NSString *)fileName;

@end
