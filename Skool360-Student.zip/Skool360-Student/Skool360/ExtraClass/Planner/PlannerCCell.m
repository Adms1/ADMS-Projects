//
//  HolidayCell.m
//  Holiday
//
//  Created by Fernando Sproviero on 30/06/14.
//  Copyright (c) 2014 FS. All rights reserved.
//

#import "PlannerCCell.h"

@implementation PlannerCCell

@end
