//
//  HolidayCell.h
//  Holiday
//
//  Created by Fernando Sproviero on 30/06/14.
//  Copyright (c) 2014 FS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlannerCCell : UICollectionViewCell
{
    
}
@property (weak, nonatomic) IBOutlet UILabel *lblDay;
@property (weak, nonatomic) IBOutlet UILabel *lblHolidayEvent;
@property (weak, nonatomic) IBOutlet UILabel *lblHolidayEventDate;
@end
