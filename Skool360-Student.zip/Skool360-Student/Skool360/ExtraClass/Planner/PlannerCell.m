//
//  HolidayCell.m
//  Holiday
//
//  Created by Fernando Sproviero on 30/06/14.
//  Copyright (c) 2014 FS. All rights reserved.
//

#import "PlannerCell.h"

@implementation PlannerCell

-(void)awakeFromNib {
    [super awakeFromNib];
    _lblMonth.transform = CGAffineTransformMakeRotation(-M_PI_2);
}
@end
