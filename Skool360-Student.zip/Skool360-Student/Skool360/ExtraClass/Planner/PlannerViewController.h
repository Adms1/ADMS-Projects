//
//  PlannerViewController.h
//  Skool360Bhadaj
//
//  Created by ADMS on 02/08/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface PlannerViewController : MasterViewController
{
    IBOutlet UITableView *tblPlanner;
    IBOutlet UILabel *lblPlannerYear;
}
@end
