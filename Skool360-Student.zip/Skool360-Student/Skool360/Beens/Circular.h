//
//  Circular.h
//  Skool360
//
//  Created by Darshan on 07/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Circular : NSObject

@property (nonatomic , strong) NSString *CreateDate;
@property (nonatomic , strong) NSString *CircularHeading;
@property (nonatomic , strong) NSString *CircularDescription;
@property (nonatomic , strong) NSString *CircularPDF;
@end
