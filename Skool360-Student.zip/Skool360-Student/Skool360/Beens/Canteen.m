//
//  Canteen.m
//  Skool360
//
//  Created by Darshan on 05/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "Canteen.h"

@implementation Canteen

@synthesize MenuDay;
@synthesize MenuDate;
@synthesize Breakfast;
@synthesize Lunch;
@synthesize FlvrMilk;

@end
