//
//  Leave.m
//  Bhadaj (Student)
//
//  Created by ADMS on 24/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "Leave.h"

@implementation Leave

@end
