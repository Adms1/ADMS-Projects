//
//  MyProfile.m
//  Skool360
//
//  Created by Darshan on 24/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MyProfile.h"

@implementation MyProfile

@synthesize StudentName;
@synthesize StudentDOB;
@synthesize StudentAge;
@synthesize StudentGender;
@synthesize BloodGroup;
@synthesize BirthPlace;
@synthesize Caste;
@synthesize House;
@synthesize StudentImage;
@synthesize FatherName;
@synthesize FatherPhone;
@synthesize FatherEmail;
@synthesize MotherName;
@synthesize MotherMobile;
@synthesize MotherEmail;
@synthesize Address;
@synthesize City;
@synthesize SMSNumber;
@synthesize Transport_KM;
@synthesize Transport_PicupTime;
@synthesize Transport_DropTime;
@synthesize Transport_RouteName;
@synthesize Transport_DropPointName;
@synthesize Transport_PickupPointName;
@synthesize GRNO;
@synthesize Standard;
@synthesize Class;
@synthesize AddmissionDate;
@synthesize ClassTeacher;
@synthesize TodayAttendance;
@synthesize UserName;
@synthesize Password;

@end
