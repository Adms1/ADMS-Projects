//
//  Holiday.h
//  Bhadaj (Student)
//
//  Created by ADMS on 28/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Holiday : NSObject

@property (nonatomic , strong) NSString *strDay;
@property (nonatomic , strong) NSString *strWeekDay;
@property (nonatomic , strong) NSString *strHoliday;
@property (nonatomic , strong) NSString *strEvent;
@property (nonatomic , strong) NSString *strHolidayDate;
@property (nonatomic , strong) NSString *strEventDate;
@end
