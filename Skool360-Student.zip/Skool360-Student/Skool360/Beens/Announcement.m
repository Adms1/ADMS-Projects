//
//  Circular.m
//  Skool360
//
//  Created by Darshan on 07/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "Announcement.h"

@implementation Announcement

@synthesize CreateDate;
@synthesize Subject;
@synthesize AnnoucementDescription;
@synthesize AnnoucementPDF;
@end
