//
//  UnitTest.h
//  Skool360
//
//  Created by Darshan on 09/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UnitTest : NSObject

@property (nonatomic , strong) NSString *Date;
@property (nonatomic , strong) NSString *MarkGained;
@property (nonatomic , strong) NSString *Percentage;
@property (nonatomic , strong) NSString *SubjectName;
@property (nonatomic , strong) NSString *TestMark;

@end
