//
//  UnitTest.m
//  Skool360
//
//  Created by Darshan on 09/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "UnitTest.h"

@implementation UnitTest

@synthesize MarkGained;
@synthesize Percentage;
@synthesize SubjectName;
@synthesize TestMark;

@end
