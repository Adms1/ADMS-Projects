//
//  Circular.m
//  Skool360
//
//  Created by Darshan on 07/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "Circular.h"

@implementation Circular

@synthesize CreateDate;
@synthesize CircularHeading;
@synthesize CircularDescription;
@synthesize CircularPDF;
@end
