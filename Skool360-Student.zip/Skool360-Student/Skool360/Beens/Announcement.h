//
//  Circular.h
//  Skool360
//
//  Created by Darshan on 07/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Announcement : NSObject

@property (nonatomic , strong) NSString *CreateDate;
@property (nonatomic , strong) NSString *Subject;
@property (nonatomic , strong) NSString *AnnoucementDescription;
@property (nonatomic , strong) NSString *AnnoucementPDF;

@end
