//
//  MyProfile.h
//  Skool360
//
//  Created by Darshan on 24/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyProfile : NSObject

@property (nonatomic , strong) NSString *StudentName;
@property (nonatomic , strong) NSString *StudentDOB;
@property (nonatomic , strong) NSString *StudentAge;
@property (nonatomic , strong) NSString *StudentGender;
@property (nonatomic , strong) NSString *BloodGroup;
@property (nonatomic , strong) NSString *BirthPlace;
@property (nonatomic , strong) NSString *Caste;
@property (nonatomic , strong) NSString *House;
@property (nonatomic , strong) NSString *StudentImage;
@property (nonatomic , strong) NSString *FatherName;
@property (nonatomic , strong) NSString *FatherPhone;
@property (nonatomic , strong) NSString *FatherEmail;
@property (nonatomic , strong) NSString *MotherName;
@property (nonatomic , strong) NSString *MotherMobile;
@property (nonatomic , strong) NSString *MotherEmail;
@property (nonatomic , strong) NSString *SMSNo;
@property (nonatomic , strong) NSString *Address;
@property (nonatomic , strong) NSString *City;
@property (nonatomic , strong) NSString *SMSNumber;
@property (nonatomic , strong) NSString *Transport_KM;
@property (nonatomic , strong) NSString *Transport_PicupTime;
@property (nonatomic , strong) NSString *Transport_DropTime;
@property (nonatomic , strong) NSString *Transport_DropPointName;
@property (nonatomic , strong) NSString *Transport_PickupPointName;
@property (nonatomic , strong) NSString *Transport_RouteName;
@property (nonatomic , strong) NSString *BusNo;
@property (nonatomic , strong) NSString *GRNO;
@property (nonatomic , strong) NSString *Standard;
@property (nonatomic , strong) NSString *Class;
@property (nonatomic , strong) NSString *AddmissionDate;
@property (nonatomic , strong) NSString *ClassTeacher;
@property (nonatomic , strong) NSString *TodayAttendance;
@property (nonatomic , strong) NSString *UserName;
@property (nonatomic , strong) NSString *Password;

@end
