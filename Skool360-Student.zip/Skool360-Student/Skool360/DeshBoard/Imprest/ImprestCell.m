//
//  ImprestCell.m
//  Skool360
//
//  Created by ADMS on 02/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "ImprestCell.h"

@implementation ImprestCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setData:(NSDictionary *)dict
{
    lblDetail.text = [dict valueForKey:@"Message"];
    lblOpeningBalance.text = [dict valueForKey:@"OpeningBalance"];
    lblDeduction.text = [dict valueForKey:@"DeductAmount"];
    lblBalance.text = [dict valueForKey:@"Balance"];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
