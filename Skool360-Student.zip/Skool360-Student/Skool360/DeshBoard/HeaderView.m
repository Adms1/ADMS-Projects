//
//  HeaderView.m
//  Skool360
//
//  Created by ADMS on 28/12/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "HeaderView.h"

@implementation HeaderView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:[self loadViewFromNib]];
    }
    return self;
}

-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    
    self = [super initWithCoder:aDecoder];
    
    if (self) {
        [self addSubview:[self loadViewFromNib]];
    }
    return self;
}

-(UIView *)loadViewFromNib
{
    UIView *headerView = [[NSBundle mainBundle]loadNibNamed:@"HeaderView" owner:self options:nil].firstObject;
    headerView.frame = self.bounds;
    headerView.autoresizingMask = (UIViewAutoresizingFlexibleWidth| UIViewAutoresizingFlexibleHeight);
    return headerView;
}

@end
