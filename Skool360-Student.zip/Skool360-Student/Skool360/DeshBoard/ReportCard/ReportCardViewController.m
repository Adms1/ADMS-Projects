//
//  ReportCardViewController.m
//  Skool360
//
//  Created by ADMS on 01/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ReportCardViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "NIDropDown.h"

@interface ReportCardViewController ()
{
    NSString *reportUrl;
    NSString *termID;
    NSInteger termDetailID;
    NSMutableArray *arrAcademic;
    NSMutableArray *arrTermID;
    NIDropDown *dropDown;
}
@end

@implementation ReportCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self callGetTermApi];
}

-(void)callGetTermApi
{
    btnAcademicYear.layer.borderWidth = 1.0f;
    btnAcademicYear.layer.borderColor = imprestBackColor.CGColor;
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    arrAcademic = [[NSMutableArray alloc] init];
    arrTermID = [[NSMutableArray alloc] init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:term_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            NSMutableArray *arrAcademicYear = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dict in arrAcademicYear) {
                NSString *strTerm = [NSString stringWithFormat:@"%@",[dict safeObjectForKey:@"Term"]];
                NSString *strTermID = [NSString stringWithFormat:@"%@",[dict safeObjectForKey:@"TermId"]];
                
                [arrAcademic addObject:strTerm];
                [arrTermID addObject:strTermID];
            }
            
            NSSortDescriptor* sortOrder = [NSSortDescriptor sortDescriptorWithKey: @"self" ascending: YES];
            arrAcademic = [arrAcademic sortedArrayUsingDescriptors: [NSArray arrayWithObject: sortOrder]];
            arrTermID = [arrTermID sortedArrayUsingDescriptors: [NSArray arrayWithObject: sortOrder]];
            
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy"];
            NSString *yearString = [formatter stringFromDate:[NSDate date]];
            int nextYear = [[yearString substringFromIndex:2]intValue]+1;
            
            NSInteger idx = [arrAcademic indexOfObject:[NSString stringWithFormat:@"%@-%d",yearString,nextYear]];
            
            if (idx > arrAcademic.count -1)
            {
                idx = arrAcademic.count -1;
            }
            
            [btnAcademicYear setTitle:[NSString stringWithFormat:@"%@",[arrAcademic objectAtIndex:idx]] forState:UIControlStateNormal];
            termID = [NSString stringWithFormat:@"%@",[arrTermID objectAtIndex:idx]];
            [self setRadioButtons];
        }else{
            
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)setRadioButtons
{
    for (UIView *view in self.view.subviews) {
        if(view.tag != 0) {
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnRadioButton:)];
            [view addGestureRecognizer:tap];
            
            if([view isKindOfClass:[UIButton classForCoder]]) {
                UIButton *btn = (UIButton *)view;
                [btn.layer setBorderColor:[[UIColor groupTableViewBackgroundColor]CGColor]];
                [btn.layer setBorderWidth:5.0];
                
                if (view.tag == 1) {
                    termDetailID = 1;
                    [btn setBackgroundColor:imgCircleColor];
                    [self getReportCardDetails];
                }
            }
        }
    }
}

-(void)tapOnRadioButton:(UITapGestureRecognizer *)gesture
{
    for (UIView *view in self.view.subviews) {
        if([view isKindOfClass:[UIButton classForCoder]]) {
            UIButton *btn = (UIButton *)view;
            if(btn.tag != 0) {
                [btn setBackgroundColor:[UIColor lightGrayColor]];
            }
        }
    }
    
    termDetailID = gesture.view.tag > 2 ? gesture.view.tag/10 : gesture.view.tag;
    [self getReportCardDetails];
    UIButton *btn = (UIButton *)[self.view viewWithTag:termDetailID];
    [btn setBackgroundColor:imgCircleColor];
}

-(void)getResultPermission
{
    [actView stopAnimating];
    [actView setHidesWhenStopped:YES];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *strStandardID = [defaults objectForKey:STANDARDID];
    
    [params setObject:strStandardID forKey:@"StandardId"];
    [params setObject:termID forKey:@"TermID"];
    
    NSLog(@"params>>> %@",params);
    
    [manager GET:GetResultPermission_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            [btnResult setHidden:![[[[responseObject safeObjectForKey:@"FinalArray"] valueForKey:@"Status"] objectAtIndex:0]boolValue]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        NSLog(@"Error: %@", error);
    }];
}

-(void)getReportCardDetails
{
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"about:blank"]]];
    
    [imgNoRecord setHidden:YES];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *strStudentID = [defaults objectForKey:STUDENTID];
    
    [params setObject:strStudentID forKey:@"Studentid"];
    [params setObject:termID forKey:@"TermID"];
    [params setObject:[NSString stringWithFormat:@"%ld",(long)termDetailID] forKey:@"TermDetailID"];
    
    NSLog(@"params>>> %@",params);
    
    [manager GET:ReportCard_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            reportUrl = [[[responseObject safeObjectForKey:@"FinalArray"] valueForKey:@"URL"] objectAtIndex:0];
            if([reportUrl isEqualToString:@""])
            {
                [imgNoRecord setHidden:NO];
            }
            else
            {
                NSURL *websiteUrl = [NSURL URLWithString:reportUrl];
                NSURLRequest *urlRequest = [NSURLRequest requestWithURL:websiteUrl];
                [webView loadRequest:urlRequest];
            }
        }else{
            [imgNoRecord setHidden:NO];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [actView stopAnimating];
        [actView setHidesWhenStopped:YES];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - BUTTONCLICK Method

- (IBAction)onClickGetResultBtn:(id)sender {
    [self getReportCardDetails];
}

- (IBAction)onClickAcademicYearBtn:(id)sender {
    
    NSArray * arr = [[NSArray alloc] initWithArray:arrAcademic];
    
    if(dropDown == nil) {
        CGFloat f = arrAcademic.count * 30;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender :(NSInteger)index
{
    [self rel];
    
    termID = [NSString stringWithFormat:@"%@",[arrTermID objectAtIndex:index]];
    [self getReportCardDetails];
    [btnAcademicYear setTitle:btnAcademicYear.titleLabel.text forState:UIControlStateNormal];
}

-(void)rel{
    dropDown = nil;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [actView startAnimating];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [actView stopAnimating];
    [actView setHidesWhenStopped:YES];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [actView stopAnimating];
    [actView setHidesWhenStopped:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
