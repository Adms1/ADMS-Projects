//
//  InboxSent.m
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "InboxSentS.h"

@implementation InboxSentS

@synthesize Name, Subject, Rdate, Suggestion, Sdate, Reply;
@end
