//
//  SentInboxCell.h
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InboxSentS.h"

@interface SentInboxSCell : UITableViewCell
@property (nonatomic , strong)IBOutlet UILabel *lblSubject;
@property (nonatomic , strong)IBOutlet UILabel *lblRDate;
@property (nonatomic , strong)IBOutlet UILabel *lblTime;
@property (nonatomic , strong)IBOutlet NSLayoutConstraint *width;

@property (nonatomic , strong)IBOutlet UILabel *lblSuggestion;
@property (nonatomic , strong)IBOutlet UILabel *lblReply;
@property (nonatomic , strong)IBOutlet UILabel *lblSDate;

-(void)displayHeaderData:(InboxSentS *)data :(BOOL)isInbox;
-(void)displaySentData:(InboxSentS *)data;
-(void)displayInboxData:(InboxSentS *)data;
@end
