//
//  InboxSentViewController.m
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "InboxSentSViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "InboxSentS.h"
#import "SentInboxSCell.h"

@interface InboxSentSViewController ()
{
    NSMutableArray *arrInboxSentData;
    NSInteger selectedIndex;
}
@end

@implementation InboxSentSViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    selectedIndex = -1;
    tblSentReceiveReq.tableFooterView = [UIView new];
    
    tblSentReceiveReq.estimatedRowHeight = 127;
    tblSentReceiveReq.rowHeight = UITableViewAutomaticDimension;
    
    tblSentReceiveReq.estimatedSectionHeaderHeight = 87;
    tblSentReceiveReq.sectionHeaderHeight = UITableViewAutomaticDimension;
    
    [self callInboxSentApi];
}

-(void)viewWillAppear:(BOOL)animated
{
    [imgNoRecord setHidden:YES];
    [self callInboxSentApi];
}

-(void)callInboxSentApi
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:[self.title isEqualToString:@"Inbox"] ? @"Inbox" : @"Sent" forKey:@"MessgaeType"];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:GetSuggestion_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        arrInboxSentData = [[NSMutableArray alloc]init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrListRequest = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dic in arrListRequest)
            {
                InboxSentS *is = [[InboxSentS alloc]init];
                
                is.Name = dic[@"Name"];
                is.Rdate = dic[@"ReplyDate"];
                is.Sdate = dic[@"Date"];
                is.Subject = dic[@"Subject"];
                is.Suggestion = dic[@"Suggestion"];
                is.Reply = dic[@"Response"];
                
                [arrInboxSentData addObject:is];
            }
        }else{
            [imgNoRecord setHidden:NO];
        }
        [tblSentReceiveReq reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    SentInboxSCell *headerView = (SentInboxSCell *)[tableView dequeueReusableCellWithIdentifier:@"SentInboxHeaderCell"];
    
    [headerView displayHeaderData:arrInboxSentData[section] :[self.title isEqualToString:@"Inbox"]];
    
    headerView.contentView.tag = section;
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(expandCollapseSection:)];
    [headerView.contentView addGestureRecognizer:tapGesture];
    
    headerView.contentView.subviews[0].subviews[0].backgroundColor = sectionSelectColor;
    
    if(section == selectedIndex)
    {
        headerView.contentView.subviews[0].subviews[0].backgroundColor = detaultColor;
    }
    
    [CommonClass addShadow:headerView.contentView.subviews[0] :2.0];
    
    return headerView.contentView;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == selectedIndex) {
        return UITableViewAutomaticDimension;
    }
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    tblSentReceiveReq.estimatedSectionHeaderHeight = 87;
    return UITableViewAutomaticDimension;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return arrInboxSentData.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *strIdentifier = @"SentCell";
    if([self.title isEqualToString:@"Inbox"]) {
        strIdentifier = @"InboxCell";
    }
    
    SentInboxSCell *cell = (SentInboxSCell *)[tableView dequeueReusableCellWithIdentifier:strIdentifier forIndexPath:indexPath];
    if([self.title isEqualToString:@"Inbox"])
    {
        [cell displayInboxData:arrInboxSentData[indexPath.section]];
    }
    else
    {
        [cell displaySentData:arrInboxSentData[indexPath.section]];
    }
    return cell;
}

-(void)expandCollapseSection:(UIGestureRecognizer *)gesture
{
    NSInteger Index = gesture.view.tag;
    if(selectedIndex == Index) {
        selectedIndex = -1;
    }
    else {
        selectedIndex = Index;
    }
    [self refreshTableData];
}

-(void)refreshTableData
{
    [tblSentReceiveReq reloadData];
    
    if (selectedIndex != -1) {
        [tblSentReceiveReq scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selectedIndex] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}
@end

