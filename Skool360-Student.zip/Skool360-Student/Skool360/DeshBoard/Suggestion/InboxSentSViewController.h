//
//  InboxSentViewController.h
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InboxSentSViewController : UIViewController
{
    IBOutlet UITableView *tblSentReceiveReq;
    IBOutlet UIImageView *imgNoRecord;
}
-(void)callInboxSentApi;
@end

