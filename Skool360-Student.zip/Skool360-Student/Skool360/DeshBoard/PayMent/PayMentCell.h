//
//  PayMentCell.h
//  Skool360
//
//  Created by Darshan on 13/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

extern BOOL isTerm1Pay,isTerm2Pay;
@interface PayMentCell : UITableViewCell

{
    IBOutlet UILabel *lblTite;
    IBOutlet UILabel *lblTerm1;
    IBOutlet UILabel *lblTerm2;
    
    IBOutlet UIView *viewback;
    IBOutlet UILabel *lblReceiptNo;
    IBOutlet UILabel *lblTerm;
    IBOutlet UILabel *lblPaymentMode;
    IBOutlet UILabel *lblBankName;
    IBOutlet UILabel *lblChequeNo;
    IBOutlet UILabel *lblCautionFee;
    IBOutlet UILabel *lblAdmissionFee;
    IBOutlet UILabel *lblTutionFee;
    IBOutlet UILabel *lblTransport;
    IBOutlet UILabel *lblImpest;
    IBOutlet UILabel *lblLateFee;
    IBOutlet UILabel *lblOff;
    IBOutlet UILabel *lblPreviousFee;
    IBOutlet UILabel *lblTotal;
    IBOutlet UILabel *lblCurrentFee;

}
-(void)setPaymentReceiptData:(NSDictionary *)dict :(NSInteger)Index;
-(void)setPaymentDeta:(NSString *)term1 :(NSString *)term2 :(NSString *)strdetail;
-(void)setPaymentDeta:(NSDictionary *)dictTerms1 term2Data:(NSDictionary *)dictTerms2 andDetail:(NSString *)strdetail;
-(void)setPaymentSummaryData:(NSDictionary *)dict;
-(void)HideData;
@end
