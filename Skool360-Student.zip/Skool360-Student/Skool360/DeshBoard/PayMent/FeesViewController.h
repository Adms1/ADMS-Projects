//
//  FeesViewController.h
//  Skool360
//
//  Created by ADMS on 04/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface FeesViewController : MasterViewController

@property(nonatomic,retain)IBOutlet UIView *circleView;
@property(nonatomic,retain)IBOutlet UILabel *lblTotalFees;
@property(nonatomic,retain)IBOutlet UILabel *lblDueFees;
@property(nonatomic,retain)IBOutlet UILabel *lblDiscountFees;
@property(nonatomic,retain)IBOutlet UIButton *btnMoreDetails;
@property(nonatomic,strong)IBOutlet UIImageView *imgRight;

@end
