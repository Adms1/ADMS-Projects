//
//  ReportCardViewController.h
//  Skool360
//
//  Created by ADMS on 01/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface PaymentOnlineVC : MasterViewController
{
    IBOutlet UIWebView *webView;
    IBOutlet UIActivityIndicatorView *actView;
}
@property(nonatomic,retain)NSString *paymentUrl;
@end
