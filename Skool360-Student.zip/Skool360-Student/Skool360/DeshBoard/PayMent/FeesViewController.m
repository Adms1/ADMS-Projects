
//
//  FeesViewController.m
//  Skool360
//
//  Created by ADMS on 04/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "FeesViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "PayMentViewController.h"

@interface FeesViewController ()
{
    NSMutableArray *arrCheckData;
}
@end

@implementation FeesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    _btnMoreDetails.layer.shadowColor = [[[UIColor clearColor] colorWithAlphaComponent:0.3] CGColor];
    _btnMoreDetails.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
    _btnMoreDetails.layer.shadowOpacity = 1.0f;
    _btnMoreDetails.layer.shadowRadius = 1.0f;
}

-(void)viewWillAppear:(BOOL)animated
{
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:self.title.uppercaseString forState:0];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:1]) addTarget:self action:@selector(onClickSideMenuBtn:) forControlEvents:UIControlEventTouchUpInside];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:2]) addTarget:self action:@selector(onClickBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    arrCheckData = [[NSMutableArray alloc]init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    NSString *strTermID = [[NSUserDefaults standardUserDefaults]objectForKey:TERMID];
    NSString *strStandardID = [[NSUserDefaults standardUserDefaults]objectForKey:STANDARDID];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strTermID forKey:@"Term"];
    [params setObject:strStandardID forKey:@"StandardID"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:payMent_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [self.view.subviews makeObjectsPerformSelector:@selector(setHidden:) withObject:NO];
            
            [_lblTotalFees setText:[NSString stringWithFormat:@"₹ %@",[responseObject safeObjectForKey:@"TermTotal"]]];
            [_lblDueFees setText:[NSString stringWithFormat:@"₹ %@",[responseObject safeObjectForKey:@"TermDuePay"]]];
            [_lblDiscountFees setText:[NSString stringWithFormat:@"₹ %@",[responseObject safeObjectForKey:@"TermDiscount"]]];
            [((UILabel *)[[_circleView subviews] firstObject]) setText:[NSString stringWithFormat:@"₹ %@",[responseObject safeObjectForKey:@"TermPaid"]]];
            
            arrCheckData = [responseObject safeObjectForKey:@"FinalArray"];
            
        }else{
            //[CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"data"] delegate:self];
            [_lblTotalFees setText:@"₹ 0.00"];
            [_lblDueFees setText:@"₹ 0.00"];
            [_lblDiscountFees setText:@"₹ 0.00"];
            [((UILabel *)[[_circleView subviews] firstObject]) setText:@"₹ 0.00"];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)viewDidAppear:(BOOL)animated
{
    [self.circleView layoutIfNeeded];
    self.circleView.layer.cornerRadius = self.circleView.frame.size.width / 2;
    self.circleView.clipsToBounds = YES;
    
    self.circleView.layer.borderColor = circleColor.CGColor;
    self.circleView.layer.borderWidth = 6.0;
}

-(IBAction)btnMoreDetails:(id)sender
{
    if(arrCheckData.count > 0) {
        ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        PayMentViewController *pvc = [storyBoard instantiateViewControllerWithIdentifier:@"PayMentViewController"];
        pvc.title = @"Payment";
        pvc.transition = animation;
        [self.navigationController pushViewController:pvc animated:YES];
    }else{
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Payment details are not available" delegate:self];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
