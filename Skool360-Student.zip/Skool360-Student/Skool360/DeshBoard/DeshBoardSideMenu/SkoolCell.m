//
//  SkoolCell.m
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "SkoolCell.h"

@implementation SkoolCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.imgProfilePic.layer.borderColor = imgCircleColor.CGColor;
    self.imgProfilePic.layer.borderWidth = 1.0f;
    
    self.lblUserName.font = IS_IPAD ? FONT_Bold(16) : FONT_Bold(13);
    self.lblGradeSection.font = IS_IPAD ? FONT_Semibold(16) : FONT_Semibold(13);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
