//
//  SkoolSideMenu.m
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "SkoolSideMenu.h"
#import "HomeView.h"
#import "MyProfileView.h"
#import "AttendanceView.h"
#import "AppDelegate.h"

@interface SkoolSideMenu ()

@end

@implementation SkoolSideMenu

AppDelegate *appDelegateSkoolSide;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    appDelegateSkoolSide = [AppDelegate sharedAppDelegate];
    
    arrSideMenu = [[NSMutableArray alloc] init];
    
    //    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadFeedViewNotification:)name:RELOAD_FEED_NOTIFICATION object:nil];
    
    [arrSideMenu addObject:[self getDictfromTitle:@"Home"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"My Profile"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Attendance"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Homework"]];
    //[arrSideMenu addObject:[self getDictfromTitle:@"Classwork"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Timetable"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Event"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Appointment Requests"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Imprest"]];
    //[arrSideMenu addObject:[self getDictfromTitle:@"Announcements"]];
    //[arrSideMenu addObject:[self getDictfromTitle:@"Circular"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Results"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Report Card"]];
    //[arrSideMenu addObject:[self getDictfromTitle:@"Exams"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Canteen"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Unit Test"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Course"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"PayMent"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Logout"]];
    
    
    tblSideMenu.tableFooterView  = [[UIView alloc]initWithFrame:CGRectZero];
}

-(void)reloadFeedViewNotification:(NSNotification *) notification
{
    appDelegateSkoolSide = [AppDelegate sharedAppDelegate];
    
    arrSideMenu = [[NSMutableArray alloc] init];
    
    [arrSideMenu addObject:[self getDictfromTitle:@"Home"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"My Profile"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Attendance"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Homework"]];
    //    [arrSideMenu addObject:[self getDictfromTitle:@"Classwork"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Timetable"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Event"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Appointment Requests"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Imprest"]];
    //    [arrSideMenu addObject:[self getDictfromTitle:@"Announcements"]];
    //    [arrSideMenu addObject:[self getDictfromTitle:@"Circular"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Results"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Report Card"]];
    //    [arrSideMenu addObject:[self getDictfromTitle:@"Exams"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Canteen"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Unit Test"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Course"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"PayMent"]];
    [arrSideMenu addObject:[self getDictfromTitle:@"Logout"]];
    
    tblSideMenu.tableFooterView  = [[UIView alloc]initWithFrame:CGRectZero];
    [tblSideMenu reloadData];
    
}

#pragma mark -
#pragma mark - SideMenu Icon And Title Dict Method

-(NSMutableDictionary *)getDictfromTitle:(NSString *)title
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setObject:title forKey:@"title"];
    return dict;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return indexPath.row == 0 ? 120 : 44;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [arrSideMenu count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SkoolCell *cell = (SkoolCell *)[tableView dequeueReusableCellWithIdentifier:indexPath.row == 0 ? @"SkoolHeaderCell" : @"SkoolCell"];
    
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SkoolCell" owner:self options:nil];
        cell = [nib objectAtIndex:indexPath.row == 0 ? 1 : 0];
    }
    
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    if(indexPath.row > 0) {
        [cell selcectedCell:[arrSideMenu objectAtIndex:indexPath.row-1]];
    }
    return cell;
}

#pragma mark -
#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    /*
     if (indexPath.row == 0) {
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 1){
     MyProfileView *objProfile = [[MyProfileView alloc] initWithNibName:@"MyProfileView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objProfile];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 2){
     AttendanceView *objAttendance = [[AttendanceView alloc] initWithNibName:@"AttendanceView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objAttendance];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 3){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 4){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 5){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 6){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 7){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 8){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 9){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 10){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 11){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 12){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 13){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 14){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 15){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 16){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }else if (indexPath.row == 17){
     HomeView *objHome = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
     NSArray *controllers = [NSArray arrayWithObject:objHome];
     UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
     navigationController.viewControllers = controllers;
     }
     
     [self.menuContainerViewController setMenuState:MFSideMenuStateClosed];
     */
    [tblSideMenu reloadData];
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
