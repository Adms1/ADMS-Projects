//
//  SkoolCell.h
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SkoolCell : UITableViewCell

{
    
}
@property(nonatomic,retain)IBOutlet UIImageView *imgProfilePic;
@property(nonatomic,retain)IBOutlet UILabel *lblUserName;
@property(nonatomic,retain)IBOutlet UILabel *lblGradeSection;
-(void)selcectedCell:(NSDictionary*)dict;

@end
