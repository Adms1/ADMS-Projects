//
//  AnnouncementPDFViewController.m
//  Bhadaj (Student)
//
//  Created by ADMS on 20/06/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "AnnouncementPDFViewController.h"
#import "UIWebView+PdfViewer.h"
#import "AppDelegate.h"

@interface AnnouncementPDFViewController ()

@end

@implementation AnnouncementPDFViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [webView downloadPdf:[NSString stringWithFormat:@"%@%@",HostName, self.strFileName]];
}

-(void)viewWillDisappear:(BOOL)animated {
    isFromPush = NO;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [actView startAnimating];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [actView stopAnimating];
    [actView setHidesWhenStopped:YES];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [actView stopAnimating];
    [actView setHidesWhenStopped:YES];
}

- (IBAction)onClickBackBtn:(id)sender {
    [[self navigationController]popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
