//
//  AnnouncementPDFViewController.h
//  Bhadaj (Student)
//
//  Created by ADMS on 20/06/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface AnnouncementPDFViewController : MasterViewController
{
    IBOutlet UIWebView *webView;
    IBOutlet UIActivityIndicatorView *actView;
}
@property(nonatomic,retain)NSString *strFileName;
@end
