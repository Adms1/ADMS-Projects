//
//  CircularViewController.m
//  Skool360
//
//  Created by ADMS on 01/11/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "AnnouncementViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "AnnouncementCell.h"
#import "Announcement.h"
#import "AnnouncementPDFViewController.h"

@interface AnnouncementViewController ()
{
    NSMutableArray *arrAnnouncementList;
    NSInteger selectedIndex;
    CGFloat webViewHeight;
    NSMutableArray *contentHeights;
}
@end

@implementation AnnouncementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblAnnouncement.tableFooterView = [UIView new];
    selectedIndex = -1;
    [self getAnnouncementData];
}

-(void)getAnnouncementData
{
    arrAnnouncementList = [[NSMutableArray alloc] init];
    contentHeights = [[NSMutableArray alloc] init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:announcement_Url parameters:@{@"StandardID" : [[NSUserDefaults standardUserDefaults] valueForKey:STANDARDID]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            imgNoRecord.hidden = YES;
            
            NSMutableArray *arrListCircular = [responseObject safeObjectForKey:@"FinalArray"];
            
            int i = 0;
            for (NSDictionary *dict in arrListCircular) {
                
                Announcement *objAnnouncement = [[Announcement alloc] init];
                
                objAnnouncement.Subject = [dict safeObjectForKey:@"Subject"];
                objAnnouncement.CreateDate = [dict safeObjectForKey:@"CreateDate"];
                if(isFromPush){
                    if ([objAnnouncement.CreateDate isEqualToString:pushDate]) {
                        selectedIndex = i;
                    }
                }
                objAnnouncement.AnnoucementDescription = [dict safeObjectForKey:@"AnnoucementDescription"];
                objAnnouncement.AnnoucementPDF = [dict safeObjectForKey:@"AnnoucementPDF"];
                
                [arrAnnouncementList addObject:objAnnouncement];
                [contentHeights addObject:[NSNumber numberWithFloat:0.0]];
                
                i += 1;
            }
        }else{
            imgNoRecord.hidden = NO;
        }
        [SHARED_APPDELEGATE hideLoadingView];
        [tblAnnouncement reloadData];
        
        if(selectedIndex != -1){
            [self goToNextViewController:selectedIndex];
            [tblAnnouncement scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selectedIndex] atScrollPosition:UITableViewScrollPositionNone animated:YES];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - Tableview DataSource & Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return arrAnnouncementList.count;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    AnnouncementCell *headerView = (AnnouncementCell *)[tableView dequeueReusableCellWithIdentifier:@"AnnouncementHeaderCell"];
    [headerView setAnnouncementHeaderData:arrAnnouncementList[section]];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(expandCollapseSection:)];
    headerView.contentView.tag = section;
    [headerView.contentView addGestureRecognizer:tapGesture];
    
    if(section == selectedIndex) {
        headerView.contentView.subviews[0].backgroundColor = TextBgColor;
        headerView.contentView.subviews[2].tintColor = TextBgColor;
    }else {
        headerView.contentView.subviews[0].backgroundColor = appColor;
        headerView.contentView.subviews[2].tintColor = appColor;
    }
    
    return arrAnnouncementList.count > 0 ? headerView.contentView : nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return IS_IPAD ? 60 : 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AnnouncementCell *headerView = (AnnouncementCell *)[tableView dequeueReusableCellWithIdentifier:@"AnnouncementHeaderCell"];
    [headerView setAnnouncementHeaderData:arrAnnouncementList[indexPath.section]];
    
    webViewHeight = [[contentHeights objectAtIndex: indexPath.section]floatValue];
    return indexPath.section == selectedIndex && [((Announcement *)arrAnnouncementList[selectedIndex]).AnnoucementPDF isEqualToString:@""] ? webViewHeight : 0;
    //    indexPath.section == selectedIndex && [((Announcement *)arrAnnouncementList[selectedIndex]).AnnoucementDescription isEqualToString:@""] ? 50 :
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return section == selectedIndex ? 1 : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *strIdentifier = @"AnnouncementCell";
    //    if([((Announcement *)arrAnnouncementList[indexPath.section]).AnnoucementDescription isEqualToString:@""]){
    //        strIdentifier = @"AnnouncementPdfCell";
    //    }
    
    AnnouncementCell *cell = (AnnouncementCell *)[tableView dequeueReusableCellWithIdentifier:strIdentifier];
    
    Announcement *objAnnouncement = arrAnnouncementList[indexPath.section];
    if([objAnnouncement.AnnoucementPDF isEqualToString:@""]){
        for (UIView *view in cell.contentView.subviews) {
            UIWebView *webView = (UIWebView *)view;
            webView.tag = indexPath.section;
            [webView loadHTMLString:objAnnouncement.AnnoucementDescription baseURL:nil];
        }
    }else{
        [[[cell contentView]subviews]firstObject].tag = indexPath.section;
    }
    return cell;
}

- (void)webViewDidFinishLoad:(UIWebView *)aWebView {
    
    webViewHeight = [[contentHeights objectAtIndex: aWebView.tag]floatValue];
    if (webViewHeight == 0) {
        
        CGRect frame = aWebView.frame;
        frame.size.height = 1;
        aWebView.frame = frame;
        CGSize fittingSize = [aWebView sizeThatFits:CGSizeZero];
        frame.size = fittingSize;
        aWebView.frame = frame;
        
        [contentHeights replaceObjectAtIndex:aWebView.tag withObject:[NSNumber numberWithFloat:fittingSize.height + 20]];
        
        if (selectedIndex != -1) {
            [tblAnnouncement reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:selectedIndex]] withRowAnimation:UITableViewRowAnimationNone];
        }
    }
}

-(void)expandCollapseSection:(UITapGestureRecognizer *)gesture
{
    NSInteger Index = gesture.view.tag;
    
    if(selectedIndex == Index) {
        selectedIndex = -1;
    }
    else {
        selectedIndex = Index;
    }
    
    [tblAnnouncement reloadData];
    
    [self goToNextViewController:Index];
    
    if(selectedIndex != -1){
        [tblAnnouncement scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selectedIndex] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

-(void)goToNextViewController:(NSInteger)idx
{
    if([((Announcement *)arrAnnouncementList[idx]).AnnoucementDescription isEqualToString:@""]) {
        
        ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        AnnouncementPDFViewController *apvc = [storyBoard instantiateViewControllerWithIdentifier:@"AnnouncementPDFViewController"];
        apvc.strFileName = ((Announcement *)arrAnnouncementList[idx]).AnnoucementPDF;
        apvc.title = self.title;
        apvc.transition = animation;
        [self.navigationController pushViewController:apvc animated:YES];
        return;
    }
}

-(IBAction)btnDownload:(UIButton *)sender
{
    ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    AnnouncementPDFViewController *apvc = [storyBoard instantiateViewControllerWithIdentifier:@"AnnouncementPDFViewController"];
    apvc.strFileName = ((Announcement *)arrAnnouncementList[sender.tag]).AnnoucementPDF;
    apvc.title = self.title;
    apvc.transition = animation;
    [self.navigationController pushViewController:apvc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

