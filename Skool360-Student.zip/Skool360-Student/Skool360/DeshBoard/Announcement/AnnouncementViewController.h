//
//  CircularViewController.h
//  Skool360
//
//  Created by ADMS on 01/11/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface AnnouncementViewController : MasterViewController
{
    IBOutlet UITableView *tblAnnouncement;
    IBOutlet UIImageView *imgNoRecord;    
}
@end
