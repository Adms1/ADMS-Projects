//
//  AppointmentViewController.h
//  Skool360
//
//  Created by Darshan on 02/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "NIDropDown.h"

@interface LeaveApplicationViewController : MasterViewController
{
    IBOutlet UIView *viewDescription;
    IBOutlet UIView *viewDatePicker;
    IBOutlet UIScrollView *scrollV;
    IBOutlet UIButton *btnSave;
    IBOutlet UIButton *btnCancel;
    IBOutlet UIButton *btnFromDate;
    IBOutlet UIButton *btnToDate;
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnPickerDateCancel;
    IBOutlet UITextField *txtReason;
    IBOutlet UITextView *txvComment;
}

@end

