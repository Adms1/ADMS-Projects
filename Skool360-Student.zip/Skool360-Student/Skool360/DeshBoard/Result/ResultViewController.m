//
//  UnitTestViewController.m
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ResultViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface ResultViewController ()
{
    NSInteger termDetailID;
}
@end

@implementation ResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    [self setRadioButtons];
    tblResult.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
}

-(void)setRadioButtons
{
    for (UIView *view in self.view.subviews) {
        if(view.tag != 0) {
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnRadioButton:)];
            [view addGestureRecognizer:tap];
            
            if([view isKindOfClass:[UIButton classForCoder]]) {
                UIButton *btn = (UIButton *)view;
                [btn.layer setBorderColor:[[UIColor groupTableViewBackgroundColor]CGColor]];
                [btn.layer setBorderWidth:5.0];
                
                if (view.tag == 1) {
                    termDetailID = 1;
                    [btn setBackgroundColor:imgCircleColor];
                    
                    [self getTimeTableData];
                }
            }
        }
    }
}

-(void)tapOnRadioButton:(UITapGestureRecognizer *)gesture
{
    for (UIView *view in self.view.subviews) {
        if([view isKindOfClass:[UIButton classForCoder]]) {
            UIButton *btn = (UIButton *)view;
            [btn setBackgroundColor:[UIColor lightGrayColor]];
        }
    }
    
    termDetailID = gesture.view.tag > 2 ? gesture.view.tag/10 : gesture.view.tag;
    UIButton *btn = (UIButton *)[self.view viewWithTag:termDetailID];
    [btn setBackgroundColor:imgCircleColor];
    
    [self getTimeTableData];
}

-(void)getTimeTableData
{
    arrResults = [[NSMutableArray alloc] init];
    
    selectedSection = -1;
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *strStudentID = [defaults objectForKey:STUDENTID];
    NSString *strTermID = [defaults objectForKey:TERMID];
    
    imgNoRecord.hidden = YES;
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strTermID forKey:@"TermID"];
    [params setObject:[NSString stringWithFormat:@"%ld",(long)termDetailID] forKey:@"TermDetailId"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:unitTest_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrListHomeWork = [responseObject safeObjectForKey:@"FinalArray"];
            [arrResults addObjectsFromArray:arrListHomeWork];
            [tblResult reloadData];
        }else{
            tblResult.hidden = YES;
            imgNoRecord.hidden = NO;
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}


#pragma mark -
#pragma mark - TableView Delegate Method



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == selectedSection){
        UnitTestCell *cell = (UnitTestCell *)[self tableView:tblResult cellForRowAtIndexPath:indexPath];
        return [cell getUnitTestCellHeight];
    }else{
        return 0;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 45;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGRect rect = CGRectMake(0, 0, SHARED_APPDELEGATE.window.frame.size.width,50);
    UnitTestSectionView *viewFit = [[UnitTestSectionView alloc] initWithFrame:rect];
    
    viewFit.testDelegate = self;
    viewFit.index = (int)section;
    
    if(section == selectedSection){
        [viewFit setSelectedColor:imgCircleColor];
    }else{
        [viewFit setNormalColor];
    }
    
    NSDictionary *dictData =[arrResults objectAtIndex:section];
    [viewFit setSectionData:[dictData objectForKey:@"TestName"]];
    
    return viewFit;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [arrResults count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    //    NSDictionary *dictData =[arrResults objectAtIndex:section];
    //    NSArray *arrData =[dictData objectForKey:@"Data"];
    //    return [arrData count];
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    if(indexPath.section != selectedSection){
        
        static NSString *simpleTableIdenti = @"UnitTest1";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdenti];
        }
        
        return  cell;
    }else{
        
        static NSString *simpleTableIdenti = @"UnitTest";
        
        UnitTestCell *cell = (UnitTestCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"UnitTestCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle  = UITableViewCellSelectionStyleNone;
        
        //        NSDictionary *dictData =[arrResults objectAtIndex:indexPath.section];
        //
        //        NSArray *arrsecton = [dictData safeObjectForKey:@"Data"];
        //        NSDictionary *dict = [arrsecton objectAtIndex:indexPath.row];
        
        [cell setMarkSheetData:[arrResults objectAtIndex:indexPath.section]];
        
        return  cell;
    }
    
    return nil;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

-(void)setUnitTestDateAtindex:(int)index
{
    NSLog(@"Section Select: %d",index);
    
    if(index == selectedSection){
        selectedSection = -1;
    }else{
        selectedSection = index;
    }
    
    [tblResult reloadData];
    
    if (selectedSection != -1 && [tblResult numberOfRowsInSection:selectedSection] > 0) {
        [tblResult scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[tblResult numberOfRowsInSection:selectedSection]-1 inSection:selectedSection] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

