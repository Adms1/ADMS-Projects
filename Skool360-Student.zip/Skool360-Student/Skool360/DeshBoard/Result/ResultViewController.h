//
//  UnitTestViewController.h
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "UnitTestCell.h"
#import "UnitTestSectionView.h"

@interface ResultViewController : MasterViewController <UnitTestDelegate>

{
    IBOutlet UITableView *tblResult;
    
    IBOutlet UILabel *lblNoFound;
    
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    IBOutlet UIImageView *imgNoRecord;

    NSMutableArray *arrResults;
    
    int selectedSection;
}

@end

