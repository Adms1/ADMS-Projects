//
//  MarkSheetListCell.h
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UnitTest.h"

@interface MarkSheetListCell : UITableViewCell

{
    IBOutlet UILabel *lblDate;
    IBOutlet UILabel *lblSubject;
    IBOutlet UILabel *lblMark;
    IBOutlet UILabel *lblTotal;
    
    CGFloat cellHeight;
}
-(void)setMarkSheetDataList:(UnitTest*)objUnitTest;
-(CGFloat )getCellHeight;

@end
