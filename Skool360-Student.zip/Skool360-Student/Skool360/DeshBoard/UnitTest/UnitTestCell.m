//
//  UnitTestCell.m
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "UnitTestCell.h"
#import "UnitTest.h"
#import "CommonClass.h"
#import "UIImageView+GetLocalImage.h"

@implementation UnitTestCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    viewCellBack.layer.cornerRadius = 4.0f;
    viewCellBack.backgroundColor = btnUnSlectBackgroundColor;
    viewCellBack.layer.shadowColor = [[UIColor grayColor] CGColor];
    viewCellBack.layer.shadowOffset = CGSizeMake(0.0f,3.0f);
    viewCellBack.layer.shadowOpacity = 1.0f;
    viewCellBack.layer.shadowRadius = 2.0f;
    
    viewBack.layer.borderWidth = 1.0;
    viewBack.layer.borderColor = cellBoardColor.CGColor;
}

-(void)setMarkSheetData:(NSArray *)arrData
{
    NSArray *arrListMarkSheet = [arrData valueForKey:@"Data"];
    //    NSLog(@"arrData>>>> %@",arrListMarkSheet);
    
    lblTotalMark.text = [arrData valueForKey:@"Total Marks"];
    lblTotalMarkGained.text = [arrData valueForKey:@"Total MarksGained"];
    lblPercentage.text = [NSString stringWithFormat:@"Percentage :   %@",[arrData valueForKey:@"Total Percentage"]];
    
    arrMarkList = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dict in arrListMarkSheet) {
        
        UnitTest *objUnitTest = [[UnitTest alloc] init];
        
        objUnitTest.MarkGained = [dict safeObjectForKey:@"MarkGained"];
        objUnitTest.Percentage = [dict safeObjectForKey:@"Percentage"];
        objUnitTest.SubjectName = [dict safeObjectForKey:@"SubjectName"];
        objUnitTest.Date = [dict safeObjectForKey:@"Date"];
        objUnitTest.TestMark = [dict safeObjectForKey:@"TestMark"];
        
        [arrMarkList addObject:objUnitTest];
    }
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return IS_IPAD ? 42 : viewHeader.frame.size.height;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return viewHeader;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return IS_IPAD ? 68 : viewFooter.frame.size.height;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return  viewFooter;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return IS_IPAD ? 42 : 36.0f;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [arrMarkList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdenti = @"MarkCell";
    
    MarkSheetListCell *cell = (MarkSheetListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MarkSheetListCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    UnitTest *objUnit = [arrMarkList objectAtIndex:indexPath.row];
    
    [cell setMarkSheetDataList:objUnit];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

-(CGFloat )getUnitTestCellHeight
{
    cellHeight = (IS_IPAD ? 42 : viewHeader.frame.size.height) + (IS_IPAD ? 68 : viewFooter.frame.size.height) + ([arrMarkList count] * (IS_IPAD ? 42 : 36)) + 4;
    return cellHeight;
}

-(void)setUnitTestData:(NSArray *)arrData
{
    [_imgDrop getIconsfromLocal:@"Drop" :YES];
    [_imgDrop setTintColor:[[UIColor clearColor] colorWithAlphaComponent:0.05]];
    
    [_viewSyllabus setHidden:NO];
    [_viewSyllabus.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    _viewSyllabus.layer.cornerRadius = 5.0;
    _viewSyllabus.clipsToBounds = YES;
    
    CGFloat constHeight = 8;
    CGFloat lblHeight = 0;
    for(int i = 0; i < arrData.count; i++)
    {
        NSString *str = [arrData objectAtIndex:i];
        CGFloat height = [CommonClass getLabelHeight:str :_viewSyllabus.frame.size.width];
        
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(0, constHeight + lblHeight, _viewSyllabus.frame.size.width, height)];
        [lbl setText:str];
        [lbl setTextAlignment:NSTextAlignmentCenter];
        [lbl setTextColor:[UIColor blackColor]];
        [lbl setFont:FONT_OpenSans(12)];
        [lbl setNumberOfLines:0];
        [lbl setLineBreakMode:NSLineBreakByWordWrapping];
        [_viewSyllabus addSubview:lbl];
        
        if (i < arrData.count - 1) {
            UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, lbl.frame.origin.y + height + constHeight, _viewSyllabus.frame.size.width, 1)];
            [line setBackgroundColor:[UIColor grayColor]];
            [_viewSyllabus addSubview:line];
            
            lblHeight = line.frame.origin.y + line.frame.size.height;
        }
        else{
            lblHeight = lbl.frame.origin.y + lbl.frame.size.height;
        }
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
