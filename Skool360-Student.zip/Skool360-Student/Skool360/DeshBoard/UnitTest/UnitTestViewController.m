//
//  UnitTestViewController.m
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "UnitTestViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface UnitTestViewController ()<NIDropDownDelegate>
{
    NSMutableDictionary *dicTag;
    NSMutableDictionary *dicExamSyllabus;
    NIDropDown *dropDown;
    NSString *selectedTest;
    NSMutableArray *arrTestNames;
}
@end

@implementation UnitTestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    selectedSection = -1;
    
    [self getTimeTableData];
    
    tblUnitTest.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    tblUnitTest.estimatedRowHeight = 50.0;
    tblUnitTest.rowHeight = UITableViewAutomaticDimension;
    
    btnUnitTest.layer.cornerRadius = 4.0f;
    btnUnitTest.layer.borderWidth = 0.5f;
    btnUnitTest.layer.borderColor = imgCircleColor.CGColor;
}

-(void)getTimeTableData
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *strStudentID = [defaults objectForKey:STUDENTID];
    NSString *strTermID = [defaults objectForKey:TERMID];
    
    imgNoRecord.hidden = YES;
    btnUnitTest.hidden = YES;
    imgArrow.hidden = YES;
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strTermID forKey:@"TermID"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    dicTag = [[NSMutableDictionary alloc] init];
    arrUnitTest = [[NSMutableArray alloc] init];
    dicExamSyllabus = [[NSMutableDictionary alloc]init];
    arrTestNames = [[NSMutableArray alloc]init];
    
    [manager POST:GetTestDetail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            btnUnitTest.hidden = NO;
            imgArrow.hidden = NO;
            
            NSMutableArray *arrListHomeWork = [responseObject safeObjectForKey:@"FinalArray"];
            
            NSMutableArray *storeValues;
            for (NSDictionary *dicValue in arrListHomeWork)
            {
                storeValues = [[NSMutableArray alloc]init];
                if(dicExamSyllabus[dicValue[@"TestName"]] == nil)
                {
                    [storeValues addObject:@{@"TestDate" : dicValue[@"TestDate"], @"Data" : dicValue[@"Data"]}];
                }
                else
                {
                    storeValues = dicExamSyllabus[dicValue[@"TestName"]];
                    [storeValues addObject:@{@"TestDate" : dicValue[@"TestDate"], @"Data" : dicValue[@"Data"]}];
                }
                
                if(![arrTestNames containsObject:[NSString stringWithFormat:@"%@",dicValue[@"TestName"]]]){
                    [arrTestNames addObject:dicValue[@"TestName"]];
                }
                [dicExamSyllabus setObject:storeValues forKey:dicValue[@"TestName"]];
            }
            
            //arrTestNames = [[dicExamSyllabus allKeys] sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
            selectedTest = arrTestNames[0];
            
            [btnUnitTest setTitle:selectedTest forState:0];
            //[arrUnitTest addObjectsFromArray:arrListHomeWork];
            [tblUnitTest reloadData];
        }else{
            tblUnitTest.hidden = YES;
            imgNoRecord.hidden = NO;
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (IBAction)onClickTestBtn:(id)sender {
    
    if(dropDown == nil) {
        CGFloat f = arrTestNames.count * 30;;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arrTestNames :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender :(NSInteger)index{
    [self rel];
    selectedTest = [arrTestNames objectAtIndex:index];
    
    dicTag = [[NSMutableDictionary alloc] init];
    selectedSection = -1;
    [tblUnitTest reloadData];
}

-(void)rel{
    dropDown = nil;
}

#pragma mark -
#pragma mark - TableView Delegate Method

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == selectedSection){
        if (dicTag != nil)
        {
            if ([[dicTag allKeys] containsObject:[NSString stringWithFormat:@"%d",indexPath.section]])
            {
                NSString *dicValue = [dicTag valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
                NSInteger section  = [[[dicValue componentsSeparatedByString:@"-"]firstObject] integerValue];
                NSInteger row  = [[[dicValue componentsSeparatedByString:@"-"]lastObject] integerValue];
                
                if (indexPath.section == section && indexPath.row == row)
                {
                    NSDictionary *dictData =[arrUnitTest objectAtIndex:indexPath.section];
                    NSArray *arrsecton = [dictData safeObjectForKey:@"Data"];
                    NSArray *array = [[[arrsecton objectAtIndex:indexPath.row] valueForKey:@"Detail"] componentsSeparatedByString:@"|"];
                    
                    CGFloat newheight = 0;
                    for(int i = 0; i < array.count; i++)
                    {
                        NSString *str = [array objectAtIndex:i];
                        CGFloat height = [CommonClass getLabelHeight:str :tblUnitTest.frame.size.width - 30];
                        newheight += height + 17;
                    }
                    return newheight + 55;
                }
                return UITableViewAutomaticDimension;
            }
            return UITableViewAutomaticDimension;
        }
        return UITableViewAutomaticDimension;
    }else{
        if (dicTag != nil) {
            [dicTag removeObjectForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
        }
        return 0;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 45;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGRect rect = CGRectMake(0, 0, SHARED_APPDELEGATE.window.frame.size.width,50);
    UnitTestSectionView *viewFit = [[UnitTestSectionView alloc] initWithFrame:rect];
    
    viewFit.testDelegate = self;
    viewFit.index = (int)section;
    
    if(section == selectedSection){
        [viewFit setSelectedColor:imgCircleColor];
    }else{
        [viewFit setNormalColor];
    }
    
    arrUnitTest = (NSMutableArray *)[dicExamSyllabus valueForKey:selectedTest]; //--
    NSDictionary *dictData =[arrUnitTest objectAtIndex:section];
    [viewFit setSectionData:[dictData objectForKey:@"TestDate"]];
    
    return viewFit;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //return [arrUnitTest count];
    return dicExamSyllabus.count > 0 ? ((NSMutableArray *)[dicExamSyllabus valueForKey:selectedTest]).count : 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    arrUnitTest = (NSMutableArray *)[dicExamSyllabus valueForKey:selectedTest]; //-- new
    NSDictionary *dictData =[arrUnitTest objectAtIndex:section];
    NSArray *arrData =[dictData objectForKey:@"Data"];
    return  section == selectedSection ? [arrData count] : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UnitTestCell *cell = (UnitTestCell *)[tblUnitTest dequeueReusableCellWithIdentifier:@"UnitTest" forIndexPath:indexPath];
    
    //        if (cell == nil)
    //        {
    //            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"UnitTestCell" owner:self options:nil];
    //            cell = [nib objectAtIndex:1];
    //        }
    //
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    arrUnitTest = (NSMutableArray *)[dicExamSyllabus valueForKey:selectedTest]; //-- new
    NSDictionary *dictData =[arrUnitTest objectAtIndex:indexPath.section];
    NSArray *arrsecton = [dictData safeObjectForKey:@"Data"];
    NSArray *arrDetails = [[[arrsecton objectAtIndex:indexPath.row] valueForKey:@"Detail"] componentsSeparatedByString:@"|"];
    
    [cell.lblSubject setText:[[arrsecton objectAtIndex:indexPath.row] valueForKey:@"Subject"]];
    [cell.btnViewSyllabus2 setTransform:CGAffineTransformIdentity];
    
    if(dicTag != nil)
    {
        if ([[dicTag allKeys] containsObject:[NSString stringWithFormat:@"%d",indexPath.section]])
        {
            NSString *dicValue = [dicTag valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
            NSInteger section  = [[[dicValue componentsSeparatedByString:@"-"]firstObject] integerValue];
            NSInteger row  = [[[dicValue componentsSeparatedByString:@"-"]lastObject] integerValue];
            
            if (indexPath.section == section && indexPath.row == row)
            {
                [cell setUnitTestData:arrDetails];
                [UIView animateWithDuration:0.3f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                    [cell.btnViewSyllabus2 setTransform:CGAffineTransformRotate(cell.btnViewSyllabus2.transform, M_PI/2)];
                } completion:nil];
                cell.btnViewSyllabus1.selected = YES;
                cell.btnViewSyllabus2.selected = YES;
            }
            else
            {
                [UIView animateWithDuration:0.3f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                    [cell.btnViewSyllabus2 setTransform:CGAffineTransformIdentity];
                } completion:nil];
                [cell.viewSyllabus.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [cell.imgDrop setTintColor:[UIColor clearColor]];
                cell.btnViewSyllabus1.selected = NO;
                cell.btnViewSyllabus2.selected = NO;
            }
        }
        else
        {
            [UIView animateWithDuration:0.3f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                [cell.btnViewSyllabus2 setTransform:CGAffineTransformIdentity];
            } completion:nil];
            [cell.viewSyllabus.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
            [cell.imgDrop setTintColor:[UIColor clearColor]];
            cell.btnViewSyllabus1.selected = NO;
            cell.btnViewSyllabus2.selected = NO;
        }
    }
    else
    {
        [UIView animateWithDuration:0.3f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [cell.btnViewSyllabus2 setTransform:CGAffineTransformIdentity];
        } completion:nil];
        [cell.viewSyllabus.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        [cell.imgDrop setTintColor:[UIColor clearColor]];
        cell.btnViewSyllabus1.selected = NO;
        cell.btnViewSyllabus2.selected = NO;
    }
    
    cell.btnViewSyllabus1.superview.tag = indexPath.section;
    cell.btnViewSyllabus2.superview.tag = indexPath.section;
    cell.btnViewSyllabus1.tag = indexPath.row;
    cell.btnViewSyllabus2.tag = indexPath.row;
    [cell.btnViewSyllabus1 addTarget:self action:@selector(btnViewSyllabus:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnViewSyllabus2 addTarget:self action:@selector(btnViewSyllabus:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
    
}

-(void)btnViewSyllabus:(UIButton *)sender
{
    sender.selected = !sender.selected;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:sender.tag inSection:sender.superview.tag];
    
    if (sender.selected)
    {
        [dicTag setObject:[NSString stringWithFormat:@"%d-%ld",sender.superview.tag,(long)sender.tag] forKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
    }
    else
    {
        [dicTag removeObjectForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
    }
    [tblUnitTest reloadData];
    
    if (selectedSection != -1 && [tblUnitTest numberOfRowsInSection:selectedSection] > 0) {
        [tblUnitTest scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

-(void)setUnitTestDateAtindex:(int)index
{
    NSLog(@"Section Select: %d",index);
    
    if(index == selectedSection){
        selectedSection = -1;
    }else{
        selectedSection = index;
    }
    [tblUnitTest reloadData];
    
    if (selectedSection != -1 && [tblUnitTest numberOfRowsInSection:selectedSection] > 0) {
        [tblUnitTest scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[tblUnitTest numberOfRowsInSection:selectedSection]-1 inSection:selectedSection] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
