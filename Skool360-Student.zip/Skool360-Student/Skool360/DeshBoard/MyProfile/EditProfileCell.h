//
//  EditProfileCell.h
//  Skool360
//
//  Created by Darshan on 24/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyProfile.h"

@protocol tblScrollDelegate <NSObject>

-(void)setTableScrollWithIndex:(int)index;
-(void)resingKeyBoard;
-(void)setUpdatePassword:(NSString*)strChange;

@end

@interface EditProfileCell : UITableViewCell

{
    NSString *strChangeType;
    IBOutlet UIImageView *imgLine;
    NSString *strPwd;
}

//Delegate
@property (strong , nonatomic) id<tblScrollDelegate> tblDelegate;

@property (nonatomic , strong) IBOutlet UILabel *lblUserName;
@property (nonatomic , strong) IBOutlet UITextField *txtPassword;
@property (nonatomic , strong) IBOutlet UIButton *btnChange;

//Integer
@property (nonatomic)int index;

-(void)setMyProfileEditData:(MyProfile *)objMyProfile;

@end
