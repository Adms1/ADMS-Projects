//
//  EducationalCell.h
//  Skool360
//
//  Created by Darshan on 24/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyProfile.h"

@interface EducationalCell : UITableViewCell

{
    
    
    
}

@property (nonatomic , strong) IBOutlet UILabel *lblGRNO;
@property (nonatomic , strong) IBOutlet UILabel *lblStandard;
@property (nonatomic , strong) IBOutlet UILabel *lblClass;

-(void)setMyProfileEducationData:(MyProfile *)objMyProfile;
@end
