//
//  EducationalCell.m
//  Skool360
//
//  Created by Darshan on 24/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "EducationalCell.h"

@implementation EducationalCell

@synthesize lblGRNO;
@synthesize lblStandard;
@synthesize lblClass;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setMyProfileEducationData:(MyProfile *)objMyProfile
{
    lblGRNO.text = objMyProfile.GRNO;
    lblStandard.text = objMyProfile.Standard;
    lblClass.text = objMyProfile.Class;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
