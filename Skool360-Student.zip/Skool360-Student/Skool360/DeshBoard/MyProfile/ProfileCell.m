//
//  ProfileCell.m
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ProfileCell.h"
#import "CommonClass.h"

@implementation ProfileCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setMyProfileData:(MyProfile *)objMyProfile
{
    cellHeight = 490.0f;
    
    lblName.text = objMyProfile.StudentName;
    lblDateOFBirth.text = objMyProfile.StudentDOB;
    lblAge.text = objMyProfile.StudentAge;
    lblGender.text = objMyProfile.StudentGender;
    lblBloodGroup.text = objMyProfile.BloodGroup;
    lblBirthPlace.text = objMyProfile.BirthPlace;
    lblFatherName.text = objMyProfile.FatherName;
    lblFatherPhoneNo.text = objMyProfile.FatherPhone;
    lblFatherEmail.text = objMyProfile.FatherEmail;
    lblMotherName.text = objMyProfile.MotherName;
    lblMotherPhoneNo.text = objMyProfile.MotherMobile;
    lblMotherEmail.text = objMyProfile.MotherEmail;
    lblSMSNo.text = objMyProfile.SMSNo;

    lblAddress.text = objMyProfile.Address;
    CGSize lblTitleExpectedsize = [CommonClass getDynamicHeightOflbl:lblAddress];
    CGRect titleNewFrame = lblAddress.frame;
    titleNewFrame.size.height = lblTitleExpectedsize.height;
    lblAddress.frame = titleNewFrame;
    [self setCellNewHeight:lblTitleExpectedsize.height];
    
    lblCity.text = objMyProfile.City;
    lblKM.text = objMyProfile.Transport_KM;
    lblPickUpTime.text = objMyProfile.Transport_PicupTime;
    lblDropTime.text = objMyProfile.Transport_DropTime;
    lblTitleDropPointName.text = objMyProfile.Transport_DropPointName;
    lblTitleRouteName.text = objMyProfile.Transport_RouteName;
    lblTitlePickupPointName.text = objMyProfile.Transport_PickupPointName;
    lblTitleBusNo.text = objMyProfile.BusNo;
}

-(void)setCellNewHeight:(float)extraheight
{
    cellHeight = cellHeight + (extraheight - 15);
}
-(CGFloat )getCellHeight
{
    return cellHeight;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
