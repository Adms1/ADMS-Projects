//
//  MyProfileView.h
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

//#import "MasterViewController.h"
#import <UIKit/UIKit.h>
#import "MasterViewController.h"
#import "ProfileCell.h"
#import "EducationalCell.h"
#import "EditProfileCell.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"

@interface MyProfileView : MasterViewController <tblScrollDelegate,UITableViewDelegate,UITableViewDataSource>

{
    IBOutlet UIView *viewFooter;
    IBOutlet UIView *viewtitle;
    
    IBOutlet UITableView *tblProfileList;
    
    IBOutlet UIButton *btnUpdatePassword;
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    
    IBOutlet UIImageView *imgLogo;
        
    NSMutableArray *arrProfileList;
    NSUserDefaults *userDefault;
    NSString *strProfileType;
}

@end
