//
//  EditProfileCell.m
//  Skool360
//
//  Created by Darshan on 24/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "EditProfileCell.h"
#import "AppDelegate.h"

@implementation EditProfileCell

@synthesize lblUserName;
@synthesize txtPassword;
@synthesize btnChange;
@synthesize index;
@synthesize tblDelegate;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setMyProfileEditData:(MyProfile *)objMyProfile
{
    lblUserName.text = objMyProfile.UserName;
    
    //txtPassword.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Password" attributes:@{NSForegroundColorAttributeName:[UIColor blackColor],NSFontAttributeName:FONT_OpenSans(13)}];
    strPwd = objMyProfile.Password;
    txtPassword.secureTextEntry = YES;
    txtPassword.text = strPwd;
    txtPassword.userInteractionEnabled = NO;
    txtPassword.leftViewMode = UITextFieldViewModeAlways;
    txtPassword.rightViewMode = UITextFieldViewModeAlways;
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    if (tblDelegate &&[tblDelegate respondsToSelector:@selector(resingKeyBoard)]) {
        [tblDelegate resingKeyBoard];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (tblDelegate &&[tblDelegate respondsToSelector:@selector(setTableScrollWithIndex:)]) {
        [tblDelegate setTableScrollWithIndex:index];
    }
}

- (IBAction)onClickChangeBtn:(id)sender {
    
    if (txtPassword.text.length == 0) {
        txtPassword.text = strPwd;
    }
    
    if (btnChange.selected == YES) {
        strChangeType = @"Cancel";
        btnChange.selected = NO;
        txtPassword.userInteractionEnabled = NO;
        imgLine.hidden = YES;
    }else{
        strChangeType = @"Change";
        btnChange.selected = YES;
        txtPassword.userInteractionEnabled = YES;
        imgLine.hidden = NO;
    }
    if (tblDelegate && [tblDelegate respondsToSelector:@selector(setUpdatePassword:)]) {
        [tblDelegate setUpdatePassword:strChangeType];
    }

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
