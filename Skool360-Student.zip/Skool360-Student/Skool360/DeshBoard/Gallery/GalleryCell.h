//
//  GalleryCell.h
//  Bhadaj (Student)
//
//  Created by ADMS on 23/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GalleryCell : UICollectionViewCell

@property(nonatomic,retain)IBOutlet UIImageView *imgPic;
@property(nonatomic,retain)IBOutlet UILabel *lblName;
@end
