//
//  GalleryViewController.h
//  Bhadaj (Student)
//
//  Created by ADMS on 23/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"
#import "Events.h"
#import "Photos.h"

extern NSInteger photoType;
extern NSMutableArray<Events *> *arrGalleryData;
extern NSInteger selectedEventIndex;
extern NSInteger selectedPhotoIndex;

@interface GalleryViewController : MasterViewController
{
    IBOutlet UICollectionView *collectionView;
    IBOutlet UIView *photoView;
    IBOutlet UIImageView *imgNoRecord;
    IBOutlet UIButton *btnNext;
    IBOutlet UIButton *btnPrevious;
}
@end
