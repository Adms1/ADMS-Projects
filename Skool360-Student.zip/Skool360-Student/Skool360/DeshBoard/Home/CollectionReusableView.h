//
//  CollectionReusableView.h
//  Skool360
//
//  Created by ADMS on 29/08/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyProfile.h"

//@protocol CollectionReusableViewDelegate <NSObject>
//-(void)headerData:(NSDictionary *)hdata;
//@end

@interface CollectionReusableView : UICollectionReusableView{
    NSTimer *timer;
}
@property(nonatomic,retain)IBOutlet UIScrollView *scrollImages;
@property(nonatomic,retain)IBOutlet UIImageView *imgStudentProfile;

-(void)addImages;
-(void)headerData:(MyProfile *)hdata;
@end
