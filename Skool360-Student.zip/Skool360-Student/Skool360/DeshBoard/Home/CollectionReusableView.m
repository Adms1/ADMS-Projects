//
//  CollectionReusableView.m
//  Skool360
//
//  Created by ADMS on 29/08/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CollectionReusableView.h"
#import "UIImageView+WebCache.h"
#import "UIImageView+GetLocalImage.h"

@implementation CollectionReusableView

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.imgStudentProfile.layer.borderColor = datePickerBoardColor.CGColor;
}

-(void)addImages
{
    [self layoutIfNeeded];
    
    self.imgStudentProfile.layer.cornerRadius = self.imgStudentProfile.frame.size.width / 2;
    self.imgStudentProfile.clipsToBounds = YES;
    
    for(int i = 0; i < 3; i++)
    {
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.scrollImages.frame.size.width * i, 0, self.scrollImages.frame.size.width, self.scrollImages.frame.size.height)];
        [imageView getIconsfromLocal:[NSString stringWithFormat:@"banner_%d",i+1] :NO];
        //imageView.contentMode = UIViewContentModeScaleAspectFill;
        [self.scrollImages addSubview:imageView];
    }
    
    [self.scrollImages setContentOffset:CGPointZero animated:YES];
    [self.scrollImages setContentSize:CGSizeMake(self.scrollImages.frame.size.width * 3, self.scrollImages.frame.size.height)];
    
    [timer invalidate];
    timer = nil;
    
    timer = [NSTimer scheduledTimerWithTimeInterval:3.0
                                                      target:self
                                                    selector:@selector(dynamicImagesChange)
                                                    userInfo:nil
                                                     repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
}

-(void)dynamicImagesChange {
    
    CGFloat pageWidth = self.scrollImages.frame.size.width;
    CGFloat maxWidth  = pageWidth * 3;
    CGFloat contentOffset  = self.scrollImages.contentOffset.x <= pageWidth * 3 ? self.scrollImages.contentOffset.x : 0;
    
    CGFloat slideToX  = contentOffset + pageWidth;
    
    if (contentOffset + pageWidth == maxWidth) {
        slideToX = 0;
    }
    
    [UIView animateWithDuration:1.0 animations:^{
        [self.scrollImages setContentOffset:CGPointMake(slideToX, 0)animated:YES];
    }];
}

-(void)headerData:(MyProfile *)hdata
{
    [self.imgStudentProfile sd_setImageWithURL:[NSURL URLWithString:[hdata.StudentImage stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"StudentProfile"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        self.imgStudentProfile.layer.borderWidth = 2.0;
    }];
    
    NSArray *arrlblData = @[hdata.StudentName,[NSString stringWithFormat:@"Grade : %@   Section : %@",hdata.Standard,hdata.Class],[NSString stringWithFormat:@"GRNO : %@",hdata.GRNO],[NSString stringWithFormat:@"Attendance : %@",[hdata.TodayAttendance isEqualToString:@""] ? @"N/A today" : hdata.TodayAttendance]];
    int i = 0;
    for (UIView *view in self.subviews[0].subviews) {
        if ([view isKindOfClass:[UILabel class]]) {
            UILabel *lbl = (UILabel *)view;
            [lbl setText:arrlblData[i]];
            [lbl sizeToFit];
            lbl.adjustsFontSizeToFitWidth = YES;
            i++;
        }
    }
    
    NSArray *arrlblOtherData = @[hdata.ClassTeacher,[NSString stringWithFormat:@"Pick Up : %@",hdata.Transport_PicupTime],[NSString stringWithFormat:@"Drop Off : %@",hdata.Transport_DropTime]];
    int j = 6;
    while (j < 8)
    {
        for (UIView *view in self.subviews[0].subviews[j].subviews) {
            
            if ([view isKindOfClass:[UILabel class]] && view.tag != 0) {
                UILabel *lbl = (UILabel *)view;
                [lbl setText:arrlblOtherData[view.tag-1]];
                [lbl sizeToFit];
                lbl.adjustsFontSizeToFitWidth = YES;
                j++;
            }
        }
    }
}

@end
