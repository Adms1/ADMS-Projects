//
//  HomeWorkViewController.h
//  Skool360
//
//  Created by Darshan on 31/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "HomeWorkCell.h"
#import "SectionView.h"

@interface HomeWorkViewController : MasterViewController <HomeWorkDateDelegate>

{
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewtitle;
    IBOutlet UIView *viewDatePicker;
    IBOutlet UIView *viewToolBar;
    
    IBOutlet UITableView *tblHomeWork;
    
    IBOutlet UILabel *lblNoFound;
    
    IBOutlet UIImageView *imgLogo;
    
    IBOutlet UIButton *btnFromDate;
    IBOutlet UIButton *btnToDate;
    IBOutlet UIButton *btnFilter;
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnCancel;
    
    IBOutlet UIImageView *imgCover;
    IBOutlet UIImageView *imgNoRecord;

//    NSMutableArray *arrHomeWork;
    NSMutableArray *arrHomeWorkList;
//    NSMutableArray *arrDateList;
    
//    BOOL cellShow;
    BOOL btnSelected;
    
    int selectedSection;
    
    IBOutlet UIDatePicker *pickerHomeWorkDate;
    
    NSString *strToDate;
    NSString *strFromDate;
    NSString *strCancelToDate;
    NSString *strCancelFromDate;
}

@end
