//
//  HomeWorkCell.h
//  Skool360
//
//  Created by Darshan on 31/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HCWork.h"

@interface HomeWorkCell : UITableViewCell

{
    IBOutlet UIView *viewBack;
    
    IBOutlet UILabel *txvHomeWorkDetail;
    
    IBOutlet UILabel *lblSubjectName;
    IBOutlet UILabel *lblChapter;
    IBOutlet UILabel *lblObj;
    IBOutlet UILabel *lblAQ;

    IBOutlet UILabel *lblHomeWorkDetail;
    IBOutlet UILabel *lblStatus;
    IBOutlet UILabel *lbl;
    IBOutlet UILabel *lbl1;
    IBOutlet UILabel *lbl2;
    IBOutlet UILabel *lbl3;
    IBOutlet UILabel *lblChapterName;
    IBOutlet UILabel *lblObjective;
    IBOutlet UILabel *lblAQuestion;
    
    IBOutlet NSLayoutConstraint *top1;
    IBOutlet NSLayoutConstraint *top2;
    IBOutlet NSLayoutConstraint *top3;
    IBOutlet NSLayoutConstraint *bottom;

}
@property(nonatomic,retain)IBOutlet UIButton *btnViewMore;
-(void)setHomeWorkData:(HCWork *)hcData;
-(void)setClassWorkData:(HCWork *)hcData;
-(void)setHomeWorkOtherData:(HCWork *)hcData;
@end
