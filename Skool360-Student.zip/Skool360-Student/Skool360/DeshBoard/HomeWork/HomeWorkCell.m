//
//  HomeWorkCell.m
//  Skool360
//
//  Created by Darshan on 31/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "HomeWorkCell.h"
#import "CommonClass.h"

@implementation HomeWorkCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    viewBack.layer.borderWidth = 1.0;
    viewBack.layer.borderColor = cellBoardColor.CGColor;
}

-(void)setHomeWorkData:(HCWork *)hcData
{
    if ([BunbleName containsString:@"Bhadaj"]) {
        lblSubjectName.text = [self stringByStrippingHTML:hcData.Subject];
        lblHomeWorkDetail.attributedText = hcData.HomeWork;
        lblStatus.text = hcData.Status;
        if([hcData.Status isEqualToString:@"Done"]){
            lblStatus.textColor = presentColor;
        }else if([hcData.Status isEqualToString:@"Pending"]){
            lblStatus.textColor = pendingColor;
        }else{
            lblStatus.textColor = absentColor;
        }
    }else{
        [viewBack.subviews makeObjectsPerformSelector:@selector(setHidden:)];
        lblSubjectName.hidden = lblHomeWorkDetail.hidden = _btnViewMore.hidden = lbl.hidden = NO;
        
        lblSubjectName.text = [self stringByStrippingHTML:hcData.Subject];
        lblHomeWorkDetail.attributedText = hcData.HomeWork;
        lblAQ.text = lblChapter.text = lblObj.text = lbl1.text = lbl2.text = lbl3.text = nil;
        lblObjective.attributedText = lblChapterName.attributedText = lblAQuestion.attributedText = nil;
        top1.constant = top2.constant = top3.constant = 0;
        bottom.constant = 10;
    }
}

-(void)setHomeWorkOtherData:(HCWork *)hcData
{
    lblSubjectName.hidden = lblHomeWorkDetail.hidden = _btnViewMore.hidden = lbl.hidden = NO;
    
    top1.constant = top2.constant = top3.constant = 8;
    
    lblChapter.text = @"Chapter Name";
    lblObj.text = @"Objective";
    lblAQ.text = @"Assessment Question";
    
    lbl1.text = @":";
    lbl2.text = @":";
    lbl3.text = @":";
    
    lblChapterName.attributedText = hcData.ChapterName;
    lblObjective.attributedText = hcData.Objective;
    lblAQuestion.attributedText = hcData.AssessmentQue;
    
    if ([CommonClass getLabelHeight:lblAQ.text :lblAQ.frame.size.width] > [CommonClass getLabelHeight:lblAQuestion.text :lblAQuestion.frame.size.width]) {
        bottom.constant = 20;
    }else {
        bottom.constant = 10;
    }
    
    [viewBack.subviews makeObjectsPerformSelector:@selector(setHidden:) withObject:NO];
}

-(void)setClassWorkData:(HCWork *)hcData
{
    lblSubjectName.text = [self stringByStrippingHTML:hcData.Subject];
    lblHomeWorkDetail.attributedText = hcData.ClassWork;
}

-(NSString *)stringByStrippingHTML:(NSString*)str
{
    NSRange r;
    while ((r = [str rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
    {
        str = [str stringByReplacingCharactersInRange:r withString:@""];
        str = [str stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@""];
        str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        str = [self htmlToText:str];
    }
    return str;
}

- (NSString *)htmlToText:(NSString*)htmlString {
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&amp;"  withString:@"&"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&lt;"  withString:@"<"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&gt;"  withString:@">"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&quot;" withString:@""""];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&#039;"  withString:@"'"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&#x27"  withString:@"'"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&#x96;"  withString:@"-"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
    return htmlString;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
