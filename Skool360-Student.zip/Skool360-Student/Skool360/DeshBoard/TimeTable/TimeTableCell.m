//
//  TimeTableCell.m
//  Skool360
//
//  Created by Darshan on 01/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "TimeTableCell.h"

@implementation TimeTableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setTimeTableData:(NSDictionary *)dictParam
{
    lblLecture.text = [NSString stringWithFormat:@"Lecture : %@",[dictParam safeObjectForKey:@"Lecture"]];
    lblSubject.text = [dictParam safeObjectForKey:@"Subject"];
    lblTeacher.text = [dictParam safeObjectForKey:@"Teacher"];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
