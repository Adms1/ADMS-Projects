//
//  TimeTableCell.h
//  Skool360
//
//  Created by Darshan on 01/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimeTableCell : UITableViewCell

{
    IBOutlet UILabel *lblLecture;
    IBOutlet UILabel *lblSubject;
    IBOutlet UILabel *lblTeacher;
}

-(void)setTimeTableData:(NSDictionary *)dictParam;

@end
