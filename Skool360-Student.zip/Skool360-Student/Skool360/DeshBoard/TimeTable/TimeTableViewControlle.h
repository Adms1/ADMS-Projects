//
//  TimeTableViewControlle.h
//  Skool360
//
//  Created by Darshan on 01/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "TimeTableCell.h"
#import "TimeTableSectionView.h"

@interface TimeTableViewControlle : MasterViewController <TimeTableDateDelegate>

{
    IBOutlet UITableView *tblTimeTable;
    
    IBOutlet UIView *viewtitle;
    
    IBOutlet UIImageView *imgLogo;
    
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    
    IBOutlet UILabel *lblNoFound;
    IBOutlet UIImageView *imgNoRecord;

    NSMutableArray *arrTimeTableList;
    
    int selectedSection;
}

@end
