//
//  TimeTableSectionView.m
//  Skool360
//
//  Created by Darshan on 01/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "TimeTableSectionView.h"
#import "AppDelegate.h"

@implementation TimeTableSectionView

//UIView
@synthesize viewBack;

//UILabel
@synthesize lblDate;

//Integer
@synthesize index;

//Delegate
@synthesize timeTableDelegate;

AppDelegate *appDelegateTimeTable;

-(id) initWithFrame:(CGRect)frame
{
    if(self == [super initWithFrame:frame])
    {
        appDelegateTimeTable = (AppDelegate *)[UIApplication sharedApplication].delegate;
        self = (TimeTableSectionView *)[TimeTableSectionView loadInstanceFromNib:self];
        
        UITapGestureRecognizer *singleFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dateSingleTap:)];
        [viewBack addGestureRecognizer:singleFingerTap];
    }
    return self;
}

-(void)setSelectedColor:(UIColor *)color
{
    imgTop.backgroundColor = sectionSelectColor;
    imgBottom.backgroundColor = sectionSelectColor;
}

-(void)setNormalColor
{
    imgTop.backgroundColor = [UIColor grayColor];
    imgBottom.backgroundColor = [UIColor grayColor];
}

-(void)setSectionData:(NSString *)title
{
    lblDate.text =title;
}

- (void)dateSingleTap:(UITapGestureRecognizer *)recognizer {
    
    if (timeTableDelegate && [timeTableDelegate respondsToSelector:@selector(setTimeTableDateAtindex:)]) {
        [timeTableDelegate setTimeTableDateAtindex:index];
    }
}

@end
