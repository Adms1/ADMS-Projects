//
//  TimeTableSectionView.h
//  Skool360
//
//  Created by Darshan on 01/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+NibLoading.h"

@protocol TimeTableDateDelegate <NSObject>

-(void)setTimeTableDateAtindex:(int)index;

@end

@interface TimeTableSectionView : UIView

{
    IBOutlet UIImageView *imgTop;
    IBOutlet UIImageView *imgBottom;
}

//Delegate
@property (strong , nonatomic) id<TimeTableDateDelegate> timeTableDelegate;

@property (nonatomic , strong) IBOutlet UIView *viewBack;
@property (nonatomic , strong) IBOutlet UILabel *lblDate;

-(void)setSectionData:(NSString *)title;

-(void)setSelectedColor:(UIColor *)color;
-(void)setNormalColor;

//Integer
@property (nonatomic)int index;

@end
