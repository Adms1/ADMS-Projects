//
//  CircularCell.m
//  Skool360
//
//  Created by ADMS on 01/11/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CircularCell.h"
#import "UIImageView+GetLocalImage.h"

@implementation CircularCell
{
    CGFloat webViewHeight;
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

-(void)setCircularHeaderData:(Circular *)circularData
{
//    self.contentView.subviews[0].layer.borderColor = detaultColor.CGColor;
//    self.contentView.subviews[0].layer.borderWidth = 1.0;
    [self.contentView.subviews[0].layer setShadowColor:[UIColor blackColor].CGColor];
    [self.contentView.subviews[0].layer setShadowOpacity:0.10f];
    [self.contentView.subviews[0].layer setShadowRadius:2.0f];
    [self.contentView.subviews[0].layer setShadowOffset:CGSizeMake(0.0f, 2.0f)];
    
    [((UIImageView *)self.contentView.subviews[2]) getIconsfromLocal:@"CanteenIcon" :YES];
    
    NSArray *array = @[circularData.CircularHeading, circularData.CreateDate];
    int i = 0;
    for (UIView *view in self.contentView.subviews[0].subviews) {
        if ([view isKindOfClass:[UILabel class]]) {
            UILabel *lbl = (UILabel *)view;
            lbl.text = array[i];
            
            i += 1;
        }
    }
}

-(void)setCircularData:(Circular *)circularData
{
    for (UIView *view in self.contentView.subviews) {
        UIWebView *webView = (UIWebView *)view;
        [webView loadHTMLString:circularData.CircularDescription baseURL:nil];
    }
}

- (void)webViewDidFinishLoad:(UIWebView *)aWebView {
    CGRect frame = aWebView.frame;
    frame.size.height = 1;
    aWebView.frame = frame;
    CGSize fittingSize = [aWebView sizeThatFits:CGSizeZero];
    frame.size = fittingSize;
    aWebView.frame = frame;
    
    webViewHeight = fittingSize.height;
}

-(CGFloat)getHeight{
    return webViewHeight + 20;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
