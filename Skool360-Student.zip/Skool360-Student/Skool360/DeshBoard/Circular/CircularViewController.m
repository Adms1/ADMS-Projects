//
//  CircularViewController.m
//  Skool360
//
//  Created by ADMS on 01/11/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CircularViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "CircularCell.h"
#import "AnnouncementPDFViewController.h"

@interface CircularViewController ()
{
    NSMutableArray *arrCircularList;
    NSInteger selectedIndex;
    CGFloat webViewHeight;
    NSMutableArray *contentHeights;
}
@end

@implementation CircularViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblCircular.tableFooterView = [UIView new];
    selectedIndex = -1;
    [self getCircularData];
}

-(void)getCircularData
{
    arrCircularList = [[NSMutableArray alloc] init];
    contentHeights = [[NSMutableArray alloc] init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:circularDetail_Url parameters:@{@"StandardID" : [[NSUserDefaults standardUserDefaults] valueForKey:STANDARDID]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            imgNoRecord.hidden = YES;
            
            NSMutableArray *arrListCircular = [responseObject safeObjectForKey:@"FinalArray"];
            
            int i = 0;
            for (NSDictionary *dict in arrListCircular) {
                
                Circular *objCircular = [[Circular alloc] init];
                
                objCircular.CircularHeading = [dict safeObjectForKey:@"Subject"];
                objCircular.CreateDate = [NSString stringWithFormat:@"(%@)",[dict safeObjectForKey:@"Date"]];
                if(isFromPush){
                    if ([[dict safeObjectForKey:@"Date"] isEqualToString:pushDate]) {
                        selectedIndex = i;
                    }
                }
                objCircular.CircularDescription = [dict safeObjectForKey:@"Discription"];
                objCircular.CircularPDF = [dict safeObjectForKey:@"CircularPDF"];
                
                [arrCircularList addObject:objCircular];
                [contentHeights addObject:[NSNumber numberWithFloat:0.0]];
                
                i += 1;
            }
        }else{
            imgNoRecord.hidden = NO;
        }
        [SHARED_APPDELEGATE hideLoadingView];
        [tblCircular reloadData];
        
        if(selectedIndex != -1){
            [self goToNextViewController:selectedIndex];
            [tblCircular scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selectedIndex] atScrollPosition:UITableViewScrollPositionNone animated:YES];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - Tableview DataSource & Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return arrCircularList.count;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CircularCell *headerView = (CircularCell *)[tableView dequeueReusableCellWithIdentifier:@"CircularHeaderCell"];
    [headerView setCircularHeaderData:arrCircularList[section]];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(expandCollapseSection:)];
    headerView.contentView.tag = section;
    [headerView.contentView addGestureRecognizer:tapGesture];
    
    if(section == selectedIndex) {
        headerView.contentView.subviews[0].backgroundColor = TextBgColor;
        headerView.contentView.subviews[2].tintColor = TextBgColor;
    }else {
        headerView.contentView.subviews[0].backgroundColor = appColor;
        headerView.contentView.subviews[2].tintColor = appColor;
    }
    return arrCircularList.count > 0 ? headerView.contentView : nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return IS_IPAD ? 60 : 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CircularCell *headerView = (CircularCell *)[tableView dequeueReusableCellWithIdentifier:@"CircularHeaderCell"];
    [headerView setCircularHeaderData:arrCircularList[indexPath.section]];
    
    webViewHeight = [[contentHeights objectAtIndex: indexPath.section]floatValue];
    return indexPath.section == selectedIndex && [((Circular *)arrCircularList[selectedIndex]).CircularPDF isEqualToString:@""] ? webViewHeight : 0;
    //     indexPath.section == selectedIndex && [((Circular *)arrCircularList[selectedIndex]).CircularDescription isEqualToString:@""] ? 50
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return section == selectedIndex ? 1 : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *strIdentifier = @"CircularCell";
    //    if([((Circular *)arrCircularList[indexPath.section]).CircularDescription isEqualToString:@""]){
    //        strIdentifier = @"CircularPdfCell";
    //    }
    
    CircularCell *cell = (CircularCell *)[tableView dequeueReusableCellWithIdentifier:strIdentifier];
    
    Circular *objCircular = arrCircularList[indexPath.section];
    if([objCircular.CircularPDF isEqualToString:@""]){
        for (UIView *view in cell.contentView.subviews) {
            UIWebView *webView = (UIWebView *)view;
            webView.tag = indexPath.section;
            [webView loadHTMLString:objCircular.CircularDescription baseURL:nil];
        }
    }else{
        [[[cell contentView]subviews]firstObject].tag = indexPath.section;
    }
    return cell;
}

- (void)webViewDidFinishLoad:(UIWebView *)aWebView {
    
    webViewHeight = [[contentHeights objectAtIndex: aWebView.tag]floatValue];
    if (webViewHeight == 0) {
        
        CGRect frame = aWebView.frame;
        frame.size.height = 1;
        aWebView.frame = frame;
        CGSize fittingSize = [aWebView sizeThatFits:CGSizeZero];
        frame.size = fittingSize;
        aWebView.frame = frame;
        
        [contentHeights replaceObjectAtIndex:aWebView.tag withObject:[NSNumber numberWithFloat:fittingSize.height + 20]];
        
        if (selectedIndex != -1) {
            [tblCircular reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:selectedIndex]] withRowAnimation:UITableViewRowAnimationNone];
        }
    }
}

-(void)expandCollapseSection:(UITapGestureRecognizer *)gesture
{
    NSInteger Index = gesture.view.tag;
    if(selectedIndex == Index) {
        selectedIndex = -1;
    }
    else {
        selectedIndex = Index;
    }
    
    [tblCircular reloadData];
    
    [self goToNextViewController:Index];
    
    if(selectedIndex != -1){
        [tblCircular scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selectedIndex] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

-(void)goToNextViewController:(NSInteger)idx
{
    if([((Circular *)arrCircularList[idx]).CircularDescription isEqualToString:@""]) {
        
        ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        AnnouncementPDFViewController *apvc = [storyBoard instantiateViewControllerWithIdentifier:@"AnnouncementPDFViewController"];
        apvc.strFileName = ((Circular *)arrCircularList[idx]).CircularPDF;
        apvc.title = self.title;
        apvc.transition = animation;
        [self.navigationController pushViewController:apvc animated:YES];
        return;
    }
}

-(IBAction)btnDownload:(UIButton *)sender
{
    ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    AnnouncementPDFViewController *apvc = [storyBoard instantiateViewControllerWithIdentifier:@"AnnouncementPDFViewController"];
    apvc.strFileName = ((Circular *)arrCircularList[sender.tag]).CircularPDF;
    apvc.title = self.title;
    apvc.transition = animation;
    [self.navigationController pushViewController:apvc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

