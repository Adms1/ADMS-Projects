//
//  ActivityLoggingVC.swift
//  Skool360Admin
//
//  Created by ADMS on 05/02/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON
import SwiftCharts

class ActivityLoggingVC: CustomViewController {
    
    @IBOutlet var btnBackChart:UIButton!
    
    var chart: Chart?
    var groupsData = [(title: String, [(min: Int, max: Int)])]()
    
    var dicMonthCounts:NSMutableDictionary? = [:]
    var dicDateCounts:NSMutableDictionary! = [:]
    
    var MaxValue:Int = 0
    var strType:String?
    
    override func viewDidLoad() {
        self.chart?.clearView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.getMonthlyCount()
    }
    
    // MARK: Api Calling
    
    func getMonthlyCount()
    {
        MaxValue = 0
        dicMonthCounts = [:]
        zoomFactor = DeviceType.isIphone5 ? 1 : 0
        btnBackChart.isHidden = true
        
        Functions.callApi(api: API.getMonthlyCountApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayCount = json!["FinalArray"].array
                
                self.displayData([json!["TotalStudentCount"].stringValue, json!["ActiveStudentCount"].stringValue, json!["TotalTeacherCount"].stringValue, json!["ActiveTeacherCount"].stringValue, json!["TotalAdminCount"].stringValue, json!["ActiveadminCount"].stringValue])
                
                for value in arrayCount! {
                    if(self.dicMonthCounts![value["Month"].stringValue] != nil) {
                        
                        let strValue:String = self.dicMonthCounts![value["Month"].stringValue] as! String
                        self.dicMonthCounts?.setValue("\(strValue)-\(value["Count"].stringValue)", forKey: value["Month"].stringValue)
                    }
                    else {
                        self.dicMonthCounts?.setValue(value["Count"].stringValue, forKey: value["Month"].stringValue)
                    }
                }
                
                print(self.dicMonthCounts!)
                
                //-----------
                
                self.findMaxValue(arrayCount!, "Count")
                
                //------
                
                var arrStuValues:[Int] = []
                var arrTecValues:[Int] = []
                var arrAdminValues:[Int] = []
                
                let arrMonths = self.dicMonthCounts!.sortedDictionary(self.dicMonthCounts!).0
                
                for month in arrMonths {
                    
                    let arrValue = (self.dicMonthCounts![month] as! String).components(separatedBy: "-")
                    arrStuValues.append(Int(arrValue[0])!)
                    arrTecValues.append(Int(arrValue[1])!)
                    arrAdminValues.append(Int(arrValue[2])!)
                }
                
                let chart = self.barsChart(arrStuValues, arrTecValues, arrAdminValues, DateFormatter().shortMonthSymbols, "Months")
                self.view.addSubview(chart.view)
                self.chart = chart
            }
        }
    }
    
    func getDateCounts(_ strMonth:Int, _ type:String)
    {
        MaxValue = 0
        dicDateCounts = [:]
        btnBackChart.isHidden = false
        
        Functions.callApi(api: API.getDateCountPerMonthApi, params: ["Month" : "\(strMonth)"]) { (json,error) in
            
            if(json != nil){
                
                let arrayCount = json!["FinalArray"].array
                
                for value in arrayCount! {
                    
                    if(value["\(type)Count"].stringValue != "0") {
                        self.dicDateCounts?.setValue(value["\(type)Count"].stringValue, forKey: value["Date"].stringValue.getDate())
                    }
                }
                
                let arrDates = self.dicDateCounts?.sortedDictionary(self.dicDateCounts!).0
                
                var arrDayCount:[Int] = []
                var arrTemp:[Int] = []
                
                for date in arrDates! {
                    arrDayCount.append(Int(self.dicDateCounts![date] as! String)!)
                    arrTemp.append(0)
                }
                
                self.findMaxValue(arrayCount!, "\(type)Count")
                
                zoomFactor = arrTemp.count > 25 ? 3 : arrTemp.count > 15 ? 2 : arrTemp.count > 10 ? 1 : 0
                self.chart?.clearView()
                let chart = self.barsChart(type == "Student" ? arrDayCount : arrTemp, type == "Teacher" ? arrDayCount : arrTemp, type == "Admin" ? arrDayCount : arrTemp, arrDates!, "Days")
                self.view.addSubview(chart.view)
                self.chart = chart
            }
        }
    }
    
    func findMaxValue(_ array:[JSON], _ key:String)
    {
        self.MaxValue = array.map { $0 }.map{ $0.dictionaryValue[key]!}.max()!.intValue
        
        if(self.MaxValue > 50)
        {
            while(self.MaxValue % 50 != 0){
                self.MaxValue += 1
            }
        }
        else
        {
            if(self.MaxValue > 10)
            {
                while(self.MaxValue % 10 != 0){
                    self.MaxValue += 1
                }
            }
        }
        print(self.MaxValue)
    }
    
    func displayData(_ arrayData:[String])
    {
        let arrColor = [GetColor.blue,GetColor.green,GetColor.orange,GetColor.green,GetColor.yellow,GetColor.green]
        
        var i = 0
        for lbl in (self.view.subviews.flatMap{ $0 as? UILabel}) {
            if(i < arrayData.count){
                lbl.text = lbl.text!.components(separatedBy: " : ").first! + " : " + arrayData[i]
                
                let attributedString = NSMutableAttributedString(
                    string: lbl.text!,
                    attributes: [:])
                
                let strSub:String = (lbl.text?.components(separatedBy: " : ").last)!
                
                attributedString.addAttribute(
                    NSAttributedStringKey.foregroundColor,
                    value: arrColor[i],
                    range: (lbl.text! as NSString).range(of: strSub))
                
                attributedString.addAttribute(
                    NSAttributedStringKey.font,
                    value: FontHelper.bold(size: DeviceType.isIpad ? 16 :DeviceType.isIphone5 ? 11 : 13),
                    range: (lbl.text! as NSString).range(of: strSub))
                
                lbl.attributedText = attributedString
                
                i += 1
            }
        }
    }
    
    fileprivate func barsChart(_ arrStudent:[Int], _ arrTeacher:[Int], _ arrAdmin:[Int], _ arrLable:[String], _ strXTitle:String) -> Chart {
        
        let labelSettings = ChartLabelSettings(font: ExamplesDefaults.labelFont)
        
        groupsData = []
        for (i,month) in arrLable.enumerated() {
            groupsData.append((month, [(0,arrStudent[i]),(0,arrTeacher[i]),(0,arrAdmin[i])]))
        }
        
        let groupColors = [GetColor.blue, GetColor.orange, GetColor.yellow]
        
        let groups: [ChartPointsBarGroup] = groupsData.enumerated().map {index, entry in
            let constant = ChartAxisValueDouble(index)
            let bars = entry.1.enumerated().map {index, tuple in
                ChartBarModel(constant: constant, axisValue1: ChartAxisValueDouble(tuple.min), axisValue2: ChartAxisValueDouble(tuple.max), bgColor: groupColors[index])
            }
            return ChartPointsBarGroup(constant: constant, bars: bars)
        }
        
        let (axisValues1, axisValues2): ([ChartAxisValue], [ChartAxisValue]) = (
            stride(from: 0, through: self.MaxValue, by: self.MaxValue > 50 ?  50 : self.MaxValue < 10 ? self.MaxValue == 0 ? 1 : self.MaxValue : 10).map {ChartAxisValueDouble(Double($0), labelSettings: labelSettings)},
            [ChartAxisValueString(order: -1)] +
                groupsData.enumerated().map {index, tuple in ChartAxisValueString(tuple.0.components(separatedBy: "/").first![tuple.0.components(separatedBy: "/").first!.index(tuple.0.components(separatedBy: "/").first!.startIndex, offsetBy: 0)] == "0" ? String(tuple.0.components(separatedBy: "/").first!.dropFirst()) : tuple.0.components(separatedBy: "/").first!, order: index, labelSettings: labelSettings)} +
                [ChartAxisValueString(order: groupsData.count)]
        )
        let (xValues, yValues) = (axisValues2, axisValues1)
        
        let xModel = ChartAxisModel(axisValues: xValues, axisTitleLabel: ChartAxisLabel(text: strXTitle, settings: labelSettings))
        let yModel = ChartAxisModel(axisValues: yValues, axisTitleLabel: ChartAxisLabel(text: "Active Counts", settings: labelSettings.defaultVertical()))
        let frame = ExamplesDefaults.chartFrame(view.bounds)
        let chartFrame = chart?.frame ?? CGRect(x: frame.origin.x, y: self.view.subviews[0].frame.size.height + 60, width: frame.size.width, height: frame.size.height - (self.view.subviews[0].frame.size.height + 100))
        
        let chartSettings = ExamplesDefaults.chartSettingsWithPanZoom
        
        let coordsSpace = ChartCoordsSpaceLeftBottomSingleAxis(chartSettings: chartSettings, chartFrame: chartFrame, xModel: xModel, yModel: yModel)
        let (xAxisLayer, yAxisLayer, innerFrame) = (coordsSpace.xAxisLayer, coordsSpace.yAxisLayer, coordsSpace.chartInnerFrame)
        
        let barViewSettings = ChartBarViewSettings(animDuration: 0.5, selectionViewUpdater: ChartViewSelectorBrightness(selectedFactor: 0.5))
        
        let groupsLayer = ChartGroupedPlainBarsLayer(xAxis: xAxisLayer.axis, yAxis: yAxisLayer.axis, groups: groups, horizontal: false, barSpacing: 2, groupSpacing:5, settings: barViewSettings, tapHandler: { tappedGroupBar /*ChartTappedGroupBar*/ in
            
            if(self.strType == nil)
            {
                switch(tappedGroupBar.barIndex)
                {
                case 0:
                    self.strType = "Student"
                case 1:
                    self.strType = "Teacher"
                default:
                    self.strType = "Admin"
                }
                self.getDateCounts(tappedGroupBar.groupIndex + 1, self.strType!)
            }
            else
            {
                strDate = arrLable[tappedGroupBar.groupIndex]
                add(asChildViewController: self.usersPopupVC, self)
            }
        })
        
        let guidelinesSettings = ChartGuideLinesLayerSettings(linesColor: UIColor.black, linesWidth: ExamplesDefaults.guidelinesWidth)
        let guidelinesLayer = ChartGuideLinesLayer(xAxisLayer: xAxisLayer, yAxisLayer: yAxisLayer, axis: .y, settings: guidelinesSettings)
        
        return Chart(
            frame: chartFrame,
            innerFrame: innerFrame,
            settings: chartSettings,
            layers: [
                xAxisLayer,
                yAxisLayer,
                guidelinesLayer,
                groupsLayer
            ]
        )
    }
    
    private lazy var usersPopupVC: UsersPopupVC = {
        
        var viewController:UsersPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "UsersPopupVC") as! UsersPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    @IBAction func btnBackChartAction(_ sender:UIButton)
    {
        strType = nil
        self.chart?.clearView()
        self.getMonthlyCount()
    }
}
