//
//  QuickEmailVC.swift
//  Shilaj (Admin)
//
//  Created by ADMS on 21/02/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import CLTokenInputView
import AVFoundation
import Photos
import MessageUI

class QuickEmailVC: CustomViewController,UIActionSheetDelegate, MFMailComposeViewControllerDelegate {
    
    @IBOutlet var tokenInputView:SVContactBubbleView!
    @IBOutlet var tokenHeightConstraint: NSLayoutConstraint?
    
    var dropTableView: UITableView!
    var txtView:UITextView!
    
    var arrPersons:[String] = ["Apple","Blackberry","Android","Samsung","Lenovo","Xolo","Airtel","Vodafone","Sony","Iphone","Idea","Uninor","Jio"]
    var filterPersons:[String] = []
    var arrSelectedPersons:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dropTableView = addCustomTableView(self, tokenInputView, self.view)
        dropTableView.isHidden = true
        
        tokenInputView.dataSource = self
        tokenInputView.delegate = self
        
        addBorderWithRadius(tokenInputView, GetColor.blue, 3.0, 0.5)
        tokenInputView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        txtView = self.view.subviews[3].subviews[0] as! UITextView
        addBorderWithRadius(txtView.superview!, GetColor.blue, 3.0, 0.5)
        txtView.textColor = .black
        txtView.inputAccessoryView = addToolbar()
    }
    
    @IBAction func btnChoosePhoto(_ sender:UIButton)
    {
        let actionSheet = UIActionSheet(title: "Choose Photo Option", delegate: self, cancelButtonTitle: "Cancel", destructiveButtonTitle: nil, otherButtonTitles: "Photo Library", "Take Photo")
        actionSheet.show(in: self.view)
    }
    
    func actionSheet(_ actionSheet: UIActionSheet, clickedButtonAt buttonIndex: Int)
    {
        let imagePicker = UIImagePickerController()
        imagePicker.allowsEditing = true
        imagePicker.delegate = self
        
        switch (buttonIndex){
        case 1:
            imagePicker.sourceType = .savedPhotosAlbum
            
            if (PHPhotoLibrary.authorizationStatus() == PHAuthorizationStatus.authorized) {
                self.present(imagePicker, animated: true, completion: nil)
            }else{
                UIApplication.shared.openURL(URL(string: UIApplicationOpenSettingsURLString)!)
            }
            
        case 2:
            imagePicker.sourceType = .camera
            
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
                if granted {
                    self.present(imagePicker, animated: true, completion: nil)
                } else {
                    UIApplication.shared.openURL(URL(string: UIApplicationOpenSettingsURLString)!)
                }
            })
        default:
            break
        }
    }
    
    @IBAction func sendEmailButtonTapped(sender: AnyObject) {
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(arrSelectedPersons)
        mailComposerVC.setSubject((self.view.subviews[2] as! UITextField).text!)
        mailComposerVC.setMessageBody(txtView.text, isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
        sendMailErrorAlert.show()
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension QuickEmailVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info:[String : Any]) {
        
        let selectedImage:UIImage = info[UIImagePickerControllerEditedImage] as! UIImage
        
        self.dismiss(animated: true, completion: nil)
        
        let textAttachment = NSTextAttachment()
        textAttachment.image = selectedImage
        textAttachment.setImageHeight(height: 100)
        
        let worldImage = NSAttributedString(attachment: textAttachment)
        
        let mutableAttributedString:NSMutableAttributedString = NSMutableAttributedString.init(attributedString: txtView.attributedText)
        mutableAttributedString.append(worldImage)
        
        txtView.attributedText = mutableAttributedString
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: SVContactBubbleDataSource

extension QuickEmailVC: SVContactBubbleDataSource
{
    func insetsForContactBubbleView(_ contactBubbleView: SVContactBubbleView) -> UIEdgeInsets?
    {
        return UIEdgeInsetsMake(5, 5, 5, 5)
    }
    
    func placeholderTextForContactBubbleView(_ contactBubbleView: SVContactBubbleView) -> String?
    {
        if arrSelectedPersons.count > 0
        {
            return "Add More..."
        }
        else
        {
            return "Recepient"
        }
    }
    
    func numberOfContactBubbleForContactBubbleView(_ contactBubbleView: SVContactBubbleView) -> Int
    {
        return arrSelectedPersons.count
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, viewForContactBubbleAtIndex index: Int) -> UIView?
    {
        let person = arrSelectedPersons[index]
        let contactBubble = SVContactBubble.contactBubbleView(person, image: nil)
        contactBubble?.layoutIfNeeded()
        return contactBubble
    }
}

//MARK: SVContactBubbleDelegate

extension QuickEmailVC: SVContactBubbleDelegate
{
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, didDeleteBubbleWithTitle title: String)
    {
        filterPersons = arrPersons.filter { $0.range(of: title, options: .caseInsensitive) != nil }
        
        if let found = filterPersons.first
        {
            arrSelectedPersons.remove(at: arrSelectedPersons.index(of: found)!)
            contactBubbleView.reloadData()
            dropTableView.reloadData()
        }
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, didChangeText text: String)
    {
        if text == "" {
            filterPersons = arrPersons
        }
        else {
            filterPersons = arrPersons.filter { $0.range(of: text, options: .caseInsensitive) != nil }
        }
        dropTableView.isHidden = false
        dropTableView.reloadData()
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, contentSizeChanged size: CGSize)
    {
        self.tokenHeightConstraint?.constant = max(40,min(size.height, 150))
        self.view.layoutIfNeeded()
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, didFinishBubbleWithText text: String)
    {
        dropTableView.isHidden = true
        self.view.endEditing(true)
    }
}

extension QuickEmailVC:UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.becomeFirstResponder()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.dismissPicker()
        return true
    }
}

extension QuickEmailVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view Data Source & Delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterPersons.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = self.dropTableView.dequeueReusableCell(withIdentifier: "Cell")
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
            cell?.selectionStyle = .none
        }
        
        let contact = filterPersons[indexPath.row]
        let isarrSelectedPersons = arrSelectedPersons.contains(contact)
        
        cell?.accessoryType = isarrSelectedPersons ? .checkmark : .none
        cell?.textLabel?.text = filterPersons[indexPath.row]
        cell?.textLabel?.font = FontHelper.regular(size: DeviceType.isIpad ? 15 :12)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let person = filterPersons[indexPath.row]
        
        if arrSelectedPersons.contains(person) {
            
            if let idx = arrSelectedPersons.index(of: person) {
                arrSelectedPersons.remove(at: idx)
            }
        }else{
            arrSelectedPersons.append(person)
        }
        
        self.tokenInputView.textfield.text = nil
        self.tokenInputView.placeholderLabel.text = self.tokenInputView.dataSource.placeholderTextForContactBubbleView(self.tokenInputView)
        filterPersons = arrPersons
        self.tokenInputView.reloadData()
        tableView.reloadData()
    }
}

