//
//  CircularVC.swift
//  Skool360Admin
//
//  Created by ADMS on 18/12/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class AnnouncementVC2: CustomViewController {
    
    @IBOutlet var tblAnnouncement:UITableView!
    
    var arrCircularData = [CircularModel]()
    var strOrder:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblAnnouncement.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.initialize()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        self.addOrderDropDown()
        
        lastViewController = self.navigationController?.viewControllers.last
        self.initalization()
    }
    
    func initialize()
    {
        (self.view.subviews[1] as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        (self.view.subviews[1] as! UIButton).titleLabel?.font = FontType.regularFont
        (self.view.subviews[2] as! UITextField).text = nil
        (self.view.subviews[3] as! UITextView).text = "Description"
        (self.view.subviews[3] as! UITextView).textColor = UIColor.gray.withAlphaComponent(0.3)
        self.view.endEditing(true)
        
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 5){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == 50 || view.tag == 60){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
            }
        }
        self.callGetCircularDataApi()
    }
    
    func addOrderDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(4)?.frame)!)
        
        var arrOrder:[String] = []
        for i in 1...10{
            arrOrder.append("\(i)")
        }
        
        dropDown.placeholder = Constants.dropDownPlaceholder
        dropDown.options = arrOrder
        dropDown.tableHeight = 5 * 35
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strOrder = option
        }
        
        for _ in (self.view.subviews.flatMap{$0 as? UIDropDown}) {
            return
        }
        self.view.addSubview(dropDown)
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 6 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = view.subviews[tag] as! LTHRadioButton
        radioButton.select(animated: true)
        strStatus = tag == 5 ? "1" : "0"
    }
    
    @IBAction func btnSaveAction(_ sender:UIButton)
    {
        let strTxtDes:String = (self.view.subviews[3] as! UITextView).textColor! == UIColor.black ? ((self.view.subviews[3] as! UITextView).text)! : ""
        let requestValues = RequestData.init(txtSub: ((self.view.subviews[2] as! UITextField).text)!, txtDes: strTxtDes, txtOrd: strOrder)
        
        if(ValidationFunctions.requestValidation(requestData: requestValues))
        {
            self.callCircularApi(requestValues)
        }
    }
    
    func callGetCircularDataApi()
    {
        self.arrCircularData = []
        
        Functions.callApi(api: API.getAnnouncementDataApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (index,value) in arrData!.enumerated() {
                    
                    self.arrCircularData.append(CircularModel(Index: "\(index+1)", Cir_Date: value["Cir_Date"].stringValue, Cir_Subject: value["Cir_Subject"].stringValue, Cir_Description: value["Cir_Description"].stringValue, Cir_Order: value["Cir_Order"].stringValue, Cir_Status: value["Cir_Status"].stringValue))
                }
            }else{
                Functions.showAlert(false, Message.noRecordFound)
            }
            self.tblAnnouncement.reloadData()
        }
    }
    
    func callCircularApi(_ requestData:RequestData)
    {
        let params = ["Dt" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "Subject" : requestData.txtSubject!,
                      "Description" : requestData.txtDescription!,
                      "order" : strOrder,
                      "Status" : strStatus,
                      "Pk_CircularID" : "0"
        ]
        
        print(params)
        
        Functions.callApi(api: API.insertAnnouncementApi, params: params) { (json,error) in
            
            if(json != nil){
                
                self.initialize()
                //Functions.showAlert(true, Message.msgSentSuccess)
            }else{
                Functions.showAlert(false, Message.somethingWrong)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AnnouncementVC2:UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.becomeFirstResponder()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        self.view.endEditing(true)
        return true
    }
}

extension AnnouncementVC2:UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        if(textView.text == "Description"){
            textView.text = nil
            textView.textColor = .black
        }
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(text == "\n") {
            if(textView.text.count == 0){
                textView.text = "Description"
                textView.textColor = UIColor.gray.withAlphaComponent(0.3)
            }
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text.count == 0){
            textView.text = "Description"
            textView.textColor = UIColor.gray.withAlphaComponent(0.3)
        }
    }
}

extension AnnouncementVC2:UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:CircularCell = tableView.dequeueReusableCell(withIdentifier: "CircularHeaderCell") as! CircularCell
        for view in headerView.contentView.subviews[0].subviews.filter({($0.isKind(of: UILabel.classForCoder()))}) {
            let lbl:UILabel = view as! UILabel
            lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 15 : DeviceType.isIphone5 ? 10 : 12)
        }
        return arrCircularData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrCircularData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrCircularData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:CircularCell = tableView.dequeueReusableCell(withIdentifier: "CircularCell", for: indexPath) as! CircularCell
        cell.displayCircularData(arrCircularData[indexPath.row])
        return cell
    }
}
