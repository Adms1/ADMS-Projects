//
//  ClassTeacherVC.swift
//  Skool360Admin
//
//  Created by ADMS on 23/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

//func sort(a: [ClassTeacherModal], basedOn b: [String]) -> [ClassTeacherModal] {
//    return a.sorted { x, y in
//        (b.index(of: x.Grade) as! Int) < (b.index(of: y.Grade) as! Int)
//    }
//}

class ClassTeacherVC: CustomViewController {
    
    @IBOutlet var collectionSection:UICollectionView!
    @IBOutlet var tblClassTeacher:UITableView!
    @IBOutlet var collectionHeight:NSLayoutConstraint!
    
    var arrTeacherDetails = [ClassTeacherModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,selector: #selector(ClassTeacherVC.getSectionReloadData),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.callGetTeachersApi(completion: { (success) in
                    self.callGetClassTeacherDetailsApi()
                    self.addDropDown()
                })
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    func callGetTeachersApi(completion:@escaping (Bool) -> Void)
    {
        dicTeachers = [:]
        
        Functions.callApi(api: API.getTeachersApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayTeachers = json!["FinalArray"].array
                
                for value in arrayTeachers! {
                    self.dicTeachers.setValue(value["Pk_EmployeeID"].stringValue, forKey: value["Teacher"].stringValue)
                }
                self.arrTeachers = self.dicTeachers.sortedDictionary(self.dicTeachers).0
                completion(true)
            }
        }
    }
    
    func callGetClassTeacherDetailsApi()
    {
        self.arrTeacherDetails = []
        
        Functions.callApi(api: API.getClassTeacherDetailApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for value in arrData! {
                    self.arrTeacherDetails.append(ClassTeacherModal(Name: value["Name"].stringValue, Grade: value["Standard"].stringValue.components(separatedBy: " - ").first!, Section: value["Standard"].stringValue.components(separatedBy: " - ").last!))
                }
                //                print(sort(a: self.arrTeacherDetails, basedOn: self.arrStandards))
                self.arrTeacherDetails = self.arrTeacherDetails.sorted { (self.arrStandards.index(of: $0.Grade) as! Int) < (self.arrStandards.index(of: $1.Grade) as! Int) }
                //self.arrTeacherDetails = self.arrTeacherDetails.sorted{(self.arrSections.index(of: $0.Section) as! Int) < (self.arrSections.index(of: $1.Section) as! Int)}
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetClassTeacherDetailsApi()
                })
            }
            self.tblClassTeacher.reloadData()
        }
    }
    
    func callInsertClassTeachersApi()
    {
        let params = ["StandardID" : self.strStdID!,
                      "ClassId" : self.strClassID!,
                      "Pk_EmployeID" : self.strEmpID!]
        
        print(params)
        
        Functions.callApi(api: API.insertClassTeachersApi, params: params) { (json,error) in
            
            if(json != nil){
                
                //let value = json!["FinalArray"].array?.first
                
                //let classTeacherModal:ClassTeacherModal = ClassTeacherModal.init(index:"\(self.arrTeacherDetails.count+1)", name: value!["Name"].stringValue, grade: value!["Standard"].stringValue.components(separatedBy: "-").first!, section: value!["Standard"].stringValue.components(separatedBy: "-").last!)
                
                //self.arrTeacherDetails.append(classTeacherModal)
                //self.tblClassTeacher.reloadData()
                Functions.showAlert(false, Message.recordInsert)
                self.callGetClassTeacherDetailsApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertClassTeachersApi()
                })
            }
        }
    }
    
    @objc func getSectionReloadData()
    {
        strClassID = nil
        let dict:NSMutableDictionary = self.dicStdSections[strStd] as! NSMutableDictionary
        arrSections = dict.sortedDictionary(dict).0
        let height:CGFloat = CGFloat((arrSections.count/3) + (arrSections.count%3 != 0 ? 1 : 0)) * 30
        collectionHeight.constant = height
        self.collectionSection.reloadData()
    }
    
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addStandardDropDown(view)
                    self.getSectionReloadData()
                    
                default:
                    self.addTeacherDropDown()
                }
                i += 1
            }
        }
    }
    
    func addTeacherDropDown()
    {
        self.strEmpID = dicTeachers.value(forKey: self.arrTeachers[0]) as! String
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(2)!.frame)
        dropDown.options = self.arrTeachers
        dropDown.tableHeight = self.arrTeachers.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrTeachers .count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = self.arrTeachers[0]
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strEmpID = self.dicTeachers.value(forKey: option) as! String
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnInsertData(_ sender:UIButton)
    {
        if strClassID == nil {
            Functions.showAlert(false, Message.noSectionSelect)
            return
        }
        self.callInsertClassTeachersApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ClassTeacherVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/2, height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrSections.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:SectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "SectionCell", for: indexPath) as! SectionCell
        
        cell.lblSection.text = arrSections[indexPath.row]
        cell.checkBox.setOn(false, animated: false)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell:SectionCell = collectionView.cellForItem(at: indexPath) as! SectionCell
        for cells in collectionView.visibleCells as! [SectionCell] {
            if(cells != cell){
                cells.checkBox.setOn(false, animated: true)
            }else{
                cell.checkBox.setOn(true, animated: true)
            }
        }
        strClassID = (self.dicStdSections[strStd] as! NSMutableDictionary)[arrSections[indexPath.row]] as? String
    }
}

extension ClassTeacherVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:ClassTeacherCell = tableView.dequeueReusableCell(withIdentifier: "ClassTeacherHeaderCell") as! ClassTeacherCell
        
        return arrTeacherDetails.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrTeacherDetails.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTeacherDetails.count > 0 ? arrTeacherDetails.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:ClassTeacherCell = tableView.dequeueReusableCell(withIdentifier: "ClassTeacherCell", for: indexPath) as! ClassTeacherCell
        
        cell.displayData(arrTeacherDetails[indexPath.row], indexPath.row+1)
        return cell
    }
}
