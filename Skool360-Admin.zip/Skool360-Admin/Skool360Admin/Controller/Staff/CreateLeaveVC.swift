//
//  CreateLeaveVC.swift
//  Bhadaj (Teacher)
//
//  Created by ADMS on 30/08/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class CreateLeaveVC: CustomViewController {
    
    @IBOutlet var btnSend:UIButton!
    @IBOutlet var btnStartDate:UIButton!
    @IBOutlet var btnEndDate:UIButton!
    @IBOutlet var txtReason:UITextView!
    @IBOutlet var tblLeaveDetails:UITableView!
    
    var dicHeadData:[String:String] = [:]
    var arrHeadNames:[String] = []
    var arrLeaveDetails = [LeaveModel]()
    
    var leaveDays:Double = 0
    var strHeadID:String!
    var selectedLeaveModel:LeaveModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblLeaveDetails.tableFooterView = UIView()
        
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
        
        self.callGetHeadApi()
        self.callGetLeaveDetailsApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension CreateLeaveVC
{
    func callGetHeadApi()
    {
        arrHeadNames = []
        dicHeadData = [:]
        
        Functions.callApi(api: API.getHeadApi, params: [:]) { (json,error) in
            if(json != nil){
                
                let arrHeads = json!["FinalArray"].array
                
                for values in arrHeads! {
                    self.dicHeadData[values["EmployeeName"].stringValue] = values["EmployeeID"].stringValue
                    self.arrHeadNames.append(values["EmployeeName"].stringValue)
                }
                self.addDropDown()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetHeadApi()
                })
            }
        }
    }
    
    func callGetLeaveDetailsApi()
    {
        arrLeaveDetails = []
        
        let params = ["StaffID":adminID!]
        
        Functions.callApi(api: API.getStaffLeaveRequestApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrLDetails = json!["FinalArray"].array
                
                for values in arrLDetails! {
                    let leaveLDModel:LeaveModel = LeaveModel.init(leaveId: values["LeaveID"].stringValue, createDate: values["CreateDate"].stringValue, leaveStartDate: values["LeaveStartDate"].stringValue, leaveEndDate: values["LeaveEndDate"].stringValue, leaveDays: values["LeaveDays"].stringValue, status: values["Status"].stringValue, arDate: "\(values["ARStartDate"].stringValue) - \(values["AREndDate"].stringValue)", arDays: values["ARDays"].stringValue, arBy: values["ARBy"].stringValue, cl: values["CL"].stringValue, pl: values["PL"].stringValue, reason: values["Reason"].stringValue, headName: values["HeadName"].stringValue)
                    self.arrLeaveDetails.append(leaveLDModel)
                }
                self.tblLeaveDetails.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetLeaveDetailsApi()
                })
            }
        }
    }
    
    func callDeleteLeaveDetailsApi(_ index:NSInteger)
    {
        let params = ["LeaveID":arrLeaveDetails[index].LeaveID!]
        
        Functions.callApi(api: API.deleteStaffLeaveApi, params: params) { (json,error) in
            if(json != nil){
                Functions.showAlert(true, Message.leaveDeleteSuccess)
                self.arrLeaveDetails.remove(at: index)
                self.tblLeaveDetails.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteLeaveDetailsApi(index)
                })
            }
        }
    }
    
    func callSendLeaveRequestApi()
    {
        let params = ["LeaveID" : selectedLeaveModel != nil ? selectedLeaveModel.LeaveID! : "0",
                      "FromDate" : btnStartDate.title(for: .normal)!,
                      "ToDate" : btnEndDate.title(for: .normal)!,
                      "StaffID" : adminID!,
                      "HeadID" : strHeadID!,
                      "LeaveDays" : "\(leaveDays)",
            "Reason" : txtReason.text!]
        
        Functions.callApi(api: API.insertStaffLeaveRequestApi, params: params) { (json,error) in
            if(json != nil){
                Functions.showAlert(true, (json!["FinalArray"].array?.first!["Message"].stringValue)!)
                self.selectedLeaveModel = nil
                self.callGetLeaveDetailsApi()
                self.resetData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSendLeaveRequestApi()
                })
            }
        }
    }
}

extension CreateLeaveVC
{
    // MARK: - Add DropDown
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.placeholder = "-Please Select-"
                dropDown.tableHeight = CGFloat(5 * 35)
                dropDown.tag = i * 10
                
                switch(i)
                {
                case 1:
                    var array:[Double] = []
                    for i in 0..<30 {
                        array.append(Double(Double(i)+0.5))
                        array.append(Double(i+1))
                    }
                    dropDown.options = array.map{String($0)}
                    if(selectedLeaveModel != nil){
                        dropDown.title.text = selectedLeaveModel.LeaveDays
                        dropDown.selectedIndex = array.index(of: Double(selectedLeaveModel.LeaveDays)!)
                        leaveDays = Double(selectedLeaveModel.LeaveDays)!
                    }
                case 2:
                    dropDown.options = arrHeadNames
                    dropDown.tableHeight = arrHeadNames.count < 5 ? CGFloat(arrHeadNames.count * 35) : CGFloat(5 * 35)
                    if(selectedLeaveModel != nil){
                        dropDown.title.text = selectedLeaveModel.HeadName!
                        dropDown.selectedIndex = arrHeadNames.index(of: selectedLeaveModel.HeadName!)
                        strHeadID = self.dicHeadData[dropDown.title.text!]
                    }
                default:
                    break
                }
                
                dropDown.didSelect { (option, index) in
                    dropDown.hideTable()
                    if(dropDown.tag == 10){
                        self.leaveDays = Double(option)!
                        self.btnEndDate.setTitle(Calendar.current.date(byAdding: .day, value: Int(round(Double(option)!))-1, to: (self.btnStartDate.title(for: .normal)?.toDate(dateFormat: "dd/MM/yyyy"))!)?.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                    }else{
                        self.strHeadID = self.dicHeadData[option]
                    }
                }
                self.view.addSubview(dropDown)
                i += 1
            }
        }
    }
    
    @IBAction func btnSendAction(_ sender:UIButton)
    {
        guard leaveDays != 0 else {
            Functions.showAlert(false, Message.leaveDaysError)
            return
        }
        
        guard strHeadID != nil else {
            Functions.showAlert(false, Message.headNameError)
            return
        }
        
        guard txtReason.text.count != 0 else {
            Functions.showAlert(false, Message.reasonError)
            return
        }
        self.callSendLeaveRequestApi()
    }
    
    func resetData()
    {
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                if(selectedLeaveModel != nil) {
                    (view as! UIButton).setTitle(view.tag == 100 ? selectedLeaveModel.LeaveStartDate! : selectedLeaveModel.LeaveEndDate!, for: .normal)
                }else {
                    (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                }
            }
        }
        if(selectedLeaveModel != nil){
            txtReason.text = selectedLeaveModel.Reason
        }else {
            txtReason.text = nil
        }
        btnSend.setTitle(selectedLeaveModel != nil ? "UPDATE" : "SEND", for: .normal)
        
        for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            view.removeFromSuperview()
        }
        self.addDropDown()
    }
}

extension CreateLeaveVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:LeaveCell = tableView.dequeueReusableCell(withIdentifier: "LeaveHeaderCell") as! LeaveCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0, 0)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        headerView.btnExpand.transform = .identity
        if section == selectedIndex {
            UIView.animate(withDuration: 0.5, animations: {
                headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
            })
        };
        headerView.displayLeaveHeaderDetails(arrLeaveDetails[section])
        return arrLeaveDetails.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return arrLeaveDetails.count > 0 ? (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50)) : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrLeaveDetails.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblLeaveDetails.rowHeight == 0 ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:LeaveCell = tableView.dequeueReusableCell(withIdentifier: arrLeaveDetails[indexPath.section].Status.capitalized == "Pending" ? "LeavePCell" : "LeaveARCell", for: indexPath) as! LeaveCell
        
        if(arrLeaveDetails[indexPath.section].Status.capitalized == "Pending") {
            cell.btnEdit.tag = indexPath.section
            cell.btnDelete.tag = indexPath.section
            
            cell.editDeleteBlock = { sender in
                if(sender == cell.btnDelete) {
                    Functions.showCustomAlert("Delete", Message.deleteLeave) { (_) in
                        self.callDeleteLeaveDetailsApi(sender.tag)
                    }
                }else{
                    self.selectedLeaveModel = self.arrLeaveDetails[indexPath.section]
                    self.resetData()
                }
            }
        }
        cell.displayLeaveDetails(arrLeaveDetails[indexPath.section])
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblLeaveDetails.reloadSections(IndexSet(integersIn: 0...arrLeaveDetails.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblLeaveDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}

extension CreateLeaveVC:UITextViewDelegate
{
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
}

extension CreateLeaveVC
{
    override func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        btnEndDate.setTitle(Calendar.current.date(byAdding: .day, value: Int(round(Double(leaveDays)))-1, to: date)?.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}
