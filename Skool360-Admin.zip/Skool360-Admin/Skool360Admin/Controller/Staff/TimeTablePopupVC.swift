//
//  TimeTablePopupVC.swift
//  Shilaj (Teacher)
//
//  Created by ADMS on 06/11/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UIDropDown

protocol TimeTablePopupVCDelagate {
    func callTimeTableApi()
}

var strLectureName:String = ""
var strDayName:String = ""
var strTeacher:String = ""
var strSubject:String = ""
var strTimeTableID:String = ""
var strSelectedClassID:String = ""
var strSelectedTermID:String = ""

class TimeTablePopupVC: CustomViewController {
    
    @IBOutlet var btnAddUpdate:UIButton!
    @IBOutlet var lblTitle:UILabel!
    var delegate:TimeTablePopupVCDelagate?
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.btnAddUpdate.setTitle(strTimeTableID == "0" ? ButtonType.add.rawValue : ButtonType.update.rawValue, for: .normal)
        self.callGetSubjectsApi {
            if(strTeacher != "" && strSubject != "") {
                self.lblTitle.text = "Update Lecture Details"
                self.callGetTeachersApi(completion: {
                    self.addDropDown()
                })
            }else{
                self.strEmpID = ""
                self.lblTitle.text = "Add Lecture Details"
                self.addDropDown()
            }
        }
    }
    
    // MARK: - API Calling
    
    func callGetSubjectsApi(completion:@escaping () -> ())
    {
        dicSubjects = [:]
        
        Functions.callApi(api: API.getSubjectApi, params: [:]) { (json, error) in
            
            if(json != nil){
                
                let arrSubjects = json!["FinalArray"].array
                
                for values in arrSubjects! {
                    self.dicSubjects.setValue(values["Pk_SubjectID"].stringValue, forKey: values["Subject"].stringValue)
                }
                self.arrSubjects = self.dicSubjects.sortedDictionary(self.dicSubjects).0
                self.strSubID = strSubject == "" ? "" : self.dicSubjects.value(forKey: strSubject) as! String
                
                completion()
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetSubjectsApi {}
                })
            }
        }
    }
    
    func callGetTeachersApi(completion:@escaping () -> ())
    {
        dicTeachers = [:]
        arrTeachers = []
        
        let params = ["TermID" : strSelectedTermID,
                      "SubjectID" : self.strSubID!]
        
        Functions.callApi(api: API.getTeacherBySubjectApi, params: params) { (json, error) in
            
            if(json != nil){
                
                let arrTeachers = json!["FinalArray"].array
                
                for values in arrTeachers! {
                    self.dicTeachers.setValue(values["EmployeeID"].stringValue, forKey: values["EmployeeName"].stringValue)
                }
                self.arrTeachers = self.dicTeachers.sortedDictionary(self.dicTeachers).0
                self.strEmpID = strTeacher == "" ? "" : self.dicTeachers.value(forKey: strTeacher) as! String
                
                completion()
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetTeachersApi {}
                })
            }else{
                completion()
            }
        }
    }
    
    // MARK: - Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews[0].subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    let lblDayName:UILabel = view as! UILabel
                    lblDayName.text = strDayName
                    
                case 2:
                    let lblLectureName:UILabel = view as! UILabel
                    lblLectureName.text = strLectureName
                    
                case 3:
                    self.addSubjectDropDown()
                    
                default:
                    break
                }
                i += 1
            }
        }
    }
    
    func addSubjectDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(3)?.frame)!)
        dropDown.placeholder = "-Select-"
        dropDown.tag = 30
        
        dropDown.options = arrSubjects
        dropDown.tableHeight = arrSubjects.count > 5 ? CGFloat(5 * 35) : CGFloat(arrSubjects.count * 35)
        
        if self.strSubID != "" {
            dropDown.title.text = self.dicSubjects.allKeys(for: self.strSubID).first as? String
            dropDown.selectedIndex = arrSubjects.index(of: dropDown.title.text!)
        }
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strSubID = self.dicSubjects[option] as! String
            strTeacher = ""
            self.strEmpID = ""
            self.callGetTeachersApi(completion: {
                self.addTeachersDropDown()
            })
        }
        
        if self.view.subviews[0].subviews[0].viewWithTag(30) != nil {
            self.view.subviews[0].subviews[0].viewWithTag(30)?.removeFromSuperview()
        }
        self.view.subviews[0].subviews[0].addSubview(dropDown)
        self.addTeachersDropDown()
    }
    
    func addTeachersDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(4)?.frame)!)
        dropDown.placeholder = "-Select-"
        dropDown.tag = 40
        
        dropDown.options = arrTeachers
        dropDown.tableHeight = arrTeachers.count > 5 ? CGFloat(5 * 35) : CGFloat(arrTeachers.count * 35)
        
        if self.strEmpID != "" {
            dropDown.title.text = self.dicTeachers.allKeys(for: self.strEmpID).first as? String
            dropDown.selectedIndex = arrTeachers.index(of: dropDown.title.text!)
        }
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strEmpID = self.dicTeachers[option] as! String
        }
        
        if self.view.subviews[0].subviews[0].viewWithTag(40) != nil {
            if let dropDown:UIDropDown = self.view.subviews[0].subviews[0].viewWithTag(40) as? UIDropDown {
                if(dropDown.table != nil){
                    dropDown.hideTable()
                }
                dropDown.removeFromSuperview()
            }
        }
        self.view.subviews[0].subviews[0].addSubview(dropDown)
    }
    
    // MARK: - Button Click Action
    
    @IBAction func btnAddUpdateLectureAction(_ sender:UIButton)
    {
        let params = ["StaffID" : self.strEmpID!,
                      "ClassID" : strSelectedClassID,
                      "SubjectID" : self.strSubID!,
                      "DayName" : strDayName,
                      "LectureName" : strLectureName,
                      "TimeTableID" : strTimeTableID,
                      "TermID" : strSelectedTermID]
        
        Functions.callApi(api: API.adminInsertTimetableApi, params: params) { (json, error) in
            Functions.showAlert(true, strTimeTableID == "" ? Message.recordInsert : Message.recordUpdate)
            self.delegate?.callTimeTableApi()
            self.btnClose()
        }
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

