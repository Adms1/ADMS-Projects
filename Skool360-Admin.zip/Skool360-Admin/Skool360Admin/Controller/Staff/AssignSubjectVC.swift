//
//  AssignSubjectVC.swift
//  Skool360Admin
//
//  Created by ADMS on 23/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class AssignSubjectVC: CustomViewController {
    
    @IBOutlet var tblAssignSubject:UITableView!
    @IBOutlet var btnAddUpdate:UIButton!
    
    var arrAssignSubjectData = [AssignSubjectModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.callGetTeachersApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (success) in
            self.callGetSubjectApi(completion: { (success) in
                self.callGetTeachersApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSubjectApi(completion:@escaping (Bool) -> Void)
    {
        dicSubjects = [:]
        
        Functions.callApi(api: API.getSubjectApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySubjects = json!["FinalArray"].array
                
                for value in arraySubjects! {
                    self.dicSubjects.setValue(value["Pk_SubjectID"].stringValue, forKey: value["Subject"].stringValue)
                }
                self.arrSubjects = self.dicSubjects.sortedDictionary(self.dicSubjects).0
                completion(true)
            }
        }
    }
    
    @objc func callGetTeachersApi()
    {
        dicTeachers = [:]
        
        Functions.callApi(api: API.getTeachersByTermIDApi, params: ["TermID" : strTermID]) { (json,error) in
            
            if(json != nil){
                
                let arrayTeachers = json!["FinalArray"].array
                
                for value in arrayTeachers! {
                    self.dicTeachers.setValue(value["EmployeeID"].stringValue, forKey: value["EmployeeName"].stringValue)
                }
                self.arrTeachers = self.dicTeachers.sortedDictionary(self.dicTeachers).0
                self.callGetAssignSubjectsDetailsApi()
            }
        }
    }
    
    @objc func callGetAssignSubjectsDetailsApi()
    {
        self.arrAssignSubjectData = []
        
        Functions.callApi(api: API.getSubjectAssginApi, params: ["Term" : strTermID]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (index,value) in arrData!.enumerated() {
                    self.arrAssignSubjectData.append(AssignSubjectModal(Index: "\(index+1)", TeacherName: value["TeacherName"].stringValue, Subject: value["Subject"].stringValue, Pk_AssignID: value["Pk_AssignID"].stringValue, Status: value["Status"].stringValue))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAssignSubjectsDetailsApi()
                })
            }
            
            for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                let dropDown:UIDropDown = view as! UIDropDown
                if(dropDown.table != nil){
                    dropDown.hideTable()
                }
                dropDown.removeFromSuperview()
            }
            
            self.addDropDown()
            self.tblAssignSubject.reloadData()
        }
    }
    
    func callInsertAssignSubjectApi(_ strAssignID:String)
    {
        let params = ["Term" : strTermID,
                      "SubjectID" : self.strSubID!,
                      "Pk_EmployeID" : self.strEmpID!,
                      "Status" : self.strStatus,
                      "Pk_AssignID" : strAssignID]
        
        print(params)
        
        Functions.callApi(api: API.insertAssignSubjectApi, params: params) { (json,error) in
            
            if(json != nil){
                //let value = json!["FinalArray"].array?.first
                
                //                let assignSubjectModal:AssignSubjectModal = AssignSubjectModal.init(index: "\(self.arrAssignSubjectData.count+1)", name: value!["TeacherName"].stringValue, subject: value!["Subject"].stringValue)
                //
                //                self.arrAssignSubjectData.append(assignSubjectModal)
                //                self.tblAssignSubject.reloadData()
                Functions.showAlert(true, Message.recordInsert)
                self.callGetAssignSubjectsDetailsApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertAssignSubjectApi(strAssignID)
                })
            }
        }
    }
    
    func callDeleteAssignSubjectsApi(_ strAssignID:String)
    {
        let params = ["Pk_AssignID" : strAssignID]
        
        print(params)
        
        Functions.callApi(api: API.deleteAssginSubjectApi, params: params) { (json,error) in
            
            if(json != nil){
                
                Functions.showAlert(false, Message.recordDelete)
                self.callGetAssignSubjectsDetailsApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteAssignSubjectsApi(strAssignID)
                })
            }
        }
    }
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addTeacherDropDown()
                    
                default:
                    self.addSubjectDropDown()
                }
                i += 1
            }
        }
    }
    
    func addTeacherDropDown()
    {
        self.strEmpID = dicTeachers.value(forKey: self.arrTeachers[0]) as! String
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(2)!.frame)
        dropDown.options = self.arrTeachers
        dropDown.tableHeight = self.arrTeachers.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrTeachers .count * 35)
        dropDown.selectedIndex = 0
        dropDown.tag = 200
        dropDown.title.text = self.arrTeachers[0]
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strEmpID = self.dicTeachers.value(forKey: option) as! String
        }
        self.view.addSubview(dropDown)
    }
    
    func addSubjectDropDown()
    {
        self.strSubID = dicSubjects.value(forKey: self.arrSubjects[0]) as! String
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(3)!.frame)
        dropDown.options = self.arrSubjects
        dropDown.tableHeight = self.arrSubjects.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrSubjects .count * 35)
        dropDown.selectedIndex = 0
        dropDown.tag = 300
        dropDown.title.text = self.arrSubjects[0]
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strSubID = self.dicSubjects.value(forKey: option) as! String
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnInsertData(_ sender:UIButton)
    {
        self.callInsertAssignSubjectApi("0")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AssignSubjectVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:AssignSubjectCell = tableView.dequeueReusableCell(withIdentifier: "AssignSubjectHeaderCell") as! AssignSubjectCell
        
        return arrAssignSubjectData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrAssignSubjectData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAssignSubjectData.count > 0 ? arrAssignSubjectData.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AssignSubjectCell = tableView.dequeueReusableCell(withIdentifier: "AssignSubjectCell", for: indexPath) as! AssignSubjectCell
        
        cell.displayData(arrAssignSubjectData[indexPath.row])
        let arrBtns = cell.contentView.subviews[0].subviews.filter{$0 is UIButton}
        arrBtns.forEach{$0.tag = indexPath.row}
        return cell
    }
    
    @IBAction func btnEditAction(_ sender:UIButton)
    {
        if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[1] == "true") {
            self.strEmpID = dicTeachers.value(forKey: self.arrAssignSubjectData[sender.tag].TeacherName) as! String
            btnAddUpdate.setTitle(ButtonType.update.rawValue, for: .normal)
            
            let assignSubjectModel:AssignSubjectModal = self.arrAssignSubjectData[sender.tag]
            
            // 1,2,3
            for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                let dropDown:UIDropDown = view as! UIDropDown
                
                var strValue:String!
                switch(dropDown.tag)
                {
                case 200:
                    strValue = assignSubjectModel.TeacherName
                    self.strEmpID = self.dicTeachers.value(forKey: strValue) as! String
                    dropDown.selectedIndex = arrTeachers.index(of: strValue)!
                case 300:
                    strValue = assignSubjectModel.Subject
                    self.strSubID = self.dicSubjects.value(forKey: strValue) as! String
                    dropDown.selectedIndex = self.arrSubjects.index(of: strValue)!
                default:
                    strValue = strTerm
                }
                dropDown.title.text = strValue
            }
        }else{
            Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "edit"))
        }
    }
    
    @IBAction func btnDeleteAction(_ sender:UIButton)
    {
        if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[2] == "true") {
            Functions.showCustomAlert("Delete", Message.deleteConfirmation) { (_) in
                self.callDeleteAssignSubjectsApi(self.arrAssignSubjectData[sender.tag].Pk_AssignID)
            }
        }else{
            Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "delete"))
        }
    }
}

