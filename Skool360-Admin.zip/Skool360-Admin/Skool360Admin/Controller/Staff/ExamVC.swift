//
//  ExamVC.swift
//  Skool360Admin
//
//  Created by ADMS on 24/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

class ExamVC: CustomViewController {
    
    @IBOutlet var tblExam:UITableView!
    
    var arrExamData = [ExamModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetExamApi()
    }
    
    func callGetExamApi()
    {
        let params = ["Stdt" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDt" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!]
        
        print(params)
        
        self.arrExamData = []
        
        Functions.callApi(api: API.getExamsApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (index,value) in arrData!.enumerated() {
                    self.arrExamData.append(ExamModal(Index: "\(index+1)", TestName: value["TestName"].stringValue, Grade: value["Grade"].stringValue, Subject: value["Subject"].stringValue, TestDate: value["TestDate"].stringValue))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetExamApi()
                })
            }
            self.tblExam.reloadData()
        }
    }
    
    @IBAction func btnFilterAction(_ sender:UIButton)
    {
        self.callGetExamApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ExamVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:ExamCell = tableView.dequeueReusableCell(withIdentifier: "ExamCell") as! ExamCell
        for view in headerView.contentView.subviews[0].subviews.filter({($0.isKind(of: UILabel.classForCoder()))}) {
            let lbl:UILabel = view as! UILabel
            lbl.font = FontType.mediumFont
        }
        return arrExamData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrExamData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrExamData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:ExamCell = tableView.dequeueReusableCell(withIdentifier: "ExamCell", for: indexPath) as! ExamCell
        
        for view in cell.contentView.subviews[0].subviews{
            if(view.isKind(of: UIImageView.classForCoder())) {
                let imgView:UIImageView = view as! UIImageView
                imgView.image = UIImage.init(named: "")
            }else{
                let lbl:UILabel = view as! UILabel
                lbl.textColor = .black
                lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
            }
        }
        cell.displayData(arrExamData[indexPath.row])
        return cell
    }
}
