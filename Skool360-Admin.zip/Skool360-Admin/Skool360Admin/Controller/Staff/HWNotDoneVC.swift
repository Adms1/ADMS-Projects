//
//  HWNotDoneVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 12/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class HWNotDoneVC: CustomViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
