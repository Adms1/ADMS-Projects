//
//  ViewLessonPlanVC.swift
//  Skool360Admin
//
//  Created by ADMS on 08/02/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class ViewLessonPlanVC: CustomViewController {
    
    @IBOutlet var tblViewLessonPlan:UITableView!
    
    var arrViewLessonPlanData = [ViewLessonPlanModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.callGetSubjectApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.addDropDown()
            self.callGetSubjectApi()
        }
    }
    
    // MARK: Api Calling
    
    @objc func callGetSubjectApi()
    {
        dicSubjects = [:]
        
        let params = ["TermId" : strTermID,
                      "StandardID" : strStdID!]
        
        Functions.callApi(api: API.getLessonPlanSubjectApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arraySubjects = json!["FinalArray"].array
                
                for value in arraySubjects! {
                    self.dicSubjects.setValue(value["SubjectID"].stringValue, forKey: value["Subject"].stringValue)
                }
                self.arrSubjects = self.dicSubjects.sortedDictionary(self.dicSubjects).0
                self.addSubjectDropDown()
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetSubjectApi()
                    })
                }else{
                    self.addSubjectDropDown()
                }
            }
        }
    }
    
    func callGetEmployeeApi()
    {
        dicTeachers = [:]
        
        let params = ["TermId" : strTermID,
                      "StandardID" : strStdID!,
                      "SubjectID" : strSubID!]
        
        print(params)
        
        Functions.callApi(api: API.getEmployeeBySubjectApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dicTeachers = json!["FinalArray"].array?.first
                
                let arrEmpIds = dicTeachers!["EmployeeId"].stringValue.components(separatedBy: ",")
                
                for (i,value) in dicTeachers!["Employee"].stringValue.components(separatedBy: ",").enumerated()
                {
                    self.dicTeachers.setValue(arrEmpIds[i], forKey: value)
                }
                self.arrTeachers = self.dicTeachers.sortedDictionary(self.dicTeachers).0
                self.addEmployeeDropDown()
                
            }else{
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetEmployeeApi()
                    })
                }else{
                    self.addEmployeeDropDown()
                }
            }
        }
    }
    
    func callGetLeesonPlanApi()
    {
        self.arrViewLessonPlanData = []
        selectedIndex = -1
        
        let params = ["TermId" : strTermID,
                      "StandardId" : strStdID!,
                      "SubjectId" : strSubID!,
                      "EmployeeId" : strEmpID!]
        
        print(params)
        
        Functions.callApi(api: API.getLessonPlanApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayData = json!["FinalArray"].array
                
                for (index,value) in (arrayData?.enumerated())! {
                    
                    self.arrViewLessonPlanData.append(ViewLessonPlanModel(Index: "\(index+1)", ID: value["ID"].stringValue, ChapterNo: value["ChapterNo"].stringValue, ChapterName: value["Chapter_Name"].stringValue.stringFromHTML(), Objective: value["Objective"].stringValue.stringFromHTML(), KeyPoint: value["Key_Point"].stringValue.stringFromHTML(), AssessmentQuestion: value["Assessment_Question"].stringValue.stringFromHTML()))
                }
            }
            self.tblViewLessonPlan.reloadData()
        }
    }
    
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addStandardDropDown(view)
                    
                case 3:
                    self.addSubjectDropDown()
                    
                default:
                    self.addEmployeeDropDown()
                }
                i += 1
            }
        }
    }
    
    func removeDropDown(_ tag:Int)
    {
        for dropDown in (self.view.subviews.flatMap{ $0 as? UIDropDown}) {
            if(dropDown.tag == tag){
                if(dropDown.table != nil){
                    dropDown.hideTable()
                }
                view.removeFromSuperview()
            }
        }
    }
    
    func addSubjectDropDown()
    {
        self.removeDropDown(3)
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(3)!.frame)
        dropDown.placeholder = Constants.dropDownPlaceholder
        
        if(dicSubjects.count > 0)
        {
            self.strSubID = dicSubjects.value(forKey: self.arrSubjects[0]) as! String
            dropDown.options = self.arrSubjects
            dropDown.tableHeight = self.arrSubjects.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrSubjects .count * 35)
            dropDown.selectedIndex = 0
            dropDown.title.text = self.arrSubjects[0]
            self.callGetEmployeeApi()
        }
        else
        {
            dropDown.options = []
            dropDown.tableHeight  = 0
        }
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strSubID = self.dicSubjects.value(forKey: option) as! String
            self.callGetEmployeeApi()
        }
        self.view.addSubview(dropDown)
    }
    
    func addEmployeeDropDown()
    {
        self.removeDropDown(4)
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(4)!.frame)
        dropDown.placeholder = Constants.dropDownPlaceholder
        
        if(dicTeachers.count > 0)
        {
            self.strEmpID = dicTeachers.value(forKey: self.arrTeachers[0]) as! String
            dropDown.options = self.arrTeachers
            dropDown.tableHeight = self.arrTeachers.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrTeachers .count * 35)
            dropDown.selectedIndex = 0
            dropDown.title.text = self.arrTeachers[0]
            self.callGetLeesonPlanApi()
        }
        else
        {
            dropDown.options = []
            dropDown.tableHeight  = 0
        }
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strEmpID = self.dicTeachers.value(forKey: option) as! String
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        if strSubID != nil {
            if(strEmpID != nil){
                self.callGetLeesonPlanApi()
            }
        }
    }
    
    @objc func btnWordClikedAction(_ sender:UIButton)
    {
        webUrl = "\(API.wordApi)\(sender.accessibilityValue!)"
        add(asChildViewController: self.viewMarksVC, self)
    }
    
    private lazy var viewMarksVC: ViewMarksPopupVC = {
        
        var viewController:ViewMarksPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "ViewMarksPopupVC") as! ViewMarksPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewLessonPlanVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:ViewLessonPlanCell = tableView.dequeueReusableCell(withIdentifier: "ViewLessonPlanHeaderCell") as! ViewLessonPlanCell
        
        headerView.headerHeight.constant = section == 0 ? 50 : 0
        headerView.lblView.superview?.addShadowWithRadius(2.0, 0, 0)
        
        if section == selectedIndex {
            headerView.lblView.textColor = GetColor.green
        }else{
            headerView.lblView.textColor = .red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblView.tag = section
        headerView.lblView.addGestureRecognizer(tapGesture)
        
        headerView.displayHeaderData(arrViewLessonPlanData[section])
        
        headerView.btnWord.addTarget(self, action: #selector(btnWordClikedAction(_:)), for: .touchUpInside)
        
        return arrViewLessonPlanData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrViewLessonPlanData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        tableView.estimatedSectionHeaderHeight = 110
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 100
        return indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:ViewLessonPlanCell = tableView.dequeueReusableCell(withIdentifier: "ViewLessonPlanCell", for: indexPath) as! ViewLessonPlanCell
        cell.displayData(arrViewLessonPlanData[indexPath.section])
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblViewLessonPlan.reloadData()
        self.tblViewLessonPlan.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .top, animated: true)
    }
}
