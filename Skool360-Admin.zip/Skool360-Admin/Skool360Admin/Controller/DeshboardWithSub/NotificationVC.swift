//
//  NotificationVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 15/11/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var arrNotificationData = [NotificationModel]()
class NotificationVC: CustomViewController {
    
    @IBOutlet var tblNotification:UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetNotificationsApi()
    }
    
    func callGetNotificationsApi()
    {
        arrNotificationData = []
        
        let params = ["StaffID" : adminID!]
        
        print(params)
        
        Functions.callApi(api: API.adminMessageApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for value in arrData! {
                    let notificationModel:NotificationModel = NotificationModel.init(nId: value["ID"].stringValue, name: value["Name"].stringValue, department: value["Department"].stringValue, uType: value["Type"].stringValue, nType: value["NotificationType"].stringValue, flag: value["Flag"].boolValue, date: value["Date"].stringValue, msg: value["Message"].stringValue, pkid: value["PKID"].stringValue)
                    
                    arrNotificationData.append(notificationModel)
                }
                self.tblNotification.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetNotificationsApi()
                })
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension NotificationVC
{
    func callBirthdayWishApi(_ idx:NSInteger)
    {
        let params = ["StaffID":adminID!,
                      "Type" : arrNotificationData[idx].UserType!,
                      "ReceiverID" : arrNotificationData[idx].ID!]
        
        Functions.callApi(api: API.birthdayWishApi, params: params) { (json,error) in
            
            if(json != nil){
                let birthdayModel = arrNotificationData[idx]
                birthdayModel.Flag = true
                arrNotificationData.remove(at: idx)
                arrNotificationData.insert(birthdayModel, at: idx)
                self.tblNotification.reloadData()
            }
        }
    }
}

extension NotificationVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrNotificationData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:NotificationCell = tableView.dequeueReusableCell(withIdentifier: "NotificationCell", for: indexPath) as! NotificationCell
        
        cell.displayData(arrNotificationData[indexPath.row])
        cell.sendNotification = { sender in }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch arrNotificationData[indexPath.row].NotificationType {
        case "BirthdayWish":
            guard !(arrNotificationData[indexPath.row].Flag) else {
                return
            }
            Functions.showCustomAlert("Birthday Wishes", "Would you like to send wishes?", isDone: { (_) in
                self.callBirthdayWishApi(indexPath.row)
            })
        default:
            isFromStudent = arrNotificationData[indexPath.row].NotificationType.caseInsensitiveCompare("StudentLeave") == .orderedSame
            notificationModel = arrNotificationData[indexPath.row]
            let vc = Constants.storyBoard.instantiateViewController(withIdentifier: arrNotificationData[indexPath.row].NotificationType == "Suggestion" ? "Give Suggestion" : "Leave Request")
            vc.view.tag = 1
            vc.title = arrNotificationData[indexPath.row].NotificationType == "Suggestion" ? "Suggestion" : "Leave Request"
            vc.accessibilityValue = self.title!
            self.navigationController?.pushPopTransition(vc,true)
        }
    }
}
