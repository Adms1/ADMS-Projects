
//
//  StudentVC.swift
//  Skool360Admin
//
//  Created by ADMS on 05/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON

var strTermID:String = "1"
var strTermDetail:String = "1"

class MainVC: CustomViewController {
    
    @IBOutlet var collectionView:UICollectionView!
    @IBOutlet var lblHeaderTitle:UILabel!
    @IBOutlet var profileView:UIView!
    @IBOutlet var presentView:UIView!
    @IBOutlet var accountView:UIView!
    @IBOutlet var smsView:UIView!
    
    @IBOutlet var viewHeight:NSLayoutConstraint!
    @IBOutlet var accountViewHeight:NSLayoutConstraint!
    var jsonValue:JSON!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self,selector: #selector(self.callApi),name: .callApi,object: nil)
        
        //        let imageData: Data? = UIImageJPEGRepresentation(#imageLiteral(resourceName: "person_placeholder"), 0.4)
        //        let imageStr = imageData?.base64EncodedString(options: .lineLength64Characters)
        //        print(imageStr!)
        
        self.displayDataInView()
    }
    
    func displayDataInView()
    {
        self.callGetTermApi(false) { (success) in
            self.addTermDropDown(self.accountView.viewWithTag(-2)!)
            self.callApi()
        }
        
        lblHeaderTitle.text = self.title?.uppercased()
        collectionView.superview?.addShadowWithRadius(3.0,15.0, 0)
        (profileView.subviews[0] as! UIImageView).getImagesfromLocal("Main", self.title!)
        
        var i = 10
        for view in accountView.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 1){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        addBorderWithRadius(profileView, GetColor.blue, profileView.frame.size.width/2, 3.0)
        
        accountViewHeight.constant = self.title == "Account" ? DeviceType.isIpad ? 240 : 210 : self.title == "Student" || self.title == "SMS" ? DeviceType.isIpad ? 165 : 135 : DeviceType.isIpad ? 130 : 100
        accountView.isHidden = self.title == "Account" ? false : true
        smsView.isHidden = self.title == "SMS" ? false : true
        
        if accountViewHeight.constant == (DeviceType.isIpad ? 130 : 100) {
            self.view.subviews[1].subviews[0].viewWithTag(10)?.isHidden = true
        }
        
        if self.title == "Transport" || self.title == "HR" || self.title == "Other" {
            presentView.isHidden = true
        }
        
        let collectionHeight:CGFloat = self.view.frame.size.height - 160
        let collectionMinHeight:CGFloat = collectionView.contentSize.height + accountViewHeight.constant + 20
        
        if collectionView.contentSize.height < collectionHeight {
            if(collectionMinHeight < collectionHeight){
                viewHeight.constant = collectionMinHeight
            }else{
                viewHeight.constant = collectionHeight
            }
        }else {
            viewHeight.constant = collectionHeight
        }
        //collectionView.reloadData()
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in accountView.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = accountView.subviews[tag] as! LTHRadioButton
        radioButton.select(animated: true)
        strTermDetail = "\(tag)"
        //self.callApi(strTermDetail)
        
        let dicCollection = self.jsonValue["Term"+strTermDetail].array?.first
        
        let accountModal = AccountModal(totalAmt: dicCollection!["TotalAmount"].stringValue, totalRcv: dicCollection!["RecievedAmount"].stringValue, totalDue: dicCollection!["DueAmount"].stringValue)
        self.displayData(arrData: [accountModal.TotalAmt!, accountModal.TotalRcv!, accountModal.TotalDue!])
    }
    
    @IBAction func btnViewSummaryAction(_ sender:UIButton)
    {
        self.presentViewController("Attendance Summary", "Attendance Summary")
    }
    
    // MARK: API Calling
    
    @objc func callApi()
    {
        var apiName:String!
        var params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy")]
        
        switch self.title! {
        case "Student":
            apiName = API.admin_StudentAttendenceApi
        case "Staff":
            apiName = API.admin_StaffAttendenceApi
        case "Account":
            apiName = API.totalFeesCollectionByTermApi
            params = ["TermID":strTermID]
        case "SMS":
            apiName = API.getAllSMSDetailApi
            params = ["StartDate":Date().toString(dateFormat: "dd/MM/yyyy"),
                      "EndDate" : Date().toString(dateFormat: "dd/MM/yyyy")]
        default:
            return
        }
        
        Functions.callApi(api: apiName, params: params) { (json,error) in
            
            if(json != nil){
                
                let dict = json!["FinalArray"].array?.first
                
                var array:[String] = []
                switch self.title! {
                case "Student","Staff":
                    let ssModal = StudentStaffModal(total: dict!["Total\(self.self.title!)"].stringValue, present: dict!["\(self.self.title!)Present"].stringValue, absent: dict!["\(self.self.title!)Leave"].stringValue, leave: dict!["\(self.self.title!)Absent"].stringValue)
                    array = [ssModal.Total!, ssModal.Present!, ssModal.Absent!, ssModal.Leave!]
                    
                case "Account":
                    self.jsonValue = json!
                    let dicCollection = self.jsonValue["Term"+strTermDetail].array?.first
                    
                    let accountModal = AccountModal(totalAmt: dicCollection!["TotalAmount"].stringValue, totalRcv: dicCollection!["RecievedAmount"].stringValue, totalDue: dicCollection!["DueAmount"].stringValue)
                    array = [accountModal.TotalAmt!, accountModal.TotalRcv!, accountModal.TotalDue!]
                    
                case "SMS":
                    array = [json!["Total"].stringValue, json!["Delivered"].stringValue, json!["Other"].stringValue]
                default:
                    break
                }
                self.displayData(arrData: array)
                //Functions.showLoader(false)
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callApi()
                })
            }
        }
    }
    
    func displayData(arrData:[String])
    {
        let cnt:Int = arrData.count == 4 ? 0 : self.title == "SMS" ? 2 : 1
        var i:Int = 3
        for view in self.view.subviews[1].subviews[cnt].subviews {
            if(view.tag == i){
                let lbl:UILabel =  view as! UILabel
                //                lbl.text = self.title == "Account" ? arrData[i-3].formatAmount(number: NSNumber.init(value: Int(arrData[i-3])!)) : arrData[i-3]
                lbl.text = arrData[i-3]
                i += 1
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MainVC:UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/2 - 1, height: collectionView.frame.size.width/2 - (DeviceType.isIphone5 ? 40:50)) // 24
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrData.count + (arrData.count % 2)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:DeshBoardCell = collectionView.dequeueReusableCell(withReuseIdentifier: "DeshBoardCell", for: indexPath) as! DeshBoardCell
        
        for view in cell.bgView.subviews{
            view.isHidden = indexPath.row == arrData.count
        }
        
        if(indexPath.row < arrData.count){
            cell.displayData(self.title!,arrData[indexPath.row])
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell:DeshBoardCell = collectionView.cellForItem(at: indexPath) as! DeshBoardCell
        
        if(indexPath.row < arrData.count){
            if self.title == "Transport" {
                self.presentViewController(self.title!, cell.lblTitle.text!)
            }else if(cell.lblTitle.text! == "Student Bulk SMS") {
                self.presentViewController("Student Absent", cell.lblTitle.text!)
            }else if(cell.lblTitle.text! == "Permission" || cell.lblTitle.text! == "Daily Report" || cell.lblTitle.text! == "Attendance Report" || cell.lblTitle.text! == "Staff Leave" || cell.lblTitle.text! == "My Leave") {
                arrSubData = []
                for (key,value) in dictPermission.value(forKey: self.title!) as! [String:String] {
                    if((dicData[cell.lblTitle.text!] as! [String]).contains(key) && value.components(separatedBy: "-")[0] == "true") {
                        arrSubData.append(key)
                    }
                }
                arrSubData = (dicData[cell.lblTitle.text!] as! [String]).filter { arrSubData.contains($0) }
                //arrSubData = dicData[cell.lblTitle.text!] as! [String]
                self.presentViewController("SubMainVC", cell.lblTitle.text!)
            }else if(cell.lblTitle.text! == "Left/Active") {
                self.presentViewController("New Register", cell.lblTitle.text!)
            }else if(cell.lblTitle.text! == "Summary" || cell.lblTitle.text! == "PTM") {
                self.presentViewController("TabVC", cell.lblTitle.text!)
            }else if(self.title == "SMS" && cell.lblTitle.text! == "Student Transport") {
                self.presentViewController("Student Transport SMS", cell.lblTitle.text!)
            }else {
                self.presentViewController(cell.lblTitle.text!, cell.lblTitle.text!)
            }
        }
    }
    
    func presentViewController(_ identifier:String, _ headerTitle:String?)
    {
        let vc = Constants.storyBoard.instantiateViewController(withIdentifier: identifier)
        vc.view.tag = 1
        vc.title = headerTitle
        vc.accessibilityValue = self.title!
        self.navigationController?.pushPopTransition(vc,true)
    }
}

