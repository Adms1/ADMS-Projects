//
//  DeshboardVC.swift
//  Skool360Admin
//
//  Created by ADMS on 05/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON

var dictPermission:NSMutableDictionary!
class DeshboardVC: CustomViewController {
    
    @IBOutlet var collectionView:UICollectionView!
    var arrHeaderTitle:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.getDynamicFont()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetPermissionApi()
    }
    
    func callGetPermissionApi()
    {
        dictPermission = [:]
        
        let params = ["UserID" : adminID!]
        
        print(params)
        
        Functions.callApi(api: API.getPermissionDataApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for value in arrData! {
                    var subPermission:[String:String] = [:]
                    
                    let array:[JSON] = value["Detail"].array as! [JSON]
                    for subValue in array {
                        subPermission[subValue["PageName"].stringValue] = "\(subValue["Status"].stringValue)-\(subValue["IsUserUpdate"].stringValue)-\(subValue["IsUserDelete"].stringValue)"
                    }
                    dictPermission.setValue(subPermission, forKey: value["Name"].stringValue)
                }
                print(dictPermission)
                
                self.arrHeaderTitle = (dictPermission.allKeys as! [String]).filter { (self.dicData["Main"] as! [String]).contains($0) }
                self.collectionView.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetPermissionApi()
                })
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension DeshboardVC:UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/2, height: collectionView.frame.size.width/2);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrHeaderTitle.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:DeshBoardCell = collectionView.dequeueReusableCell(withReuseIdentifier: "DeshBoardCell", for: indexPath) as! DeshBoardCell
        cell.bgView.addShadowWithRadius(3.0,15.0, 0)
        cell.displayData("Main",arrHeaderTitle[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let vc:MainVC = Constants.storyBoard.instantiateViewController(withIdentifier: "MainVC") as! MainVC
        vc.title = arrHeaderTitle[indexPath.row]
        
        arrData = []
        for (key,value) in dictPermission.value(forKey: arrHeaderTitle[indexPath.row]) as! [String:String] {
            if((dicData[vc.title!] as! [String]).contains(key) && value.components(separatedBy: "-")[0] == "true") {
                arrData.append(key)
            }
        }
        arrData = (dicData[vc.title!] as! [String]).filter { arrData.contains($0) }
        //arrData = dicData[vc.title!] as! [String]
        self.navigationController?.pushPopTransition(vc,true)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        let animation = CABasicAnimation(keyPath: "cornerRadius")
        animation.fromValue = cell.frame.size.width
        cell.layer.cornerRadius = 0
        animation.toValue = 0
        animation.duration = 1
        cell.layer.add(animation, forKey: animation.keyPath)
    }
}
