//
//  WishVC.swift
//  ANBC - Teacher
//
//  Created by ADMS on 01/11/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import SwiftGifOrigin

class WishVC: UIViewController {
    
    @IBOutlet var imgBirthday:UIImageView!
    @IBOutlet var lblName:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        imgBirthday.loadGif(name: "birthday")
        lblName.text = isFromPush ? (pushData["Name"] as! String).replacingOccurrences(of: "|", with: " ") : "Anand Niketan Bhadaj"
        
        let strMain:String = isFromPush ? pushData["Name"] as! String : "Anand|Niketan|Bhadaj"
        let stringInputArr:[String] = strMain.components(separatedBy: "|")
        
        let attribute = NSMutableAttributedString.init(string: lblName.text!)
        
        let range1 = (lblName.text! as NSString).range(of: "\(stringInputArr[0].first!)")
        attribute.addAttribute(NSAttributedStringKey.foregroundColor, value: GetColor.pink, range: range1)
        
        if(stringInputArr.count > 1) {
            let range2 = (lblName.text! as NSString).range(of: "\(stringInputArr[1].first!)")
            attribute.addAttribute(NSAttributedStringKey.foregroundColor, value: GetColor.pink, range: range2)
        }
        if(stringInputArr.count > 2) {
            let range3 = (lblName.text! as NSString).range(of: "\(stringInputArr[2].first!)")
            attribute.addAttribute(NSAttributedStringKey.foregroundColor, value: GetColor.pink, range: range3)
        }
        lblName.attributedText = attribute
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
