
//
//  StudentVC.swift
//  Skool360Admin
//
//  Created by ADMS on 05/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

class SubMainVC: CustomViewController {
    
    @IBOutlet var collectionView:UICollectionView!
    @IBOutlet var lblHeaderTitle:UILabel!
    @IBOutlet var profileView:UIView!
    @IBOutlet var viewHeight:NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        lblHeaderTitle.text = self.title?.uppercased()
        collectionView.superview?.addShadowWithRadius(3.0,15.0, 0)
        (profileView.subviews[0] as! UIImageView).getImagesfromLocal("Main", self.title!)
        
        addBorderWithRadius(profileView, GetColor.blue, profileView.frame.size.width/2, 3.0)
        
        let collectionHeight:CGFloat = self.view.frame.size.height - 160
        let collectionMinHeight:CGFloat = collectionView.contentSize.height + (DeviceType.isIpad ? 140 : 110)
        
        if collectionView.contentSize.height < collectionHeight {
            if(collectionMinHeight < collectionHeight){
                viewHeight.constant = collectionMinHeight
            }else{
                viewHeight.constant = collectionHeight
            }
        }else {
            viewHeight.constant = collectionHeight
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SubMainVC:UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/2 - 1, height: collectionView.frame.size.width/2 - (DeviceType.isIphone5 ? 40:50)) // 24
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrSubData.count + (arrSubData.count % 2)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:DeshBoardCell = collectionView.dequeueReusableCell(withReuseIdentifier: "DeshBoardCell", for: indexPath) as! DeshBoardCell
        
        for view in cell.bgView.subviews{
            view.isHidden = indexPath.row == arrSubData.count
        }
        
        if(indexPath.row < arrSubData.count){
            cell.displayData(self.title!,arrSubData[indexPath.row])
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell:DeshBoardCell = collectionView.cellForItem(at: indexPath) as! DeshBoardCell
        
        if(indexPath.row < arrSubData.count){
            if(cell.lblTitle.text! == "Marks/Syllabus Permission") {
                self.presentViewController("Marks Syllabus Permission", cell.lblTitle.text!)
            }else if(self.title == "Staff Leave" && cell.lblTitle.text! == "Leave Balance") {
                self.presentViewController("Leave Balance New", cell.lblTitle.text!)
            }else if(self.title == "Daily Report") {
                self.presentViewController(self.title!, cell.lblTitle.text!)
            }else if(cell.lblTitle.text! == "Employee In Out Details") {
                self.presentViewController("Employee Present Details", cell.lblTitle.text!)
            }else{
                self.presentViewController(cell.lblTitle.text!, cell.lblTitle.text!)
            }
        }
    }
    
    func presentViewController(_ identifier:String, _ headerTitle:String?)
    {
        let vc = Constants.storyBoard.instantiateViewController(withIdentifier: identifier)
        vc.title = headerTitle
        self.navigationController?.pushPopTransition(vc,true)
    }
}
