//
//  MISVC.swift
//  Skool360Admin
//
//  Created by ADMS on 11/12/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class MISVC: CustomViewController {
    
    @IBOutlet var tblMIS:UITableView!
    var dictMISData:[String:[String]] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMIS.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetMISData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MISVC
{
    func callGetMISData()
    {
        self.dictMISData = [:]
        
        let params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy"),
                      "TermID" : "3"]
        
        print(params)
        
        Functions.callApi(api: API.getMISDataApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dictData = json!["FinalArray"].array?.first!
                
                for item in self.dicData[self.title!] as! [String] {
                    
                    var array:[String] = []
                    if let value = dictData![item].dictionary {
                        switch(item)
                        {
                        case "Student":
                            array = [value["Total"]!.stringValue, value["TotalPresent"]!.stringValue, value["TotalAbsent"]!.stringValue, value["TotalLeave"]!.stringValue, value["TotalStudentANT"]!.stringValue, value["TotalConsistanceAbsent"]!.stringValue]
                        case "Staff":
                            array = [value["Total"]!.stringValue, value["TotalPresent"]!.stringValue, value["TotalAbsent"]!.stringValue, value["TotalLeave"]!.stringValue, value["TotalConsistanceAbsent"]!.stringValue, value["TotalStudentANT"]!.stringValue, "\(value["WorkPlanDone"]!.stringValue)/\(value["WorkPlanTotal"]!.stringValue)", "\(value["HWDone"]!.stringValue)/\(value["HWTotal"]!.stringValue)"]
                        case "Account":
                            array = [value["TotalToBeCollected"]!.stringValue, value["Term1Fees"]!.stringValue, value["Term2Fees"]!.stringValue, "",  value["Term1FeesCollection"]!.stringValue, value["Term2FeesCollection"]!.stringValue, value["TotalOS"]!.stringValue, "", value["CashCollection"]!.stringValue, value["ChequeDD"]!.stringValue, value["Online"]!.stringValue]
                        case "New Addmission":
                            array = [value["TotalInquiry"]!.stringValue, value["IssueAddmissionForm"]!.stringValue, value["RcvAddmissionForm"]!.stringValue, "",  value["ComeForInterview"]!.stringValue, value["ConfirmAddmission"]!.stringValue, "", value["RejectedInquiry"]!.stringValue, value["InquiryFeesRcvd"]!.stringValue]
                        default:
                            array = [value["SMSSent"]!.stringValue, value["SMSDelivered"]!.stringValue, value["SMSPending"]!.stringValue]
                        }
                    }
                    self.dictMISData[item] = array
                }                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMISData()
                })
            }
            self.tblMIS.reloadData()
        }
    }
}

extension MISVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:MISCell = tableView.dequeueReusableCell(withIdentifier: "MISHeaderCell") as! MISCell
        headerView.lblHeader.text = (dicData[self.title!] as! [String])[section]
        headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 20 : 18)
        return headerView.contentView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (dicData[self.title!] as! [String]).count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let array = dicData[self.title!] as! [String]
        return dictMISData.count == 0 ? 0 : (dicData["MIS Value"] as! [String:[String]])[array[section]]!.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return dictMISData.count > 0 ? 40 + indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1 ? 10 : 0 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MISCell = tableView.dequeueReusableCell(withIdentifier: "MISCell", for: indexPath) as! MISCell
        
        cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
        cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
        
        if(indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1) {
            cell.viewBottom.constant = 10.0
        }else {
            cell.viewBottom.constant = -1.0
        }
        
        let array = dicData[self.title!] as! [String]
        let arrTitles:[String] = (dicData["MIS Value"] as! [String:[String]])[array[indexPath.section]]!
        if dictMISData.count > 0 {
            let arrValue:[String] = dictMISData[array[indexPath.section]]!
            cell.displayMISData([arrTitles[indexPath.row], arrValue[indexPath.row]])
            cell.btnView.tag = indexPath.row
            cell.btnView.superview?.tag = indexPath.section
        }
        return cell
    }
    
    @IBAction func btnClickAction(_ sender:UIButton)
    {
        let array = dicData[self.title!] as! [String]
        let arrTitles:[String] = (dicData["MIS Value"] as! [String:[String]])[array[(sender.superview?.tag)!]]!
        
        switch (sender.superview?.tag)! {
        case 0:
            sender.accessibilityValue = arrTitles[sender.tag]
            switch(sender.tag)
            {
            case 0:
                sender.accessibilityLabel = "Total Student"
            case 1:
                sender.accessibilityLabel = "Present"
            case 2:
                sender.accessibilityLabel = "Absent"
            case 3:
                sender.accessibilityLabel = "Leave"
            case 4:
                sender.accessibilityLabel = "Attendance Not Taken"
            default:
                break
            }
        default:
            break
        }
        
        let vc:MISDetailVC = Constants.storyBoard.instantiateViewController(withIdentifier: "MISDetails") as! MISDetailVC
        vc.title = array[(sender.superview?.tag)!]
        vc.accessibilityValue = sender.accessibilityValue
        vc.accessibilityLabel = sender.accessibilityLabel
        self.navigationController?.pushPopTransition(vc,true)
    }
}
