//
//  MISVC.swift
//  Skool360Admin
//
//  Created by ADMS on 11/12/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class MISVC: CustomViewController {
    
    @IBOutlet var tblMIS:UITableView!
    var dictMISData:[String:[String]] = [:]
    var i = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMIS.tableFooterView = UIView()
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.reloadData),name: .callApi,object: nil)
        //    }
        ////
        //    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (_) in
            self.addTermDropDown(self.view.subviews[1])
            self.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MISVC
{
    @objc func reloadData()
    {
        self.dictMISData = [:]
        self.i = 0
        self.callMISApi()
    }
    
    func callMISApi()
    {
        let array = self.dicData[self.title!] as! [String]
        if i < 5 {
            self.callGetMISData(array[self.i], completion: {
                self.tblMIS.reloadData()
                self.callMISApi()
                self.i += 1
            })
        }
    }
    
    func callGetMISData(_ item:String, completion:@escaping() -> ())
    {
        let params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy"),
                      "TermID" : strTermID,
                      "RequestType" : item]
        
        print(params)
        
        Functions.callApi(api: API.getMISDataApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let value = json!["FinalArray"].array?.first!
                
                //                for item in self.dicData[self.title!] as! [String] {
                //
                //var array:[String] = []
                //                    if let value = dictData![item].dictionary {
                switch(item)
                {
                case "Student":
                    self.dictMISData[item] = [value!["Total"].stringValue, value!["TotalPresent"].stringValue, value!["TotalAbsent"].stringValue, value!["TotalLeave"].stringValue, value!["TotalStudentANT"].stringValue, value!["TotalConsistanceAbsent"].stringValue]
                    completion()
                    
                case "Staff":
                    self.dictMISData[item] = [value!["Total"].stringValue, value!["TotalPresent"].stringValue, value!["TotalAbsent"].stringValue, value!["TotalLeave"].stringValue, value!["TotalStudentANT"].stringValue, "\(value!["DailyEntryDone"].stringValue)/\(value!["DailyEntryTotal"].stringValue)", "\(value!["CWDone"].stringValue)/\(value!["CWTotal"].stringValue)", "\(value!["HWDone"].stringValue)/\(value!["HWTotal"].stringValue)"]
                    completion()
                    
                case "Account":
                    self.dictMISData[item] = [value!["TotalToBeCollected"].stringValue, value!["Term1Fees"].stringValue, value!["Term2Fees"].stringValue, " ",  value!["Term1FeesCollection"].stringValue, value!["Term2FeesCollection"].stringValue, value!["TotalOS"].stringValue, " ", value!["CashCollection"].stringValue, value!["ChequeDD"].stringValue, value!["Online"].stringValue]
                    completion()
                    
                case "New Addmission":
                    self.dictMISData[item] = [value!["TotalInquiry"].stringValue, value!["IssueAddmissionForm"].stringValue, value!["RcvAddmissionForm"].stringValue,  value!["ComeForInterview"].stringValue, value!["ConfirmAddmission"].stringValue, value!["RejectedInquiry"].stringValue, value!["InquiryFeesRcvd"].stringValue]
                    completion()
                    
                default:
                    self.dictMISData[item] = [value!["SMSSent"].stringValue, value!["SMSDelivered"].stringValue, value!["SMSPending"].stringValue]
                    self.tblMIS.reloadData()
                }
                //}
                //                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMISData(item, completion: {
                        self.tblMIS.reloadData()
                    })
                })
            }
        }
    }
}

extension MISVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:MISCell = tableView.dequeueReusableCell(withIdentifier: "MISHeaderCell") as! MISCell
        headerView.lblHeader.text = (dicData[self.title!] as! [String])[section]
        headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 20 : 18)
        return headerView.contentView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (dicData[self.title!] as! [String]).count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let array = dicData[self.title!] as! [String]
        return dictMISData[array[section]] == nil ? 1 : (dicData["MIS Value"] as! [String:[String]])[array[section]]!.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let array = dicData[self.title!] as! [String]
        return dictMISData[array[indexPath.section]] != nil ? 40 + (indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1 ? 10 : 0) : 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let array = dicData[self.title!] as! [String]
        let cell:MISCell = tableView.dequeueReusableCell(withIdentifier: dictMISData[array[indexPath.section]] == nil ? "MISLoaderCell" : "MISCell", for: indexPath) as! MISCell
        
        if dictMISData[array[indexPath.section]] == nil {
            if let actView = cell.contentView.subviews[0].subviews[0].subviews[0] as? UIActivityIndicatorView {
                actView.startAnimating()
            }
        }
        else {
            cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
            cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
            
            if(indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1) {
                cell.viewBottom.constant = 10.0
            }else {
                cell.viewBottom.constant = -1.0
            }
            
            let arrTitles:[String] = (dicData["MIS Value"] as! [String:[String]])[array[indexPath.section]]!
            if dictMISData[array[indexPath.section]] != nil {
                let arrValue:[String] = dictMISData[array[indexPath.section]]!
                cell.displayMISData([arrTitles[indexPath.row], arrValue[indexPath.row]])
                cell.btnView.tag = indexPath.row
                cell.btnView.superview?.tag = indexPath.section
            }
        }
        return cell
    }
    
    @IBAction func btnClickAction(_ sender:UIButton)
    {
        let array = dicData[self.title!] as! [String]
        let arrTitles:[String] = (dicData["MIS Value"] as! [String:[String]])[array[(sender.superview?.tag)!]]!
        
        switch (sender.superview?.tag)! {
        case 0:
            sender.accessibilityValue = arrTitles[sender.tag]
            switch(sender.tag)
            {
            case 0:
                sender.accessibilityLabel = "Total Student"
            case 1,2,3:
                sender.accessibilityLabel = arrTitles[sender.tag]
            case 4:
                sender.accessibilityLabel = "Attendance Not Taken"
            default:
                sender.accessibilityLabel = ""
            }
        default:
            break
        }
        
        let vc:MISDetailVC = Constants.storyBoard.instantiateViewController(withIdentifier: "MISDetails") as! MISDetailVC
        vc.title = array[(sender.superview?.tag)!]
        vc.accessibilityValue = sender.accessibilityValue
        vc.accessibilityLabel = sender.accessibilityLabel
        if (sender.superview?.tag)! == 0 {
            self.navigationController?.pushPopTransition(vc,true)
        }
    }
}
