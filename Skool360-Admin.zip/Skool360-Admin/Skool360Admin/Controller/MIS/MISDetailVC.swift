//
//  MISDetailVC.swift
//  Skool360Admin
//
//  Created by ADMS on 11/12/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class MISDetailVC: CustomViewController {
    
    @IBOutlet var tblMISDetails:UITableView!
    var arrStandardData = [StandardModel]()
    var arrStudentData = [StudentModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMISDetails.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetMISDetails()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MISDetailVC
{
    func callGetMISDetails()
    {
        self.arrStandardData = []
        self.arrStudentData = []
        
        let params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy"),
                      "TermID" : "3",
                      "RequestType" : self.accessibilityValue!]
        
        print(params)
        
        Functions.callApi(api: API.getMISStudentApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dictData = json!["FinalArray"].array?.first!
                
                for standardData in dictData!["StandardData"].array! {
                    self.arrStandardData.append(StandardModel.init(std: standardData["Standard"].stringValue, totalStudent: standardData["Total Student"].stringValue))
                }
                
                let key = self.accessibilityValue == "A.N.T." ? "ANT" : "StudentData"
                for studentData in dictData![key].array! {
                    if self.accessibilityValue == "A.N.T." {
                        self.arrStudentData.append(StudentModal.init(grade: studentData["Grade"].stringValue, section: studentData["Section"].stringValue, totalStudent: studentData["TotalStudent"].stringValue, classTeacher: studentData["ClassTeacher"].stringValue))
                    }else {
                        self.arrStudentData.append(StudentModal.init(grade: studentData["Grade"].stringValue, section: studentData["Section"].stringValue, stuName: studentData["StudentName"].stringValue, grno: studentData["GRNO"].stringValue, status: studentData["AttendanceStatus"].stringValue))
                    }
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMISDetails()
                })
            }
            self.tblMISDetails.reloadData()
        }
    }
}

extension MISDetailVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: section == 0 && self.accessibilityValue != "A.N.T." ? "MISHeaderCell" : "MIS\(self.accessibilityValue == "Total" || self.accessibilityValue == "A.N.T." ? self.accessibilityValue! : "PAL")HeaderCell") as! MISDetailCell
        if section == 0 && self.accessibilityValue != "A.N.T." {
            headerView.lblHeader.text = self.accessibilityLabel!
            headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 20 : 18)
        }
        return arrStudentData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 && self.accessibilityValue != "A.N.T." && arrStudentData.count > 0 ? 50 : arrStudentData.count > 0 ?DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.accessibilityValue == "A.N.T." ? 1 : 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 && self.accessibilityValue != "A.N.T." ? arrStandardData.count : arrStudentData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == 0 ? arrStandardData.count > 0 ? 40 + (indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1 ? 10 : 0) : 0  : arrStudentData.count > 0 ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: indexPath.section == 0 && self.accessibilityValue != "A.N.T." ? "MISCell" : "MIS\(self.accessibilityValue == "Total" || self.accessibilityValue == "A.N.T." ? self.accessibilityValue! : "PAL")Cell", for: indexPath) as! MISDetailCell
        
        if indexPath.section == 0 && self.accessibilityValue != "A.N.T." {
            cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
            cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
            
            if(indexPath.row == tableView.numberOfRows(inSection: 0)-1) {
                cell.viewBottom.constant = 10.0
            }else {
                cell.viewBottom.constant = -1.0
            }
            cell.displayStandardData(arrStandardData[indexPath.row])
        }else{
            if self.accessibilityValue == "A.N.T." {
                cell.displayANTData(arrStudentData[indexPath.row])
            }else {
                cell.displayStudentData(arrStudentData[indexPath.row])
            }
        }
        return cell
    }
}
