//
//  MISDetailVC.swift
//  Skool360Admin
//
//  Created by ADMS on 11/12/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class MISDetailVC: CustomViewController {
    
    @IBOutlet var tblMISDetails:UITableView!
    var arrStandardData = [StandardModel]()
    var arrStudentData = [StudentModal]()
    var arrStaffData = [StaffModal]()
    var str:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMISDetails.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetMISDetails()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MISDetailVC
{
    func callGetMISDetails()
    {
        self.arrStandardData = []
        self.arrStudentData = []
        
        let params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy"),
                      "TermID" : strTermID,
                      "RequestType" : self.accessibilityValue!]
        
        print(params)
        
        var strApi:String!
        switch (self.title)! {
        case "Student":
            strApi = API.getMISStudentApi
        case "Staff":
            strApi = API.getMISStaffApi
        default:
            break
        }
        
        Functions.callApi(api: strApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dictData = json!["FinalArray"].array?.first!
                
                let key = self.accessibilityValue == "A.N.T." || self.accessibilityLabel == "A.N.T." ? "ANT" : "\((self.title)!)Data"
                if key != "ANT" && self.title != "Staff" {
                    for standardData in dictData!["StandardData"].array! {
                        self.arrStandardData.append(StandardModel.init(std: standardData["Standard"].stringValue, totalStudent: standardData["Total Student"].stringValue))
                    }
                }
                
                for data in dictData![key].array! {
                    if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                        self.arrStudentData.append(StudentModal.init(grade: data["Grade"].stringValue, section: data["Section"].stringValue, totalStudent: data["TotalStudent"].stringValue, classTeacher: data["ClassTeacher"].stringValue))
                    }else {
                        switch (self.title)! {
                        case "Student":
                            self.arrStudentData.append(StudentModal.init(grade: data["Grade"].stringValue, section: data["Section"].stringValue, stuName: data["StudentName"].stringValue, grno: data["GRNO"].stringValue, status: data["AttendanceStatus"].stringValue))
                            
                        case "Staff":
                            self.arrStaffData.append(StaffModal.init(name: data["StaffName"].stringValue, code: data["StaffCode"].stringValue, department: data["Department"].stringValue, status: data["AttendanceStatus"].stringValue))
                        default:
                            break
                        }
                    }
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMISDetails()
                })
            }
            self.tblMISDetails.reloadData()
        }
    }
}

extension MISDetailVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var strIdentifier:String!
        switch section {
        case 0:
            switch((self.title)!)
            {
            case "Student":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    strIdentifier = "MIS\(self.title!)\(self.accessibilityValue!)HeaderCell"
                }else{
                    strIdentifier = "MISHeaderCell"
                }
            case "Staff":
                strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.title!)\(self.accessibilityValue!)HeaderCell" : "MIS\(self.title!)PALHeaderCell"
            default:
                break
            }
        default:
            strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.title!)\(self.accessibilityValue!)HeaderCell" : "MIS\(self.title!)PALHeaderCell"
        }
        
        let headerView:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier) as! MISDetailCell
        if section == 0 && !(self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! && self.title == "Student" {
            headerView.lblHeader.text = self.accessibilityLabel!
            headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 20 : 18)
        }
        
        switch (self.title)! {
        case "Student":
            return arrStudentData.count > 0 ? headerView.contentView : nil
        case "Staff":
            return arrStaffData.count > 0 ? headerView.contentView : nil
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch section {
        case 0:
            if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                switch (self.title)! {
                case "Student":
                    return arrStudentData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
                case "Staff":
                    return arrStaffData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
                default:
                    return 0
                }
            }else{
                switch (self.title)! {
                case "Student":
                    return arrStandardData.count > 0 ? 50 : 0
                case "Staff":
                    return arrStaffData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
                default:
                    return 0
                }
            }
        default:
            switch (self.title)! {
            case "Student":
                return arrStudentData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
            case "Staff":
                return arrStaffData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
            default:
                return 0
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        switch (self.title)! {
        case "Student":
            return (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! ? 1 : 2
        case "Staff":
            return 1
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                switch (self.title)! {
                case "Student":
                    return arrStudentData.count
                case "Staff":
                    return arrStaffData.count
                default:
                    return 0
                }
            }else{
                switch (self.title)! {
                case "Student":
                    return arrStandardData.count
                case "Staff":
                    return arrStaffData.count
                default:
                    return 0
                }
            }
        default:
            switch (self.title)! {
            case "Student":
                return arrStudentData.count
            case "Staff":
                return arrStaffData.count
            default:
                return 0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                switch (self.title)! {
                case "Student":
                    return arrStudentData.count > 0 ? UITableViewAutomaticDimension : 0
                case "Staff":
                    return arrStaffData.count > 0 ? UITableViewAutomaticDimension : 0
                default:
                    return 0
                }
            }else{
                switch (self.title)! {
                case "Student":
                    return arrStandardData.count > 0 ? 40 + (indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1 ? 10 : 0) : 0
                case "Staff":
                    return arrStaffData.count > 0 ? UITableViewAutomaticDimension : 0
                default:
                    return 0
                }
            }
        default:
            switch (self.title)! {
            case "Student":
                return arrStudentData.count > 0 ? UITableViewAutomaticDimension : 0
            case "Staff":
                return arrStaffData.count > 0 ? UITableViewAutomaticDimension : 0
            default:
                return 0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        switch indexPath.section {
        case 0:
            switch (self.title)! {
            case "Student":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    strIdentifier = "MIS\(self.title!)\(self.accessibilityValue!)Cell"
                }else{
                    strIdentifier = "MISCell"
                }
            case "Staff":
                strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.title!)\(self.accessibilityValue!)Cell" : "MIS\(self.title!)PALCell"
            default:
                break
            }
        default:
            strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.title!)\(self.accessibilityValue!)Cell" : "MIS\(self.title!)PALCell"
        }
        
        let cell:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! MISDetailCell
        
        if indexPath.section == 0 && !(self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! && self.title == "Student" {
            cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
            cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
            
            if(indexPath.row == tableView.numberOfRows(inSection: 0)-1) {
                cell.viewBottom.constant = 10.0
            }else {
                cell.viewBottom.constant = -1.0
            }
            cell.displayStandardData(arrStandardData[indexPath.row])
        }else{
            switch (self.title)! {
            case "Student":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    cell.displayStudentANTData(arrStudentData[indexPath.row])
                }else {
                    cell.displayStudentData(arrStudentData[indexPath.row])
                }
            case "Staff":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    cell.displayStaffANTData(arrStaffData[indexPath.row])
                }else {
                    cell.displayStaffData(arrStaffData[indexPath.row])
                }
            default:
                break
            }
        }
        return cell
    }
}
