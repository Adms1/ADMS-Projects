//
//  SideMenuTableView.swift
//  SideMenu
//
//  Created by Jon Kent on 4/5/16.
//  Copyright © 2016 CocoaPods. All rights reserved.
//

import Foundation
import LGSideMenuController

class SideMenuVC: CustomViewController {
    
    @IBOutlet var tblSideMenu:UITableView!
    @IBOutlet var lblAdminName:UILabel!
    @IBOutlet var lblAdminDesignation:UILabel!
    
    var arrMenuItems = ["Student","Staff","SMS","Account","HR", "Logout"]
    var arrSubMenuItems:[String] = []
    
    var headerTitle:String!
    var arrCategoryData:[String] = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tblSideMenu.tableFooterView = UIView()
        
        lblAdminName.text = adminName!
        lblAdminDesignation.text = adminDesignation!
    }
}

extension SideMenuVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:MenuCell = tableView.dequeueReusableCell(withIdentifier: "MenuCell") as! MenuCell
        headerView.viewSelected.isHidden = section == selectedIndex ? false : true
        headerView.displayMenuItems(arrMenuItems[section], section == selectedIndex)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        return  headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrMenuItems.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MenuSubItemCell = tableView.dequeueReusableCell(withIdentifier: "MenuSubItemCell", for: indexPath) as! MenuSubItemCell
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        selectedIndex = (gesture.view?.tag)!
        
        tblSideMenu.reloadSections(IndexSet(integersIn: 0...arrMenuItems.count-1), with: .automatic)
        
        if selectedIndex != 5 {
            let mvc:MainVC = Constants.storyBoard.instantiateViewController(withIdentifier: "MainVC") as! MainVC
            mvc.title = arrMenuItems[selectedIndex]
            arrData = dicData[mvc.title!] as! [String]
            self.pushToViewController(mvc,arrMenuItems)
        }else{
            Functions.showCustomAlert("Logout", Message.logout, isDone: { (_) in
                UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
                Constants.appDelegate.rootViewController()
            })
        }
    }
    
    func pushToViewController(_ vc:UIViewController, _ array:[String])
    {
        let mainViewController = Constants.appDelegate.window!.rootViewController! as! LGSideMenuController
        
        if(array[selectedIndex] == lastViewController.value(forKey: "storyboardIdentifier") as! String)
        {
            self.hideView(mainViewController)
            return
        }
        
        let navigationController = mainViewController.rootViewController as! UINavigationController
        navigationController.pushPopTransition(vc,true)
        self.hideView(mainViewController)
    }
    
    func hideView(_ mvc:LGSideMenuController)
    {
        mvc.hideRightView(animated: true, completionHandler: nil)
        selectedIndex = -1
        tblSideMenu.reloadData()
    }
}
