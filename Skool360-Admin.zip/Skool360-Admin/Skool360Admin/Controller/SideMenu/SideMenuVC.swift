//
//  SideMenuTableView.swift
//  SideMenu
//
//  Created by Jon Kent on 4/5/16.
//  Copyright © 2016 CocoaPods. All rights reserved.
//

import Foundation
import LGSideMenuController

class SideMenuVC: CustomViewController {
    
    @IBOutlet var tblSideMenu:UITableView!
    
    var arrMenuItems = ["Student","Staff","SMS","Account","HR", "Logout"]
    var arrSubMenuItems:[String] = []
    
    var headerTitle:String!
    var arrCategoryData:[String] = []
    var Index:NSInteger = -1
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tblSideMenu.tableFooterView = UIView()
        
//        if let path = Bundle.main.path(forResource: "AdminList", ofType: "plist") {
//            arrSubMenuItems = NSDictionary(contentsOfFile: path)!.value(forKey: "Other") as! [String]
//        }
    }
}

extension SideMenuVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:MenuCell = tableView.dequeueReusableCell(withIdentifier: "MenuCell") as! MenuCell
        headerView.viewSelected.isHidden = section == selectedIndex ? false : true
        headerView.viewSelected.isHidden = section == selectedIndex ? false : true
        headerView.displayMenuItems(arrMenuItems[section], section == selectedIndex)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        return  headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrMenuItems.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == arrMenuItems.count - 2 && selectedIndex == arrMenuItems.count - 2){
            return DeviceType.isIpad ? 50 : 40
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView.rowHeight == 0 ? 0 : arrSubMenuItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MenuSubItemCell = tableView.dequeueReusableCell(withIdentifier: "MenuSubItemCell", for: indexPath) as! MenuSubItemCell
        cell.backgroundColor = UIColor.clear
        cell.displaySubMenuItems(arrSubMenuItems[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        Index = indexPath.row
        
        var strIdentifier:String = "Student Absent"
        var title:String = "Bulk SMS"
        
        //if Index != 0 && Index != 1 {
        strIdentifier = "\(arrSubMenuItems[Index])"
        title = strIdentifier
        
        if(Index == 0 || Index == 2){
            strIdentifier = "TabVC"
            if(Index == 0){
                title = "Summary"
            }else {
                title = "PTM"
            }
        }
        //        }else{
        //            if Index != 1 {
        //                title = strIdentifier
        //            }
        //        }
        
        let vc = Constants.storyBoard.instantiateViewController(withIdentifier: strIdentifier)
        vc.view.tag = 1
        vc.title = title
        self.pushToViewController(vc,arrSubMenuItems)
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        Index = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        tblSideMenu.reloadSections(IndexSet(integersIn: 0...arrMenuItems.count-1), with: .automatic)
        
        if Index != 6 && Index != 7 {
            let mvc:MainVC = Constants.storyBoard.instantiateViewController(withIdentifier: "MainVC") as! MainVC
            mvc.title = arrMenuItems[Index]
            arrData = dicData[mvc.title!] as! [String]
            self.pushToViewController(mvc,arrMenuItems)
        }
    }
    
    func pushToViewController(_ vc:UIViewController, _ array:[String])
    {
        let mainViewController = Constants.appDelegate.window!.rootViewController! as! LGSideMenuController
        
        if(array[Index] == lastViewController.value(forKey: "storyboardIdentifier") as! String)
        {
            self.hideView(mainViewController)
            return
        }
        
        let navigationController = mainViewController.rootViewController as! UINavigationController
        navigationController.pushPopTransition(vc,true)
        self.hideView(mainViewController)
    }
    
    func hideView(_ mvc:LGSideMenuController)
    {
        mvc.hideRightView(animated: true, completionHandler: nil)
        selectedIndex = -1
        tblSideMenu.reloadData()
    }
}
