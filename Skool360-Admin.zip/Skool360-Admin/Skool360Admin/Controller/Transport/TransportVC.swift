//
//  FeesStructureVC.swift
//  Skool360Admin
//
//  Created by ADMS on 30/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class TransportVC: CustomViewController {
    
    @IBOutlet var tblTransport:UITableView!
    @IBOutlet var lblHeaderTitle:UILabel!
    @IBOutlet var topViewHeight:NSLayoutConstraint!
    
    var arrTransportDetails = [TransportModal]()
    var strRoute:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        topViewHeight.constant = 5.0
        
        switch self.title! {
        case "Transport Charges":
            self.callGetTermApi(false) { (success) in
                self.addDropDown()
            }
            
        case "Route Pick Up Point Detail":
            self.callGetRoutesApi(completion: { (success) in
                self.addDropDown()
            })
            
        case "Vehicle Detail":
            self.callTransportApi(API.getVehicleDetail, strTermID)
            
        default:
            self.callTransportApi(API.getVehicleToRouteDetail, strTermID)
        }
    }
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        topViewHeight.constant = 70.0
        let dropDown:UIDropDown = UIDropDown(frame: CGRect(x:self.view.frame.size.width/2 - (self.title == "Transport Charges" ? 60 : 75), y:self.view.subviews[1].frame.origin.y, width:self.title == "Transport Charges" ? 120 : 150, height:self.view.subviews[1].frame.size.height))
        dropDown.placeholder = Constants.dropDownPlaceholder
        
        var strValue:String!
        if self.title == "Transport Charges" {
            strValue = (dicTerms.allKeys(for: strTermID) as! [String]).first!
            dropDown.options = self.arrTerms as! [String]
            dropDown.tableHeight = (dicTerms.allKeys as! [String]).count > 5 ? CGFloat(5 * 35) : CGFloat(dicTerms.allKeys.count * 35)
            dropDown.selectedIndex = (self.arrTerms as! [String]).index(of: strValue)
        }else {
            strValue = strRoute
            dropDown.options = self.arrRoutes
            dropDown.tableHeight = self.arrRoutes.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrRoutes.count * 35)
            dropDown.selectedIndex = self.arrRoutes.index(of: strValue)
        }
        dropDown.title.text = strValue
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            
            if self.title == "Transport Charges" {
                strTermID = self.dicTerms[option] as! String
                self.callTransportApi(API.getTrasportChargesApi, strTermID)
            }else {
                self.strRoute = option
                self.getRoutesData()
            }
        }
        self.view.addSubview(dropDown)
        if self.title == "Transport Charges"{
            self.callTransportApi(API.getTrasportChargesApi, strTermID)
        }else{
            self.getRoutesData()
        }
    }
    
    func getRoutesData()
    {
        arrTransportDetails = dicRoutes.value(forKey: strRoute!) as! [TransportModal]
        if arrTransportDetails.count == 1 {
            Functions.showAlert(false, Message.noRecordFound)
        }
        tblTransport.reloadData()
    }
    
    // MARK: Api Calling
    
    func callGetRoutesApi(completion:@escaping (Bool) -> Void)
    {
        dicRoutes = [:]
        
        Functions.callApi(api: API.getRoutePickUpPointDetail, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayRoutes = json!["FinalArray"].array
                
                for value in arrayRoutes! {
                    
                    if(self.strRoute == nil){
                        self.strRoute = value["Route"].stringValue
                    }
                    
                    let arrPickupPointDetail:[JSON] = value["PickupPointDetail"].array!
                    
                    var arrPickupPoints = [TransportModal]()
                    for (index,subValues) in arrPickupPointDetail.enumerated() {
                        let pickUpPointModal:TransportModal = TransportModal.init(index:"\(index+1)", pickUpPoint: subValues["PickupPoint"].stringValue, status: subValues["Status"].stringValue)
                        
                        arrPickupPoints.append(pickUpPointModal)
                    }
                    self.dicRoutes.setValue(arrPickupPoints, forKey: value["Route"].stringValue)
                    
                    self.arrRoutes = (self.dicRoutes.allKeys as! [String]).sorted {
                        (s1, s2) -> Bool in return s1.localizedStandardCompare(s2) == .orderedAscending
                    }
                }
                completion(true)
            }
        }
    }
    
    func callTransportApi(_ webApi:String, _ strTermID:String)
    {
        let params = ["Term_ID" : strTermID]
        
        print(params)
        
        arrTransportDetails = []
        
        Functions.callApi(api: webApi, params: self.title == "Transport Charges" ? params : [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayTransportData = json!["FinalArray"].array
                
                for (i,value) in arrayTransportData!.enumerated() {
                    
                    var transportModal:TransportModal!
                    switch(self.title!)
                    {
                    case "Transport Charges":
                        transportModal = TransportModal.init(kms: value["Km"].stringValue, term1Fee: value["Term 1"].stringValue, term2Fee: value["Term 2"].stringValue)
                        
                    case "Vehicle Detail":
                        transportModal = TransportModal.init(index: "\(i+1)", vehicleName: value["VehicleName"].stringValue, regNo: value["Registration No."].stringValue, passngCapacity: value["Passng Capacity"].stringValue)
                        
                    default:
                        transportModal = TransportModal.init(index: "\(i+1)", vehicleName: value["Vehicle"].stringValue, routeNm: value["RouteNm"].stringValue)
                    }
                    self.arrTransportDetails.append(transportModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callTransportApi(webApi, strTermID)
                })
            }
            self.tblTransport.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension TransportVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let strIdentifier:String = "\((self.title?.replacingOccurrences(of: " ", with: ""))!)Cell"
        
        let headerView:TransportCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier) as! TransportCell
        
        for view in headerView.contentView.subviews[0].subviews.filter({($0.isKind(of: UILabel.classForCoder()))}) {
            let lbl:UILabel = view as! UILabel
            lbl.font = FontType.mediumFont
        }
        
        return arrTransportDetails.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        tableView.estimatedSectionHeaderHeight = DeviceType.isIpad ? 45 : 40
        return arrTransportDetails.count > 0 ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTransportDetails.count > 0 ? arrTransportDetails.count : 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = DeviceType.isIpad ? 50 : 40
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let strIdentifier:String = "\((self.title?.replacingOccurrences(of: " ", with: ""))!)Cell"
        let cell:TransportCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! TransportCell
        
        for view in cell.contentView.subviews[0].subviews{
            if(view.isKind(of: UIImageView.classForCoder())) {
                let imgView:UIImageView = view as! UIImageView
                imgView.image = UIImage.init(named: "")
            }else{
                let lbl:UILabel = view as! UILabel
                lbl.textColor = .black
                lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
                if(lbl.tag == -2){
                    lbl.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
                }
            }
        }
        
        switch self.title! {
        case "Transport Charges":
            cell.displayTransportChargesData(arrTransportDetails[indexPath.row])
            
        case "Vehicle Detail":
            cell.displayVehicleDetailData(arrTransportDetails[indexPath.row])
            
        case "Vehicle Route's":
            cell.displayVehicleRouteData(arrTransportDetails[indexPath.row])
            
        default:
            cell.displayPickupDetailData(arrTransportDetails[indexPath.row])
        }
        return cell
    }
}

