//
//  SMS.swift
//  Skool360Admin
//
//  Created by ADMS on 28/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class AppSMSVC: CustomViewController {
    
    @IBOutlet var tblAppSMS:UITableView!
    @IBOutlet var btnSubmit:UIButton!
    @IBOutlet var btnSearch:UIButton!
    
    var arrAPPSMSData = [SMSModel]()
    var selectedCheckBoxFlag = 0
    var activateField:UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arrSelectedIds = []
        NotificationCenter.default.addObserver(self,selector: #selector(self.callGetAppSMSApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.arrStandards.insert("All", at: 0)
                self.strStatus = "Active"
                self.addDropDown()
                self.callGetAppSMSApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    @objc func callGetAppSMSApi()
    {
        let params = ["StandardName" : self.strStd!,
                      "ClassName" : self.strClass!,
                      "TermID" : strTermID,
                      "Status" : strStatus]
        
        print(params)
        
        arrAPPSMSData = []
        
        Functions.callApi(api: API.getAppSMSDataApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayGetData = json!["FinalArray"].array
                
                for (i,value) in arrayGetData!.enumerated() {
                    
                    let smsModal:SMSModel = SMSModel.init(index: "\(i+1)", stuName: value["StudentName"].stringValue, grno: value["GR"].stringValue, std: value["Standard"].stringValue, cls: value["ClassName"].stringValue, smsNo: value["Sms_No"].stringValue, stuId: value["Fk_StudentID"].stringValue, stdId: value["Fk_StandardID"].stringValue, clsId: value["Fk_ClassID"].stringValue, status: value["AppStatus"].stringValue)
                    
                    self.arrAPPSMSData.append(smsModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAppSMSApi()
                })
            }
            self.btnSubmit.isHidden = self.arrAPPSMSData.count > 0 ? false : true
            self.checkBtnStatus()
            self.tblAppSMS.reloadData()
        }
    }
    
    func callSentMessageApi()
    {
        let params = ["TermID" : strTermID,
                      "StuIDMobile" : arrSelectedIds.joined(separator: ",")]
        
        print(params)
        
        Functions.callApi(api: API.sendAppSMSApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(false, Message.msgSentSuccess)
                
                strTermID = "3"
                self.strTerm = (self.dicTerms as NSDictionary).allKeys(for: strTermID).first as! String
                self.strClass = "All"
                self.strStd = "All"
                self.strStatus = "Active"
                arrSelectedIds = []
                
                // 1,2
                for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                    let dropDown:UIDropDown = view as! UIDropDown
                    if(dropDown.table != nil){
                        dropDown.hideTable()
                    }
                    dropDown.removeFromSuperview()
                }
                self.addDropDown()
                self.callGetAppSMSApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSentMessageApi()
                })
            }
        }
    }
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 2:
                    self.addStandardDropDown(view)
                    
                case 4:
                    self.addStatusDropDown(view)
                    
                default:
                    self.addSectionDropDown(3)
                }
                i += 1
                
            }else if(view.tag == i) {
                self.addTermDropDown(view)
                i += 1
            }
        }
    }
    
    func addStatusDropDown(_ subView:UIView)
    {
        let array:[String] = ["Active", "Inactive"]
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.placeholder = Constants.dropDownPlaceholder
        dropDown.tag = 40
        dropDown.options = array
        dropDown.tableHeight = 2 * 35
        dropDown.selectedIndex = 0
        dropDown.title.text = array[0]
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strStatus = option
        }
        view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchSubmitAction(_ sender:UIButton)
    {
        if sender.tag == 10 {
            self.callGetAppSMSApi()
        }else{
            self.callSentMessageApi()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AppSMSVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        UIView.animate(withDuration: 0.5) {
            self.tblAppSMS.frame.origin.y = 300
            self.tblAppSMS.setContentOffset(CGPoint(x: 0, y:((textField.superview?.superview?.superview?.frame.origin.y)!-40)), animated: true)
        }
        activateField = textField
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(range.location > 9){
            return false
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if((textField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }else {
            textField.resignFirstResponder()
            self.view.endEditing(true)
            UIView.animate(withDuration: 0.5) {
                self.tblAppSMS.reloadData()
                self.tblAppSMS.contentOffset = .zero
            }
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        let smsModal:SMSModel = self.arrAPPSMSData[textField.tag]
        
        if(arrSelectedIds.contains("\(smsModal.StudentID!)|\(smsModal.SMSNo!)")) {
            let index:NSInteger = arrSelectedIds.index(of: "\(smsModal.StudentID!)|\(smsModal.SMSNo!)")!
            arrSelectedIds[index] = "\(smsModal.StudentID!)|\(textField.text!)"
        }
        smsModal.SMSNo = textField.text
        
        self.arrAPPSMSData[textField.tag] = smsModal
        self.tblAppSMS.reloadRows(at: [IndexPath.init(row:textField.tag, section: 0)], with: .automatic)
    }
    
    override func dismissPicker() {
        
        activateField.resignFirstResponder()
        self.view.endEditing(true)
        UIView.animate(withDuration: 0.5) {
            self.tblAppSMS.reloadData()
            self.tblAppSMS.contentOffset = .zero
        }
        
        if((activateField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }
    }
}

extension AppSMSVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSHeaderCell") as! SMSCell
        
        for view in headerView.contentView.subviews[0].subviews {
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    checkBox.setOn(false, animated: true)
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    
                    if(isOn){
                        self.selectedCheckBoxFlag = checkBox.tag
                        
                        for value in self.arrAPPSMSData {
                            arrSelectedIds.append("\(value.StudentID!)|\(value.SMSNo!)")
                        }
                    }else{
                        self.selectedCheckBoxFlag = 0
                        arrSelectedIds = []
                    }
                    self.checkBtnStatus()
                    checkBox.setOn(isOn, animated: true)
                    tableView.reloadData()
                }
            }else if(view.isKind(of: UILabel.classForCoder())){
                (view as! UILabel).font = FontHelper.medium(size: DeviceType.isIpad ? 15 : 10)
            }
        }
        return self.arrAPPSMSData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return self.arrAPPSMSData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrAPPSMSData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSCell", for: indexPath) as! SMSCell
        
        let smsModal:SMSModel = self.arrAPPSMSData[indexPath.row]
        cell.displayAppSMSData(smsModal)
        
        for view in cell.contentView.subviews[0].subviews {
            
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    if(arrSelectedIds.contains("\(smsModal.StudentID!)|\(smsModal.SMSNo!)")) {
                        checkBox.setOn(true, animated: true)
                    }else {
                        checkBox.setOn(false, animated: true)
                    }
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    checkBox.setOn(isOn, animated: true)
                    if(self.selectedCheckBoxFlag == checkBox.tag) {
                        self.selectedCheckBoxFlag = 0
                        self.tblAppSMS.reloadSections(IndexSet(integersIn: 0...0), with: .automatic)
                    }
                    
                    if(checkBox.isOn()) {
                        arrSelectedIds.append("\(smsModal.StudentID!)|\(smsModal.SMSNo!)")
                    }
                    else {
                        arrSelectedIds.remove(at: arrSelectedIds.index(of: "\(smsModal.StudentID!)|\(smsModal.SMSNo!)")!)
                    }
                    
                    self.tblAppSMS.reloadRows(at: [IndexPath.init(row: indexPath.row, section: 0)], with: .automatic)
                    self.checkBtnStatus()
                }
            }else if(view.isKind(of: UITextField.classForCoder())){
                (view as! UITextField).font = FontHelper.regular(size: DeviceType.isIpad ? 15 : 10)
                (view as! UITextField).inputAccessoryView = addToolbar()
                view.tag = indexPath.row
            }else{
                (view as! UILabel).font = FontHelper.regular(size: DeviceType.isIpad ? 15 : 10)
            }
        }
        return cell
    }
    
    func checkBtnStatus()
    {
        btnSubmit.isEnabled = arrSelectedIds.count > 0 ? true : false
        btnSubmit.alpha = btnSubmit.isEnabled ? 1.0 : 0.5
    }
}
