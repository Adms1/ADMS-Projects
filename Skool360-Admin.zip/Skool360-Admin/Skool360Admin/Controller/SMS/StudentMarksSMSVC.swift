//
//  SMS.swift
//  Skool360Admin
//
//  Created by ADMS on 28/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class StudentMarksSMSVC: CustomViewController {
    
    @IBOutlet var tblStudentMarks:UITableView!
    @IBOutlet var btnSubmit:UIButton!
    @IBOutlet var btnSearch:UIButton!
    
    var arrStudentMarksData = [SMSMarksModel]()
    var selectedCheckBoxFlag = 0
    var activateField:UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arrSelectedIds = []
        NotificationCenter.default.addObserver(self,selector: #selector(self.callGetMarksApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.addDropDown()
                self.callGetSubjectApi(completion: { (success) in
                    self.addSubjectDropDown()
                    self.callGetMarksApi()
                })
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionCombineApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    self.dicStdSections.setValue(value["ClassID"].stringValue, forKey: value["StandardClass"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    @objc func callGetMarksApi()
    {
        let params = ["ClassID" : self.strClassID!,
                      "TermID" : strTermID,
                      "SubjectID" : strSubID!]
        
        print(params)
        
        arrStudentMarksData = []
        
        Functions.callApi(api: API.getMarksApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayGetData = json!["FinalArray"].array
                
                for (i,value) in arrayGetData!.enumerated() {
                    
                    let smsMarksModal:SMSMarksModel = SMSMarksModel.init(stuName: value["StudentName"].stringValue, grno: value["GRNO"].stringValue, stuId: value["StudentID"].stringValue, smsNo: value["SMSNo"].stringValue, marksId: value["MarkID"].stringValue, marks: value["Mark"].stringValue)
                    
                    self.arrStudentMarksData.append(smsMarksModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMarksApi()
                })
            }
            self.btnSubmit.isHidden = self.arrStudentMarksData.count > 0 ? false : true
            self.checkBtnStatus()
            self.tblStudentMarks.reloadData()
        }
    }
    
    func callSentMessageApi()
    {
        let params = ["TermID" : strTermID,
                      "ClassID" : strClassID!,
                      "SubjectID" : strSubID!,
                      "SubjectName" : strSub!,
                      "StuIDMobile" : arrSelectedIds.joined(separator: ",")]
        
        print(params)
        
        Functions.callApi(api: API.sendStudentMarksSMSApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(false, Message.msgSentSuccess)
                
                strTermID = "3"
                self.strTerm = (self.dicTerms as NSDictionary).allKeys(for: strTermID).first as! String
                arrSelectedIds = []
                
                // 1,2
                for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                    let dropDown:UIDropDown = view as! UIDropDown
                    dropDown.removeFromSuperview()
                }
                self.addDropDown()
                self.callGetSubjectApi(completion: { (success) in
                    self.addSubjectDropDown()
                    self.callGetMarksApi()
                })
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSentMessageApi()
                })
            }
        }
    }
    
    // MARK: Api Calling
    
    @objc func callGetSubjectApi(completion:@escaping (Bool) -> Void)
    {
        dicSubjects = [:]
        
        let params = ["TermId" : strTermID,
                      "StaffID" : "0",
                      "ClassID" : strClassID!]
        
        Functions.callApi(api: API.getTestForMarksApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arraySubjects = json!["FinalArray"].array
                
                for value in arraySubjects! {
                    self.dicSubjects.setValue(value["SubjectID"].stringValue, forKey: value["SubjectName"].stringValue)
                }
                self.arrSubjects = self.dicSubjects.sortedDictionary(self.dicSubjects).0
                completion(true)
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetSubjectApi(completion: { (_ ) in
                            self.addSubjectDropDown()
                        })
                    })
                }
            }
        }
    }
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 2:
                    self.addStandardSectionDropDown(view)
                default:
                    break
                }
                i += 1
                
            }else if(view.tag == i) {
                self.addTermDropDown(view)
                i += 1
            }
        }
    }
    
    func addStandardSectionDropDown(_ subView:UIView)
    {
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.tag = subView.tag
        
        arrSections = self.dicStdSections.sortedDictionary(self.dicStdSections).0
        
        dropDown.options = arrSections
        dropDown.tableHeight = arrSections.count > 5 ? CGFloat(5 * 35) : CGFloat(arrSections.count * 35)
        
        strClass = arrSections[0]
        strClassID = self.dicStdSections.value(forKey: strClass) as? String
        dropDown.title.text = strClass
        dropDown.selectedIndex = 0
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strClass = self.arrSections[index]
            self.strClassID = self.dicStdSections.value(forKey: self.strClass) as? String
            self.callGetSubjectApi(completion: { (_) in
                self.addSubjectDropDown()
            })
        }
        view.addSubview(dropDown)
    }
    
    func addSubjectDropDown()
    {
        self.removeDropDown(3)
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(3)!.frame)
        dropDown.placeholder = Constants.dropDownPlaceholder
        
        if(dicSubjects.count > 0)
        {
            self.strSubID = dicSubjects.value(forKey: self.arrSubjects[0]) as! String
            self.strSub = self.arrSubjects[0]
            dropDown.options = self.arrSubjects
            dropDown.tableHeight = self.arrSubjects.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrSubjects .count * 35)
            dropDown.selectedIndex = 0
            dropDown.title.text = self.arrSubjects[0]
        }
        else
        {
            dropDown.options = []
            self.strSubID = nil
            self.strSub = nil
            dropDown.tableHeight  = 0
        }
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strSub = option
            self.strSubID = self.dicSubjects.value(forKey: option) as! String
        }
        self.view.addSubview(dropDown)
    }
    
    func removeDropDown(_ tag:Int)
    {
        for dropDown in (self.view.subviews.flatMap{ $0 as? UIDropDown}) {
            if(dropDown.tag == tag){
                if(dropDown.table != nil){
                    dropDown.hideTable()
                }
                view.removeFromSuperview()
            }
        }
    }
    
    @IBAction func btnSearchSubmitAction(_ sender:UIButton)
    {
        if sender.tag == 10 {
            self.callGetMarksApi()
        }else{
            self.callSentMessageApi()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StudentMarksSMSVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        UIView.animate(withDuration: 0.5) {
            self.tblStudentMarks.frame.origin.y = 250
            self.tblStudentMarks.setContentOffset(CGPoint(x: 0, y:((textField.superview?.superview?.superview?.frame.origin.y)!-40)), animated: true)
        }
        activateField = textField
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(range.location > 9){
            return false
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if((textField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }else {
            textField.resignFirstResponder()
            self.view.endEditing(true)
            UIView.animate(withDuration: 0.5) {
                self.tblStudentMarks.reloadData()
                self.tblStudentMarks.contentOffset = .zero
            }
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        let smsMarksModel:SMSMarksModel = self.arrStudentMarksData[textField.tag]
        
        if(arrSelectedIds.contains("\(smsMarksModel.StudentID!)|\(smsMarksModel.SMSNo!)|\(smsMarksModel.Marks!)")) {
            let index:NSInteger = arrSelectedIds.index(of: "\(smsMarksModel.StudentID!)|\(smsMarksModel.SMSNo!)|\(smsMarksModel.Marks!)")!
            arrSelectedIds[index] = "\(smsMarksModel.StudentID!)|\(textField.text!)"
        }
        smsMarksModel.SMSNo = textField.text
        
        self.arrStudentMarksData[textField.tag] = smsMarksModel
        self.tblStudentMarks.reloadRows(at: [IndexPath.init(row:textField.tag, section: 0)], with: .automatic)
    }
    
    override func dismissPicker() {
        
        activateField.resignFirstResponder()
        self.view.endEditing(true)
        UIView.animate(withDuration: 0.5) {
            self.tblStudentMarks.reloadData()
            self.tblStudentMarks.contentOffset = .zero
        }
        
        if((activateField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }
    }
}

extension StudentMarksSMSVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:SMSCell = tableView.dequeueReusableCell(withIdentifier: "MarkSMSHeaderCell") as! SMSCell
        
        for view in headerView.contentView.subviews[0].subviews {
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    checkBox.setOn(false, animated: true)
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    
                    if(isOn){
                        self.selectedCheckBoxFlag = checkBox.tag
                        
                        for value in self.arrStudentMarksData {
                            arrSelectedIds.append("\(value.StudentID!)|\(value.SMSNo!)|\(value.Marks!)")
                        }
                    }else{
                        self.selectedCheckBoxFlag = 0
                        arrSelectedIds = []
                    }
                    self.checkBtnStatus()
                    checkBox.setOn(isOn, animated: true)
                    tableView.reloadData()
                }
            }else if(view.isKind(of: UILabel.classForCoder())){
                (view as! UILabel).font = FontType.mediumFont
            }
        }
        return self.arrStudentMarksData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return self.arrStudentMarksData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrStudentMarksData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SMSCell = tableView.dequeueReusableCell(withIdentifier: "MarkSMSCell", for: indexPath) as! SMSCell
        
        let smsMarksModel:SMSMarksModel = self.arrStudentMarksData[indexPath.row]
        cell.displayStudentMarksSMSData(smsMarksModel)
        
        for view in cell.contentView.subviews[0].subviews {
            
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    if(arrSelectedIds.contains("\(smsMarksModel.StudentID!)|\(smsMarksModel.SMSNo!)|\(smsMarksModel.Marks!)")) {
                        checkBox.setOn(true, animated: true)
                    }else {
                        checkBox.setOn(false, animated: true)
                    }
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    checkBox.setOn(isOn, animated: true)
                    if(self.selectedCheckBoxFlag == checkBox.tag) {
                        self.selectedCheckBoxFlag = 0
                        self.tblStudentMarks.reloadSections(IndexSet(integersIn: 0...0), with: .automatic)
                    }
                    
                    if(checkBox.isOn()) {
                        arrSelectedIds.append("\(smsMarksModel.StudentID!)|\(smsMarksModel.SMSNo!)|\(smsMarksModel.Marks!)")
                    }
                    else {
                        arrSelectedIds.remove(at: arrSelectedIds.index(of: "\(smsMarksModel.StudentID!)|\(smsMarksModel.SMSNo!)|\(smsMarksModel.Marks!)")!)
                    }
                    
                    self.tblStudentMarks.reloadRows(at: [IndexPath.init(row: indexPath.row, section: 0)], with: .automatic)
                    self.checkBtnStatus()
                }
            }else if(view.isKind(of: UITextField.classForCoder())){
                (view as! UITextField).font = FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
                (view as! UITextField).inputAccessoryView = addToolbar()
                view.tag = indexPath.row
            }else{
                (view as! UILabel).font = FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
            }
        }
        return cell
    }
    
    func checkBtnStatus()
    {
        btnSubmit.isEnabled = arrSelectedIds.count > 0 ? true : false
        btnSubmit.alpha = btnSubmit.isEnabled ? 1.0 : 0.5
    }
}

