//
//  SMSPopupVC.swift
//  Skool360Admin
//
//  Created by ADMS on 28/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

var arrSelectedIds:[String] = []

class SMSPopupVC: UIViewController {
    
    var strDate:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.initialize()
    }
    
    func initialize()
    {
        strDate = btnDate == nil ?  Date().toString(dateFormat: "dd/MM/yyyy") : (btnDate.titleLabel?.text)!
        (self.view.subviews[0].subviews[0].subviews[0] as!  UIButton).setTitle(strDate, for: .normal)
        (self.view.subviews[0].subviews[0].subviews[0] as! UIButton).titleLabel?.font = FontType.regularFont
        (self.view.subviews[0].subviews[0].subviews[1] as! UITextView).text = "Message"
        (self.view.subviews[0].subviews[0].subviews[1] as! UITextView).textColor = UIColor.gray.withAlphaComponent(0.5)
    }
    
    @IBAction func btnSendClosedAction(_ sender:UIButton)
    {
        if sender.tag == 10 {
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
        }else if sender.tag == 20 {
            self.initialize()
        }else{
            let txtView:UITextView = self.view.subviews[0].subviews[0].subviews[1] as! UITextView
            if(txtView.text.count > 0 && txtView.textColor == .black){
                self.view.endEditing(true)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.callSentMessageApi(txtView.text)
                }
            }else{
                Functions.showAlert(false, Message.msgError)
            }
        }
    }
    
    func callSentMessageApi(_ txtMsg:String)
    {
        let params = ["SMS" : txtMsg,
                      "Date" : strDate!,
                      "MobileNo" : arrSelectedIds.joined(separator: ",")]
        
        print(params)
        
        var strWebApi:String!
        switch self.title! {
        case "Bulk SMS":
            strWebApi = API.insertBulkSMSDataApi
        case "Employee SMS":
            strWebApi = API.insertStaffSMSDataApi
        case "Student Transport":
            strWebApi = API.sendSMSApi
        default:
            strWebApi = API.insertAbsentTodaySMSApi
        }
        
        Functions.callApi(api: strWebApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(false, Message.msgSentSuccess)
                self.view.removeFromSuperview()
                self.removeFromParentViewController()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSentMessageApi(txtMsg)
                })
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SMSPopupVC:UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        if(textView.text == "Message"){
            textView.text = nil
            textView.textColor = .black 
        }
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(text == "\n") {
            if(textView.text.count == 0){
                textView.text = "Message"
                textView.textColor = UIColor.gray.withAlphaComponent(0.5)
            }
            textView.resignFirstResponder()
            return false
        }
        return true
    }
}
