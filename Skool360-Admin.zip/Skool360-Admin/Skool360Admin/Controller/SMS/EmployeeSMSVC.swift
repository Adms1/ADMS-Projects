//
//  SMS.swift
//  Skool360Admin
//
//  Created by ADMS on 28/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class EmployeeSMSVC: CustomViewController {
    
    @IBOutlet var tblEmployeeSMS:UITableView!
    @IBOutlet var btnSubmit:UIButton!
    
    var arrEmployeeSMSData = [SMSModel]()
    var selectedCheckBoxFlag = 0
    var activateField:UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetEmployeeSMSDataApi()
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    func callGetEmployeeSMSDataApi()
    {
        arrEmployeeSMSData = []
        
        Functions.callApi(api: API.getStaffSMSDataApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayGetData = json!["FinalArray"].array
                
                for (i,value) in arrayGetData!.enumerated() {
                    
                    let smsModal:SMSModel = SMSModel.init(index: "\(i+1)", empName: value["EmpName"].stringValue, empId: value["PK_EmployeeID"].stringValue, empMobile: value["Emp_MobileNo"].stringValue)
                    
                    self.arrEmployeeSMSData.append(smsModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetEmployeeSMSDataApi()
                })
            }
            self.btnSubmit.isHidden = self.arrEmployeeSMSData.count > 0 ? false : true
            self.checkBtnStatus()
            self.tblEmployeeSMS.reloadData()
        }
    }
    
    @IBAction func btnSubmitAction(_ sender:UIButton)
    {
        add(asChildViewController: smsPopupVC)
    }
    
    private lazy var smsPopupVC: SMSPopupVC = {
        
        var viewController:SMSPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "SMSPopupVC") as! SMSPopupVC
        viewController.title = self.title!
        self.add(asChildViewController: viewController)
        return viewController
    }()
    
    private func add(asChildViewController viewController: UIViewController) {
        
        addChildViewController(viewController)
        view.addSubview(viewController.view)
        viewController.view.frame = view.bounds
        viewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        viewController.didMove(toParentViewController: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension EmployeeSMSVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        UIView.animate(withDuration: 0.5) {
            self.tblEmployeeSMS.setContentOffset(CGPoint(x: 0, y:((textField.superview?.superview?.superview?.frame.origin.y)!-40)), animated: true)
        }
        activateField = textField
        //textField.becomeFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(range.location > 9){
            return false
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        activateField.resignFirstResponder()
        self.view.endEditing(true)
        UIView.animate(withDuration: 0.5) {
            self.tblEmployeeSMS.contentOffset = .zero
        }
        
        if((activateField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        let smsModal:SMSModel = self.arrEmployeeSMSData[textField.tag]
        
        if(arrSelectedIds.contains("\(smsModal.EmployeeID!)|\(smsModal.SMSNo!)")) {
            let index:NSInteger = arrSelectedIds.index(of: "\(smsModal.EmployeeID!)|\(smsModal.SMSNo!)")!
            arrSelectedIds[index] = "\(smsModal.EmployeeID!)|\(textField.text!)"
        }
        smsModal.SMSNo = textField.text
        
        self.arrEmployeeSMSData[textField.tag] = smsModal
        self.tblEmployeeSMS.reloadRows(at: [IndexPath.init(row:textField.tag, section: 0)], with: .automatic)
    }
    
    override func dismissPicker() {
        
        activateField.resignFirstResponder()
        self.view.endEditing(true)
        UIView.animate(withDuration: 0.5) {
            self.tblEmployeeSMS.contentOffset = .zero
        }
        
        if((activateField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }
    }
}

extension EmployeeSMSVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSEmployeeHeaderCell") as! SMSCell
        
        for view in headerView.contentView.subviews[0].subviews {
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    checkBox.setOn(false, animated: true)
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    
                    if(isOn){
                        self.selectedCheckBoxFlag = checkBox.tag
                        
                        for value in self.arrEmployeeSMSData {
                            arrSelectedIds.append("\(value.EmployeeID!)|\(value.SMSNo!)")
                        }
                    }else{
                        self.selectedCheckBoxFlag = 0
                        arrSelectedIds = []
                    }
                    self.checkBtnStatus()
                    checkBox.setOn(isOn, animated: true)
                    tableView.reloadData()
                }
            }else if(view.isKind(of: UILabel.classForCoder())){
                (view as! UILabel).font = FontType.mediumFont
            }
        }
        return self.arrEmployeeSMSData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return self.arrEmployeeSMSData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrEmployeeSMSData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSEmployeeCell", for: indexPath) as! SMSCell
        
        let smsModal:SMSModel = self.arrEmployeeSMSData[indexPath.row]
        cell.displayEmployeeData(smsModal)
        
        for view in cell.contentView.subviews[0].subviews {
            
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    if(arrSelectedIds.contains("\(smsModal.EmployeeID!)|\(smsModal.SMSNo!)")) {
                        checkBox.setOn(true, animated: true)
                    }else {
                        checkBox.setOn(false, animated: true)
                    }
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    checkBox.setOn(isOn, animated: true)
                    if(self.selectedCheckBoxFlag == checkBox.tag) {
                        self.selectedCheckBoxFlag = 0
                        self.tblEmployeeSMS.reloadSections(IndexSet(integersIn: 0...0), with: .automatic)
                    }
                    
                    if(checkBox.isOn()) {
                        arrSelectedIds.append("\(smsModal.EmployeeID!)|\(smsModal.SMSNo!)")
                    }
                    else {
                        arrSelectedIds.remove(at: arrSelectedIds.index(of: "\(smsModal.EmployeeID!)|\(smsModal.SMSNo!)")!)
                    }
                    
                    self.tblEmployeeSMS.reloadRows(at: [IndexPath.init(row: indexPath.row, section: 0)], with: .automatic)
                    self.checkBtnStatus()
                }
            }else if(view.isKind(of: UITextField.classForCoder())){
                (view as! UITextField).font = FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
                (view as! UITextField).inputAccessoryView = addToolbar()
                view.tag = indexPath.row
            }else{
                (view as! UILabel).font = FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
            }
        }
        return cell
    }
    
    func checkBtnStatus()
    {
        btnSubmit.isEnabled = arrSelectedIds.count > 0 ? true : false
        btnSubmit.alpha = btnSubmit.isEnabled ? 1.0 : 0.5
    }
}

