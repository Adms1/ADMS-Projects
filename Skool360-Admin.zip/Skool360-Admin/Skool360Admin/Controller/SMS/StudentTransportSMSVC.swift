//
//  StudentTransportSMSVC.swift
//  Skool360Admin
//
//  Created by ADMS on 22/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class StudentTransportSMSVC: CustomViewController {
    
    @IBOutlet var tblStudentTransport:UITableView!
    @IBOutlet var btnSubmit:UIButton!
    
    var arrTransportDetails:[String] = []
    var dicRoutesWithIds:NSMutableDictionary = [:]
    var dicPickupPoints:NSMutableDictionary = [:]
    var strRoute:String!
    var strPickupPoint:String!
    var selectedCheckBoxFlag = 0
    var activateField:UITextField!
    
    var arrStudentTransportData = [StudentTransportModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arrSelectedIds = []
        tblStudentTransport.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (success) in
            self.callGetRoutesApi(completion: { (success) in
                self.addDropDown()
                self.callTransportDetailsApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetRoutesApi(completion:@escaping (Bool) -> Void)
    {
        dicRoutes = [:]
        dicPickupPoints = [:]
        dicRoutesWithIds = [:]
        
        Functions.callApi(api: API.getRoutePickUpPointDetail, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayRoutes = json!["FinalArray"].array
                
                for value in arrayRoutes! {
                    
                    let arrPickupPointDetail:[JSON] = value["PickupPointDetail"].array!
                    
                    var arrPickupPoints:[String] = []
                    for subValues in arrPickupPointDetail {
                        arrPickupPoints.append(subValues["PickupPoint"].stringValue)
                        self.dicPickupPoints.setValue(subValues["PickupPointID"].stringValue, forKey: subValues["PickupPoint"].stringValue)
                    }
                    self.dicRoutes.setValue(arrPickupPoints, forKey: value["Route"].stringValue)
                    self.dicRoutesWithIds.setValue(value["RouteID"].stringValue, forKey: value["Route"].stringValue)
                    
                    self.arrRoutes = (self.dicRoutes.allKeys as! [String]).sorted {
                        (s1, s2) -> Bool in return s1.localizedStandardCompare(s2) == .orderedAscending
                    }
                    self.strRoute = self.arrRoutes[0]
                    
                    for key in self.arrRoutes {
                        for item in self.dicRoutes[key] as! [String] {
                            self.arrTransportDetails.append(item)
                        }
                    }
                    let sortedKeys = self.arrTransportDetails.sorted(by: <)
                    self.strPickupPoint = sortedKeys[0]
                }
                completion(true)
            }
        }
    }
    
    func callTransportDetailsApi()
    {
        let params = ["Term" : strTermID,
                      "RouteID" : self.dicRoutesWithIds[strRoute] as! String,
                      "PickupPoint" : self.dicPickupPoints[strPickupPoint] as! String,
                      "GRNO" : ""]
        
        print(params)
        
        self.arrStudentTransportData = []
        selectedIndex = -1
        
        Functions.callApi(api: API.studentTransportDetailApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrGetData = json!["FinalArray"].array
                
                for value in arrGetData! {
                    self.arrStudentTransportData.append(StudentTransportModal(StudentName: value["StudentName"].stringValue, GRNO: value["GRNO"].stringValue, Grade: value["Standard"].stringValue, RouteName: value["RouteName"].stringValue, PickupPointName: value["PickupPointName"].stringValue, KM: value["KM"].stringValue, StudentID: value["StudentID"].stringValue, SMSMobileNo: value["SMSNo"].stringValue))
                }
                self.btnSubmit.isHidden = self.arrStudentTransportData.count > 0 ? false : true
                self.checkBtnStatus()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callTransportDetailsApi()
                })
            }
            self.tblStudentTransport.reloadData()
        }
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 2:
                    self.addRouteDropDown()
                    
                default:
                    self.addPickupPointDropDown()
                }
                i += 1
            }else if(view.tag == i) {
                self.addTermDropDown(view)
                i += 1
            }
        }
    }
    
    func addRouteDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(2)?.frame)!)
        dropDown.options = self.arrRoutes
        dropDown.tableHeight = self.arrRoutes.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrRoutes.count * 35)
        dropDown.selectedIndex = self.arrRoutes.index(of: strRoute)
        dropDown.title.text = strRoute
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strRoute = option
            self.addPickupPointDropDown()
        }
        self.view.addSubview(dropDown)
    }
    
    func addPickupPointDropDown()
    {
        self.arrTransportDetails = []
        let strValue:String = strPickupPoint
        
        var dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(3)?.frame)!)
        dropDown.placeholder = Constants.dropDownPlaceholder
        dropDown.tableHeight = 0.0
        dropDown.tag = 30
        
        for key in self.arrRoutes {
            for item in dicRoutes[key] as! [String] {
                self.arrTransportDetails.append(item)
            }
        }
        
        let sortedKeys = self.arrTransportDetails.sorted(by: <)
        if(sortedKeys.count > 0){
            for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                if(view.tag == 30){
                    dropDown = view as! UIDropDown
                }
            }
            
            dropDown.options = sortedKeys
            dropDown.tableHeight = sortedKeys.count > 5 ? CGFloat(5 * 35) : CGFloat(sortedKeys.count * 35)
            dropDown.selectedIndex = sortedKeys.index(of: strValue)
            dropDown.title.text = strValue
            
            dropDown.didSelect { (option, index) in
                dropDown.hideTable()
                self.strPickupPoint = option
            }
        }
        
        for dd in (self.view.subviews.flatMap{$0 as? UIDropDown}) {
            if(dd.tag == 30){
                return
            }
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.view.endEditing(true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.callTransportDetailsApi()
        }
    }
    
    @IBAction func btnSubmitAction(_ sender:UIButton)
    {
        add(asChildViewController: smsPopupVC)
    }
    
    private lazy var smsPopupVC: SMSPopupVC = {
        
        var viewController:SMSPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "SMSPopupVC") as! SMSPopupVC
        viewController.title = self.title!
        self.add(asChildViewController: viewController)
        return viewController
    }()
    
    private func add(asChildViewController viewController: UIViewController) {
        
        addChildViewController(viewController)
        view.addSubview(viewController.view)
        viewController.view.frame = view.bounds
        viewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        viewController.didMove(toParentViewController: self)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StudentTransportSMSVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        UIView.animate(withDuration: 0.5) {
            self.tblStudentTransport.frame.origin.y = 250
            self.tblStudentTransport.setContentOffset(CGPoint(x: 0, y:((textField.superview?.superview?.superview?.frame.origin.y)!-40)), animated: true)
        }
        activateField = textField
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(range.location > 9){
            return false
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if((textField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }else {
            textField.resignFirstResponder()
            self.view.endEditing(true)
            UIView.animate(withDuration: 0.5) {
                self.tblStudentTransport.reloadData()
                self.tblStudentTransport.contentOffset = .zero
            }
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        var studentTransportModal:StudentTransportModal = self.arrStudentTransportData[textField.tag]
        
        if(arrSelectedIds.contains("\(studentTransportModal.StudentID!)|\(studentTransportModal.SMSMobileNo!)")) {
            let index:NSInteger = arrSelectedIds.index(of: "\(studentTransportModal.StudentID!)|\(studentTransportModal.SMSMobileNo!)")!
            arrSelectedIds[index] = "\(studentTransportModal.StudentID!)|\(textField.text!)"
        }
        studentTransportModal.SMSMobileNo = textField.text
        
        self.arrStudentTransportData[textField.tag] = studentTransportModal
        self.tblStudentTransport.reloadRows(at: [IndexPath.init(row:textField.tag, section: 0)], with: .automatic)
    }
    
    override func dismissPicker() {
        
        activateField.resignFirstResponder()
        self.view.endEditing(true)
        UIView.animate(withDuration: 0.5) {
            self.tblStudentTransport.reloadData()
            self.tblStudentTransport.contentOffset = .zero
        }
        
        if((activateField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }
    }
}

extension StudentTransportSMSVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSHeaderCell") as! SMSCell
        
        for view in headerView.contentView.subviews[0].subviews {
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    checkBox.setOn(false, animated: true)
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    
                    if(isOn){
                        self.selectedCheckBoxFlag = checkBox.tag
                        
                        for value in self.arrStudentTransportData {
                            arrSelectedIds.append("\(value.StudentID!)|\(value.SMSMobileNo!)")
                        }
                    }else{
                        self.selectedCheckBoxFlag = 0
                        arrSelectedIds = []
                    }
                    self.checkBtnStatus()
                    checkBox.setOn(isOn, animated: true)
                    tableView.reloadData()
                }
            }else if(view.isKind(of: UILabel.classForCoder())){
                (view as! UILabel).font = FontHelper.medium(size: DeviceType.isIpad ? 15 : 11)
            }
        }
        return self.arrStudentTransportData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return self.arrStudentTransportData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrStudentTransportData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSCell", for: indexPath) as! SMSCell
        
        let studentTransportModal:StudentTransportModal = self.arrStudentTransportData[indexPath.row]
        cell.displayStudentTransportData(studentTransportModal, indexPath.row+1)
        
        for view in cell.contentView.subviews[0].subviews {
            
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    if(arrSelectedIds.contains("\(studentTransportModal.StudentID!)|\(studentTransportModal.SMSMobileNo!)")) {
                        checkBox.setOn(true, animated: true)
                    }else {
                        checkBox.setOn(false, animated: true)
                    }
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    checkBox.setOn(isOn, animated: true)
                    if(self.selectedCheckBoxFlag == checkBox.tag) {
                        self.selectedCheckBoxFlag = 0
                        self.tblStudentTransport.reloadSections(IndexSet(integersIn: 0...0), with: .automatic)
                    }
                    
                    if(checkBox.isOn()) {
                        arrSelectedIds.append("\(studentTransportModal.StudentID!)|\(studentTransportModal.SMSMobileNo!)")
                    }
                    else {
                        arrSelectedIds.remove(at: arrSelectedIds.index(of: "\(studentTransportModal.StudentID!)|\(studentTransportModal.SMSMobileNo!)")!)
                    }
                    
                    self.tblStudentTransport.reloadRows(at: [IndexPath.init(row: indexPath.row, section: 0)], with: .automatic)
                    self.checkBtnStatus()
                }
            }else if(view.isKind(of: UITextField.classForCoder())){
                (view as! UITextField).font = FontHelper.regular(size: DeviceType.isIpad ? 15 : 11)
                (view as! UITextField).inputAccessoryView = addToolbar()
                view.tag = indexPath.row
            }else{
                (view as! UILabel).font = FontHelper.regular(size: DeviceType.isIpad ? 15 : 11)
            }
        }
        return cell
    }
    
    func checkBtnStatus()
    {
        btnSubmit.isEnabled = arrSelectedIds.count > 0 ? true : false
        btnSubmit.alpha = btnSubmit.isEnabled ? 1.0 : 0.5
    }
}
