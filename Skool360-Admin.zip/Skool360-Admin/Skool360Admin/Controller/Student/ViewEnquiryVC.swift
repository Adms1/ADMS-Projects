//
//  ViewEnquiryVC.swift
//  Skool360Admin
//
//  Created by ADMS on 30/01/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class ViewEnquiryVC: CustomViewController {
    
    @IBOutlet var tblEnquiry:UITableView!
    
    var arrEnquiryData = [EnquiryModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var i = 20
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 2){
                    strStatusMode = -1
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
                
            } else if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.getEnquiryCount),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (success) in
            self.getEnquiryCount()
            self.addDropDown()
            self.callSearchEnquiryApi()
        }
    }
    
    // MARK: Api Calling
    
    @objc func getEnquiryCount()
    {
        Functions.callApi(api: API.getEnquiryCountApi, params: ["TermId" : strTermID]) { (json,error) in
            
            if(json != nil){
                
                let arrayCount = json!["FinalArray"].array
                
                for (i,value) in arrayCount!.enumerated() {
                    (self.view.viewWithTag(i+200) as! UILabel).text = value["Total"].stringValue
                }
            }
        }
    }
    
    func callSearchEnquiryApi()
    {
        arrEnquiryData = []
        selectedIndex = -1
        
        let params = ["TermID" : strTermID,
                      "stdt" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "enddt" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!,
                      "status" : strStatus,
                      "onlineStatus" : strStatusMode == -1 ? "All" : "\(strStatusMode)"]
        
        print(params)
        
        Functions.callApi(api: API.getEnquiryDataApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrEnquiryData = json!["FinalArray"].array!
                
                for (i,value) in arrEnquiryData.enumerated() {
                    
                    let arrSubValue:[JSON] = value["Staus Detail"].array!
                    
                    var arrStatus = [EnquiryModel]()
                    arrStatus.append(EnquiryModel.init(status: "Status", date: "Date"))
                    
                    for subValue in arrSubValue {
                        
                        let EnquiryStatusModal:EnquiryModel = EnquiryModel.init(status: subValue["Status"].stringValue, date: subValue["Date"].stringValue.getDate())
                        
                        arrStatus.append(EnquiryStatusModal)
                    }
                    let EnquiryModal:EnquiryModel = EnquiryModel.init(index: "\(i+1)", stuName: value["Name"].stringValue, stuId: value["StudentID"].stringValue, grade: value["Grade"].stringValue, gender: value["Gender"].stringValue, status: value["Current Status"].stringValue, arrStatusData: arrStatus)
                    
                    self.arrEnquiryData.append(EnquiryModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSearchEnquiryApi()
                })
            }
            self.tblEnquiry.reloadData()
        }
    }
    
    
    // MARK: Function for Choose Options for Term
    
    func addDropDown()
    {
        var i = 100
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 100:
                    self.addTermDropDown(view)
                    
                default:
                    self.addSelectOptionDropDown()
                }
                i += 1
            }
        }
    }
    
    func addSelectOptionDropDown()
    {
        strStatus = "All"
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(101)!.frame)
        dropDown.options = dicData[self.title!] as! [String]
        dropDown.tableHeight = CGFloat(5 * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = strStatus
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strStatus = (self.dicData["\(self.title!) - Value"] as! [String])[index]
        }
        self.view.addSubview(dropDown)
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 4 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = view.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        strStatusMode = tag-3
    }
    
    @IBAction func btnEnquirySearchAction(_ sender:UIButton)
    {
        self.callSearchEnquiryApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewEnquiryVC:UITableViewDataSource,UITableViewDelegate,CustomCellDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:EnquiryCell = tableView.dequeueReusableCell(withIdentifier: "EnquiryHeaderCell") as! EnquiryCell
        
        headerView.lblView.superview?.addShadowWithRadius(2.0, 0, 0)
        
        if section == selectedIndex {
            headerView.lblView.textColor = GetColor.green
        }else{
            headerView.lblView.textColor = .red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblView.tag = section
        headerView.lblView.addGestureRecognizer(tapGesture)
        
        headerView.displayEnquiryHeaderData(arrEnquiryData[section])
        
        return arrEnquiryData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrEnquiryData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? 110 : 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrEnquiryData[section].StatusData.count > 0 ? arrEnquiryData[section].StatusData.count + 1: 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == selectedIndex ? DeviceType.isIpad ? 45 : 40.0 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String = "EnquiryCell"
        if(indexPath.row == arrEnquiryData[indexPath.section].StatusData.count){
            strIdentifier = "EnquiryFooterCell"
        }
        
        let cell:EnquiryCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! EnquiryCell
        
        if(indexPath.row < arrEnquiryData[indexPath.section].StatusData.count)
        {
            for view in cell.contentView.subviews[0].subviews{
                if(view.isKind(of: UIImageView.classForCoder())) {
                    let imgView:UIImageView = view as! UIImageView
                    indexPath.row > 0 ? imgView.image = UIImage.init(named: "") : imgView.loadIconsFromLocal("BlueBox")
                }else{
                    let lbl:UILabel = view as! UILabel
                    lbl.textColor = indexPath.row > 0 ? .black : .white
                    lbl.font = indexPath.row == 0 ? FontHelper.medium(size:  DeviceType.isIpad ? 16 : 13) : FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
                }
            }
            cell.displayEnquiryData(arrEnquiryData[indexPath.section].StatusData[indexPath.row])
        }
        else {
            cell.delegate = self
            cell.contentView.subviews[0].subviews[1].tag = indexPath.section
        }
        return cell
    }
    
    func performAction(_ sender:UIButton)
    {
        let vc:StudentDetailVC = Constants.storyBoard.instantiateViewController(withIdentifier: "StudentDetailVC") as! StudentDetailVC
        vc.strStudentID = arrEnquiryData[sender.tag].StudentID
        vc.title = "Student Profile"
        self.navigationController?.pushPopTransition(vc,true)
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblEnquiry.reloadData()
        tblEnquiry.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
    }
}
