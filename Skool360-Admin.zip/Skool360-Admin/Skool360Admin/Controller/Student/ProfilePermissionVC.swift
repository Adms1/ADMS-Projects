//
//  ProfilePermissionVC.swift
//  Skool360Admin
//
//  Created by ADMS on 24/01/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class ProfilePermissionVC: CustomViewController {
    
    @IBOutlet var tblProfilePermission:UITableView!
    
    var arrProfileDetails = [PermissionModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var i = 10
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 2){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.addDropDown()
                self.callGetProfilePermissionApi()
            })
        }
    }
    
    
    // MARK: Api Calling
    
    func callGetProfilePermissionApi()
    {
        self.arrProfileDetails = []
        
        Functions.callApi(api: API.getStudentProfilePermissionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for value in arrData! {
                    let profilePermissionModal:PermissionModel = PermissionModel.init(standard: value["Standard"].stringValue,cls: value["Class"].stringValue, status: value["Status"].stringValue)
                    
                    self.arrProfileDetails.append(profilePermissionModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetProfilePermissionApi()
                })
            }
            self.tblProfilePermission.reloadData()
        }
    }
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    func callInsertProfilePermissionApi()
    {
        let params = ["GradeID" : strStdID!,
                      "SectionID" : strClassID!,
                      "Status" : "\(strStatusMode)"]
        
        print(params)
        
        Functions.callApi(api: API.insertProfilePermissionApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(true, Message.recordInsert)
                self.resetData()
                self.callGetProfilePermissionApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertProfilePermissionApi()
                })
            }
        }
    }
    
    func resetData()
    {
        strStd = self.arrStandards[0]
        strStdID = self.dicStandards.value(forKey: strStd) as! String
        let dict:NSMutableDictionary = self.dicStdSections[strStd] as! NSMutableDictionary
        arrSections = dict.sortedDictionary(dict).0
        strClassID = (self.dicStdSections[strStd] as! NSMutableDictionary)[arrSections[0]] as? String
        
        // 1,2
        for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dropDown:UIDropDown = view as! UIDropDown
            
            var strValue:String!
            switch(dropDown.tag)
            {
            case 100:
                strValue = strStd
                
            case 1000:
                
                let dict:NSMutableDictionary = self.dicStdSections[strStd] as! NSMutableDictionary
                arrSections = dict.sortedDictionary(dict).0
                dropDown.options = arrSections
                dropDown.tableHeight = arrSections.count > 5 ? CGFloat(5 * 35) : CGFloat(arrSections.count * 35)
                
                strValue = arrSections[0]
                
            default:
                break
            }
            
            dropDown.selectedIndex = 0
            dropDown.title.text = strValue
        }
        
        self.resetRadioButton(.active)
    }
    
    func resetRadioButton(_ mode:StatusMode)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        strStatusMode = mode == .active ? 1 : 0
        let radioButton:LTHRadioButton = view.viewWithTag(strStatusMode+1) as! LTHRadioButton
        radioButton.select(animated: true)
    }
    
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 100
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 100:
                    self.addStandardDropDown(view)
                    
                default:
                    self.addSectionDropDown(101)
                }
                i += 1
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = view.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        strStatusMode = tag-1
    }
    
    @IBAction func btnSubmitAction(_ sender:UIButton)
    {
        self.callInsertProfilePermissionApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ProfilePermissionVC:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:PermissionCell = tableView.dequeueReusableCell(withIdentifier: "ProfilePermissionHeaderCell") as! PermissionCell
        
        return arrProfileDetails.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrProfileDetails.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrProfileDetails.count > 0 ? arrProfileDetails.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:PermissionCell = tableView.dequeueReusableCell(withIdentifier: "ProfilePermissionCell", for: indexPath) as! PermissionCell
        
        cell.displayProfileData(arrProfileDetails[indexPath.row])
        return cell
    }
}
