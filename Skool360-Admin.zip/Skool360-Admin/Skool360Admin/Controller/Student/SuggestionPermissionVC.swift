//
//  SuggestionPermissionVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 20/09/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

import UIKit
import UIDropDown

class SuggestionPermissionVC: CustomViewController {
    
    @IBOutlet var tblSuggestionPermission:UITableView!
    
    var arrSuggestionDetails = [PermissionModel]()
    var dictEmployee:[String:String] = [:]
    var strSelectedType:String!
    var arrEmployeeIds:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetEmployeeForSuggestionPermissionApi {
            self.addDropDown()
            self.callGetSuggestionPermissionApi()
        }
    }
    
    // MARK: Api Calling
    
    func callGetEmployeeForSuggestionPermissionApi(completion:@escaping () -> ())
    {
        self.dictEmployee = [:]
        
        Functions.callApi(api: API.getGetEmployeeForSuggestionPermissionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for value in arrData! {
                    self.dictEmployee[value["EmployeeName"].stringValue] = value["EmployeeID"].stringValue
                }
                completion()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetEmployeeForSuggestionPermissionApi {}
                })
            }
        }
    }
    
    func callGetSuggestionPermissionApi()
    {
        self.arrSuggestionDetails = []
        
        Functions.callApi(api: API.getGetSuggestionPermissionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (i,value) in arrData!.enumerated() {
                    let suggestionPermissionModal:PermissionModel = PermissionModel.init(index: "\(i+1)", permissionId: value["AssignPermissionID"].stringValue, type: value["Type"].stringValue, ename: value["EmployeeName"].stringValue, eid: value["EmployeeID"].stringValue)
                    self.arrSuggestionDetails.append(suggestionPermissionModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetSuggestionPermissionApi()
                })
            }
            self.tblSuggestionPermission.reloadData()
        }
    }
    
    func callInsertSuggestionPermissionApi()
    {
        let params = ["Type" : strSelectedType!,
                      "StaffIDs" : arrEmployeeIds.joined(separator: ",")]
        
        print(params)
        
        Functions.callApi(api: API.insertSuggestionPermissionApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(true, Message.recordInsert)
                self.resetData()
                self.callGetSuggestionPermissionApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertSuggestionPermissionApi()
                })
            }
        }
    }
    
    func callDeleteSuggestionPermissionApi(_ index:NSInteger)
    {
        let params = ["AssignPermissionID" : arrSuggestionDetails[index].AssignPermissionID!]
        
        print(params)
        
        Functions.callApi(api: API.deleteSuggestionPermissionApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(true, Message.recordDelete)
                self.resetData()
                self.callGetSuggestionPermissionApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteSuggestionPermissionApi(index)
                })
            }
        }
    }
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTypeDropDown(view)
                    
                default:
                    self.addEmloyeeDropDown(view)
                }
                i += 1
            }
        }
    }
    
    func addTypeDropDown(_ subView:UIView)
    {
        let array:[String] = ["Admin", "Academic", "Other"]
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.placeholder = Constants.dropDownPlaceholder
        dropDown.tag = 100
        dropDown.options = array
        dropDown.tableHeight = 3 * 35
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strSelectedType = array[index]
        }
        view.addSubview(dropDown)
    }
    
    func addEmloyeeDropDown(_ subView:UIView)
    {
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.placeholder = Constants.dropDownPlaceholder
        dropDown.tag = 5000
        dropDown.options = self.dictEmployee.keys.sorted(by: <)
        dropDown.tableHeight = self.dictEmployee.keys.count > 5 ? CGFloat(5 * 35) : CGFloat(self.dictEmployee.keys.count * 35) * 35
        
        dropDown.didSelectMultiple { (options, indexes) in
            self.arrEmployeeIds = []
            for option in options {
                self.arrEmployeeIds.append(self.dictEmployee[option]!)
            }
        }
        view.addSubview(dropDown)
    }
    
    func resetData()
    {
        strSelectedType = nil
        arrEmployeeIds = []
        
        // 1,2
        for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dropDown:UIDropDown = view as! UIDropDown
            dropDown.removeFromSuperview()
        }
        self.addDropDown()
    }
    
    @IBAction func btnSubmitAction(_ sender:UIButton)
    {
        guard strSelectedType != nil else {
            Functions.showAlert(false, Message.selectType)
            return
        }
        
        guard arrEmployeeIds.count > 0 else {
            Functions.showAlert(false, Message.selectEmployee)
            return
        }
        
        self.callInsertSuggestionPermissionApi()
    }
    
    @IBAction func btnDeleteAction(_ sender:UIButton)
    {
        Functions.showCustomAlert("Delete", Message.deleteConfirmation) { (_) in
            self.callDeleteSuggestionPermissionApi(sender.tag)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SuggestionPermissionVC: UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:PermissionCell = tableView.dequeueReusableCell(withIdentifier: "PermissionHeaderCell") as! PermissionCell
        
        return arrSuggestionDetails.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrSuggestionDetails.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSuggestionDetails.count > 0 ? arrSuggestionDetails.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:PermissionCell = tableView.dequeueReusableCell(withIdentifier: "PermissionCell", for: indexPath) as! PermissionCell
        cell.displaySuggestionData(arrSuggestionDetails[indexPath.row])
        cell.contentView.subviews[0].subviews.last?.tag = indexPath.row
        return cell
    }
}
