//
//  CircularVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 01/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import MobileCoreServices
import Alamofire
import UIDropDown

var selectedCircularModel:AnnoucementModel!
class CircularVC: CustomViewController {
    
    @IBOutlet var scrollView:UIScrollView!
    @IBOutlet var collectionGrade:UICollectionView!
    @IBOutlet var btnAddUpdate:UIButton!
    @IBOutlet var collectionHeight:NSLayoutConstraint!
    
    @IBOutlet var txtSubject:UITextField!
    @IBOutlet var btnCreateDate:UIButton!
    
    @IBOutlet var descriptionView:UITextView!
    @IBOutlet var descriptionHeight:NSLayoutConstraint!
    @IBOutlet var btnChooseFile:UIButton!
    @IBOutlet var lblSubTitle:UILabel!
    @IBOutlet var scheduleCheck:VKCheckbox!
    @IBOutlet var scheduleView:UIView!
    @IBOutlet var scheduleHeight:NSLayoutConstraint!
    @IBOutlet var btnScheduleDate:UIButton!
    @IBOutlet var lblPdfInfo:UILabel!
    
    var arrStdSelectedIds:[String] = []
    var strType:Int = 1
    var strSendTo:String = "Y"
    var strPdfUrl:URL!
    var isOpen:Bool = false
    var strHour:String = "00"
    var strMin:String = "00"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var i = 10
        for view in scrollView.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag % 2 != 0){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
        
        scheduleCheck.line             = .normal
        scheduleCheck.bgColorSelected  = GetColor.blue
        scheduleCheck.color            = .white
        scheduleCheck.borderColor      = GetColor.blue
        scheduleCheck.borderWidth      = 1.0
        scheduleCheck.cornerRadius     = 5.0
        
        scheduleCheck.checkboxValueChangedBlock = { isOn in
            self.scheduleCheck.setOn(isOn, animated: true)
            self.scheduleView.isHidden = !self.scheduleCheck.isOn()
            self.scheduleHeight.constant = self.scheduleCheck.isOn() ? 95 : 0
            if isOn {
                for i in 1000...1001 {
                    self.addDropDown(self.scrollView.viewWithTag(i)!)
                }
            }else{
                self.clearData()
            }
        }
        self.resetData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(isOpen) {
            isOpen = false
            return
        }
        self.arrStandards = []
        self.callGetTermApi(true) { (success) in
            let height:CGFloat = CGFloat((self.arrStandards.count/(DeviceType.isIpad ? 5 : 3)) + (self.arrStandards.count%(DeviceType.isIpad ? 5 : 3) != 0 ? 1 : 0)) * 30
            self.collectionHeight.constant = height
            self.view.layoutIfNeeded()
            self.resetData()
        }
    }
    
    func resetData()
    {
        if(selectedCircularModel != nil) {
            btnCreateDate.setTitle(selectedCircularModel.strCreateDate, for: .normal)
            btnScheduleDate.setTitle(selectedCircularModel.strScheduleDate, for: .normal)
            btnAddUpdate.setTitle(ButtonType.update.rawValue, for: .normal)
            strType = selectedCircularModel.strPDF == "" ? 1 : 2
            strSendTo = selectedCircularModel.strGradeStatus == "All" ? "Y" : "N"
            strStatusMode = selectedCircularModel.strStatus == "Yes" ? 5 : 6
            if(strType == 2) {
                self.strPdfUrl = URL.init(string: API.hostName + selectedCircularModel.strPDF)
                lblPdfInfo.text = "\(Date().toMillis()!).pdf"
            }
            self.scheduleCheck.setOn(selectedCircularModel.strScheduleTime != "", animated: false)
            self.scheduleView.isHidden = !self.scheduleCheck.isOn()
            self.scheduleHeight.constant = self.scheduleCheck.isOn() ? 95 : 0
            
            if(selectedCircularModel.strScheduleTime != "") {
                strHour = selectedCircularModel.strScheduleTime.components(separatedBy: ":").first!
                strMin = selectedCircularModel.strScheduleTime.components(separatedBy: ":").last!
                
                for view in self.scrollView.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                    let dropDown:UIDropDown = view as! UIDropDown
                    if(dropDown.table != nil){
                        dropDown.hideTable()
                    }
                    dropDown.removeFromSuperview()
                }
                
                for i in 1000...1001 {
                    self.addDropDown(self.scrollView.viewWithTag(i)!)
                }
            }
        } else {
            btnCreateDate.setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            btnAddUpdate.setTitle(ButtonType.add.rawValue, for: .normal)
            strType = 1
            strSendTo = "Y"
            strStatusMode = 5
            lblPdfInfo.text = nil
            self.clearData()
        }
        
        for view in scrollView.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
            
            switch(radioButton.tag) {
            case 1,2:
                if(radioButton.tag == strType) {
                    radioButton.select(animated: true)
                }
            case 3,4:
                if(radioButton.tag == (strSendTo == "Y" ? 3 : 4)) {
                    radioButton.select(animated: true)
                    if strSendTo == "Y" {
                        self.arrStdSelectedIds = self.dicStandards.allValues as! [String]
                    }else {
                        self.arrStdSelectedIds = []
                    }
                }
            default:
                if(radioButton.tag == strStatusMode) {
                    radioButton.select(animated: true)
                }
            }
        }
        
        if(selectedCircularModel != nil) {
            self.arrStdSelectedIds = selectedCircularModel.strStandardID.components(separatedBy: ",")
            self.txtSubject.text = selectedCircularModel.strSubjectName
            self.descriptionView.text = selectedCircularModel.strDescription
        }else {
            self.arrStdSelectedIds = self.dicStandards.allValues as! [String]
            self.txtSubject.text = nil
            self.descriptionView.text = nil
        }
        self.collectionGrade.reloadData()
        self.updateFields()
    }
    
    func updateFields()
    {
        lblSubTitle.text = strType == 1 ? "Enter Description" : "Upload PDF"
        descriptionView.isHidden = strType == 2
        btnChooseFile.isHidden = strType == 1
        descriptionHeight.constant = strType == 1 ? (DeviceType.isIpad ? 80 : 60) : (DeviceType.isIpad ? 40 : 35)
        lblPdfInfo.text = nil
    }
    
    func clearData()
    {
        scheduleView.isHidden = true
        scheduleHeight.constant = 0
        scheduleCheck.setOn(false, animated: true)
        
        btnScheduleDate.setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        
        strHour = "00"
        strMin = "00"
        
        for view in self.scrollView.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dropDown:UIDropDown = view as! UIDropDown
            if(dropDown.table != nil){
                dropDown.hideTable()
            }
            dropDown.removeFromSuperview()
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        let tag:NSInteger = (gesture.view?.tag)! > 9 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        switch tag {
        case 1,2:
            strType = tag
            self.updateFields()
        case 3,4:
            strSendTo = tag == 3 ? "Y" : "N"
            if strSendTo == "Y" {
                self.arrStdSelectedIds = self.dicStandards.allValues as! [String]
            }else {
                self.arrStdSelectedIds = []
            }
            self.collectionGrade.reloadData()
        default:
            strStatusMode = tag
        }
        
        for view in scrollView.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: false)
            
            switch(radioButton.tag) {
            case 1,2:
                if(radioButton.tag == strType) {
                    radioButton.select(animated: radioButton.tag == tag)
                    
                    if(self.scheduleCheck.isOn()) {
                        self.view.layoutIfNeeded()
                        for view in self.scrollView.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                            let dropDown:UIDropDown = view as! UIDropDown
                            if(dropDown.table != nil){
                                dropDown.hideTable()
                            }
                            dropDown.removeFromSuperview()
                        }
                        
                        for i in 1000...1001 {
                            self.addDropDown(self.scrollView.viewWithTag(i)!)
                        }
                    }
                }
            case 3,4:
                if(radioButton.tag == (strSendTo == "Y" ? 3 : 4)) {
                    radioButton.select(animated: radioButton.tag == tag)
                }
            default:
                if(radioButton.tag == strStatusMode) {
                    radioButton.select(animated: radioButton.tag == tag)
                }
            }
        }
    }
    
    func addDropDown(_ subView:UIView)
    {
        var array:[String] = []
        for i in 0..<(subView.tag == 1000 ? 24 : 60) {
            array.append(i < 10 ? "0\(i)" : "\(i)")
        }
        
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.options = array
        dropDown.tableHeight = CGFloat(5 * 35)
        dropDown.selectedIndex = array.index(of: subView.tag == 1000 ? strHour : strMin)!
        dropDown.title.text = subView.tag == 1000 ? strHour : strMin
        dropDown.tag = subView.tag * 10
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            if dropDown.tag == 10000 {
                self.strHour = option
            }else{
                self.strMin = option
            }
        }
        self.scrollView.addSubview(dropDown)
    }
    
    @IBAction override func btnChooseDateAction(_ sender: UIButton) {
        
        btnDate = sender
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDateRange.setStartDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        selector.optionCurrentDateRange.setEndDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        if(selectedCircularModel != nil) {
            if selectedCircularModel.strCreateDate.toDate(dateFormat: "dd/MM/yyyy") > Date().toString(dateFormat: "dd/MM/yyyy").toDate(dateFormat: "dd/MM/yyyy") {
                present(selector, animated: true, completion: nil)
            }
        }else {
            present(selector, animated: true, completion: nil)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension CircularVC
{
    func callInsertUpdateCircularApi()
    {
        let strPdfName:String = "Pdf_\(Date().toMillis()!).pdf"
        let params = ["Subject" : txtSubject.text!,
                      "Description" : descriptionView.text!,
                      "GradeID" : arrStdSelectedIds.joined(separator: ","),
                      "Status" : "\(strStatusMode - 4)",
            "CircularID" : selectedCircularModel != nil ? selectedCircularModel.strAnnoucementID! : "0",
            "FileName" : strType == 1 ? "" : strPdfName,
            "GradeAll" : strSendTo,
            "Date" : btnCreateDate.title(for: .normal)!,
            "ScheduleDate" : scheduleCheck.isOn() ? (btnScheduleDate.title(for: .normal))! : "",
            "ScheduleTime" : scheduleCheck.isOn() ? strHour + ":" + strMin : ""]
        
        Functions.callApi(api: API.insertCircularApi, params: params) { (json,error) in
            
            if(json != nil){
                if(self.strType == 1) {
                    let msg:String = self.btnAddUpdate.titleLabel?.text == ButtonType.add.rawValue ? Message.recordInsert : Message.recordUpdate
                    Functions.showAlert(true, msg)
                    self.navigationController?.pushPopTransition((self.navigationController?.viewControllers[(self.navigationController?.viewControllers.count)!-2])!,false)
                }else{
                    
                    Alamofire.upload(multipartFormData: { (multipartFormData) in
                        
                        if let urlString = self.strPdfUrl {
                            let pdfData = try! Data(contentsOf: urlString.asURL())
                            let data : Data = pdfData
                            multipartFormData.append(data, withName: "PDFFiles", fileName: strPdfName, mimeType: "application/pdf")
                        }
                        
                    },usingThreshold:UInt64.init(),
                      to: API.uploadPdfUrl,
                      method:.post,
                      encodingCompletion: { result in
                        
                        switch result{
                        case .success(let upload, _, _):
                            upload.responseJSON {_ in
                                let msg:String = self.btnAddUpdate.titleLabel?.text == ButtonType.add.rawValue ? Message.recordInsert : Message.recordUpdate
                                Functions.showAlert(true, msg)
                                self.navigationController?.pushPopTransition((self.navigationController?.viewControllers[(self.navigationController?.viewControllers.count)!-2])!,false)
                            }
                        case .failure(let error):
                            print("Error in upload: \(error.localizedDescription)")
                        }
                    })
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertUpdateCircularApi()
                })
            }
        }
    }
}

extension CircularVC
{
    @IBAction func btnChooseFile(_ sender:UIButton) {
        let importMenu = UIDocumentMenuViewController(documentTypes: [String(kUTTypePDF)], in: .import)
        importMenu.delegate = self
        importMenu.modalPresentationStyle = .formSheet
        self.present(importMenu, animated: true, completion: nil)
    }
    
    @IBAction func btnInsertUpdateData(_ sender:UIButton)
    {
        if(txtSubject.text?.isEmpty)! {
            Functions.showAlert(false, Message.enterSubject)
            return
        }
        if arrStdSelectedIds.count == 0 && strSendTo == "N" {
            Functions.showAlert(false, Message.noGradeSelect)
            return
        }
        if strType == 1 && (descriptionView.text?.isEmpty)! {
            Functions.showAlert(false, Message.enterDescription)
            return
        }
        self.callInsertUpdateCircularApi()
    }
}

extension CircularVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/(DeviceType.isIpad ? 5 : 3), height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrStandards.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:SectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "SectionCell", for: indexPath) as! SectionCell
        
        cell.lblSection.text = arrStandards[indexPath.row]
        
        //        if(selectedCircularModel != nil) {
        //            if(arrStdSelectedIds.contains(dicStandards.value(forKey: cell.lblSection.text!) as! String)) {
        //                cell.checkBox.setOn(true, animated: false)
        //            }else{
        //                cell.checkBox.setOn(false, animated: false)
        //            }
        //        }else{
        //            cell.checkBox.setOn(false, animated: false)
        //        }
        
        if(strSendTo == "N") {
            let stdID = dicStandards.value(forKey: self.arrStandards[indexPath.row]) as! String
            cell.checkBox.setOn(self.arrStdSelectedIds.contains(stdID), animated: false)
        }else{
            cell.checkBox.setOn(true)
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell:SectionCell = collectionView.cellForItem(at: indexPath) as! SectionCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        strStdID = dicStandards.value(forKey: self.arrStandards[indexPath.row]) as! String
        
        if(cell.checkBox.isOn()){
            self.arrStdSelectedIds.append(strStdID)
        }else{
            let idx:NSInteger = self.arrStdSelectedIds.index(of: strStdID)!
            self.arrStdSelectedIds.remove(at: idx)
        }
    }
}

extension CircularVC: UIDocumentMenuDelegate,UIDocumentPickerDelegate,UINavigationControllerDelegate
{
    func documentMenu(_ documentMenu: UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self
        isOpen = true
        present(documentPicker, animated: true, completion: nil)
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        let myURL = url as URL
        strPdfUrl = myURL
        lblPdfInfo.text = "\(Date().toMillis()!).pdf"
        print("import result : \(myURL)")
    }
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        dismiss(animated: true, completion: nil)
    }
}

extension CircularVC: UITextFieldDelegate, UITextViewDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
        }
        return true
    }
}
