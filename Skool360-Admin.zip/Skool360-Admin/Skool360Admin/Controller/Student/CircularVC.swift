//
//  CircularVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 01/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import MobileCoreServices
import Alamofire

class CircularVC: CustomViewController {
    
    @IBOutlet var collectionGrade:UICollectionView!
    @IBOutlet var tblAnnoucement:UITableView!
    @IBOutlet var btnAddUpdate:UIButton!
    @IBOutlet var collectionHeight:NSLayoutConstraint!
    
    @IBOutlet var txtSubject:UITextField!
    @IBOutlet var btnDate:UIButton!
    
    @IBOutlet var descriptionView:UITextView!
    @IBOutlet var descriptionHeight:NSLayoutConstraint!
    @IBOutlet var btnChooseFile:UIButton!
    @IBOutlet var lblSubTitle:UILabel!
    
    var arrStdSelectedIds:[String] = []
    var strType:Int = 1
    var strSendTo:String = "Y"
    var strPdfUrl:URL!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var i = 10
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag % 2 != 0){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
        self.resetData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.arrStandards = []
        self.callGetTermApi(true) { (success) in
            let height:CGFloat = CGFloat((self.arrStandards.count/(DeviceType.isIpad ? 5 : 3)) + (self.arrStandards.count%(DeviceType.isIpad ? 5 : 3) != 0 ? 1 : 0)) * 30
            self.collectionHeight.constant = height
            self.resetData()
        }
    }
    
    func resetData()
    {
        strType = 1
        strSendTo = "Y"
        strStatusMode = 5
        
        btnDate.setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
            
            switch(radioButton.tag) {
            case 1,2:
                if(radioButton.tag == strType) {
                    radioButton.select(animated: true)
                }
            case 3,4:
                if(radioButton.tag == (strSendTo == "Y" ? 3 : 4)) {
                    radioButton.select(animated: true)
                }
            default:
                if(radioButton.tag == strStatusMode) {
                    radioButton.select(animated: true)
                }
            }
        }
        
        self.arrStdSelectedIds = []
        self.collectionGrade.reloadData()
        
        self.txtSubject.text = nil
        self.descriptionView.text = nil
        self.updateFields()
    }
    
    func updateFields()
    {
        lblSubTitle.text = strType == 1 ? "Enter Description" : "Upload PDF"
        descriptionView.isHidden = strType == 2
        btnChooseFile.isHidden = strType == 1
        descriptionHeight.constant = strType == 1 ? (DeviceType.isIpad ? 80 : 60) : (DeviceType.isIpad ? 40 : 35)
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        let tag:NSInteger = (gesture.view?.tag)! > 9 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        switch tag {
        case 1,2:
            strType = tag
            self.updateFields()
        case 3,4:
            strSendTo = tag == 3 ? "Y" : "N"
        default:
            strStatusMode = tag
        }
        
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: false)
            
            switch(radioButton.tag) {
            case 1,2:
                if(radioButton.tag == strType) {
                    radioButton.select(animated: radioButton.tag == tag)
                }
            case 3,4:
                if(radioButton.tag == (strSendTo == "Y" ? 3 : 4)) {
                    radioButton.select(animated: radioButton.tag == tag)
                }
            default:
                if(radioButton.tag == strStatusMode) {
                    radioButton.select(animated: radioButton.tag == tag)
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension CircularVC
{
    func callInsertUpdateCircularApi()
    {
        let params = ["Subject" : txtSubject.text!,
                      "Description" : descriptionView.text!,
                      "GradeID" : arrStdSelectedIds.joined(separator: ","),
                      "Status" : "\(strStatusMode - 4)",
            "CircularID" : "0",
            "FileName" : strType == 1 ? "" : "1.pdf",
            "GradeAll" : strSendTo]
        
        print(params)
        
        Functions.callApi(api: API.insertCircularApi, params: params) { (json,error) in
            
            if(json != nil){
                let msg:String = self.btnAddUpdate.titleLabel?.text == ButtonType.add.rawValue ? Message.recordInsert : Message.recordUpdate
                Functions.showAlert(false, msg)
                self.resetData()
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertUpdateCircularApi()
                })
            }
        }
    }
}

extension CircularVC
{
    @IBAction func btnChooseFile(_ sender:UIButton) {
        let importMenu = UIDocumentMenuViewController(documentTypes: [String(kUTTypePDF)], in: .import)
        importMenu.delegate = self
        importMenu.modalPresentationStyle = .formSheet
        self.present(importMenu, animated: true, completion: nil)
    }
    
    @IBAction func btnInsertUpdateData(_ sender:UIButton)
    {
        if(txtSubject.text?.isEmpty)! {
            Functions.showAlert(false, Message.enterSubject)
            return
        }
        if arrStdSelectedIds.count == 0 && strSendTo == "N" {
            Functions.showAlert(false, Message.noGradeSelect)
            return
        }
        if strType == 1 && (descriptionView.text?.isEmpty)! {
            Functions.showAlert(false, Message.enterDescription)
            return
        }
        self.callInsertUpdateCircularApi()
    }
}

extension CircularVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/(DeviceType.isIpad ? 5 : 3), height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrStandards.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:SectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "SectionCell", for: indexPath) as! SectionCell
        
        cell.lblSection.text = arrStandards[indexPath.row]
        
        //        if strStdID != nil && cell.lblSection.text == dicStandards.allKeys(for: strStdID).first as? String
        //        {
        //            self.arrStdSelectedIds.append(strStdID)
        //            cell.checkBox.setOn(true, animated: false)
        //        }
        //        else
        //        {
        cell.checkBox.setOn(false, animated: false)
        //        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell:SectionCell = collectionView.cellForItem(at: indexPath) as! SectionCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        strStdID = dicStandards.value(forKey: self.arrStandards[indexPath.row]) as! String
        
        if(cell.checkBox.isOn()){
            self.arrStdSelectedIds.append(strStdID)
        }else{
            let idx:NSInteger = self.arrStdSelectedIds.index(of: strStdID)!
            self.arrStdSelectedIds.remove(at: idx)
        }
    }
}

extension CircularVC: UIDocumentMenuDelegate,UIDocumentPickerDelegate,UINavigationControllerDelegate
{
    func documentMenu(_ documentMenu: UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self
        present(documentPicker, animated: true, completion: nil)
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        let myURL = url as URL
        strPdfUrl = myURL
        print("import result : \(myURL)")
    }
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        dismiss(animated: true, completion: nil)
    }
}

extension CircularVC: UITextFieldDelegate, UITextViewDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
        }
        return true
    }
}
