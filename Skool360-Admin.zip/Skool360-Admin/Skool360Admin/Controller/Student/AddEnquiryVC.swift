//
//  AddEnquiryVC.swift
//  Skool360Admin
//
//  Created by ADMS on 25/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON
import UIDropDown

class AddEnquiryVC: CustomViewController {
    
    @IBOutlet var tblAddEnquiry:UITableView!
    
    var arrStudentHeaderTitle:[String] = []
    var arrStudentHeaderColor:[UIColor] = [GetColor.darkBlue,GetColor.green,GetColor.yellow,GetColor.lightBlue,GetColor.greenGray]
    var dicStudentDetails:NSMutableDictionary = [:]
    var arrError = [Message.firstName, "", Message.lastName, Message.gradeSection, Message.session, "", "", "", Message.psa, Message.fFirstName, "", Message.fLastName, Message.fMobileNo]
    var isError:Bool = false
    var txtFld:UITextField!
    var dictValue:[String:String] = [:]
    var strGender:String = "Male"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblAddEnquiry.estimatedRowHeight = 30.0
        
        NotificationCenter.default.addObserver(self, selector: #selector(openDatePicker(_:)), name: .openDatePicker, object: nil)
        
        arrStudentHeaderTitle = dicData[self.title!] as! [String]
        self.callGetHeaderData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (_) in
        }
    }
    
    func callGetHeaderData()
    {
        for value in self.arrStudentHeaderTitle {
            
            var arrStudentDetailTitle:[String] = []
            
            switch(value) {
            case "Student Details":
                arrStudentDetailTitle = [StudentDetailsModal.FirstName, StudentDetailsModal.MiddleName, StudentDetailsModal.LastName, StudentDetailsModal.GS, StudentDetailsModal.Session, StudentDetailsModal.Date,  StudentDetailsModal.Gender,  StudentDetailsModal.DOB,  StudentDetailsModal.PreviousSchoolAttended]
                
            case "Father Details":
                arrStudentDetailTitle = [StudentDetailsModal.FMFName, StudentDetailsModal.FMMName, StudentDetailsModal.FMLName, StudentDetailsModal.FMMobile, ""]
                
            default:
                break
            }
            self.dicStudentDetails.setValue(arrStudentDetailTitle, forKey: value)
        }
        self.tblAddEnquiry.reloadData()
    }
    
    @objc func openDatePicker(_ notification:NSNotification)
    {
        txtFld = notification.userInfo!["txtfld"] as! UITextField
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (txtFld.text!.toDate(dateFormat: "dd/MM/yyyy"))
        selector.optionCurrentDateRange.setStartDate(txtFld.text!.toDate(dateFormat: "dd/MM/yyyy"))
        selector.optionCurrentDateRange.setEndDate(txtFld.text!.toDate(dateFormat: "dd/MM/yyyy"))
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    func callSaveInquiry()
    {
        let params = ["UserID" : adminID!,
                      "StudentFName" : dictValue["First Name"]!,
                      "StudentMName" : dictValue["Middle Name"]!,
                      "StudentLName" : dictValue["Last Name"]!,
                      "GradeID" : dictValue["First Name"]!,
                      "SectionID" : dictValue["First Name"]!,
                      "TermID" : dictValue["Session"]!,
                      "Date" : dictValue["Date"]!,
                      "Gender" : dictValue["Gender"]!,
                      "StudentDOB" : dictValue["Date Of Birth"]!,
                      "PreviousSchool" : dictValue["Previous School"]!,
                      "FatherFName" : dictValue["Date"]!,
                      "FatherMName" : dictValue["Date"]!,
                      "FatherLName" : dictValue["Date"]!,
                      "FatherContactMobile" : dictValue["Date"]!,
                      ]
        
        Functions.callApi(api: API.insertInquiryApi, params: params) { (json, error) in
            
            if(json != nil) {
                Functions.showAlert(true, Message.addEnquirySuccess)
                self.navigationController?.pushPopTransition(self, false)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AddEnquiryVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: "StudentProfileHeaderCell") as! StudentProfileCell
        
        headerView.displayHeaderData(arrStudentHeaderTitle[section], arrStudentHeaderColor[section], true)
        
        return  headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == 1 && indexPath.row == 4 ? DeviceType.isIpad ? 60 : 50 : UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (dicStudentDetails[arrStudentHeaderTitle[section]] as! NSArray).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let strIdentifier:String = indexPath.section == 1 && indexPath.row == 4 ? "StudentProfileFooterCell" : "StudentProfileCell\(indexPath.row == 6 ? "1" : "")"
        
        let cell:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! StudentProfileCell
        
        let array:[String] = (dicStudentDetails[arrStudentHeaderTitle[indexPath.section]] as! [String])
        
        if(strIdentifier == "StudentProfileCell") {
            cell.bottomSpace.constant = indexPath.row ==  array.count - 1 ? 1.0 : -1.0
            cell.txtFld.tag = (indexPath.row + 1) * 100
            if((cell.txtFld.text?.isEmpty)! && (cell.txtFld.tag == 600 || cell.txtFld.tag == 800)) {
                cell.txtFld.text = Date().toString(dateFormat: "dd/MM/yyyy")
            }else {
                
            }
        }else if(strIdentifier == "StudentProfileCell1"){
            var i = 1
            for view in (cell.contentView.subviews[0].subviews) {
                if(view.isKind(of: LTHRadioButton.classForCoder())) {
                    
                    let radioButton:LTHRadioButton = view as! LTHRadioButton
                    radioButton.selectedColor = GetColor.blue
                    radioButton.deselectedColor = .lightGray
                    
                    if(radioButton.tag == 10){
                        radioButton.select(animated: true)
                    }
                    
                    let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                    radioButton.addGestureRecognizer(tapGesture)
                    
                } else if (view.tag == i){
                    
                    let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                    view.addGestureRecognizer(tapGesture)
                    
                    i += 1
                }
            }
        }
        cell.displayData([array[indexPath.row]], true)
        
        cell.saveEnquiryDetails = { sender in
            self.isError = false
            self.dictValue = [:]
            
            for (i, cell) in tableView.visibleCells.enumerated() {
                let cell = cell as! StudentProfileCell
                if(cell.txtFld != nil && !self.isError) {
                    switch sender.title(for: .normal)! {
                    case ButtonType.save.rawValue:
                        if (cell.txtFld.text?.isEmpty)! && i != 1 && i != 10 {
                            Functions.showAlert(false, self.arrError[i])
                            self.isError = true
                        }
                        self.dictValue[(cell.contentView.subviews[0].subviews[0] as! UILabel).text!] = cell.txtFld.text!
                        
                    default:
                        cell.txtFld.text = nil
                        self.dictValue = [:]
                        
                        if((cell.txtFld.text?.isEmpty)! && (cell.txtFld.tag == 600 || cell.txtFld.tag == 800)) {
                            cell.txtFld.text = Date().toString(dateFormat: "dd/MM/yyyy")
                        }
                    }
                }else{
                    
                }
            }
            
            if(self.dictValue.count > 0 && sender.title(for: .normal) == ButtonType.save.rawValue && !(self.isError)) {
                self.dictValue["Gender"] = self.strGender
                self.callSaveInquiry()
            }
        }
        return cell
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in (gesture.view?.superview?.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}))! {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! < 10 ? (gesture.view?.tag)!*10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = gesture.view?.superview!.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        strGender = tag == 10 ? "Male" : "Female"
    }
    
    /*func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        let footerView:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: "StudentProfileFooterCell") as! StudentProfileCell
        
        footerView.saveEnquiryDetails = { sender in
            self.isError = false
            self.dictValue = [:]
            
            for (i, cell) in tableView.visibleCells.enumerated() {
                let cell = cell as! StudentProfileCell
                if(cell.txtFld != nil && !self.isError) {
                    switch sender.title(for: .normal)! {
                    case ButtonType.save.rawValue:
                        if (cell.txtFld.text?.isEmpty)! && i != 1 && i != 10 {
                            Functions.showAlert(false, self.arrError[i])
                            self.isError = true
                        }
                        self.dictValue[(cell.contentView.subviews[0].subviews[0] as! UILabel).text!] = cell.txtFld.text!
                        
                    default:
                        cell.txtFld.text = nil
                        self.dictValue = [:]
                        
                        if((cell.txtFld.text?.isEmpty)! && (cell.txtFld.tag == 600 || cell.txtFld.tag == 800)) {
                            cell.txtFld.text = Date().toString(dateFormat: "dd/MM/yyyy")
                        }
                    }
                }else{
                    
                }
            }
            
            if(self.dictValue.count > 0 && sender.title(for: .normal) == ButtonType.save.rawValue && !(self.isError)) {
                self.dictValue["Gender"] = self.strGender
                self.callSaveInquiry()
            }
        }
        return section == 1 ? nil : nil
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return section == 1 ? 0 : 0
    }*/
}

extension AddEnquiryVC
{
    // MARK: Calender Delegate
    
    override func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        self.txtFld.text = date.toString(dateFormat: "dd/MM/yyyy")
    }
}
