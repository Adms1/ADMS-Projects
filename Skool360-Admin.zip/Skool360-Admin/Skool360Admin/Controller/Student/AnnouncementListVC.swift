//
//  AnnouncementListVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 17/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class AnnouncementListVC: CustomViewController {
    
    @IBOutlet weak var tblAnnoucementList:UITableView!
    
    var arrAnnoucementData = [AnnoucementModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblAnnoucementList.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetAnnoucementData()
    }
    
    private lazy var viewMarksVC: ViewMarksPopupVC = {
        
        var viewController:ViewMarksPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "ViewMarksPopupVC") as! ViewMarksPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AnnouncementListVC
{
    func callGetAnnoucementData()
    {
        arrAnnoucementData = []
        selectedIndex = -1
        
        Functions.callApi(api: API.getAnnouncementDataApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrAnnoucement = json!["FinalArray"].array
                
                for (_,value) in arrAnnoucement!.enumerated() {
                    self.arrAnnoucementData.append(AnnoucementModel.init(subject: value["SubjectName"].stringValue, description: value["Ann_Desc"].stringValue, pdf: value["AnnoucementPDF"].stringValue, createDate: value["CreateDate"].stringValue, status: value["AnnStatus"].stringValue, announcementId: value["PK_AnnouncmentID"].stringValue, std: value["Standard"].stringValue, stdId: value["StandardID"].stringValue, sDate:value["ScheduleDate"].stringValue, sTime:value["ScheduleTime"].stringValue, gradeStatus:value["GradeStatus"].stringValue))
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAnnoucementData()
                })
            }
            self.tblAnnoucementList.reloadData()
        }
    }
    
    func callDeleteAnnouncementApi(_ index:NSInteger)
    {
        let params = ["PK_AnnouncmentID":arrAnnoucementData[index].strAnnoucementID!]
        
        Functions.callApi(api: API.deleteAnnouncementApi, params: params) { (json,error) in
            if(json != nil){
                Functions.showAlert(true, Message.announcementDeleteSuccess)
                self.arrAnnoucementData.remove(at: index)
                self.tblAnnoucementList.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteAnnouncementApi(index)
                })
            }
        }
    }
}

extension AnnouncementListVC
{
    @IBAction func btnAddAction(_ sender:UIButton)
    {
        selectedAnnoucementModel = nil
        self.goToAnnoucement()
    }
    
    func goToAnnoucement()
    {
        let vc = Constants.storyBoard.instantiateViewController(withIdentifier: "AddAnnouncement")
        vc.title = self.title!
        self.navigationController?.pushPopTransition(vc,true)
    }
}

extension AnnouncementListVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:AnnoucementCell = tableView.dequeueReusableCell(withIdentifier: "AnnoucementHeaderCell") as! AnnoucementCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0, 0)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        headerView.btnExpand.transform = .identity
        if section == selectedIndex {
            UIView.animate(withDuration: 0.5, animations: {
                headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
            })
        };
        headerView.displayAnnouncementHeaderDetails(arrAnnoucementData[section])
        return arrAnnoucementData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        tableView.estimatedSectionHeaderHeight = (DeviceType.isIpad ? 60 : 50)
        return arrAnnoucementData.count > 0 ? (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50)) : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrAnnoucementData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblAnnoucementList.rowHeight == 0 ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AnnoucementCell = tableView.dequeueReusableCell(withIdentifier: arrAnnoucementData[indexPath.section].strPDF == "" ? "AnnoucementCell1" : "AnnoucementCell2", for: indexPath) as! AnnoucementCell
        
        cell.btnEdit.tag = indexPath.section
        cell.btnDelete.tag = indexPath.section
        if(arrAnnoucementData[indexPath.section].strPDF != "") {
            cell.btnViewPdf.tag = indexPath.section
        }
        cell.displayAnnouncementData(arrAnnoucementData[indexPath.section])
        cell.editDeleteViewBlock = { sender in
            if(sender == cell.btnDelete) {
                if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[2] == "true") {
                    Functions.showCustomAlert("Delete", Message.deleteAnnoucement) { (_) in
                        self.callDeleteAnnouncementApi(sender.tag)
                    }
                }
                else{
                    Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "delete"))
                }
            }else if(sender == cell.btnEdit){
                if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[1] == "true") {
                    selectedAnnoucementModel = self.arrAnnoucementData[indexPath.section]
                    self.goToAnnoucement()
                }
                else{
                    Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "edit"))
                }
            }else{
                webUrl = URL.init(string: API.hostName + self.arrAnnoucementData[indexPath.section].strPDF)
                add(asChildViewController: self.viewMarksVC, self)
            }
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblAnnoucementList.reloadSections(IndexSet(integersIn: 0...arrAnnoucementData.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblAnnoucementList.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}
