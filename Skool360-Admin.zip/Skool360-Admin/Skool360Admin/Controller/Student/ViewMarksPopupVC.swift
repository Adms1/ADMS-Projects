//
//  LessonPlanPopupVC.swift
//  Skool360Teacher
//
//  Created by ADMS on 12/10/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var webUrl:URL!
class ViewMarksPopupVC: UIViewController {
    
    @IBOutlet var webView:UIWebView!
    @IBOutlet var actView:UIActivityIndicatorView!
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        actView.startAnimating()
        
        webView.loadRequest(URLRequest.init(url: URL.init(string: "about:blank")!))
        webView.loadRequest(URLRequest.init(url: webUrl))
    }
    
    // MARK: - Button Click Action
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewMarksPopupVC:UIWebViewDelegate
{
    func webViewDidFinishLoad(_ webView: UIWebView) {
        actView.stopAnimating()
        actView.hidesWhenStopped = true
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        actView.stopAnimating()
        actView.hidesWhenStopped = true
    }
}
