//
//  DetailVC.swift
//  Skool360Admin
//
//  Created by ADMS on 25/01/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class GRRegister_LeftDetailVC: CustomViewController {
    
    @IBOutlet var tblSearchStudent:UITableView!
    @IBOutlet var lblStatus:UILabel!
    @IBOutlet var lbl:UILabel!
    @IBOutlet var lblStatusValue:UILabel!
    @IBOutlet var topValue:NSLayoutConstraint!
    
    var searchType:String!
    var arrSearchStudents = [SearchStudentsModal]()
    var arrData:[JSON] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lblStatus.isHidden = self.title == "New Register"
        lbl.isHidden = self.title == "New Register"
        lblStatusValue.isHidden = self.title == "New Register"
        topValue.constant = self.title == "New Register" ? -24 : 15
        
        for _ in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            return
        }
        
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.arrStandards.insert("All", at: 0)
                self.addDropDown()
                self.callSearchStudentApi(self.title == "New Register" ? API.getNewRegisterApi : API.getLeftDetainStudentApi)
            })
        }
    }
    
    func callSearchStudentApi(_ webApi:String)
    {
        arrSearchStudents = []
        
        let params = ["Year" : strTermID,
                      "Grade" : strStdID!,
                      "Section" : strClass!,
                      "Status" : searchType!]
        
        print(params)
        
        Functions.callApi(api: webApi, params: params) { (json,error) in
            
            if(json != nil){
                
                self.arrData = json!["FinalArray"].array!
                
                for value in self.arrData {
                    
                    let searchStudentModal:SearchStudentsModal = SearchStudentsModal.init(studentName: self.title == "New Register" ? value["StudentName"].stringValue.capitalized : "\(value["First Name"].stringValue.capitalized)|\(value["Last Name"].stringValue.capitalized)", grno: value["GRNO"].stringValue, grade: "\(value["Grade"].stringValue.capitalized)-\(value["Section"].stringValue.capitalized)")
                    
                    self.arrSearchStudents.append(searchStudentModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSearchStudentApi(webApi)
                })
            }
            self.tblSearchStudent.reloadData()
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.tag = i * 10
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addStandardDropDown(view)
                    
                case 3:
                    self.addSectionDropDown(3)
                    
                default:
                    if self.title != "New Register" {
                        self.addSelectOptionDropDown()
                    }else{
                        searchType = ""
                    }
                }
                i += 1
            }
        }
    }
    
    func addSelectOptionDropDown()
    {
        searchType = self.title == "New Register" ? "Current Student" : "Left School"
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(4)!.frame)
        dropDown.options = dicData[self.title!] as! [String]
        dropDown.tableHeight = CGFloat(2 * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = searchType
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.searchType = option
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callSearchStudentApi(self.title == "New Register" ? API.getNewRegisterApi : API.getLeftDetainStudentApi)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension GRRegister_LeftDetailVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:SearchStudentCell = tableView.dequeueReusableCell(withIdentifier: self.title == "New Register" ? "SearchStudentHeaderCell1" : "SearchStudentHeaderCell") as! SearchStudentCell
        return  arrSearchStudents.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrSearchStudents.count > 0 ? DeviceType.isIpad ? 60 : 50 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSearchStudents.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = DeviceType.isIpad ? 50 : 40
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SearchStudentCell = tableView.dequeueReusableCell(withIdentifier: self.title == "New Register" ? "SearchStudentCell1" : "SearchStudentCell", for: indexPath) as! SearchStudentCell
        
        if(self.title == "New Register") {
            cell.displayNewRegisterStudentData(arrSearchStudents[indexPath.row], indexPath.row+1)
        }else {
            cell.displayStudentData(arrSearchStudents[indexPath.row], indexPath.row+1)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc:GRRegister_Left_StudentDetailsVC = Constants.storyBoard.instantiateViewController(withIdentifier: "GRRegister_Left_StudentDetailsVC") as! GRRegister_Left_StudentDetailsVC
        vc.title = "Student Details"
        vc.dicStudentData = arrData[indexPath.row].dictionary!
        vc.strTerm = (dicTerms.allKeys(for: strTermID) as! [String]).first!
        self.navigationController?.pushPopTransition(vc,true)
    }
}
