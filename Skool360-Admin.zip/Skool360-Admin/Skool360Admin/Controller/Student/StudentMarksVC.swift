//
//  DetailVC.swift
//  Skool360Admin
//
//  Created by ADMS on 25/01/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class StudentMarksVC: CustomViewController {
    
    @IBOutlet var collectionTest:UICollectionView!
    @IBOutlet var collectionHeight:NSLayoutConstraint!
    
    var dicTestData:NSMutableDictionary = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.callGetTestsApi(completion: { (success) in
                
                let height:CGFloat = CGFloat((self.arrTests.count/(DeviceType.isIpad ? 3 : 2)) + (self.arrTests.count%(DeviceType.isIpad ? 3 : 2) != 0 ? 1 : 0)) * 30
                self.collectionHeight.constant = height
                self.collectionTest.reloadData()
                
                self.callGetSectionsApi(completion: { (success) in
                    self.addDropDown()
                })
            })
        }
    }
    
    
    // MARK: Api Calling
    
    func callGetTestsApi(completion:@escaping (Bool) -> Void)
    {
        dicTests = [:]
        
        Functions.callApi(api: API.getTestNameApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayTests = json!["FinalArray"].array
                
                for value in arrayTests! {
                    self.dicTests.setValue(value["Test ID"].stringValue, forKey: value["Test Name"].stringValue)
                }
                self.arrTests = self.dicTests.sortedDictionary(self.dicTests).0
                completion(true)
            }
        }
    }
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    func callViewStudentMarks()
    {
        let params = ["TermID" : strTermID,
                      "TermValue" : strTerm!,
                      "TestIds": (dicTestData.allKeys as! [String]).joined(separator: "|"),
                      "TestValues" : (dicTestData.allValues as! [String]).joined(separator: "|"),
                      "GradeId" : strStdID!,
                      "GradeValue" : strStd!,
                      "SectionId" : strClassID!,
                      "SectionValue" : strClass!]
        
        print(params)
        
        Functions.callApi(api: API.getStudentMarksApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dict = json!["FinalArray"].array?.first
                
                webUrl = (dict!["URL"].url)
                add(asChildViewController: self.viewMarksVC, self)
            }
        }
    }
    
    private lazy var viewMarksVC: ViewMarksPopupVC = {
        
        var viewController:ViewMarksPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "ViewMarksPopupVC") as! ViewMarksPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews[1].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.tag = i * 10
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addStandardDropDown(view)
                    
                default:
                    self.addSectionDropDown(3)
                }
                i += 1
            }
        }
    }
    
    @IBAction func btnViewMarksAction(_ sender:UIButton)
    {
        if dicTestData.count == 0 {
            Functions.showAlert(false, Message.noTestSelect)
            return
        }
        self.callViewStudentMarks()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StudentMarksVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/(DeviceType.isIpad ? 3 : 2), height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrTests.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:SectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "SectionCell", for: indexPath) as! SectionCell
        
        cell.lblSection.text = arrTests[indexPath.row]
        cell.checkBox.setOn(false, animated: false)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell:SectionCell = collectionView.cellForItem(at: indexPath) as! SectionCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        if(cell.checkBox.isOn()){
            self.dicTestData.setValue(arrTests[indexPath.row], forKey: dicTests.value(forKey: arrTests[indexPath.row]) as! String)
        }else{
            self.dicTestData.removeObject(forKey: dicTests.value(forKey: arrTests[indexPath.row]) as! String)
        }
    }
}

