//
//  SearchStudent.swift
//  Skool360Admin
//
//  Created by ADMS on 25/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

var searchType:String = "Current Student"
class SearchStudentVC: CustomViewController {
    
    @IBOutlet var tblSearchStudent:UITableView!
    
    var dropDown: UIDropDown!
    var arrParentsData:[String] = []
    var arrStudentsData:[String] = []
    
    var arrParentsSearchData:[String] = []
    var arrStudentsSearchData:[String] = []
    
    var count = 1
    var activateField:DropDownTextField!
    
    var arrSearchStudents = [SearchStudentsModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblSearchStudent.tableFooterView = UIView()
        tblSearchStudent.estimatedRowHeight = 40.0
        tblSearchStudent.rowHeight = UITableViewAutomaticDimension
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        var flag:Bool = false
        for _ in (self.view.subviews.flatMap{ $0 as? UIDropDown }) {
            flag = true
        }
        if !flag {
            self.callGetTermApi(false) { (success) in
                self.callGetSectionsApi(completion: { (success) in
                    
                    self.addDropDown()
                    self.addAutoCompleteMenu()
                    self.callSearchByParent_Student_GRNOApi(API.admin_StudentSearchByParentName, searchType, (self.view.viewWithTag(2) as! UITextField).text!)
                    
                    self.callSearchApi()
                })
            }
        }
        
        lastViewController = self.navigationController?.viewControllers.last
        self.initalization()
    }
    
    // MARK: Drop Down
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                default:
                    self.addStandardSectionDropDown(view)
                }
                i += 1
            }
        }
    }
    
    func addStandardSectionDropDown(_ subView:UIView)
    {
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.tag = subView.tag
        
        arrSections = self.dicStdSections.sortedDictionary(self.dicStdSections).0
        
        dropDown.options = arrSections
        dropDown.tableHeight = arrSections.count > 5 ? CGFloat(5 * 35) : CGFloat(arrSections.count * 35)
        
        strClass = arrSections[0]
        strClassID = self.dicStdSections.value(forKey: strClass) as? String
        dropDown.title.text = strClass
        dropDown.selectedIndex = 0
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strClass = self.arrSections[index]
            self.strClassID = self.dicStdSections.value(forKey: self.strClass) as? String
        }
        view.addSubview(dropDown)
    }
    
    /*func addDropDown()
     {
     dropDown = UIDropDown(frame: (self.view.subviews[1].frame))
     dropDown.placeholder = Constants.dropDownPlaceholder
     dropDown.options = dicData[self.title!] as! [String]
     dropDown.tableHeight = CGFloat(4 * 35)
     dropDown.selectedIndex = 0
     searchType = "Current Student"
     dropDown.title.text = searchType
     dropDown.didSelect { (option, index) in
     self.dropDown.hideTable()
     searchType = option
     
     self.reset()
     self.callSearchByParent_Student_GRNOApi(API.admin_StudentSearchByParentName, searchType, (self.view.viewWithTag(2) as! UITextField).text!)
     
     self.callSearchApi()
     }
     self.view.addSubview(dropDown)
     self.callSearchByParent_Student_GRNOApi(API.admin_StudentSearchByParentName, dropDown.title.text!, (self.view.viewWithTag(2) as! UITextField).text!)
     }*/
    
    func reset()
    {
        self.count = 1
        self.arrParentsData = []
        self.arrParentsSearchData = []
        self.arrStudentsData = []
        self.arrStudentsSearchData = []
        
        for view in self.view.subviews.filter({($0.isKind(of: DropDownTextField.classForCoder()))}) {
            
            let dropDownTextField:DropDownTextField = view as! DropDownTextField
            dropDownTextField.resignFirstResponder()
            dropDownTextField.text = nil
        }
    }
    
    // MARK: AutoCompleteMenu
    
    func addAutoCompleteMenu()
    {
        for view in self.view.subviews.filter({($0.isKind(of: DropDownTextField.classForCoder()))}) {
            
            let dropDownTextField:DropDownTextField = view as! DropDownTextField
            activateField = dropDownTextField
            
            dropDownTextField.dropDownTableView.tag = 1
            dropDownTextField.dropDownTableView.dataSource = self
            dropDownTextField.dropDownTableView.delegate = self
            
            dropDownTextField.dropDownTableView.isHidden = true
            dropDownTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        }
    }
    
    // MARK: Api Calling
    
    func callSearchByParent_Student_GRNOApi(_ webApi:String, _ searchType:String, _ inputValue:String)
    {
        count += 1
        
        let params = ["SearchType" : searchType,
                      "InputValue" : inputValue]
        
        print(params)
        
        Functions.callApi(api: webApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrGetData = json!["FinalArray"].array
                for values in arrGetData! {
                    switch(self.count)
                    {
                    case 2:
                        self.arrParentsData.append(values["Name"].stringValue)
                        self.arrParentsSearchData = self.arrParentsData
                        
                    case 3:                        self.arrStudentsData.append(values["Name"].stringValue)
                    self.arrStudentsSearchData = self.arrStudentsData
                        
                    default:
                        break
                    }
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSearchByParent_Student_GRNOApi(webApi, searchType, inputValue)
                })
            }
            
            if self.count == 2 {
                self.callSearchByParent_Student_GRNOApi(API.admin_StudentSearchByStuName, searchType, (self.view.viewWithTag(self.count + 1) as! UITextField).text!)
            }
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionCombineApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    self.dicStdSections.setValue(value["ClassID"].stringValue, forKey: value["StandardClass"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    func callSearchApi()
    {
        let params = ["TermID" : strTermID,
                      "ParentName" : (self.view.viewWithTag(2) as! DropDownTextField).text!,
                      "StudentName":(self.view.viewWithTag(3) as! DropDownTextField).text!,
                      "GRNO":(self.view.viewWithTag(4) as! DropDownTextField).text!,
                      "ClassID" : strClassID!]
        
        arrSearchStudents = []
        
        Functions.callApi(api: API.admin_SearchStudent, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for value in arrData!{
                    
                    let searchStudentModal:SearchStudentsModal = SearchStudentsModal.init(parentName: value["Father Name"].stringValue.capitalized, studentId:value["StudentID"].stringValue, modal:SearchStudentsModal.init(studentName:value["StudentName"].stringValue.capitalized, grno: value["GRNO"].stringValue, grade: value["Grade_Section"].stringValue))
                    
                    self.arrSearchStudents.append(searchStudentModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSearchApi()
                })
            }
            self.tblSearchStudent.reloadData()
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.view.endEditing(true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.callSearchApi()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SearchStudentVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activateField = textField as! DropDownTextField
        textField.becomeFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(textField.tag == 4 && range.location > 4){
            return false
        }
        return true
    }
    
    @objc func textFieldDidChange(_ textField: DropDownTextField) {
        
        if(textField.tag < 4)
        {
            activateField = textField
            switch textField.tag {
            case 2:
                let filtered = arrParentsSearchData.filter { $0.range(of: textField.text!, options: .caseInsensitive) != nil }
                arrParentsData = textField.text == "" ? [] : filtered
                if(arrParentsData.count == 0){
                    textField.dropDownTableView.isHidden = true
                    return
                }
                
            default:
                let filtered = arrStudentsSearchData.filter { $0.range(of: textField.text!, options: .caseInsensitive) != nil }
                arrStudentsData = textField.text == "" ? [] : filtered
                if(arrStudentsData.count == 0){
                    textField.dropDownTableView.isHidden = true
                    return
                }
            }
            
            textField.dropDownTableView.isHidden = false
            textField.dropDownTableView.reloadData()
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        dismissPicker()
        return true
    }
    
    override func dismissPicker(){
        activateField.resignFirstResponder()
        if activateField.dropDownTableView.isHidden == false {
            activateField.dropDownTableView.isHidden = true
        }
        self.view.endEditing(true)
    }
}

extension SearchStudentVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:SearchStudentCell = tableView.dequeueReusableCell(withIdentifier: "SearchStudentHeaderCell") as! SearchStudentCell
        return  tableView.tag == 1 ? nil : arrSearchStudents.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return tableView.tag == 1 ? 0 : arrSearchStudents.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1 {
            switch activateField.tag {
            case 2:
                return arrParentsData.count
            default:
                return arrStudentsData.count
            }
        }
        return arrSearchStudents.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = DeviceType.isIpad ? 50 : 40
        return tableView.tag == 1 ? 30 : UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView.tag == 1 && activateField != nil {
            var cell = activateField.dropDownTableView.dequeueReusableCell(withIdentifier: "Cell")
            if cell == nil {
                cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
                cell?.selectionStyle = .none
            }
            
            var array:[String] = []
            switch activateField.tag {
            case 2:
                array =  arrParentsData
            default:
                array =  arrStudentsData
            }
            
            cell?.textLabel?.font = FontHelper.regular(size: DeviceType.isIpad ? 15 :12)
            cell!.textLabel!.text = array[indexPath.row]
            
            return cell!
        }
        else {
            let cell:SearchStudentCell = tableView.dequeueReusableCell(withIdentifier: "SearchStudentCell", for: indexPath) as! SearchStudentCell
            cell.displayData(arrSearchStudents[indexPath.row])
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView.tag == 1 {
            let cell = activateField.dropDownTableView.cellForRow(at: indexPath)
            activateField.text = cell?.textLabel?.text
            self.dismissPicker()
        }else {
            let vc:StudentDetailVC = Constants.storyBoard.instantiateViewController(withIdentifier: "StudentDetailVC") as! StudentDetailVC
            vc.strStudentID = arrSearchStudents[indexPath.row].StudentID
            vc.title = "Student Details"
            self.navigationController?.pushPopTransition(vc,true)
        }
    }
}
