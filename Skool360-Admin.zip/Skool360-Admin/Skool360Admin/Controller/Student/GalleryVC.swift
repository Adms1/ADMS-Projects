//
//  GalleryVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 16/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import ImagePicker
import Alamofire
import DialogBox

class GalleryVC: CustomViewController {
    
    @IBOutlet weak var tblGallery:UITableView!
    @IBOutlet weak var collectionGallery:UICollectionView!
    @IBOutlet weak var collectionHeight:NSLayoutConstraint!
    @IBOutlet var btnAddUpdate:UIButton!
    @IBOutlet var btnChooseFile:UIButton!
    @IBOutlet var txtTitle:UITextField!
    @IBOutlet var txtComment:UITextField!
    @IBOutlet var btnStartDate:UIButton!
    
    var arrGalleryImages:[Any] = []
    var arrGalleryUpdateImages:[Any] = []
    var arrGalleryData = [GalleryModel]()
    var strID:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.resetData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension GalleryVC
{
    func callGetGalleryDataApi()
    {
        arrGalleryData = []
        arrGalleryImages = []
        arrGalleryUpdateImages = []
        
        Functions.callApi(api: API.getGalleryDataApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrGallery = json!["FinalArray"].array
                
                for (_,value) in arrGallery!.enumerated() {
                    
                    var arrPhotos:[GalleryModel] = []
                    for imgValue in value["Photos"].arrayValue {
                        arrPhotos.append(GalleryModel.init(detailId: imgValue["DetaiID"].stringValue, image: imgValue["ImagePath"].stringValue))
                    }
                    self.arrGalleryData.append(GalleryModel.init(galleryId: value["GalleryID"].stringValue, title: value["Title"].stringValue, comment: value["Comment"].stringValue, date: value["Date"].stringValue, images: arrPhotos))
                }
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetGalleryDataApi()
                    })
                }
            }
            self.tblGallery.reloadData()
        }
    }
    
    func callInsertUpdateGalleryApi(_ strGalleryID:String)
    {
        var arrImageName:[String] = []
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (i,image) in self.arrGalleryImages.enumerated() {
                if let img = image as? UIImage {
                    if let data = UIImageJPEGRepresentation(img, 0.5){
                        arrImageName.append("Image_\(Date().toMillis()!).jpeg")
                        multipartFormData.append(data, withName: "Image", fileName: arrImageName[i], mimeType: "image/jpeg")
                    }
                }
            }
        },usingThreshold:UInt64.init(),
          to:"http://192.168.1.11:8086/upload.aspx",
          method:.post,
          encodingCompletion: { result in
            
            switch result{
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    print("Succesfully uploaded  = \(response)")
                    
                    let params = ["Title" : self.txtTitle.text!,
                                  "Date" : self.btnStartDate.title(for: .normal)!,
                                  "Comment" : self.txtComment.text!,
                                  "ID" : strGalleryID,
                                  "Phohtos" : arrImageName.joined(separator: ","),
                                  "Base64" : ""]
                    
                    print(params)
                    
                    Functions.callApi(api: API.insertGalleryApi, params: params) { (json,error) in
                        
                        if(json != nil){
                            let msg:String = self.btnAddUpdate.titleLabel?.text == ButtonType.add.rawValue ? Message.recordInsert : Message.recordUpdate
                            Functions.showAlert(false, msg)
                            self.resetData()
                            
                        }else if(error != nil) {
                            Functions.showDialog(finish: {
                                self.callInsertUpdateGalleryApi(strGalleryID)
                            })
                        }
                    }
                }
            case .failure(let error):
                print("Error in upload: \(error.localizedDescription)")
            }
        })
    }
    
    func callDeleteGalleryApi(_ strGalleryID:String)
    {
        let params = ["GalleryID" : strGalleryID]
        
        print(params)
        
        Functions.callApi(api: API.deleteGalleryApi, params: params) { (json,error) in
            
            if(json != nil){
                
                Functions.showAlert(false, Message.recordDelete)
                self.resetData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteGalleryApi(strGalleryID)
                })
            }
        }
    }
}

extension GalleryVC
{
    func resetData()
    {
        self.btnStartDate.setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        self.btnAddUpdate.setTitle(ButtonType.add.rawValue, for: .normal)
        self.txtTitle.text = nil
        self.txtComment.text = nil
        self.collectionHeight.constant = 0
        self.callGetGalleryDataApi()
    }
    
    @IBAction func btnChooseFile(_ sender:UIButton) {
        var config = Configuration()
        config.doneButtonTitle = "Done"
        config.noImagesTitle = "Sorry! There are no images here!"
        config.recordLocation = false
        config.allowVideoSelection = true
        
        let imagePicker = ImagePickerController(configuration: config)
        imagePicker.delegate = self
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func btnInsertUpdateData(_ sender:UIButton)
    {
        if(txtTitle.text?.isEmpty)! {
            Functions.showAlert(false, Message.enterTitle)
            return
        }
        else if(txtComment.text?.isEmpty)! {
            Functions.showAlert(false, Message.enterComment)
            return
        }
        self.callInsertUpdateGalleryApi(sender.title(for: .normal) == ButtonType.update.rawValue ? strID : "0")
    }
}

extension GalleryVC: ImagePickerDelegate
{
    // MARK: - ImagePickerDelegate
    
    func cancelButtonDidPress(_ imagePicker: ImagePickerController) {
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    func wrapperDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
        guard images.count > 0 else { return }
        self.arrGalleryImages = self.arrGalleryUpdateImages + images
        self.refreshGrid()
    }
    
    func doneButtonDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
        imagePicker.dismiss(animated: true, completion: nil)
        self.arrGalleryImages = self.arrGalleryUpdateImages + images
        self.refreshGrid()
    }
    
    func refreshGrid()
    {
        self.collectionGallery.reloadData()
        self.collectionHeight.constant = self.arrGalleryImages.count > 0 ? 80 : 0
    }
}

extension GalleryVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrGalleryImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.height + 10, height:collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:SectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCell", for: indexPath) as! SectionCell
        if let imageView = cell.contentView.subviews[0].subviews[0] as? UIImageView {
            if let image = self.arrGalleryImages[indexPath.row] as? UIImage {
                imageView.image = image
            }else{
                imageView.setImageWithFadeFromURL(url: URL.init(string: API.hostName + (self.arrGalleryImages[indexPath.row] as! String))!, finish: {
                    self.arrGalleryImages[indexPath.row] = imageView.image!
                    if(self.arrGalleryUpdateImages.count > 0){
                        self.arrGalleryUpdateImages[indexPath.row] = imageView.image!
                    }
                })
            }
        }
        cell.contentView.subviews[0].subviews.last?.tag = indexPath.row
        return cell
    }
    
    @IBAction func btnRemoveAction(_ sender:UIButton) {
        arrGalleryImages.remove(at: sender.tag)
        self.refreshGrid()
    }
    
    @IBAction func btnEditAction(_ sender:UIButton)
    {
        btnAddUpdate.setTitle(ButtonType.update.rawValue, for: .normal)
        
        let galleryModelData = arrGalleryData[sender.tag]
        strID = galleryModelData.strGalleryID
        
        txtTitle.text = galleryModelData.strTitle
        txtComment.text = galleryModelData.strComment
        btnStartDate.setTitle(galleryModelData.strDate, for: .normal)
        
        arrGalleryImages = galleryModelData.arrImages.map{$0.strImage}
        arrGalleryUpdateImages = arrGalleryImages
        self.refreshGrid()
    }
    
    @IBAction func btnDeleteAction(_ sender:UIButton)
    {
        Functions.showCustomAlert("Delete", Message.deleteConfirmation) { (_) in
            self.callDeleteGalleryApi(self.arrGalleryData[sender.tag].strGalleryID)
        }
    }
    
    @IBAction func btnViewAction(_ sender:UIButton)
    {
        
    }
}

extension GalleryVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:GalleryCell = tableView.dequeueReusableCell(withIdentifier: "GalleryHeaderCell") as! GalleryCell
        
        return arrGalleryData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrGalleryData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrGalleryData.count > 0 ? arrGalleryData.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:GalleryCell = tableView.dequeueReusableCell(withIdentifier: "GalleryCell", for: indexPath) as! GalleryCell
        
        cell.displayData(arrGalleryData[indexPath.row])
        let arrBtns = cell.contentView.subviews[0].subviews.filter{$0 is UIButton}
        arrBtns.forEach{$0.tag = indexPath.row}
        return cell
    }
}
