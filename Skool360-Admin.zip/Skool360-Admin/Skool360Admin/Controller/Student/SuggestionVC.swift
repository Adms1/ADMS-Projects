//
//  SuggestionVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 16/11/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class SuggestionVC: CustomViewController {
    
    @IBOutlet var tblSuggestion:UITableView!
    @IBOutlet var btnStartDate:UIButton!
    @IBOutlet var btnEndDate:UIButton!
    
    var arrSuggestionData = [SuggestionModel]()
    var clickOnReply:Bool = false
    var strSuggestionStatus:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblSuggestion.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).setTitle(notificationModel != nil ? notificationModel.Date : isFromPush ? pushData["Date"] as! String : Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
        strSuggestionStatus = notificationModel != nil || isFromPush ? "Pending" : ""
        NotificationCenter.default.addObserver(self, selector: #selector(callGetParentSuggestionsApi(completion:)), name: .refreshData, object: nil)
        
        self.callGetParentSuggestionsApi {
            self.addDropDown()
        }
    }
    
    @objc func callGetParentSuggestionsApi(completion:@escaping() -> ())
    {
        arrSuggestionData = []
        
        let params = ["FromDate" : btnStartDate.title(for: .normal)!,
                      "ToDate" : btnEndDate.title(for: .normal)!,
                      "Status" : strSuggestionStatus,
                      "UserID" : adminID!]
        
        Functions.callApi(api: API.getParentSuggestionApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrLDetails = json!["FinalArray"].array
                
                for (_,values) in arrLDetails!.enumerated() {
                    let suggestionModel:SuggestionModel = SuggestionModel.init(suggestionId: values["PK_SuggestionID"].stringValue, stuName: values["StudentName"].stringValue, std: values["Standard"].stringValue, clsName: values["ClassName"].stringValue, date: values["Date"].stringValue, subject: values["Subject"].stringValue, comment: values["Comment"].stringValue, reply: values["Reply"].stringValue, replyDate: values["ReplyDate"].stringValue, replyPerson: values["EmployeeName"].stringValue, status: values["Status"].stringValue)
                    
                    if(isFromPush || notificationModel != nil) {
                        if(suggestionModel.SuggestionID == (isFromPush ? pushData["ID"] as! String : notificationModel.PkID)) {
                            self.selectedIndex = 0
                            self.arrSuggestionData.append(suggestionModel)
                        }
                    }else{
                        self.arrSuggestionData.append(suggestionModel)
                    }
                }
                completion()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetParentSuggestionsApi {
                        self.addDropDown()
                    }
                })
            }
            completion()
            self.tblSuggestion.reloadData()
        }
    }
    
    func callReplyParentSuggestionsApi(_ idx:NSInteger, _ strReply:String)
    {
        let params = ["PK_SuggestionID" : arrSuggestionData[idx].SuggestionID!,
                      "Reply" : strReply,
                      "UserID" : adminID!]
        
        Functions.callApi(api: API.replyToParentSuggestiontApi, params: params) { (json,error) in
            if(json != nil){
                self.callGetParentSuggestionsApi {
                    self.clickOnReply = false
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callReplyParentSuggestionsApi(idx, strReply)
                })
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SuggestionVC
{
    // MARK: - Add DropDown
    
    func addDropDown()
    {
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == 100){
                
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.tableHeight = 3 * 35
                dropDown.options = ["-Select-","Pending", "Replying"]
                dropDown.selectedIndex = strSuggestionStatus == "" ? 0 : ["-Select-","Pending", "Replying"].index(of: strSuggestionStatus)
                dropDown.title.text = strSuggestionStatus == "" ? "-Select-" : strSuggestionStatus
                
                dropDown.didSelect { (option, index) in
                    dropDown.hideTable()
                    self.strSuggestionStatus = option == "-Select-" ? "" : option
                }
                self.view.addSubview(dropDown)
            }
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callGetParentSuggestionsApi {}
    }
}

extension SuggestionVC: UITableViewDataSource, UITableViewDelegate
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrSuggestionData.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell:SuggestionCell = tableView.dequeueReusableCell(withIdentifier: "SuggestionHeaderCell") as! SuggestionCell
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        cell.contentView.tag = section
        cell.contentView.addGestureRecognizer(tapGesture)
        
        cell.contentView.subviews[0].subviews[0].backgroundColor = section == selectedIndex ? GetColor.blue : GetColor.orange
        cell.contentView.subviews[0].addShadowWithRadius(2.0, 0, 0)
        
        cell.displayHeaderData(arrSuggestionData[section])
        return arrSuggestionData.count > 0 ? cell.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSuggestionData.count > 0 ? 1 : 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if(arrSuggestionData[indexPath.section].Status.caseInsensitiveCompare("Pending") == .orderedSame)
        {
            strIdentifier = clickOnReply ? "GSPendingCell" : "RSPendingCell"
        }
        else
        {
            strIdentifier = "SReplyingCell"
        }
        
        let cell:SuggestionCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier) as! SuggestionCell
        cell.displaySentInboxData(arrSuggestionData[indexPath.section], strIdentifier == "SReplyingCell")
        
        if(strIdentifier == "GSPendingCell") {
            cell.txtReply.text = "Message"
            cell.txtReply.textColor = UIColor.gray.withAlphaComponent(0.3)
        }
        
        cell.btnSendTapped = { sender in
            switch sender.title(for: .normal)! {
            case "SEND":
                guard cell.txtReply.textColor == .black else {
                    Functions.showAlert(false, "Please enter message")
                    return
                }
                self.callReplyParentSuggestionsApi(indexPath.section, cell.txtReply.text!)
            default:
                self.clickOnReply = sender.title(for: .normal)! == "REPLY" ? true : false
                self.tblSuggestion.reloadData()
            }
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
            clickOnReply = false
        }
        else {
            selectedIndex = Index
        }
        
        tblSuggestion.reloadSections(IndexSet(integersIn: 0...arrSuggestionData.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblSuggestion.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}

extension SuggestionVC:UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        if(textView.text == "Message"){
            textView.text = nil
            textView.textColor = .black
        }
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(textView.text.count == 0){
            textView.text = "Message"
            textView.textColor = UIColor.gray.withAlphaComponent(0.3)
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text.count == 0){
            textView.text = "Message"
            textView.textColor = UIColor.gray.withAlphaComponent(0.3)
        }
    }
}
