//
//  StudentTransportVC.swift
//  Skool360Admin
//
//  Created by ADMS on 22/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class StudentTransportVC: CustomViewController {
    
    @IBOutlet var tblStudentTransport:UITableView!
    
    var arrTransportDetails:[String] = []
    var dicRoutesWithIds:NSMutableDictionary = [:]
    var dicPickupPoints:NSMutableDictionary = [:]
    var strRoute:String = "All"
    var strPickupPoint:String = "All"
    
    var arrStudentTransportData = [StudentTransportModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblStudentTransport.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (success) in
            self.callGetRoutesApi(completion: { (success) in
                self.arrRoutes.insert("All", at: 0)
                self.dicRoutes.setValue("All", forKey: "All")
                self.addDropDown()
                self.callTransportDetailsApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetRoutesApi(completion:@escaping (Bool) -> Void)
    {
        dicRoutes = [:]
        dicPickupPoints = [:]
        dicRoutesWithIds = [:]
        
        Functions.callApi(api: API.getRoutePickUpPointDetail, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayRoutes = json!["FinalArray"].array
                
                for value in arrayRoutes! {
                    
                    let arrPickupPointDetail:[JSON] = value["PickupPointDetail"].array!
                    
                    var arrPickupPoints:[String] = []
                    for subValues in arrPickupPointDetail {
                        arrPickupPoints.append(subValues["PickupPoint"].stringValue)
                        self.dicPickupPoints.setValue(subValues["PickupPointID"].stringValue, forKey: subValues["PickupPoint"].stringValue)
                    }
                    self.dicRoutes.setValue(arrPickupPoints, forKey: value["Route"].stringValue)
                    self.dicRoutesWithIds.setValue(value["RouteID"].stringValue, forKey: value["Route"].stringValue)
                    
                    self.arrRoutes = (self.dicRoutes.allKeys as! [String]).sorted {
                        (s1, s2) -> Bool in return s1.localizedStandardCompare(s2) == .orderedAscending
                    }
                }
                completion(true)
            }
        }
    }
    
    func callTransportDetailsApi()
    {
        let params = ["Term" : strTermID,
                      "RouteID" : strRoute == "All" ? "All" : self.dicRoutesWithIds[strRoute] as! String,
                      "PickupPoint" : self.arrTransportDetails.count == 0 ? "" : strPickupPoint == "All" ? "All" : self.dicPickupPoints[strPickupPoint] as! String,
                      "GRNO" : (self.view.viewWithTag(4) as! UITextField).text!]
        
        print(params)
        
        self.arrStudentTransportData = []
        selectedIndex = -1
        
        Functions.callApi(api: API.studentTransportDetailApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrGetData = json!["FinalArray"].array
                
                for value in arrGetData! {
                    self.arrStudentTransportData.append(StudentTransportModal(StudentName: value["StudentName"].stringValue, GRNO: value["GRNO"].stringValue, Grade: value["Standard"].stringValue, RouteName: value["RouteName"].stringValue, PickupPointName: value["PickupPointName"].stringValue, KM: value["KM"].stringValue, StudentID: "", SMSMobileNo: ""))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callTransportDetailsApi()
                })
            }
            self.tblStudentTransport.reloadData()
        }
    }
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addRouteDropDown()
                    
                default:
                    self.addPickupPointDropDown()
                }
                i += 1
            }
        }
    }
    
    func addRouteDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(2)?.frame)!)
        dropDown.options = self.arrRoutes
        dropDown.tableHeight = self.arrRoutes.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrRoutes.count * 35)
        dropDown.selectedIndex = self.arrRoutes.index(of: strRoute)
        dropDown.title.text = strRoute
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strRoute = option
            self.addPickupPointDropDown()
        }
        self.view.addSubview(dropDown)
    }
    
    func addPickupPointDropDown()
    {
        self.arrTransportDetails = []
        let strValue:String = strPickupPoint
        
        var dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(3)?.frame)!)
        dropDown.placeholder = Constants.dropDownPlaceholder
        dropDown.tableHeight = 0.0
        dropDown.tag = 30
        
        if strRoute != "All" {
            self.arrTransportDetails = self.dicRoutes.value(forKey: self.strRoute) as! [String]
        }else{
            for key in self.arrRoutes {
                if(key != "All"){
                    for item in dicRoutes[key] as! [String] {
                        self.arrTransportDetails.append(item)
                    }
                }
            }
        }
        
        var sortedKeys = self.arrTransportDetails.sorted(by: <)
        if(sortedKeys.count > 0){
            sortedKeys.insert("All", at: 0)
            
            for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                if(view.tag == 30){
                    dropDown = view as! UIDropDown
                }
            }
            
            dropDown.options = sortedKeys
            dropDown.tableHeight = sortedKeys.count > 5 ? CGFloat(5 * 35) : CGFloat(sortedKeys.count * 35)
            dropDown.selectedIndex = sortedKeys.index(of: strValue)
            dropDown.title.text = strValue
            
            dropDown.didSelect { (option, index) in
                dropDown.hideTable()
                self.strPickupPoint = option
            }
        }
        
        for dd in (self.view.subviews.flatMap{$0 as? UIDropDown}) {
            if(dd.tag == 30){
                return
            }
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.view.endEditing(true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.callTransportDetailsApi()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StudentTransportVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.becomeFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(range.location > 4){
            return false
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        self.view.endEditing(true)
        return true
    }
}

extension StudentTransportVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:StudentTransportCell = tableView.dequeueReusableCell(withIdentifier: "StudentTransportHeaderCell") as! StudentTransportCell
        
        headerView.headerHeight.constant = section == 0 ? DeviceType.isIpad ? 45 : 40 : 0
        headerView.lblView.superview?.addShadowWithRadius(2.0, 0, 0)
        
        if section == selectedIndex {
            headerView.lblView.textColor = GetColor.green
        }else{
            headerView.lblView.textColor = .red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblView.superview?.tag = section
        headerView.lblView.superview?.addGestureRecognizer(tapGesture)
        
        headerView.displayHeaderData(arrStudentTransportData[section], idx: section+1)
        
        return arrStudentTransportData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrStudentTransportData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        tableView.estimatedSectionHeaderHeight = 90
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = DeviceType.isIpad ? 100 : 90.0
        return indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:StudentTransportCell = tableView.dequeueReusableCell(withIdentifier: "StudentTransportCell", for: indexPath) as! StudentTransportCell
        cell.displayData(arrStudentTransportData[indexPath.section])
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblStudentTransport.reloadData()
        self.tblStudentTransport.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
    }
}
