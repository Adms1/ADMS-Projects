//
//  StudentDetailVC.swift
//  Skool360Admin
//
//  Created by ADMS on 25/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON

class StudentDetailVC: CustomViewController {
    
    @IBOutlet var tblStudentDetails:UITableView!
    
    var arrStudentHeaderTitle:[String] = []
    var arrStudentHeaderColor:[UIColor] = [GetColor.darkBlue,GetColor.green,GetColor.yellow,GetColor.lightBlue,GetColor.greenGray]
    var dicStudentDetails:NSMutableDictionary = [:]
    var strStudentID:String!
    var isFromInquiry:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblStudentDetails.estimatedRowHeight = 30.0
        
        arrStudentHeaderTitle = dicData[self.title!] as! [String]
        callGetStudentDataApi(isFromInquiry ? API.getEnduiryDataByIDApi : API.admin_StudentFullDetailApi)
    }
    
    func callGetStudentDataApi(_ webApi:String)
    {
        Functions.callApi(api: webApi, params: ["StudentID" : strStudentID!]) { (json,error) in
            
            if(json != nil){
                
                let dict = json!["FinalArray"].array?.first
                
                for value in self.arrStudentHeaderTitle {
                    
                    self.strStatus = dict!["Status"].stringValue
                    
                    var arrStudentDetailTitle:[String] = []
                    
                    switch(value) {
                    case "Student Details":
                        if(webApi == API.admin_StudentFullDetailApi)
                        {
                            arrStudentDetailTitle = [StudentDetailsModal.StudentImage, StudentDetailsModal.Tag, StudentDetailsModal.FirstName, StudentDetailsModal.MiddleName, StudentDetailsModal.LastName, StudentDetailsModal.DOB, StudentDetailsModal.BirthPlace, StudentDetailsModal.Age, StudentDetailsModal.Gender, StudentDetailsModal.Board, StudentDetailsModal.AadharNo,  StudentDetailsModal.AcedamicYear, StudentDetailsModal.Grade, StudentDetailsModal.Section, StudentDetailsModal.LastSchool, StudentDetailsModal.DOA, StudentDetailsModal.AdmissionTaken, StudentDetailsModal.BloodGrp, StudentDetailsModal.House, StudentDetailsModal.StuUniqueNo, StudentDetailsModal.Religion, StudentDetailsModal.Nationality,  StudentDetailsModal.Location, StudentDetailsModal.UserName, StudentDetailsModal.Password,StudentDetailsModal.Status, StudentDetailsModal.GRNO, StudentDetailsModal.OldGRNO,
                            ]
                        }
                        else
                        {
                            arrStudentDetailTitle = [StudentDetailsModal.StudentImage, StudentDetailsModal.FirstName, StudentDetailsModal.MiddleName, StudentDetailsModal.LastName, StudentDetailsModal.GS, StudentDetailsModal.Session, StudentDetailsModal.FormNo, StudentDetailsModal.Date, StudentDetailsModal.GRNO,  StudentDetailsModal.Gender, StudentDetailsModal.BloodGrp, StudentDetailsModal.DOB, StudentDetailsModal.BirthPlace, StudentDetailsModal.Nationality, StudentDetailsModal.HomeTown, StudentDetailsModal.MotherTongue, StudentDetailsModal.CRW, StudentDetailsModal.PreviousSchoolAttended, StudentDetailsModal.FCaH, StudentDetailsModal.Sibling1, StudentDetailsModal.Sibling1Type, StudentDetailsModal.Sibling1Grade, StudentDetailsModal.Sibling1School, StudentDetailsModal.Sibling2, StudentDetailsModal.Sibling2Type, StudentDetailsModal.Sibling2Grade, StudentDetailsModal.Sibling2School, StudentDetailsModal.NoLG, StudentDetailsModal.CoLG, StudentDetailsModal.Address, StudentDetailsModal.EmergencyNo, StudentDetailsModal.TF
                            ]
                        }
                        self.fillData(true, nil, arrStudentDetailTitle, dict, value)
                        
                    case "Transport Details":
                        arrStudentDetailTitle = [StudentDetailsModal.Route, StudentDetailsModal.PickupBus, StudentDetailsModal.PickupPoint, StudentDetailsModal.PickupPointTime, StudentDetailsModal.DropBus, StudentDetailsModal.DropPoint, StudentDetailsModal.DropPointTime]
                        
                        self.fillData(false, nil, arrStudentDetailTitle, dict, value)
                        
                    case "Father Details":
                        if(webApi == API.admin_StudentFullDetailApi)
                        {
                            arrStudentDetailTitle = [StudentDetailsModal.FMFName, StudentDetailsModal.FMLName, StudentDetailsModal.FMPhone, StudentDetailsModal.FMMobile, StudentDetailsModal.FMEmail, StudentDetailsModal.FMQualification, StudentDetailsModal.FMOcupation, StudentDetailsModal.FMOrganization, StudentDetailsModal.FMDesignation, StudentDetailsModal.FMOA]
                        }
                        else
                        {
                            arrStudentDetailTitle = [StudentDetailsModal.FMImage, StudentDetailsModal.FMFName, StudentDetailsModal.FMMName, StudentDetailsModal.FMLName, StudentDetailsModal.FMDOB, StudentDetailsModal.FMBP, StudentDetailsModal.FMOcupation, StudentDetailsModal.FMNoC, StudentDetailsModal.FMQualification, StudentDetailsModal.FMDesignation, StudentDetailsModal.FMNationality, StudentDetailsModal.FMLK, StudentDetailsModal.FMMobile, StudentDetailsModal.FMCOffice, StudentDetailsModal.FMCHome, StudentDetailsModal.FMEmail, StudentDetailsModal.FMAHome, StudentDetailsModal.FMAOffice, StudentDetailsModal.FMStatus, StudentDetailsModal.FMAI
                            ]
                        }
                        self.fillData(true, "Father", arrStudentDetailTitle, dict, value)
                        
                    case "Mother Details":
                        if(webApi == API.admin_StudentFullDetailApi)
                        {
                            arrStudentDetailTitle = [StudentDetailsModal.FMFName, StudentDetailsModal.FMLName, StudentDetailsModal.FMPhone, StudentDetailsModal.FMMobile, StudentDetailsModal.FMEmail, StudentDetailsModal.FMQualification, StudentDetailsModal.FMOcupation, StudentDetailsModal.FMOrganization, StudentDetailsModal.FMDesignation, StudentDetailsModal.FMOA]
                        }
                        else
                        {
                            arrStudentDetailTitle = [StudentDetailsModal.FMImage, StudentDetailsModal.FMFName, StudentDetailsModal.FMMName, StudentDetailsModal.FMLName, StudentDetailsModal.FMDOB, StudentDetailsModal.FMBP, StudentDetailsModal.FMOcupation, StudentDetailsModal.FMNoC, StudentDetailsModal.FMQualification, StudentDetailsModal.FMDesignation, StudentDetailsModal.FMNationality, StudentDetailsModal.FMLK, StudentDetailsModal.FMMobile, StudentDetailsModal.FMCOffice, StudentDetailsModal.FMCHome, StudentDetailsModal.FMEmail, StudentDetailsModal.FMAHome, StudentDetailsModal.FMAOffice, StudentDetailsModal.FMStatus, StudentDetailsModal.FMAI
                            ]
                        }
                        self.fillData(true, "Mother", arrStudentDetailTitle, dict, value)
                        
                    case "For Office Use":
                        let str1 = "1 Interaction "; let str2 = "2 Interaction "
                        arrStudentDetailTitle = [StudentDetailsModal.RegistrationNo, StudentDetailsModal.RegistrationDate, StudentDetailsModal.DBC, StudentDetailsModal.DP, StudentDetailsModal.DOTC, StudentDetailsModal.IDProofFather, StudentDetailsModal.FPC, StudentDetailsModal.FLC, StudentDetailsModal.FAC, StudentDetailsModal.IDProofMother, StudentDetailsModal.MPC, StudentDetailsModal.MLC, StudentDetailsModal.MAC, StudentDetailsModal.AtG, StudentDetailsModal.WS, StudentDetailsModal.Remarks, StudentDetailsModal.AM, str1 + StudentDetailsModal.IDate, str1 + StudentDetailsModal.IDate, str1 + StudentDetailsModal.ITime, str1 + StudentDetailsModal.IWith, str1 + StudentDetailsModal.IRemarks/*, str2 + StudentDetailsModal.IDate, str2 + StudentDetailsModal.IDate, str2 + StudentDetailsModal.ITime, str2 + StudentDetailsModal.IWith, str2 + StudentDetailsModal.IRemarks*/]
                        
                        self.fillData(false, nil, arrStudentDetailTitle, dict, value)
                        
                    default:
                        arrStudentDetailTitle = [StudentDetailsModal.SMSNo, StudentDetailsModal.City, StudentDetailsModal.ZipCode, //StudentDetailsModal.UserName, StudentDetailsModal.Password,
                            StudentDetailsModal.CommEmailID,
                            StudentDetailsModal.Address]
                        
                        self.fillData(false, nil, arrStudentDetailTitle, dict, value)
                    }
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetStudentDataApi(webApi)
                })
            }
            self.tblStudentDetails.reloadData()
        }
    }
    
    func callCancelRequest()
    {
        Functions.callApi(api: API.rejectEnquiryApi, params: ["StudentID" : strStudentID!]) { (json,error) in
            
            if(json != nil){
                
                Functions.showAlert(true, Message.cancelEnquirySuccess)
                
                self.callGetStudentDataApi(self.arrStudentHeaderTitle.count == 3 ? API.getEnduiryDataByIDApi : API.admin_StudentFullDetailApi)
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callCancelRequest()
                    })
                }
            }
        }
    }
    
    func fillData(_ test:Bool, _ str:String?, _ arrayTitle:[String], _ dict:JSON?, _ key:String)
    {
        var arrStudentDetailValue:[String] = []
        
        for value in arrayTitle {
            let itemKey:String = str == nil ? value : "\(str!) \(value)"
            if(itemKey == "Password"){
                arrStudentDetailValue.append(String(dict![itemKey].stringValue.map { _ in return "•" }))
            }else if(itemKey == "Status"){
                arrStudentDetailValue.append(searchType == "Current Student" ? "Active" : "InActive")
            }else{
                if(itemKey.contains("Date")){
                    arrStudentDetailValue.append(dict![itemKey].stringValue.components(separatedBy: " ").first!)
                }else {
                    arrStudentDetailValue.append(dict![itemKey].stringValue)
                }
            }
        }
        self.dicStudentDetails.setValue([arrayTitle,arrStudentDetailValue], forKey: key)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StudentDetailVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var strIdentifier:String = "StudentProfileHeaderCell"
        if section == arrStudentHeaderTitle.count {
            strIdentifier = "StudentProfileFooterCell"
        }
        
        let headerView:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier) as! StudentProfileCell
        
        if section < arrStudentHeaderTitle.count {
            headerView.displayHeaderData(arrStudentHeaderTitle[section], arrStudentHeaderColor[section], selectedIndex == section ? true : false)
            
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
            headerView.contentView.tag = section
            headerView.contentView.addGestureRecognizer(tapGesture)
            
        }else {
            (headerView.contentView.subviews[0] as! UIButton).addTarget(self, action: #selector(cancelRequestAction), for: .touchUpInside)
        }
        return  headerView.contentView
    }
    
    @objc func cancelRequestAction() {
        Functions.showCustomAlert("Cancel Enquiry", Message.cancelEnquiry) { (_) in
            self.callCancelRequest()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dicStudentDetails.count > 0 ? arrStudentHeaderTitle.count + (isFromInquiry ? self.strStatus != "=-1" ? 0 : 1 : 0): 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == selectedIndex {
            switch(indexPath.row){
            case 0:
                if(isFromInquiry) {
                    return indexPath.section < 3 ? DeviceType.isIpad ? 120 : 100 : UITableViewAutomaticDimension
                }else {
                    return indexPath.section == 0 ? DeviceType.isIpad ? 120 : 100 : UITableViewAutomaticDimension
                }
            default:
                return isFromInquiry && indexPath.section == 3 && (indexPath.row == 17 || indexPath.row == 22) ? DeviceType.isIpad ? 60 : 50 : UITableViewAutomaticDimension
            }
        }else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section < arrStudentHeaderTitle.count ? ((dicStudentDetails[arrStudentHeaderTitle[section]] as! NSArray).firstObject as! NSArray).count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        switch(indexPath.row){
        case 0:
            if(isFromInquiry) {
                strIdentifier = indexPath.section < 3 ? "StudentProfilePicCell" : "StudentProfileCell"
            }else {
                strIdentifier = indexPath.section == 0 ? "StudentProfilePicCell" : "StudentProfileCell"
            }
        default:
            strIdentifier = isFromInquiry && indexPath.section == 3 && (indexPath.row == 17 || indexPath.row == 22) ? "StudentProfileHCell" : "StudentProfileCell"
        }
        
        let cell:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! StudentProfileCell
        
        let array:NSArray = (dicStudentDetails[arrStudentHeaderTitle[indexPath.section]] as! NSArray)
        let arrTitle:[String] = array.firstObject as! [String]
        let arrValue:[String] = array.lastObject as! [String]
        
        if isFromInquiry && indexPath.section == 3 && (indexPath.row == 17 || indexPath.row == 22) {
            cell.displayHeaderData("\(indexPath.row == 17 ? "" : "2nd") Interaction", UIColor.groupTableViewBackground, true)
            return cell
        }else{
            cell.bottomSpace.constant = indexPath.row ==  arrTitle.count - 1 ? 1.0 : -1.0
        }
        
        cell.displayData([arrTitle[indexPath.row].replacingOccurrences(of: "\(indexPath.row > 17 && indexPath.row < 22 ? "1" : "2") Interaction ", with: ""), arrValue[indexPath.row]], selectedIndex == indexPath.section ? true : false)
        
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblStudentDetails.reloadSections(IndexSet(integersIn: 0...arrStudentHeaderTitle.count-1), with: .automatic)
        
        if selectedIndex != -1 {
            self.tblStudentDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: true)
        }
    }
}
