//
//  PlannerVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 01/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import MobileCoreServices
import Alamofire

class PlannerVC: CustomViewController {
    
    @IBOutlet var collectionGrade:UICollectionView!
    @IBOutlet var tblPlanner:UITableView!
    @IBOutlet var btnAddUpdate:UIButton!
    @IBOutlet var collectionHeight:NSLayoutConstraint!
    
    @IBOutlet var txtSubject:UITextField!
    
    var arrStdSelectedIds:[String] = []
    var strType:Int = 1
    var strSendTo:String = "Y"
    var arrPlannerData = [HolidayModel]()
    var strID:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var i = 10
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag % 2 != 0){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
        self.resetData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.arrStandards = []
        self.callGetTermApi(true) { (success) in
            let height:CGFloat = CGFloat((self.arrStandards.count/(DeviceType.isIpad ? 5 : 3)) + (self.arrStandards.count%(DeviceType.isIpad ? 5 : 3) != 0 ? 1 : 0)) * 30
            self.collectionHeight.constant = height
            self.resetData()
        }
    }
    
    func resetData()
    {
        strType = 1
        strSendTo = "Y"
        
        for view in view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
        
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
            
            switch(radioButton.tag) {
            case 1,2:
                if(radioButton.tag == strType) {
                    radioButton.select(animated: true)
                }
            case 3,4:
                if(radioButton.tag == (strSendTo == "Y" ? 3 : 4)) {
                    radioButton.select(animated: true)
                }
            default:
                break
            }
        }
        
        self.arrStdSelectedIds = self.dicStandards.allKeys as! [String]
        self.collectionGrade.reloadData()
        
        self.txtSubject.text = nil
        self.callGetPlannerApi()
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        let tag:NSInteger = (gesture.view?.tag)! > 9 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        switch tag {
        case 1,2:
            strType = tag
        case 3,4:
            strSendTo = tag == 3 ? "Y" : "N"
        default:
            break
        }
        
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: false)
            
            switch(radioButton.tag) {
            case 1,2:
                if(radioButton.tag == strType) {
                    radioButton.select(animated: radioButton.tag == tag)
                }
            case 3,4:
                if(radioButton.tag == (strSendTo == "Y" ? 3 : 4)) {
                    radioButton.select(animated: radioButton.tag == tag)
                }
            default:
                break
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension PlannerVC
{
    func callGetPlannerApi()
    {
        arrPlannerData = []
        
        Functions.callApi(api: API.getPlannerApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrHolidayData = json!["FinalArray"].array
                
                for (index,value) in arrHolidayData!.enumerated() {
                    
                    self.arrPlannerData.append(HolidayModel(Index: "\(index+1)", CategoryID: value["GradeID"].stringValue, HolidayID: value["ID"].stringValue, Holiday: value["Type"].stringValue, StartDate: value["StartDate"].stringValue, EndDate: value["EndDate"].stringValue, Description: value["Name"].stringValue))
                }
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetPlannerApi()
                    })
                }
            }
            self.tblPlanner.reloadData()
        }
    }
    
    func callInsertUpdatePlannerApi(_ strPlannerID:String)
    {
        let params = ["Title" : txtSubject.text!,
                      "Type" : strType == 1 ? "Holiday" : "Event",
                      "GradeIds" : arrStdSelectedIds.joined(separator: ","),
                      "StartDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!,
                      "ID" : strPlannerID]
        
        print(params)
        
        Functions.callApi(api: API.insertPlannerApi, params: params) { (json,error) in
            
            if(json != nil){
                let msg:String = self.btnAddUpdate.titleLabel?.text == ButtonType.add.rawValue ? Message.recordInsert : Message.recordUpdate
                Functions.showAlert(false, msg)
                self.resetData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertUpdatePlannerApi(strPlannerID)
                })
            }
        }
    }
    
    func callDeletePlannerApi(_ strPlannerID:String)
    {
        let params = ["ID" : strPlannerID]
        
        print(params)
        
        Functions.callApi(api: API.deletePlannerApi, params: params) { (json,error) in
            
            if(json != nil){
                
                Functions.showAlert(false, Message.recordDelete)
                self.callGetPlannerApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeletePlannerApi(strPlannerID)
                })
            }
        }
    }
}

extension PlannerVC
{
    @IBAction func btnInsertUpdateData(_ sender:UIButton)
    {
        if(txtSubject.text?.isEmpty)! {
            Functions.showAlert(false, Message.enterSubject)
            return
        }
        if arrStdSelectedIds.count == 0 && strSendTo == "N" {
            Functions.showAlert(false, Message.noGradeSelect)
            return
        }
        self.callInsertUpdatePlannerApi(sender.title(for: .normal) == ButtonType.update.rawValue ? strID : "0")
    }
}

extension PlannerVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/(DeviceType.isIpad ? 5 : 3), height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrStandards.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:SectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "SectionCell", for: indexPath) as! SectionCell
        
        cell.lblSection.text = arrStandards[indexPath.row]
        
        if(strSendTo == "N") {
            let stdID = dicStandards.value(forKey: self.arrStandards[indexPath.row]) as! String
            cell.checkBox.setOn(self.arrStdSelectedIds.contains(stdID), animated: false)
        }else{
            cell.checkBox.setOn(true)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell:SectionCell = collectionView.cellForItem(at: indexPath) as! SectionCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        strStdID = dicStandards.value(forKey: self.arrStandards[indexPath.row]) as! String
        
        if(cell.checkBox.isOn()){
            self.arrStdSelectedIds.append(strStdID)
        }else{
            let idx:NSInteger = self.arrStdSelectedIds.index(of: strStdID)!
            self.arrStdSelectedIds.remove(at: idx)
        }
    }
}

extension PlannerVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:HolidayCell = tableView.dequeueReusableCell(withIdentifier: "HolidayHeaderCell") as! HolidayCell
        
        return arrPlannerData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrPlannerData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPlannerData.count > 0 ? arrPlannerData.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:HolidayCell = tableView.dequeueReusableCell(withIdentifier: "HolidayCell", for: indexPath) as! HolidayCell
        
        cell.btnEdit.tag = indexPath.row
        cell.btnDelete.tag = indexPath.row
        
        cell.displayData(arrPlannerData[indexPath.row])
        
        return cell
    }
    
    @IBAction func btnEditAction(_ sender:UIButton)
    {
        btnAddUpdate.setTitle(ButtonType.update.rawValue, for: .normal)
        
        let plannerModelData:HolidayModel = arrPlannerData[sender.tag]
        strID = plannerModelData.HolidayID
        
        // 2
        (self.view.viewWithTag(300) as! UIButton).setTitle(plannerModelData.StartDate, for: .normal)
        (self.view.viewWithTag(301) as! UIButton).setTitle(plannerModelData.EndDate, for: .normal)
        
        txtSubject.text = plannerModelData.Description
        self.arrStdSelectedIds = plannerModelData.CategoryID.components(separatedBy: ",")
        
        self.strSendTo = self.arrStdSelectedIds.count == self.arrStandards.count ? "Y" : "N"
        self.strType = plannerModelData.Holiday == "Holiday" ? 1 : 2
        self.collectionGrade.reloadData()
        
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
            
            switch(radioButton.tag) {
            case 1,2:
                if(radioButton.tag == strType) {
                    radioButton.select(animated: true)
                }
            case 3,4:
                if(radioButton.tag == (strSendTo == "Y" ? 3 : 4)) {
                    radioButton.select(animated: true)
                }
            default:
                break
            }
        }
    }
    
    @IBAction func btnDeleteAction(_ sender:UIButton)
    {
        Functions.showCustomAlert("Delete", Message.deleteConfirmation) { (_) in
            self.callDeletePlannerApi(self.arrPlannerData[sender.tag].HolidayID)
        }
    }
}

extension PlannerVC: UITextFieldDelegate, UITextViewDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

