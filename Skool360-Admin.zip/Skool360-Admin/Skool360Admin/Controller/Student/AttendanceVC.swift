//
//  SMS.swift
//  Skool360Admin
//
//  Created by ADMS on 28/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class AttendanceVC: CustomViewController {
    
    @IBOutlet var tblAttendance:UITableView!
    @IBOutlet var tblHeaderView:UIView!
    
    var arrAttendanceData = [StudentAttendanceModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.addDropDown()
                self.callAttendanceApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    func callAttendanceApi()
    {
        let params = ["AttDate":((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "StdID":strStdID!,
                      "ClsID":strClassID!]
        
        print(params)
        
        self.arrAttendanceData = []
        
        Functions.callApi(api: API.getAttendenceAdminApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dict = json!["FinalArray"].array?.first
                
                let finalResults = dict!["StudentDetail"].array
                
                for values in finalResults! {
                    
                    let stuID = values["StudentID"].numberValue
                    let attID = values["AttendanceID"].numberValue
                    
                    let attendanceData = StudentAttendanceModel.init(attendanceStatus: values["AttendenceStatus"].stringValue, studentID: stuID, studentName: values["StudentName"].stringValue, attendanceID: attID, studentImage: values["StudentImage"].stringValue)
                    
                    self.arrAttendanceData.append(attendanceData)
                }
                
                let attendanceModal:ShilajStudentAttendanceModel = ShilajStudentAttendanceModel.init(Total: dict!["Total"].numberValue, TotalAbsent: dict!["TotalAbsent"].numberValue, TotalPresent: dict!["TotalPresent"].numberValue, TotalLeave: dict!["TotalLeave"].numberValue)
                self.displayStudentData(StudentAttendanceModel.init(ShilajModal: attendanceModal, TotalOnDuty: dict!["TotalOnDuty"].numberValue))
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callAttendanceApi()
                    })
                }
            }
            self.tblAttendance.reloadData()
        }
    }
    
    
    // MARK: - Display Function
    
    func displayStudentData(_ studentData:StudentAttendanceModel)
    {
        let arrData = [studentData.ShilajModalValue?.Total,studentData.ShilajModalValue?.TotalPresent,studentData.ShilajModalValue?.TotalAbsent,studentData.ShilajModalValue?.TotalLeave,studentData.TotalOnDuty]
        let arrColor = [GetColor.blue,GetColor.green,GetColor.red,GetColor.orange,GetColor.yellow]
        
        var i = 1
        for view in tblHeaderView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i) {
                let lbl = view as! UILabel
                lbl.text = "\((lbl.text?.components(separatedBy: " : ").first)!) : \(arrData[i-1]!)"
                
                let attributedString = NSMutableAttributedString(
                    string: lbl.text!,
                    attributes: [:])
                
                let strSub:String = (lbl.text?.components(separatedBy: " : ").last)!
                
                attributedString.addAttribute(
                    NSAttributedStringKey.foregroundColor,
                    value: arrColor[i-1],
                    range: (lbl.text! as NSString).range(of: strSub))
                
                attributedString.addAttribute(
                    NSAttributedStringKey.font,
                    value: FontHelper.bold(size: 14),
                    range: (lbl.text! as NSString).range(of: strSub))
                
                lbl.attributedText = attributedString
                
                i += 1
            }
        }
    }
    
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 2:
                    self.addStandardDropDown(view)
                    
                default:
                    self.addSectionDropDown(3)
                }
                i += 1
                
            }else if(view.tag == i) {
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                i += 1
            }
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callAttendanceApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AttendanceVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        return arrAttendanceData.count > 0 ? tblHeaderView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return arrAttendanceData.count > 0 ? DeviceType.isIpad ? 130 : 100 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAttendanceData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AttendanceCell = tableView.dequeueReusableCell(withIdentifier:"AttendanceCell", for: indexPath) as! AttendanceCell
        
        cell.displayData(attendanceData: arrAttendanceData[indexPath.row])
        return cell
    }
}
