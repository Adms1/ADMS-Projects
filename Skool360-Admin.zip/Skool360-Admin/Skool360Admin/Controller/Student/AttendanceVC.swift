//
//  SMS.swift
//  Skool360Admin
//
//  Created by ADMS on 28/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class AttendanceVC: CustomViewController {
    
    @IBOutlet var tblAttendance:UITableView!
    @IBOutlet var tblHeaderView:UIView!
    @IBOutlet var btnFooter:UIButton!
    
    var arrAttendanceData = [StudentAttendanceModel]()
    var dictData:[String:JSON] = [:]
    var dictSelectedData:NSMutableDictionary = [:]
    var status:Int = 0
    var strID:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.addDropDown()
                self.callAttendanceApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    func callAttendanceApi()
    {
        let params = ["AttDate":((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "StdID":strStdID!,
                      "ClsID":strClassID!]
        
        print(params)
        
        self.arrAttendanceData = []
        
        Functions.callApi(api: API.getAttendenceAdminApi, params: params) { (json,error) in
            
            if(json != nil){
                
                self.dictData = ((json!["FinalArray"].array?.first)?.dictionaryValue)!
                
                let finalResults = self.dictData["StudentDetail"]?.array
                
                var i = 0
                for values in finalResults! {
                    
                    let stuID = values["StudentID"].numberValue
                    let attID = values["AttendanceID"].numberValue
                    
                    let attendanceData = StudentAttendanceModel.init(attendanceStatus: values["AttendenceStatus"].stringValue, studentID: stuID, studentName: values["StudentName"].stringValue, attendanceID: attID, studentImage: values["StudentImage"].stringValue, rowEnable:values["RowEnable"].boolValue)
                    
                    self.status = Int(attendanceData.AttendanceStatus!)!
                    if(self.status == -2){
                        self.status = 1
                        self.dictSelectedData.setValue([stuID,attID,1], forKey: "\(i)")
                        self.status = -2
                    }
                    i += 1
                    self.arrAttendanceData.append(attendanceData)
                }
                
                let attendanceModal:BhadajStudentAttendanceModel = BhadajStudentAttendanceModel.init(Total: self.dictData["Total"]!.numberValue, TotalAbsent: self.dictData["TotalAbsent"]!.numberValue, TotalPresent: self.dictData["TotalPresent"]!.numberValue, TotalLeave: self.dictData["TotalLeave"]!.numberValue)
                self.displayStudentData(StudentAttendanceModel.init(BhadajModal: attendanceModal))
                self.btnFooter.isHidden = json!["HolidayFlag"].boolValue
                
                if(self.btnFooter.isHidden) {
                    Functions.showAlert(false, json!["Message"].stringValue)
                }
            }else {
                self.btnFooter.isHidden = true
                
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callAttendanceApi()
                    })
                }
            }
            self.tblAttendance.reloadData()
        }
    }
    
    // MARK: - Button Click Actions
    
    @IBAction func insertUpdateAttendence()
    {
        let attendenceData = StudentAttendanceModel.init(standardID: (dictData["StandardID"]?.numberValue)!, classID: (dictData["ClassID"]?.numberValue)!, Date: ((self.view.subviews[1] as! UIButton).titleLabel?.text)!)
        
        if(self.dictSelectedData != nil)
        {
            let arrStudentIds:NSMutableArray = []
            let arrAttendenceIds:NSMutableArray = []
            let arrAttendenceStatus:NSMutableArray = []
            
            for values in dictSelectedData.allValues {
                
                let data:NSArray = values as! NSArray
                arrStudentIds.add(data[0])
                arrAttendenceIds.add(data[1])
                arrAttendenceStatus.add(data[2])
            }
            
            guard dictSelectedData.count > 0 else {
                Functions.showAlert(true, self.status == -2 ? Message.attendenceAddSuccess : Message.attendenceUpdateSuccess)
                return
            }
            
            let params = ["StaffID":adminID!,
                          "CurrantDate":((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                          "StandardID":(attendenceData.StandardID?.stringValue)!,
                          "ClassID":(attendenceData.ClassID?.stringValue)!,
                          "Date":attendenceData.Date!,
                          "AttendanceID":arrAttendenceIds.componentsJoined(by: ","),
                          "StudentID":arrStudentIds.componentsJoined(by: ","),
                          "AttendacneStatus":arrAttendenceStatus.componentsJoined(by: ","),
                          "Comment":""]
            
            print(params)
            
            Functions.callApi(api: API.attendenceInsertUpdateApi, params: params) { (json,error) in
                
                if(json != nil) {
                    
                    self.status = 0
                    
                    Functions.showAlert(true, self.status == -2 ? Message.attendenceAddSuccess : Message.attendenceUpdateSuccess)
                    
                    self.dictData = ((json!["FinalArray"].array?.first)?.dictionaryValue)!
                    
                    let attendenceModal:BhadajStudentAttendanceModel = BhadajStudentAttendanceModel.init(Total: self.dictData["Total"]!.numberValue, TotalAbsent: self.dictData["TotalAbsent"]!.numberValue, TotalPresent: self.dictData["TotalPresent"]!.numberValue, TotalLeave: self.dictData["TotalLeave"]!.numberValue)
                    self.displayStudentData(StudentAttendanceModel.init(BhadajModal: attendenceModal))
                    
                }else if(error != nil) {
                    Functions.showDialog(finish: {
                        self.insertUpdateAttendence()
                    })
                }
            }
        }
    }
    
    // MARK: - Display Function
    
    func displayStudentData(_ studentData:StudentAttendanceModel)
    {
        if(status == -2){
            btnFooter.loadIconsFromLocal("Submit")
        } else {
            btnFooter.loadIconsFromLocal("Update")
        }
        
        let arrData = [studentData.BhadajModalValue?.Total,studentData.BhadajModalValue?.TotalPresent,studentData.BhadajModalValue?.TotalAbsent,studentData.BhadajModalValue?.TotalLeave]
        let arrColor = [GetColor.blue,GetColor.green,GetColor.red,GetColor.orange]
        
        var i = 1
        for view in tblHeaderView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i) {
                let lbl = view as! UILabel
                lbl.text = "\((lbl.text?.components(separatedBy: " : ").first)!) : \(arrData[i-1]!)"
                
                let attributedString = NSMutableAttributedString(
                    string: lbl.text!,
                    attributes: [:])
                
                let strSub:String = (lbl.text?.components(separatedBy: " : ").last)!
                
                attributedString.addAttribute(
                    NSAttributedStringKey.foregroundColor,
                    value: arrColor[i-1],
                    range: (lbl.text! as NSString).range(of: strSub))
                
                attributedString.addAttribute(
                    NSAttributedStringKey.font,
                    value: FontHelper.bold(size: 14),
                    range: (lbl.text! as NSString).range(of: strSub))
                
                lbl.attributedText = attributedString
                
                i += 1
            }
        }
    }
    
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 2:
                    self.addStandardDropDown(view)
                    
                default:
                    self.addSectionDropDown(3)
                }
                i += 1
                
            }else if(view.tag == i) {
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                i += 1
            }
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callAttendanceApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AttendanceVC:UITableViewDataSource,UITableViewDelegate,AttendanceCellDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        tblHeaderView.layoutIfNeeded()
        tblHeaderView.subviews[0].subviews.flatMap{$0 as? UIButton}.forEach{$0.layer.cornerRadius = $0.frame.size.width/2}
        return arrAttendanceData.count > 0 ? tblHeaderView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return arrAttendanceData.count > 0 ? DeviceType.isIpad ? 130 : 120 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAttendanceData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AttendanceCell = tableView.dequeueReusableCell(withIdentifier:"AttendanceCell", for: indexPath) as! AttendanceCell
        
        cell.cellDelegate = self
        cell.isUserInteractionEnabled = !(self.btnFooter.isHidden)
        if cell.isUserInteractionEnabled {
            cell.isUserInteractionEnabled = arrAttendanceData[indexPath.row].RowEnable
        }
        cell.displayData(attendanceData: arrAttendanceData[indexPath.row])
        cell.contentView.tag = arrAttendanceData.count + indexPath.row
        
        return cell
    }
    
    // MARK: - TableView Cell Delegate
    
    func insertUpdateData(_ sender:AnyObject)
    {
        let index:NSInteger = (sender.superview??.tag)!-self.arrAttendanceData.count
        
        let stuID:NSNumber = arrAttendanceData[index].StudentID!
        let attID:NSNumber = arrAttendanceData[index].AttendanceID!
        
        self.dictSelectedData.setValue([stuID,attID,sender.tag], forKey: "\(index)")
        
        let attendenceData:StudentAttendanceModel = self.arrAttendanceData[index]
        attendenceData.AttendanceStatus = "\((sender.tag)!)"
        
        self.arrAttendanceData.remove(at: index)
        self.arrAttendanceData.insert(attendenceData, at: index)
        
        self.tblAttendance.reloadRows(at: [NSIndexPath.init(row: index, section: 0) as IndexPath], with: .none)
    }
}
