//
//  LeaveModifyPopupVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 08/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

var selectedLeaveModifyModel:LeaveModel!
class LeaveModifyPopupVC: CustomViewController {
    
    @IBOutlet weak var mainView:UIView!
    @IBOutlet weak var btnStartDate:UIButton!
    @IBOutlet weak var btnEndDate:UIButton!
    
    var leaveDays:Double = 0
    var modifyLeaveBlock:(([String]) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        for view in mainView.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).setTitle(view.tag == 100 ? (selectedLeaveModifyModel.LeaveDate.components(separatedBy: "-").first)! : (selectedLeaveModifyModel.LeaveDate.components(separatedBy: "-").last)!, for: .normal)
            }
        }
        self.addDropDown()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension LeaveModifyPopupVC
{
    // MARK: - Add DropDown
    
    func addDropDown()
    {
        for view in mainView.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == 1){
                
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.tableHeight = CGFloat(5 * 35)
                var array:[Double] = []
                for i in 0..<30 {
                    array.append(Double(Double(i)+0.5))
                    array.append(Double(i+1))
                }
                dropDown.options = array.map{String($0)}
                dropDown.title.text = selectedLeaveModifyModel.LeaveDays
                dropDown.selectedIndex = array.index(of: Double(selectedLeaveModifyModel.LeaveDays)!)
                leaveDays = Double(selectedLeaveModifyModel.LeaveDays)!
                
                dropDown.didSelect { (option, index) in
                    dropDown.hideTable()
                    if(Double(option)! > self.leaveDays) {
                        dropDown.title.text = "\(self.leaveDays)"
                        Functions.showAlert(false, Message.noMoreDaySelect)
                        return
                    }
                    self.leaveDays = Double(option)!
                    self.btnEndDate.setTitle(Calendar.current.date(byAdding: .day, value: Int(round(Double(option)!))-1, to: (self.btnStartDate.title(for: .normal)?.toDate(dateFormat: "dd/MM/yyyy"))!)?.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                }
                mainView.addSubview(dropDown)
            }
        }
    }
}

// MARK: - Button Click Action

extension LeaveModifyPopupVC
{
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    @IBAction func btnSaveAction(_ sender:UIButton)
    {
        if(self.modifyLeaveBlock != nil){
            self.modifyLeaveBlock!([(btnStartDate.title(for: .normal))!, (btnEndDate.title(for: .normal))!, "\(self.leaveDays)"])
            self.btnClose()
        }
    }
}

extension LeaveModifyPopupVC
{
    override func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        btnEndDate.setTitle(Calendar.current.date(byAdding: .day, value: Int(round(Double(leaveDays)))-1, to: date)?.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}
