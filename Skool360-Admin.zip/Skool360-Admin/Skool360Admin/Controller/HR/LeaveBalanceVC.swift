//
//  LeaveBalanceVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 08/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class LeaveBalanceVC: CustomViewController {
    
    @IBOutlet weak var tblLeaveBalance:UITableView!
    
    var arrLeaveBalanceData = [LeaveModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self,selector: #selector(self.callGetLeaveBalance),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (_) in
            self.addTermDropDown(self.view.subviews[1])
            self.callGetLeaveBalance()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension LeaveBalanceVC
{
    @objc func callGetLeaveBalance()
    {
        arrLeaveBalanceData = []
        
        Functions.callApi(api: API.leaveBalanceApi, params: ["TermID" : strTermID]) { (json, error) in
            
            if(json != nil){
                
                let arrLBetails = json!["FinalArray"].array
                
                for values in arrLBetails! {
                    let leaveLBModel:LeaveModel = LeaveModel(empId: values["EmployeeID"].stringValue, empName: values["EmployeeName"].stringValue, plUsed: values["PLUSed"].stringValue, plTotal: values["TotalPL"].stringValue, clUsed: values["CLUsed"].stringValue, clTotal: values["TotalCL"].stringValue, total: values["Total"].stringValue, used: values["Used"].stringValue)
                    
                    self.arrLeaveBalanceData.append(leaveLBModel)
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetLeaveBalance()
                })
            }
            self.tblLeaveBalance.reloadData()
        }
    }
}

extension LeaveBalanceVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrLeaveBalanceData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrLeaveBalanceData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView:LeaveCell = tableView.dequeueReusableCell(withIdentifier: "LeaveBHeaderCell") as! LeaveCell
        return arrLeaveBalanceData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:LeaveCell = tableView.dequeueReusableCell(withIdentifier: "LeaveBCell") as! LeaveCell
        cell.displayLeaveBalanceData(arrLeaveBalanceData[indexPath.row])
        return cell
    }
}
