//
//  DailyReportVC.swift
//  Bhadaj (Teacher)
//
//  Created by ADMS on 30/08/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class DailyReportVC: CustomViewController {
    
    @IBOutlet var btnStartDate:UIButton!
    @IBOutlet var btnEndDate:UIButton!
    @IBOutlet var tblDailyReport:UITableView!
    
    var arrDailyReportDetails = [DailyReportModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblDailyReport.tableFooterView = UIView()
        
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
        self.perform(NSSelectorFromString("call\(self.title!.replacingOccurrences(of: " ", with: ""))DataApi"))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension DailyReportVC
{
    @objc func callTransportationDataApi()
    {
        arrDailyReportDetails = []
        
        let params = ["StartDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!]
        
        Functions.callApi(api: API.dailyTransportationApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrTransport = json!["FinalArray"].array
                
                for (i,values) in arrTransport!.enumerated() {
                    let dailyReportModel:DailyReportModel = DailyReportModel.init(index: "\(i+1)", date: values["Date"].stringValue, createBy: values["EmployeeName"].stringValue, routeProblem: values["RouteProblem"].stringValue, driverComplaint: values["DriverComplaint"].stringValue, parentsComplaint: values["ParentsComplaint"].stringValue, timingProblem: values["TimingProblem"].stringValue, vehicleProblem: values["VehicleProblem"].stringValue, other: values["Other"].stringValue)
                    
                    self.arrDailyReportDetails.append(dailyReportModel)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callTransportationDataApi()
                })
            }
            self.tblDailyReport.reloadData()
        }
    }
    
    @objc func callAccountDataApi()
    {
        arrDailyReportDetails = []
        
        let params = ["StartDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!]
        
        Functions.callApi(api: API.dailyAccountApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrAccount = json!["FinalArray"].array
                
                for (i,values) in arrAccount!.enumerated() {
                    let dailyReportModel:DailyReportModel = DailyReportModel.init(index: "\(i+1)", date: values["Date"].stringValue, createBy: values["EmployeeName"].stringValue, bankBalance: values["BankBalance"].stringValue, pettyCash: values["PettyCash"].stringValue, expenses: values["Expenses"].stringValue, feesReceived: values["FeesRecieved"].stringValue, depositedInBank: values["DepositedInBank"].stringValue, other: values["Other"].stringValue)
                    
                    self.arrDailyReportDetails.append(dailyReportModel)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callAccountDataApi()
                })
            }
            self.tblDailyReport.reloadData()
        }
    }
    
    @objc func callInformationTechnologyDataApi()
    {
        arrDailyReportDetails = []
        
        let params = ["StartDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!]
        
        Functions.callApi(api: API.dailyITApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrIT = json!["FinalArray"].array
                
                for (i,values) in arrIT!.enumerated() {
                    let dailyReportModel:DailyReportModel = DailyReportModel.init(index: "\(i+1)", date: values["Date"].stringValue, createBy: values["EmployeeName"].stringValue, laptopIssued: values["LaptopIssued"].stringValue, tabletIssued: values["TabletIssued"].stringValue, printing: values["Printing"].stringValue, it: values["IT"].stringValue, other: values["Other"].stringValue)
                    
                    self.arrDailyReportDetails.append(dailyReportModel)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callAccountDataApi()
                })
            }
            self.tblDailyReport.reloadData()
        }
    }
}

extension DailyReportVC
{
    @IBAction func btnSearchAction(_ sender:UIButton) {
        self.perform(NSSelectorFromString("call\(self.title!.replacingOccurrences(of: " ", with: ""))DataApi"))
    }
}

extension DailyReportVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:DailyReportCell = tableView.dequeueReusableCell(withIdentifier: "DailyReportHeaderCell") as! DailyReportCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0, 0)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        headerView.btnExpand.transform = .identity
        if section == selectedIndex {
            UIView.animate(withDuration: 0.5, animations: {
                headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
            })
        };
        headerView.displayDailyReportHeaderDetails(arrDailyReportDetails[section])
        return arrDailyReportDetails.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return arrDailyReportDetails.count > 0 ? (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50)) : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrDailyReportDetails.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblDailyReport.rowHeight == 0 ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:DailyReportCell = tableView.dequeueReusableCell(withIdentifier: "\(self.title!.replacingOccurrences(of: " ", with: ""))Cell", for: indexPath) as! DailyReportCell
        
        switch (self.title)! {
        case "Transportation":
            cell.displayTransportationData(arrDailyReportDetails[indexPath.section])
        case "Account":
            cell.displayAccountData(arrDailyReportDetails[indexPath.section])
        default:
            cell.displayITData(arrDailyReportDetails[indexPath.section])
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblDailyReport.reloadSections(IndexSet(integersIn: 0...arrDailyReportDetails.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblDailyReport.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}
