//
//  MenuPermissionVC.swift
//  Skool360Admin
//
//  Created by ADMS on 24/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class MenuPermissionVC: CustomViewController {
    
    @IBOutlet var tblMenuPermission:UITableView!
    @IBOutlet var btnSubmit:UIButton!
    
    var radioFlag:String = "Teacher"
    var selectedCheckBoxes:[Int] = []
    //    var unSelectedCheckBoxes:[Int] = [0,0,0]
    
    var arrPageListData = [MenuPermissionModel]()
    
    var arrPageIds:[String] = []
    var arrAllIds:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var i = 10
        for view in self.view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 1){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTeachersApi { (success) in
            self.addDropDown()
        }
    }
    
    // MARK: Function for Radio Button Selection
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in self.view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        if radioFlag != (tag == 1 ? "Teacher" : "Other") {
            radioFlag = tag == 1 ? "Teacher" : "Other"
            self.callGetTeachersApi { (success) in
                self.addDropDown()
            }
        }
        radioFlag = tag == 1 ? "Teacher" : "Other"
        
        let radioButton:LTHRadioButton = self.view.subviews[tag] as! LTHRadioButton
        radioButton.select(animated: true)
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dd:UIDropDown = view as! UIDropDown
            if(dd.table != nil){
                dd.hideTable()
            }
            view.removeFromSuperview()
        }
        
        let dropDown:UIDropDown = UIDropDown(frame: self.view.subviews[3].frame)
        dropDown.placeholder = Constants.dropDownPlaceholder
        
        self.strEmpID = dicTeachers.value(forKey: self.arrTeachers[0]) as! String
        dropDown.options = self.arrTeachers
        dropDown.tableHeight = self.arrTeachers.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrTeachers .count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = self.arrTeachers[0]
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strEmpID = self.dicTeachers.value(forKey: option) as! String
            self.callGetPageList()
        }
        self.view.addSubview(dropDown)
        self.callGetPageList()
    }
    
    // MARK: Api Calling
    
    func callGetTeachersApi(completion:@escaping (Bool) -> Void)
    {
        dicTeachers = [:]
        
        Functions.callApi(api: API.getTeachersApi, params: ["Type" : radioFlag]) { (json,error) in
            
            if(json != nil){
                
                let arrayTeachers = json!["FinalArray"].array
                
                for value in arrayTeachers! {
                    self.dicTeachers.setValue(value["Pk_EmployeeID"].stringValue, forKey: value["Emp_Name"].stringValue)
                }
                self.arrTeachers = self.dicTeachers.sortedDictionary(self.dicTeachers).0
                completion(true)
            }
        }
    }
    
    // MARK: Api Calling
    
    func callGetPageList()
    {
        let params = ["EmployeeID" : self.strEmpID!,
                      "flag" : radioFlag]
        
        print(params)
        
        self.refreshArray()
        
        Functions.callApi(api: API.getPageListApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayPageList = json!["FinalArray"].array
                
                for (index,value) in arrayPageList!.enumerated() {
                    
                    let menuPermissionModal:MenuPermissionModel = MenuPermissionModel.init(index: "\(index+1)", pageName: value["Page_Nam"].stringValue, pageUnderName: value["Page_UnderName"].stringValue, pageId: value["PK_PageID"].stringValue, status: value["Status"].boolValue, isUpdate: value["IsUserUpdate"].boolValue, isDelete: value["IsUserDelete"].boolValue, isView: value["IsUserView"].boolValue, pageUrl: value["Page_URL"].stringValue, visibleStatus: value["VisibleStatus"].boolValue, visibleUpdateStatus: value["VisibleIsUpdate"].boolValue, visibleDeleteStatus: value["VisibleIsDelete"].boolValue, visibleViewStatus: value["VisibleIsView"].boolValue)
                    
                    if(value["Status"].boolValue || value["IsUserUpdate"].boolValue || value["IsUserDelete"].boolValue || value["IsUserView"].boolValue)
                    {
                        self.addRemoveIds(menuPermissionModal)
                    }
                    self.arrPageListData.append(menuPermissionModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetPageList()
                })
            }
            self.btnSubmit.isHidden = self.arrPageListData.count > 0 ? false : true
            self.tblMenuPermission.reloadData()
        }
    }
    
    func callSubmitPageList()
    {
        let params = ["Pk_EmployeID" : self.strEmpID!,
                      "Pages" : self.arrAllIds.joined(separator: ",")]
        
        print(params)
        
        Functions.callApi(api: API.insertMenuPermissionApi, params: params) { (json,error) in
            
            if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSubmitPageList()
                })
            }
        }
    }
    
    @IBAction func btnSubmitAction(_ sender:UIButton)
    {
        self.callSubmitPageList()
    }
    
    func refreshArray()
    {
        self.arrPageListData = []
        self.selectedCheckBoxes = []
        //        self.unSelectedCheckBoxes = [0,0,0]
        self.arrPageIds = []
        self.arrAllIds = []
        self.refreshButton()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MenuPermissionVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let strIdentifier:String = radioFlag == "Teacher" ? "MenuPermissionTHeaderCell" : "MenuPermissionOHeaderCell"
        
        let headerView:MenuPermissionCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier) as! MenuPermissionCell
        
        var i = 10
        for view in headerView.contentView.subviews[0].subviews {
            
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                
                if(selectedCheckBoxes.contains(checkBox.tag)){
                    checkBox.setOn(true, animated: true)
                }else{
                    checkBox.setOn(false, animated: true)
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    
                    switch(checkBox.tag)
                    {
                    case 2,3:
                        if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[checkBox.tag-1] == "false") {
                            checkBox.setOn(false, animated: true)
                            Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: checkBox.tag == 2 ? "edit" : "delete"))
                            return
                        }
                    default:
                        break
                    }
                    
                    if(isOn){
                        self.selectedCheckBoxes.append(checkBox.tag)
                        //self.unSelectedCheckBoxes[checkBox.tag-1] = 0
                    }else{
                        self.selectedCheckBoxes.remove(at: self.selectedCheckBoxes.index(of: checkBox.tag)!)
                        //self.unSelectedCheckBoxes[checkBox.tag-1] = checkBox.tag
                    }
                    checkBox.setOn(isOn, animated: true)
                    tableView.reloadData()
                    
                    for values in self.arrPageListData {
                        
                        switch(checkBox.tag){
                        case 1:
                            values.Status = isOn
                        case 2:
                            values.IsUserUpdate = isOn
                        case 3:
                            values.IsUserDelete = isOn
                        default:
                            values.IsUserView = isOn
                        }
                        self.addRemoveIds(values)
                    }
                }
            }else if(view.tag == i){
                (view as! UILabel).font = FontHelper.medium(size: DeviceType.isIpad ? 15 : 12)
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(checkBoxSelectUnSelect(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }else if(view.isKind(of: UILabel.classForCoder())){
                (view as! UILabel).font = FontHelper.medium(size: DeviceType.isIpad ? 15 : 12)
            }
        }
        return self.arrPageListData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return self.arrPageListData.count > 0 ? radioFlag == "Teacher" ? 60 : 75 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrPageListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let strIdentifier:String = radioFlag == "Teacher" ? "MenuPermissionTCell" : "MenuPermissionOCell"
        
        let cell:MenuPermissionCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! MenuPermissionCell
        
        if self.arrPageListData.count > 0
        {
            let menuPermissionModal:MenuPermissionModel = self.arrPageListData[indexPath.row]
            cell.displayData(menuPermissionModal)
            
            let arrayStatus:[Bool] = [self.arrPageListData[indexPath.row].Status, self.arrPageListData[indexPath.row].IsUserUpdate, self.arrPageListData[indexPath.row].IsUserDelete, self.arrPageListData[indexPath.row].IsUserView]
            
            let arrayVisibleStatus:[Bool] = [self.arrPageListData[indexPath.row].VisibleStatus, self.arrPageListData[indexPath.row].VisibleUpdateStatus, self.arrPageListData[indexPath.row].VisibleDeleteStatus, self.arrPageListData[indexPath.row].VisibleViewStatus]

            var i = 0
            for view in cell.contentView.subviews[0].subviews {
                
                if(view.isKind(of: VKCheckbox.classForCoder())) {
                    
                    let checkBox:VKCheckbox = view as! VKCheckbox
                    checkBox.isUserInteractionEnabled = true
                    checkBox.isHidden = !arrayVisibleStatus[i]
                    
                    if(selectedCheckBoxes.contains(checkBox.tag)) {
                        checkBox.setOn(true, animated: true)
                    }
                    else {
                        //                        if(unSelectedCheckBoxes.contains(checkBox.tag)) {
                        //                            checkBox.setOn(false, animated: true)
                        //                        }
                        //                        else {
                        checkBox.setOn(arrayStatus[i], animated: true)
                        //                        }
                    }
                    i += 1
                    
                    checkBox.checkboxValueChangedBlock = {
                        isOn in
                        
                        checkBox.setOn(isOn, animated: true)
                        if(self.selectedCheckBoxes.contains(checkBox.tag)){
                            self.selectedCheckBoxes.remove(at: self.selectedCheckBoxes.index(of: checkBox.tag)!)
                            self.tblMenuPermission.reloadSections(IndexSet(integersIn: 0...0), with: .automatic)
                        }
                        
                        switch(checkBox.tag){
                        case 1:
                            menuPermissionModal.Status = isOn
                        case 2:
                            menuPermissionModal.IsUserUpdate = isOn
                        case 3:
                            menuPermissionModal.IsUserDelete = isOn
                        default:
                            menuPermissionModal.IsUserView = isOn
                        }
                        self.addRemoveIds(menuPermissionModal)
                        
                        /*
                         */
                        
                        self.arrPageListData[indexPath.row] = menuPermissionModal
                        self.tblMenuPermission.reloadRows(at: [IndexPath.init(row: indexPath.row, section: 0)], with: .automatic)
                    }
                }else{
                    (view as! UILabel).font = FontHelper.regular(size: DeviceType.isIpad ? 15 : 12)
                }
            }
        }
        return cell
    }
    
    @objc func checkBoxSelectUnSelect(_ gesture:UITapGestureRecognizer)
    {
        let tag:NSInteger = (gesture.view?.tag)! / 10
        let checkBox:VKCheckbox = gesture.view?.superview?.viewWithTag(tag) as! VKCheckbox
        checkBox.setOn(!checkBox.isOn(), animated: true)
        
        if(checkBox.isOn()){
            self.selectedCheckBoxes.append(checkBox.tag)
        }else{
            self.selectedCheckBoxes.remove(at: self.selectedCheckBoxes.index(of: checkBox.tag)!)
        }
        self.tblMenuPermission.reloadData()
    }
    
    func addRemoveIds(_ menuPermissionModal:MenuPermissionModel)
    {
        if !self.arrPageIds.contains(menuPermissionModal.PK_PageID)
        {
            self.arrPageIds.append(menuPermissionModal.PK_PageID)
            self.arrAllIds.append("\(menuPermissionModal.PK_PageID!)|\(menuPermissionModal.Page_URL!)|\(menuPermissionModal.Status!)|\(menuPermissionModal.IsUserUpdate!)|\(menuPermissionModal.IsUserDelete!)|\(menuPermissionModal.IsUserView!)|\(menuPermissionModal.VisibleStatus!)|\(menuPermissionModal.VisibleUpdateStatus!)|\(menuPermissionModal.VisibleDeleteStatus!)|\(menuPermissionModal.VisibleViewStatus!)")
        }
        else
        {
            let idx:NSInteger = self.arrPageIds.index(of: menuPermissionModal.PK_PageID)!
            
            if(!menuPermissionModal.Status && !menuPermissionModal.IsUserUpdate && !menuPermissionModal.IsUserDelete && !menuPermissionModal.IsUserView)
            {
                self.arrAllIds.remove(at: idx)
                self.arrPageIds.remove(at: idx)
                self.refreshButton()
                return
            }
            self.arrAllIds[idx] = "\(menuPermissionModal.PK_PageID!)|\(menuPermissionModal.Page_URL!)|\(menuPermissionModal.Status!)|\(menuPermissionModal.IsUserUpdate!)|\(menuPermissionModal.IsUserDelete!)|\(menuPermissionModal.IsUserView!)|\(menuPermissionModal.VisibleStatus!)|\(menuPermissionModal.VisibleUpdateStatus!)|\(menuPermissionModal.VisibleDeleteStatus!)|\(menuPermissionModal.VisibleViewStatus!)"
        }
        self.refreshButton()
    }
    
    func refreshButton()
    {
        btnSubmit.isEnabled = self.arrPageIds.count > 0 ? true : false
        btnSubmit.alpha = btnSubmit.isEnabled ? 1.0 : 0.5
    }
}
