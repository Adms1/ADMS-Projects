//
//  OnlineTransactionVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 05/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class OnlineTransactionVC: CustomViewController {
    
    @IBOutlet weak var tblOnlineTransaction:UITableView!
    @IBOutlet weak var txtTransactionID:DropDownTextField!
    
    var arrTransactionIDData:[String] = []
    var arrTransactionIDSearchData:[String] = []
    var arrOnlineTransactionData = [OnlineTransactionModel]()
    var status:Int = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for view in view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.addAutoCompleteMenu()
        self.callGetOnlineTransactionID {
            self.addStatusDropDown()
            self.callGetOnlineTransaction()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension OnlineTransactionVC
{
    func callGetOnlineTransactionID(completion:@escaping () -> ())
    {
        arrTransactionIDSearchData = []
        arrTransactionIDData = []
        
        Functions.callApi(api: API.getOnlineTransactionIDApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrTransactionIDs = json!["FinalArray"].array
                
                for values in arrTransactionIDs! {
                    self.arrTransactionIDData.append(values["TransactionID"].stringValue)
                }
                self.arrTransactionIDSearchData = self.arrTransactionIDData.map{ $0 }
                
                completion()
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetOnlineTransactionID {}
                })
            }else{
                completion()
            }
            self.tblOnlineTransaction.reloadData()
        }
    }
    
    func callGetOnlineTransaction()
    {
        arrOnlineTransactionData = []
        
        let params = ["StartDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!,
                      "Status" : "\(status)",
            "TransactionID" : txtTransactionID.text!]
        
        print(params)
        
        Functions.callApi(api: API.onlineTransactionListApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrOnlineData = json!["FinalArray"].array
                
                for values in arrOnlineData! {
                    let onlineTransactionModel:OnlineTransactionModel = OnlineTransactionModel.init(transactionId: values["TransactionID"].stringValue, paymentId: values["PaymentID"].stringValue, date: values["Date"].stringValue, studentName: values["StudentName"].stringValue, grade: values["Grade"].stringValue, amount: values["Amount"].stringValue, status: values["Status"].stringValue)
                    self.arrOnlineTransactionData.append(onlineTransactionModel)
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetOnlineTransaction()
                })
            }
            self.tblOnlineTransaction.reloadData()
        }
    }
}

extension OnlineTransactionVC
{
    // MARK: AutoCompleteMenu
    
    func addAutoCompleteMenu()
    {
        txtTransactionID.dropDownTableView.tag = 1
        txtTransactionID.dropDownTableView.dataSource = self
        txtTransactionID.dropDownTableView.delegate = self
        
        txtTransactionID.dropDownTableView.isHidden = true
        txtTransactionID.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    func addStatusDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(100)!.frame)
        dropDown.options = ["All", "Unsettled", "Settled"]
        dropDown.tableHeight = CGFloat(3 * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = "All"
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.status = index - 1
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton) {
        self.callGetOnlineTransaction()
    }
}

extension OnlineTransactionVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.becomeFirstResponder()
    }
    
    @objc func textFieldDidChange(_ textField: DropDownTextField) {
        
        let filtered = arrTransactionIDSearchData.filter { $0.range(of: textField.text!, options: .caseInsensitive) != nil }
        arrTransactionIDData = textField.text == "" ? [] : filtered
        if(arrTransactionIDData.count == 0){
            textField.dropDownTableView.isHidden = true
            return
        }
        textField.dropDownTableView.isHidden = false
        textField.dropDownTableView.reloadData()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        dismissPicker()
        return true
    }
    
    override func dismissPicker(){
        txtTransactionID.resignFirstResponder()
        if txtTransactionID.dropDownTableView.isHidden == false {
            txtTransactionID.dropDownTableView.isHidden = true
        }
        self.view.endEditing(true)
    }
}

extension OnlineTransactionVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView.tag == 1 ? arrTransactionIDData.count : 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return tableView.tag == 1 ? 1 : arrOnlineTransactionData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return tableView.tag == 1 ? 0 : arrOnlineTransactionData.count > 0 ? (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50)) : 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = DeviceType.isIpad ? 50 : 40
        return tableView.tag == 1 ? 30 : indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView:OnlineTransactionCell = tableView.dequeueReusableCell(withIdentifier: "OnlineTransactionHeaderCell") as! OnlineTransactionCell
        
        if(tableView.tag != 1)
        {
            headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0, 0)
            
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
            headerView.contentView.tag = section
            headerView.contentView.addGestureRecognizer(tapGesture)
            
            headerView.btnExpand.transform = .identity
            if section == selectedIndex {
                UIView.animate(withDuration: 0.5, animations: {
                    headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
                })
            };
            
            headerView.displayOnlineTransactionHeaderDetails(arrOnlineTransactionData[section])
        }
        return tableView.tag == 1 ? nil : arrOnlineTransactionData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 1 {
            var cell = txtTransactionID.dropDownTableView.dequeueReusableCell(withIdentifier: "Cell")
            if cell == nil {
                cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
                cell?.selectionStyle = .none
            }
            
            cell?.textLabel?.font = FontHelper.regular(size: DeviceType.isIpad ? 15 :12)
            cell!.textLabel!.text = arrTransactionIDData[indexPath.row]
            
            return cell!
        }
        else {
            let cell:OnlineTransactionCell = tableView.dequeueReusableCell(withIdentifier: "OnlineTransactionCell") as! OnlineTransactionCell
            cell.displayOnlineTransactionDetails(arrOnlineTransactionData[indexPath.row])
            return cell
        }
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblOnlineTransaction.reloadSections(IndexSet(integersIn: 0...arrOnlineTransactionData.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblOnlineTransaction.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView.tag == 1 {
            let cell = txtTransactionID.dropDownTableView.cellForRow(at: indexPath)
            txtTransactionID.text = cell?.textLabel?.text
            self.dismissPicker()
        }
    }
}
