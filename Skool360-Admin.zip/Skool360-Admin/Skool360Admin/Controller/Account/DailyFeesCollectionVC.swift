//
//  DailyFeesStructureVC.swift
//  Skool360Admin
//
//  Created by ADMS on 30/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class DailyFeesCollectionVC: CustomViewController {
    
    @IBOutlet var tblDailyFeesCollection:UITableView!
    
    var arrDailyFeesData = [DailyFeesCollectionModal]()
    var strPaymentMode:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.addDropDown()
        }
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addSelectTermDropDown()
                    
                case 3:
                    self.addStandardDropDown(view)
                    
                case 4:
                    self.addSelectPaymentModeDropDown()
                    self.callDailyFeesCollectionApi()
                    
                default:
                    break
                }
                i += 1
            }
            else if(view.tag == i){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                i += 1
            }
        }
    }
    
    func addSelectTermDropDown()
    {
        let arrTerms = ["Term 1", "Term 2"]
        let strValue:String = arrTerms[Int(strTermDetail)! - 1]
        
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(2)?.frame)!)
        dropDown.options = arrTerms
        dropDown.tableHeight = CGFloat(arrTerms.count * 35)
        dropDown.selectedIndex = Int(strTermDetail)! - 1
        dropDown.title.text = strValue
        
        dropDown.didSelect { (option, index) in
            strTermDetail = "\(index+1)"
        }
        self.view.addSubview(dropDown)
    }
    
    func addSelectPaymentModeDropDown()
    {
        strPaymentMode = "All"
        
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(4)?.frame)!)
        dropDown.options = self.dicData[self.title!] as! [String]
        dropDown.tableHeight = CGFloat(4 * 35)
        dropDown.selectedIndex = 3
        dropDown.title.text = strPaymentMode
        
        dropDown.didSelect { (option, index) in
            self.strPaymentMode = option
        }
        self.view.addSubview(dropDown)
    }
    
    
    func callDailyFeesCollectionApi()
    {
        let params = ["TermID" : strTermID,
                      "TermDetailID" : strTermDetail,
                      "Standard" : strStdID!,
                      "Mode" : strPaymentMode!]
        
        print(params)
        
        arrDailyFeesData = []
        selectedIndex = -1
        previousIndex = -1
        
        Functions.callApi(api: API.dailyFeeCollectionApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayDailyfees = json!["FinalArray"].array
                
                for value in arrayDailyfees! {                
                    self.arrDailyFeesData.append(DailyFeesCollectionModal(StudentName: value["Name"].stringValue, GRNO: value["GRNO"].stringValue, Standard: value["Standard"].stringValue, TotalFees: value["TotalFees"].stringValue, TotalReceiveFees: value["ReceivedFees"].stringValue, PendingFees: value["PendingFees"].stringValue))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDailyFeesCollectionApi()
                })
            }
            self.tblDailyFeesCollection.reloadData()
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callDailyFeesCollectionApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension DailyFeesCollectionVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:DailyFeesCollectionCell = tableView.dequeueReusableCell(withIdentifier: "DailyFeesCollectionHeaderCell") as! DailyFeesCollectionCell
        
        headerView.headerHeight.constant = section == 0 ? DeviceType.isIpad ? 45 : 40 : 0
        headerView.lblDay.superview?.addShadowWithRadius(2.0, 0, 0)
        
        //        if(section == previousIndex) {
        //            headerView.lblDay.textColor = .red
        //        }else
        if section == selectedIndex {
            headerView.lblDay.textColor = GetColor.green
        }else{
            headerView.lblDay.textColor = .red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblDay.tag = section
        headerView.lblDay.addGestureRecognizer(tapGesture)
        
        headerView.displayHeaderData(arrDailyFeesData[section], section+1)
        return arrDailyFeesData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrDailyFeesData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        tableView.estimatedSectionHeaderHeight = 90
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = DeviceType.isIpad ? 50 : 40
        return indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String = "DailyFeesCollectionTitleCell"
        if indexPath.row > 0 {
            strIdentifier = "DailyFeesCollectionCell"
        }
        
        let cell:DailyFeesCollectionCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! DailyFeesCollectionCell
        
        for view in cell.contentView.subviews[0].subviews{
            if(view.isKind(of: UIImageView.classForCoder())) {
                let imgView:UIImageView = view as! UIImageView
                indexPath.row > 0 ? imgView.image = UIImage.init(named: "") : imgView.loadIconsFromLocal("BlueBox")
            }else{
                let lbl:UILabel = view as! UILabel
                lbl.textColor = indexPath.row > 0 ? .black : .white
                lbl.font = indexPath.row == 0 ? FontHelper.medium(size:  DeviceType.isIpad ? 16 : 13) : FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
                if(lbl.tag == -2){
                    lbl.backgroundColor = indexPath.row > 0 ? UIColor.lightGray.withAlphaComponent(0.3) : .white
                }
            }
        }
        
        if indexPath.row > 0 {
            cell.displayData(arrDailyFeesData[indexPath.section])
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        if(previousIndex != -1){
            //tblDailyFeesCollection.reloadSections(NSIndexSet(index: previousIndex) as IndexSet, with: .automatic)
        }
        
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblDailyFeesCollection.reloadData()
        self.tblDailyFeesCollection.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
        
        previousIndex = selectedIndex
    }
}
