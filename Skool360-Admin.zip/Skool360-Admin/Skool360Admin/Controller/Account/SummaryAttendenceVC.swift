//
//  SummaryAttendence.swift
//  Skool360Admin
//
//  Created by ADMS on 09/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

class SummaryAttendanceVC: CustomViewController {
    
    @IBOutlet var tblAttendance:UITableView!
    
    var arrAttendanceData = [AttendanceModal]()
    var arrStandardData = [StandardModal]()
    var arrAbsentData = [AbsentModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if self.view.tag != -1000 {
            view.subviews[0].addConstraint(NSLayoutConstraint.init(item: view.subviews[0], attribute: .height, relatedBy: .equal, toItem: view.subviews[0], attribute: .width, multiplier: 0, constant: 0))
            self.view.layoutIfNeeded()
        }
        self.view.subviews[0].isHidden = self.view.tag == -1000 ? false : true
        
        self.callGetAttendanceDataApi()
    }
    
    func callGetAttendanceDataApi()
    {
        let params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy")]
        
        arrAttendanceData = []
        arrStandardData = []
        arrAbsentData = []
        
        Functions.callApi(api: API.admin_StudentAttendenceApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let stuDict = json!["FinalArray"].array?.first
                
                let arrayStd = json!["StandardWiseAttendance"].array
                for values in arrayStd! {                    
                    self.arrStandardData.append(StandardModal(Standard: values["Standard"].stringValue, Class: values["Class"].stringValue, TotalStudent: values["TotalStudent"].stringValue, Present: values["Present"].stringValue, Absent: values["Absent"].stringValue, Leave: values["Leave"].stringValue))
                }
                //let standardModal:StandardModal = StandardModal.init(standard: "Standard", status: "Status")
                //self.arrStandardData.insert(standardModal, at: 0)
                
                /*
                 */
                
                //Functions.callApi(api: API.admin_StaffAttendenceApi, params: params) { (json,error) in
                
                if(json != nil){
                    
                    let staffdict = json!["FinalArray"].array?.first
                    let arrStr = ["Absent","Leave","Present","Total"]
                    
                    for i in 0..<4 {
                        let strStatus:String = arrStr[i]
                        self.arrAttendanceData.append(AttendanceModal(stuStatus: stuDict![i == 3 ? "\(strStatus)Student" : "Student\(strStatus)"].stringValue, status: strStatus, staffStatus: staffdict![i == 3 ? "\(strStatus)Staff" : "Staff\(strStatus)"].stringValue))
                    }
                    
                    let arrayAbsent = json!["ConsistentAbsent"].array
                    for values in arrayAbsent! {
                        self.arrAbsentData.append(AbsentModal(Name: values["StudentName"].stringValue.capitalized, Standard: values["Standard"].stringValue, Class: values["Class"].stringValue, Days: values["Days"].stringValue))
                    }
                    //let absentModal:AbsentModal = AbsentModal.init(empName: "Employee", days: "Days")
                    //self.arrAbsentData.insert(absentModal, at: 0)
                }
                self.tblAttendance.reloadData()
                //}
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAttendanceDataApi()
                })
            }
            self.tblAttendance.reloadData()
        }
    }
}

extension SummaryAttendanceVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:SummaryItemCell = tableView.dequeueReusableCell(withIdentifier: "SummaryHeaderCell") as! SummaryItemCell
        switch section {
        case 0:
            headerView.lblHeader.text = "Attendance"
        case 1:
            headerView.lblHeader.text = "Standard Wise Attendance"
        default:
            headerView.lblHeader.text = "Consistence Absent Student"
        }
        headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 23 : 20)
        return (arrStandardData.count > 0 && arrAttendanceData.count > 0)  ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return (arrStandardData.count > 0 && arrAttendanceData.count > 0) ?60 : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if arrStandardData.count > 0 && arrAttendanceData.count > 0 {
            return 3
        }
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            switch(indexPath.row){
            case 4:
                return 100
            default:
                return 40
            }
        }else {
            switch(indexPath.row){
            case 0:
                return 50
            default:
                return indexPath.section == 1 ? (indexPath.row == self.arrStandardData.count ? 50 : 40) : (indexPath.row == self.arrAbsentData.count ? 60 : 50)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return (self.arrAttendanceData.count > 0 ? self.arrAttendanceData.count + 1 : 0)
        case 1:
            return (self.arrStandardData.count > 0 ? self.arrStandardData.count + 1 : 0)
        default:
            return (self.arrAbsentData.count > 0 ? self.arrAbsentData.count + 1 : 0)
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                strIdentifier = "SummaryItemHeaderCell"
            }else if (indexPath.row == 4){
                strIdentifier = "SummaryItemFooterCell"
            }else{
                strIdentifier = "SummaryItemCell"
            }
        } else if indexPath.section == 1 {
            if indexPath.row == 0 {
                strIdentifier = "SummaryHeaderItemCell"
            }else {
                strIdentifier = "SummaryItem"
            }
        }else {
            if indexPath.row == 0 {
                strIdentifier = "SummaryHeaderAbsentCell"
            }else {
                strIdentifier = "AbsentItem"
            }
        }
        
        let cell:SummaryItemCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! SummaryItemCell
        
        if indexPath.section == 0 && strIdentifier != "SummaryItemHeaderCell" {
            cell.displayAttendanceItemData(indexPath.row, arrAttendanceData[indexPath.row-1])
        }
        
        if indexPath.section > 0 {
            cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
            cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
            
            if(indexPath.row > 0) {
                if(indexPath.row == (indexPath.section == 1 ? arrStandardData.count : arrAbsentData.count)){
                    cell.viewBottom.constant = 10.0
                }else{
                    cell.viewBottom.constant = -1.0
                }
                
                if(indexPath.section == 1){
                    cell.displayStandardItemData(arrStandardData[indexPath.row-1])
                }else{
                    cell.displayAbsentItemData(arrAbsentData[indexPath.row-1])
                }
            }else{
                for lbl in (cell.contentView.subviews[0].subviews[0].subviews.flatMap{ $0 as? UILabel }) {
                    lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 18 : 14)
                }
            }
        }
        return cell
    }
}
