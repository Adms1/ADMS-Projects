//
//  ChequePaymentVC.swift
//  Skool360Admin
//
//  Created by ADMS on 02/02/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class ChequePaymentVC: CustomViewController {
    
    @IBOutlet var tblChequePayment:UITableView!
    
    var arrChequePaymentData = [ChequePaymentModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
        self.callChequePaymentApi()
    }
    
    // MARK: Api Calling
    
    func callChequePaymentApi()
    {
        arrChequePaymentData = []
        
        let params = ["Chequeno" : ((self.view.viewWithTag(2) as! UITextField).text)!,
                      "FromDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "ToDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!,]
        
        Functions.callApi(api: API.getReceiptDetailsApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrGetData = json!["FinalArray"].array
                
                for value in arrGetData! {
                    self.arrChequePaymentData.append(ChequePaymentModel(GRNO: value["GRNO"].stringValue, Date: value["PayDate"].stringValue, Status: value["ChequeStatus"].stringValue, Amount: value["Paid"].stringValue, ChequeNo: value["ChequeNo"].stringValue, Term: value["Term"].stringValue, ReceiptNo: value["ReceiptNo"].stringValue, AdmissionFees: value["AdmissionFee"].stringValue, TuitionFees: value["TuitionFee"].stringValue, TransportFees: value["Transport"].stringValue, Imprest: value["ImprestFee"].stringValue, LateFees: value["LatesFee"].stringValue, Discount: value["DiscountFee"].stringValue, PreviousFees: value["PreviousFees"].stringValue, PayPaidFees: value["PayPaidFees"].stringValue, CurrentOutstandingFees: value["CurrentOutstandingFees"].stringValue))
                }
                self.tblChequePayment.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callChequePaymentApi()
                })
            }
        }
    }
    
    @IBAction func btnChequePaymentSearchAction(_ sender:UIButton)
    {
        self.callChequePaymentApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ChequePaymentVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.becomeFirstResponder()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        textField.resignFirstResponder()
        return true
    }
}

extension ChequePaymentVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:ChequePaymentCell = tableView.dequeueReusableCell(withIdentifier: "ChequePaymentHeaderCell") as! ChequePaymentCell
        
        headerView.lblView.superview?.addShadowWithRadius(2.0, 0, 0)
        
        if section == selectedIndex {
            headerView.lblView.textColor = GetColor.green
        }else{
            headerView.lblView.textColor = .red
        }
        
        headerView.contentView.subviews[0].isHidden = section == 0 ? false : true
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblView.tag = section
        headerView.lblView.addGestureRecognizer(tapGesture)
        headerView.displayChequePaymentHeaderData(arrChequePaymentData[section])
        
        return arrChequePaymentData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrChequePaymentData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? 100 : 50
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == selectedIndex ? 1 : 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == selectedIndex ? DeviceType.isIpad ? 285 : 247 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:ChequePaymentCell = tableView.dequeueReusableCell(withIdentifier: "ChequePaymentCell", for: indexPath) as! ChequePaymentCell
        cell.displayChequePaymentData(arrChequePaymentData[indexPath.section])
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblChequePayment.reloadData()
        
        if(selectedIndex != -1) {
            tblChequePayment.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: true)
        }
    }
}
