//
//  SummaryCollectionVC.swift
//  Skool360Admin
//
//  Created by ADMS on 09/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class SummaryCollectionVC: CustomViewController {
    
    @IBOutlet var tblCollection:UITableView!
    @IBOutlet var topViewHeight:NSLayoutConstraint!
    
    var arrCollectionData = [CollectionModal]()
    var arrStandardCollectionData = [StandardCollectionModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.callCollectionApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        if self.view.tag != 1 {
            view.subviews[0].addConstraint(NSLayoutConstraint.init(item: view.subviews[0], attribute: .height, relatedBy: .equal, toItem: view.subviews[0], attribute: .width, multiplier: 0, constant: 0))
            self.view.layoutIfNeeded()
        }
        topViewHeight.constant = self.view.tag == -1000 ? 15 : 25
        self.view.subviews[0].isHidden = self.view.tag == -1000 ? false : true
        
        self.callGetTermApi(false) { (success) in
            self.addDropDown()
        }
    }
    
    @objc func callCollectionApi()
    {
        let params = ["Term_ID" : strTermID,
                      "TermDetailID" : strTermDetail]
        
        print(params)
        
        arrCollectionData = []
        arrStandardCollectionData = []
        
        Functions.callApi(api: API.totalFeesCollectionByTermApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dict = json!["FinalArray"].array?.first
                let dicCollection = dict!["Collection"].array?.first
                
                var arrAmtStr = ["Total Amt","Total Rcv","Total Due"]
                for i in 0..<3 {
                    let strAmountType:String = arrAmtStr[i].replacingOccurrences(of: " ", with: "")
                    self.arrCollectionData.append(CollectionModal(TotalAmount: "\(dicCollection![strAmountType].stringValue)\(i == 2 ? " (\(dicCollection!["TotalDuePer"].stringValue)%)" : "")", AmountType: arrAmtStr[i], StudentAmount: "\(dicCollection!["\(strAmountType)Student"].stringValue)\(i == 2 ? " (\(dicCollection!["DueStudentPer"].stringValue)%)" : "")"))
                }
                
                let arrayCollectionStd = dict!["StandardCollection"].array
                for values in arrayCollectionStd! {
                    self.arrStandardCollectionData.append(StandardCollectionModal(Standard: values["Standard"].stringValue, Total: "\(values["StdTotalFees"].stringValue) (\(values["StdStudent"].stringValue))", Received: "\(values["StdTotalRcv"].stringValue) (\(values["StdStudentRcv"].stringValue))", Dues: "\(values["StdTotalDues"].stringValue) (\(values["StdStudentDues"].stringValue))"))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callCollectionApi()
                })
            }
            self.tblCollection.reloadData()
        }
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                if(i == 1) {
                    self.addTermDropDown(view)
                }
                else
                {
                    self.addSelectTermDropDown()
                    self.callCollectionApi()
                }
                i += 1
            }
        }
    }
    
    func addSelectTermDropDown()
    {
        let arrTerms = ["Term 1", "Term 2"]
        let strValue:String = arrTerms[Int(strTermDetail)! - 1]
        
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(2)?.frame)!)
        dropDown.options = arrTerms
        dropDown.tableHeight = CGFloat(arrTerms.count * 35)
        dropDown.selectedIndex = Int(strTermDetail)! - 1
        dropDown.title.text = strValue
        
        dropDown.didSelect { (option, index) in
            strTermDetail = "\(index+1)"
            self.callCollectionApi()
        }
        self.view.addSubview(dropDown)
    }
}

extension SummaryCollectionVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:SummaryItemCell = tableView.dequeueReusableCell(withIdentifier: "SummaryHeaderCell") as! SummaryItemCell
        switch section {
        case 0:
            headerView.lblHeader.text = "Collection's"
        default:
            headerView.lblHeader.text = "Standard Wise Collection"
        }
        headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 23 : 20)
        return  arrCollectionData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrCollectionData.count > 0 ? 60 : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if arrCollectionData.count > 0 && arrStandardCollectionData.count > 0 {
            return 2
        }
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            switch(indexPath.row){
            case 3:
                return 120
            default:
                return DeviceType.isIphone5 ? 50 : 40
            }
        }else {
            return indexPath.row == self.arrStandardCollectionData.count ? 60 : 50
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? (self.arrCollectionData.count > 0 ? self.arrCollectionData.count + 1 : 0) : (self.arrStandardCollectionData.count > 0 ? self.arrStandardCollectionData.count + 1 : 0)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                strIdentifier = "SummaryItemHeaderCell"
            }else if (indexPath.row == 3){
                strIdentifier = "SummaryItemFooterCell"
            }else{
                strIdentifier = "SummaryItemCell"
            }
        } else {
            if indexPath.row == 0 {
                strIdentifier = "SummaryHeaderItemCell"
            }else {
                strIdentifier = "SummaryItem"
            }
        }
        let cell:SummaryItemCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! SummaryItemCell
        
        if indexPath.section == 0 && strIdentifier != "SummaryItemHeaderCell" {
            cell.displayCollectionItemData(arrCollectionData[indexPath.row - 1])
        }
        
        if indexPath.section == 1 {
            cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
            cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
            
            
            if(indexPath.row > 0) {
                if(indexPath.row == arrStandardCollectionData.count){
                    cell.viewBottom.constant = 10.0
                }else{
                    cell.viewBottom.constant = -1.0
                }; cell.displayStandardCollectionItemData(arrStandardCollectionData[indexPath.row-1])
            }else{
                for lbl in (cell.contentView.subviews[0].subviews[0].subviews.flatMap{ $0 as? UILabel }) {
                    lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 18 : 14)
                }
            }
        }
        return cell
    }
}
