//
//  DailyFeesStructureVC.swift
//  Skool360Admin
//
//  Created by ADMS on 30/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class StudentDiscountVC: CustomViewController {
    
    @IBOutlet var tblStudentDiscount:UITableView!
    
    var arrStudentDiscountData = [StudentDiscountModal]()
    var strDiscType:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.addDropDown()
        }
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addSelectOptionDropDown()
                    
                case 3:
                    self.addStandardDropDown(view)
                    self.callStudentDiscountApi()
                    
                default:
                    break
                }
                i += 1
            }
            else if(view.isKind(of: UITextField.classForCoder())){
                let txtfld:UITextField = view as! UITextField
                txtfld.font = FontType.regularFont
                txtfld.text = Date().toString(dateFormat: "dd/MM/yyyy")
                addBorderWithRadius(txtfld, GetColor.blue, 3.0, 1.0)
            }
        }
    }
    
    func addSelectOptionDropDown()
    {
        strDiscType = "2"
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(2)!.frame)
        dropDown.options = self.dicData[self.title!] as! [String]
        dropDown.tableHeight = CGFloat(3 * 35)
        dropDown.selectedIndex = 1
        dropDown.title.text = "All"
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strDiscType = "\(index+1)"
        }
        self.view.addSubview(dropDown)
    }
    
    func callStudentDiscountApi()
    {
        let params = ["TermID" : strTermID,
                      "Standard" : strStdID!,
                      "DiscType":strDiscType!]
        
        print(params)
        
        arrStudentDiscountData = []
        selectedIndex = -1
        previousIndex = -1
        
        Functions.callApi(api: API.getDiscountDetailApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayStudentDiscount = json!["FinalArray"].array
                
                for value in arrayStudentDiscount! {
                    self.arrStudentDiscountData.append(StudentDiscountModal(StudentName: value["Name"].stringValue, GRNO: value["GRNO"].stringValue, Standard: value["Standard"].stringValue, TotalFees: value["TotalFees"].stringValue, WaveOffAmt: value["WaveOffAmt"].stringValue, Discount: value["Discount"].stringValue, PayableAmt: value["PayableAmt"].stringValue))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callStudentDiscountApi()
                })
            }
            self.tblStudentDiscount.reloadData()
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callStudentDiscountApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StudentDiscountVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:StudentDiscountCell = tableView.dequeueReusableCell(withIdentifier: "StudentDiscountHeaderCell") as! StudentDiscountCell
        
        headerView.headerHeight.constant = section == 0 ? DeviceType.isIpad ? 45 : 40 : 0
        headerView.lblDay.superview?.addShadowWithRadius(2.0, 0, 0)
        
        if section == selectedIndex {
            headerView.lblDay.textColor = GetColor.green
        }else{
            headerView.lblDay.textColor = .red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblDay.tag = section
        headerView.lblDay.addGestureRecognizer(tapGesture)
        
        headerView.displayHeaderData(arrStudentDiscountData[section], section+1)
        return arrStudentDiscountData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrStudentDiscountData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        tableView.estimatedSectionHeaderHeight = 90
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == selectedIndex ? indexPath.row == 0 ?  DeviceType.isIpad ? 50 : 60 : DeviceType.isIpad ? 50 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String = "StudentDiscountTitleCell"
        if indexPath.row > 0 {
            strIdentifier = "StudentDiscountCell"
        }
        
        let cell:StudentDiscountCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! StudentDiscountCell
        
        for view in cell.contentView.subviews[0].subviews{
            if(view.isKind(of: UIImageView.classForCoder())) {
                let imgView:UIImageView = view as! UIImageView
                indexPath.row > 0 ? imgView.image = UIImage.init(named: "") : imgView.loadIconsFromLocal("BlueBox")
            }else{
                let lbl:UILabel = view as! UILabel
                lbl.textColor = indexPath.row > 0 ? .black : .white
                lbl.font = indexPath.row == 0 ? FontHelper.medium(size:  DeviceType.isIpad ? 16 : 13) : FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
                if(lbl.tag == -2){
                    lbl.backgroundColor = indexPath.row > 0 ? UIColor.lightGray.withAlphaComponent(0.3) : .white
                }
            }
        }
        
        if indexPath.row > 0 {
            cell.displayData(arrStudentDiscountData[indexPath.section])
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        if(previousIndex != -1){
            tblStudentDiscount.reloadSections(NSIndexSet(index: previousIndex) as IndexSet, with: .automatic)
        }
        
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblStudentDiscount.reloadData()
        self.tblStudentDiscount.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
        
        previousIndex = selectedIndex
    }
}

