//
//  DailyFeesStructureVC.swift
//  Skool360Admin
//
//  Created by ADMS on 30/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class ImprestVC: CustomViewController {
    
    @IBOutlet var tblImprest:UITableView!
    
    var arrImprestData = [ImprestModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.addDropDown()
        }
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addStandardDropDown(view)
                    self.callImprestDetailsApi()
                    
                default:
                    break
                }
                i += 1
            }
            else if(view.isKind(of: UITextField.classForCoder())){
                let txtfld:UITextField = view as! UITextField
                txtfld.text = Date().toString(dateFormat: "dd/MM/yyyy")
                addBorderWithRadius(txtfld, GetColor.blue, 3.0, 1.0)
            }
        }
    }
    
    func callImprestDetailsApi()
    {
        let params = ["TermID" : strTermID,
                      "Standard" : strStdID!]
        
        print(params)
        
        arrImprestData = []
        selectedIndex = -1
        previousIndex = -1
        
        Functions.callApi(api: API.getImprestDetailApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayImprest = json!["FinalArray"].array
                
                for value in arrayImprest! {
                    
                    self.arrImprestData.append(ImprestModal(StudentName: value["Name"].stringValue, GRNO: value["GRNO"].stringValue, Standard: value["Standard"].stringValue, TotalImprest: value["TotalImprest"].stringValue, DeductImprest: value["DeductImprest"].stringValue, RemainImprest: value["RemainImprest"].stringValue))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callImprestDetailsApi()
                })
            }
            self.tblImprest.reloadData()
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callImprestDetailsApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ImprestVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:ImprestCell = tableView.dequeueReusableCell(withIdentifier: "ImprestHeaderCell") as! ImprestCell
        
        headerView.headerHeight.constant = section == 0 ? DeviceType.isIpad ? 45 : 40 : 0
        headerView.lblDay.superview?.addShadowWithRadius(2.0, 0, 0)
        
        if section == selectedIndex {
            headerView.lblDay.textColor = GetColor.green
        }else{
            headerView.lblDay.textColor = .red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblDay.tag = section
        headerView.lblDay.addGestureRecognizer(tapGesture)
        
        headerView.displayHeaderData(arrImprestData[section], section+1)
        return arrImprestData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrImprestData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        tableView.estimatedSectionHeaderHeight = 90
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = DeviceType.isIpad ? 50 : 40
        return indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String = "ImprestTitleCell"
        if indexPath.row > 0 {
            strIdentifier = "ImprestCell"
        }
        
        let cell:ImprestCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! ImprestCell
        
        for view in cell.contentView.subviews[0].subviews{
            if(view.isKind(of: UIImageView.classForCoder())) {
                let imgView:UIImageView = view as! UIImageView
                indexPath.row > 0 ? imgView.image = UIImage.init(named: "") : imgView.loadIconsFromLocal("BlueBox")
            }else{
                let lbl:UILabel = view as! UILabel
                lbl.textColor = indexPath.row > 0 ? .black : .white
                lbl.font = indexPath.row == 0 ? FontHelper.medium(size:  DeviceType.isIpad ? 16 : 13) : FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
                if(lbl.tag == -2){
                    lbl.backgroundColor = indexPath.row > 0 ? UIColor.lightGray.withAlphaComponent(0.3) : .white
                }
            }
        }
        
        if indexPath.row > 0 {
            cell.displayData(arrImprestData[indexPath.section])
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        if(previousIndex != -1){
            //tblImprest.reloadSections(NSIndexSet(index: previousIndex) as IndexSet, with: .automatic)
        }
        
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblImprest.reloadData()
        self.tblImprest.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: false)
        
        previousIndex = selectedIndex
    }
}
