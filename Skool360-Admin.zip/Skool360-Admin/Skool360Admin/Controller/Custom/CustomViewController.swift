//
//  CustomViewController.swift
//  Skool360Admin
//
//  Created by ADMS on 14/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
//import KWTransition

var btnDate:UIButton!
var lastViewController:UIViewController!
var arrData:[String] = []
var arrSubData:[String] = []

class CustomViewController: UIViewController {
    
    //    let KWtransition:KWTransition = KWTransition.manager()
    var selectedIndex:NSInteger = -1
    var previousIndex:NSInteger = -1
    var strStatus:String = "1"
    var strStatusMode:Int = 1
    
    var strStd:String!
    var strStdID:String!
    var strEmpID:String!
    var strTerm:String!
    var strClass:String!
    var strClassID:String?
    var strSub:String!
    var strSubID:String!
    
    var dicData:NSDictionary = [:]
    let dicTerms:NSMutableDictionary = [:]
    let dicStandards:NSMutableDictionary = [:]
    var dicRoutes:NSMutableDictionary = [:]
    var dicTeachers:NSMutableDictionary = [:]
    var dicStdSections:NSMutableDictionary = [:]
    var dicTests:NSMutableDictionary = [:]
    var dicSubjects:NSMutableDictionary = [:]
    
    var arrTerms:Any!
    var arrStandards:[String] = []
    var arrRoutes:[String] = []
    var arrTeachers:[String] = []
    var arrSections:[String] = []
    var arrTests:[String] = []
    var arrSubjects:[String] = []
    
    override func viewDidLoad() {
        
        if let path = Bundle.main.path(forResource: "AdminList", ofType: "plist") {
            dicData = NSDictionary(contentsOfFile: path)!
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if !(self is SideMenuVC) {
            lastViewController = self.navigationController?.viewControllers.last
        }
        self.initalization()
    }
    
    func initalization()
    {
        if(self.view.subviews[0].subviews.count > 0 && !(self is MainVC) && !(self is SubMainVC) && !(self is SideMenuVC) && !(self is LeaveModifyPopupVC) && !(self is TimeTablePopupVC)) {
            
            let strTitle:String = (self.title! == "Result" || self.title! == "Online Payment" || self.title! == "Profile") ? "\(self.title!) Permission" : self.title!
            
            (self.view.subviews[0].subviews[0].subviews[1] as! UILabel).text = strTitle.uppercased()
            (self.view.subviews[0].subviews[0].subviews[2] as! UIButton).addTarget(self, action: #selector(btnBackAction), for: .touchUpInside)
            (self.view.subviews[0].subviews[0].subviews[3] as! UIButton).addTarget(self, action: #selector(openRightView(_:)), for: .touchUpInside)
        }
    }
    
    //    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
    //
    //        KWtransition.action = KWTransitionStep.present
    //        return KWtransition
    //    }
    //
    //    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
    //
    //        KWtransition.action = KWTransitionStep.dismiss
    //        return KWtransition
    //    }
    
    func callGetTermApi(_ flag:Bool, completionHandler:@escaping (Bool) -> Void)
    {
        Functions.callApi(api: API.getTermApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrTerm = json!["FinalArray"].array
                
                self.strTerm = json!["Term"].stringValue
                strTermID = json!["TermID"].stringValue
                
                for values in arrTerm! {
                    self.dicTerms.setValue(values["TermId"].stringValue, forKey: values["Term"].stringValue)
                }
                
                if(self.dicTerms.count > 0){
                    let sorted = zip(self.dicTerms.allKeys, self.dicTerms.allValues as! [String]).sorted { $0.1 < $1.1 }
                    self.arrTerms = sorted.map { $0.0 }
                    
                    if(flag){
                        self.callGetStandardsApi(completion: { (success) in
                            completionHandler(success)
                        })
                    }else{
                        completionHandler(true)
                    }
                }
            }
        }
    }
    
    func callGetStandardsApi(completion:@escaping (Bool) -> Void)
    {
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrStandards = json!["FinalArray"].array
                
                for value in arrStandards! {
                    if(self.strStdID == nil){
                        self.strStdID = value["StandardID"].stringValue
                    };
                    self.dicStandards.setValue(value["StandardID"].stringValue, forKey: "\(value["StandardID"].stringValue)-\(value["Standard"].stringValue)")
                }
                self.arrStandards = self.dicStandards.sortedDictionary(self.dicStandards).1
                
                let dict:NSMutableDictionary = [:]
                self.dicStandards.forEach { dict[$0] = $1 }
                
                for (key,value) in dict {
                    self.dicStandards.setValue(value, forKey: (key as! String).components(separatedBy: "-").last!)
                    self.dicStandards.removeObject(forKey: key)
                }
                completion(true)
            }
        }
    }
    
    @IBAction func btnChooseDateAction(_ sender:UIButton)
    {
        btnDate = sender
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDateRange.setStartDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        selector.optionCurrentDateRange.setEndDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    @IBAction func btnBackAction()
    {
        for controller in self.navigationController!.viewControllers as Array
        {
            if controller.isKind(of: self is StudentDetailVC ? (self.title?.contains("Profile"))! ? ViewEnquiryVC.self : SearchStudentVC.self : self is CircularVC ? CircularListVC.self : self is AnnouncementVC ? AnnouncementListVC.self : (self is LeaveRequestVC || self is SuggestionVC) && notificationModel != nil ? NotificationVC.self : (self is ResultPermissionVC || self is OnlinePaymentPermissionVC || self is ProfilePermissionVC ||  self is MarksSyllabusVC || self is CreateLeaveVC || self is LeaveBalanceVC || self is DailyReportVC || self is LeaveDetailsVC || self is LeaveRequestVC || self is InOutSummaryVC || self is EmployeePresentDetailsVC) ? SubMainVC.self : self is GRRegister_Left_StudentDetailsVC ? GRRegister_LeftDetailVC.self : self is MainVC ? DeshboardVC.self : MainVC.self) {
                self.navigationController?.pushPopTransition(controller,false)
                break
            }
            else {
                self.navigationController?.pushPopTransition(Constants.storyBoard.instantiateViewController(withIdentifier: "DeshboardVC"),true)
            }
        }
        isFromPush = false
        notificationModel = nil
    }
}

extension CustomViewController:WWCalendarTimeSelectorProtocol
{
    // MARK: Calender Delegate
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        if self is ExamVC || self is ViewEnquiryVC || self is ChequePaymentVC || self is HolidayVC
        {
            if(self.view.subviews[1] == btnDate)
            {
                if(dateFormatter.date(from: ((self.view.subviews[2] as! UIButton).titleLabel?.text)!)?.compare(date) == .orderedAscending)
                {
                    Functions.showAlert(false, Message.fromDate)
                    return
                }
            }
            else
            {
                if(dateFormatter.date(from: ((self.view.subviews[1] as! UIButton).titleLabel?.text)!)?.compare(date) == .orderedDescending)
                {
                    Functions.showAlert(false, Message.toDate)
                    return
                }
            }
        }
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}
