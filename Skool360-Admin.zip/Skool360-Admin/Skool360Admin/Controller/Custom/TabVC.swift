//
//  MainVC.swift
//  FirebaseChat
//
//  Created by ADMS on 17/08/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var tabBarTitle = [""]
class TabVC: CustomViewController {
    
    @IBOutlet var tabCollection: UICollectionView!
    @IBOutlet var constantViewWidth: NSLayoutConstraint!
    @IBOutlet var constantViewLeft: NSLayoutConstraint!
    
    var pageController: UIPageViewController!
    var arrVC:[UIViewController] = []
    var currentPage: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //(self.view.subviews[0].subviews[0] as! UILabel).text = self.title?.uppercased()
        
        //        switch (self.title)! {
        //        case "Summary":
        //            tabBarTitle = ["Attendence", "Collection's"]
        //            arrVC = self.summaryViewControllers()
        
        //        case "PTM":
        //        tabBarTitle = ["Inbox", "Sent", "Create"]
        //        arrVC = self.ptmViewControllers()
        
        //        default:
        //            break
        //        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        switch (self.title)! {
        case "Summary":
            tabBarTitle = ["Attendance", "Collection's"]
            arrVC = self.summaryViewControllers()
            
        case "PTM":
            tabBarTitle = ["Inbox", "Sent", "Create"]
            arrVC = self.ptmViewControllers()
            
        default:
            break
        }
        
        constantViewWidth.constant = self.view.bounds.size.width/CGFloat(tabBarTitle.count)
        self.tabCollection.reloadData()
        
        let pointY:CGFloat = self.view.subviews[0].frame.size.height + self.view.subviews[1].frame.size.height + 5.0
        self.view.subviews[1].addShadowWithRadius(2.0, 0, 0)
        
        createPageViewController(pointY)
    }
    
    func summaryViewControllers()->[UIViewController]
    {
        let SAvc = self.storyboard?.instantiateViewController(withIdentifier: "Attendance Summary")
        SAvc?.title = tabBarTitle[0]
        
        let SCvc = self.storyboard?.instantiateViewController(withIdentifier: "Account Summary")
        SCvc?.title = tabBarTitle[1]
        
        return [SAvc!,SCvc!]
    }
    
    func ptmViewControllers()->[UIViewController]
    {
        let RequestVC = self.storyboard?.instantiateViewController(withIdentifier: "RequestVC")
        
        var viewControllers:[UIViewController] = []
        for i in 0..<tabBarTitle.count-1 {
            let sentInboxVC:SentInboxVC = self.storyboard?.instantiateViewController(withIdentifier: "SentInboxVC") as! SentInboxVC
            sentInboxVC.title = tabBarTitle[i]
            viewControllers.append(sentInboxVC)
        }
        viewControllers.append(RequestVC!)
        return viewControllers
    }
    
    //MARK: - CreatePagination
    
    func createPageViewController(_ pointY:CGFloat) {
        
        pageController = UIPageViewController.init(transitionStyle: UIPageViewControllerTransitionStyle.scroll, navigationOrientation: UIPageViewControllerNavigationOrientation.horizontal, options: nil)
        
        pageController.view.backgroundColor = UIColor.clear
        pageController.delegate = self
        pageController.dataSource = self
        
        for svScroll in pageController.view.subviews as! [UIScrollView] {
            svScroll.delegate = self
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.pageController.view.frame = CGRect(x: 0, y: pointY, width: self.view.frame.size.width, height: self.view.frame.size.height-pointY)
        }
        
        pageController.setViewControllers([arrVC[0]], direction: UIPageViewControllerNavigationDirection.forward, animated: false, completion: nil)
        
        self.addChildViewController(pageController)
        self.view.addSubview(pageController.view)
        pageController.didMove(toParentViewController: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension TabVC:UIPageViewControllerDataSource, UIPageViewControllerDelegate
{
    func indexofviewController(viewController: UIViewController) -> Int {
        if(arrVC.contains(viewController)) {
            return arrVC.index(of: viewController)!
        }
        return -1
    }
    
    //MARK: - Pagination Delegate Methods
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        var index = indexofviewController(viewController: viewController)
        
        if(index != -1) {
            index = index - 1
        }
        
        if(index < 0) {
            return nil
        }
        else {
            return arrVC[index]
        }
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        var index = indexofviewController(viewController: viewController)
        
        if(index != -1) {
            index = index + 1
        }
        
        if(index >= arrVC.count) {
            return nil
        }
        else {
            return arrVC[index]
        }
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        
        if(completed) {
            currentPage = arrVC.index(of: (pageViewController.viewControllers?.last)!)!
        }
    }
}

extension TabVC:UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width:constantViewWidth.constant , height:collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tabBarTitle.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TabCell", for: indexPath) as! TabCell
        cell.lblTitle.text = tabBarTitle[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        var direction = UIPageViewControllerNavigationDirection(rawValue: 0)
        if(self.currentPage > indexPath.row){
            direction = UIPageViewControllerNavigationDirection.reverse
        }
        pageController.setViewControllers([arrVC[indexPath.row]], direction: direction!, animated: true, completion: {(Bool) -> Void in
            self.currentPage = indexPath.row
        })
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let xFromCenter: CGFloat = self.view.frame.size.width-scrollView.contentOffset.x
        let xCoor: CGFloat = CGFloat(self.view.bounds.size.width/CGFloat(tabBarTitle.count)) * CGFloat(currentPage)
        let xPosition: CGFloat = xCoor - xFromCenter/CGFloat(arrVC.count)
        constantViewLeft.constant = xPosition
    }
}

//TabBarCell Class
class TabCell: UICollectionViewCell {
    @IBOutlet weak var lblTitle: UILabel!
}
