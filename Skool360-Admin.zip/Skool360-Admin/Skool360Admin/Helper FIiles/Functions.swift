//
//  Functions.swift
//  FirebaseChatDemo
//
//  Created by ADMS on 26/07/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
//import SCLAlertView
//import ZVProgressHUD
import Alamofire
import SwiftyJSON
import DialogBox

var dialogBox:DialogBox!
class Functions {
    
    class func callApi(api:String, params:[String:String] ,completionHandler:@escaping (JSON?,Error?) -> Void)
    {
        let headers = [
            "Content-Type": "application/x-www-form-urlencoded"
        ]
        
        if dialogBox == nil {
            dialogBox = DialogBox.init()
            dialogBox.show(title: nil, message: "Loading...", boxApp: BoxAppearanceLoading._1)
        }
        
        Alamofire.request(api, method: .post, parameters: params, headers: headers).validate().responseJSON { response in
            switch response.result {
            case .success(let value):
                
                let json = JSON(value)
                print(json)
                
                if(json["Success"].stringValue.caseInsensitiveCompare("True") == .orderedSame) {
                    completionHandler(json,nil)
                    if api != API.loginApi {
                        if dialogBox != nil {
                            dialogBox.dismiss()
                        }
                        dialogBox = nil
                    }
                }
                else {
                    if(api == API.admin_StudentSearchByParentName || api == API.admin_StudentSearchByStuName || api == API.getAllPaymentLedger || api == API.admin_StudentFullDetailApi || api == API.getTestNameForMarksSyllabusPermissionApi || api == API.getTeacherBySubjectApi || api == API.totalFeesCollectionByTermApi){
                    }else if(api == API.insertClassTeachersApi || api == API.insertPlannerApi || api == API.insertStaffLeaveRequestApi){
                        self.showAlert(false, json["Message"].stringValue)
                    }else{
                        self.showAlert(false, Message.noRecordFound)
                    }
                    completionHandler(nil,nil)
                    if api != API.loginApi {
                        if dialogBox != nil {
                            dialogBox.dismiss()
                        }
                        dialogBox = nil
                    }
                }
                
            case .failure(let error):
                if api != API.loginApi {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        if dialogBox != nil {
                            dialogBox.dismiss()
                        }
                        dialogBox = nil
                    }
                }
                
                if error._code == NSURLErrorNotConnectedToInternet {
                    completionHandler(nil,error)
                }else if error._code == NSURLErrorTimedOut {
                    self.showAlert(false, Message.timeOutError)
                }else {
                    self.showAlert(false, Message.somethingWrong)
                }
            }
        }
    }
    
    class func showDialog(finish:@escaping ()->Void)
    {
        DialogBox.show(title: nil, message: Message.internetFailure,superView: Constants.window , boxApp: BoxAppearanceScreenMessages._1, buttonTitle: "Try Again", buttonAppearance: nil) {
            finish()
        }
    }
    
    class func showAlert(_ isSuccess:Bool,_ msg:String) -> Bool
    {
        let dialogBox = DialogBox.init()
        dialogBox.addButton(title: "OK", buttonAppearance: nil) {
            print("Pressed OK")
        }
        dialogBox.show(title: nil, message: msg, boxApp: BoxAppearanceAlert._1)
        return false
    }
    
    class func showCustomAlert(_ title:String, _ msg:String, isDone:@escaping (Bool) -> Void)
    {
        let dialogBox = DialogBox.init()
        dialogBox.addButton(title: "YES", buttonAppearance: nil) {
            print("Pressed YES")
            isDone(true)
        }
        dialogBox.addButton(title: "NO", buttonAppearance: nil) {
            print("Pressed NO")
        }
        dialogBox.show(title: title, message: msg, boxApp: BoxAppearanceAlert._2)
    }
}
