//
//  Help Files.swift
//  Chat
//
//  Created by ADMS on 01/08/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import SDWebImage
import TransitionButton
import LGSideMenuController
import Alamofire
import SwiftyJSON
import UIDropDown

// MARK: Bundle

let bundleName               = Bundle.main.infoDictionary?["CFBundleName"] as! String

// MARK: Struct

struct API {
    
    //static let hostName:String          = bundleName.contains("Shilaj") ? "http://103.8.216.132" : "http://103.24.183.28:8085" // Live
    static let hostName:String          = "http://192.168.1.12:\(bundleName.contains("Shilaj") ? 8085 : 8086)" // Local
    
    static let baseUrl:String            = "\(hostName)/MobileApp_Service.asmx/"
    static let imageUrl:String          = hostName
    static let iconsLinkUrl:String      = "\(hostName)/SKOOL360-Design-Icons/Admin/"
    static let  imagesLinkUrl:String     = "\(hostName)/SKOOL360-Category-Images/Admin/"
    static let  fontLinkUrl:String       = "\(hostName)/SKOOL360-Fonts/"
    static let  downloadUrl:String       = "\(hostName)/Backend/"
    
    
    static let loginApi:String                          = "\(baseUrl)StaffLogin"
    static let getTermApi:String                        = "\(baseUrl)GetTerm"
    
    // MARK: Student
    
    static let admin_StudentAttendenceApi:String        = "\(baseUrl)Admin_StudentAttendence"
    static let admin_StaffAttendenceApi:String          = "\(baseUrl)Admin_StaffAttendence"
    static let admin_AccountFeesStatusApi:String        = "\(baseUrl)Admin_AccountFeesStatus"
    
    static let admin_StudentSearchByParentName:String   = "\(baseUrl)Admin_StudentSearchByParentName"
    static let admin_StudentSearchByStuName:String      = "\(baseUrl)Admin_StudentSearchByStuName"
    static let admin_StudentShowFilteredData:String     = "\(baseUrl)Admin_StudentShowFilteredData"
    static let admin_StudentFullDetailApi:String        = "\(baseUrl)Admin_StudentFullDetail"
    
    static let studentTransportDetailApi:String         = "\(baseUrl)StudentTransportDetail"
    
    static let getResultPermissionApi:String            = "\(baseUrl)GetResultPermission"
    static let insertResultPermissionApi:String         = "\(baseUrl)InsertResultPermission"
    
    static let getOnlinePaymentPermissionApi:String     = "\(baseUrl)GetOnlinePaymentPermission"
    static let insertOnlinePaymentPermissionApi:String  = "\(baseUrl)InsertOnlinePaymentPermission"
    
    static let getStudentProfilePermissionApi:String    = "\(baseUrl)GetStudentProfilePermission"
    static let insertProfilePermissionApi:String        = "\(baseUrl)InsertProfilePermission"
    
    static let getGRRegisterApi:String                  = "\(baseUrl)GetGRRegister"
    static let getLeftDetainStudentApi:String           = "\(baseUrl)GetLeftDetainStudent"
    
    static let getEnquiryCountApi:String                = "\(baseUrl)GetInquiryCount"
    static let getEnquiryDataApi:String                 = "\(baseUrl)GetInquiryData"
    static let getEnduiryDataByIDApi:String             = "\(baseUrl)GetInduiryDataByID"
    static let rejectEnquiryApi:String                  = "\(baseUrl)RejectInquiry"
    
    static let getAttendenceAdminApi:String             = "\(baseUrl)GetAttendence_Admin"
    
    static let getTestNameApi:String                    = "\(baseUrl)GetTestName"
    static let getStudentMarksApi:String                = "\(baseUrl)GetStudentMarks"
    
    // MARK: Staff
    
    static let getTeachersApi:String                    = "\(baseUrl)GetTeachers"
    static let getStandardSectionApi:String             = "\(baseUrl)GetStandardSection"
    static let insertClassTeachersApi:String            = "\(baseUrl)InsertClassTeachers"
    static let getClassTeacherDetailApi:String          = "\(baseUrl)GetClassTeacherDetail"
    
    static let getSubjectApi:String                     = "\(baseUrl)GetSubject"
    static let getSubjectAssginApi:String               = "\(baseUrl)GetSubjectAssgin"
    static let insertAssignSubjectApi:String            = "\(baseUrl)InsertAssignSubject"
    
    static let getLessonPlanSubjectApi:String           = "\(baseUrl)GetLessonPlanSubject"
    static let getEmployeeBySubjectApi:String           = "\(baseUrl)GetEmployeeBySubject"
    static let getLessonPlanApi:String                  = "\(baseUrl)GetLessonPlan"
    static let wordApi:String                           = "\(downloadUrl)LessonPlanWord_Mobile.aspx?ID="
    
    static let getExamsApi:String                       = "\(baseUrl)GetExams"
    
    static let teacherGetTimeTableApi:String            = "\(baseUrl)TeacherGetTimetable"
    
    // MARK: Account
    
    static let admin_AccountFeesStructureApi:String     = "\(baseUrl)Admin_AccountFeesStructure"
    static let dailyFeeCollectionApi:String             = "\(baseUrl)DailyFeeColleCtion"
    static let getImprestDetailApi:String               = "\(baseUrl)GetImprestDetail"
    static let getDiscountDetailApi:String              = "\(baseUrl)GetDiscountDetail"
    
    static let getPaymentLedger:String                  = "\(baseUrl)GetPaymentLedger"
    static let getAllPaymentLedger:String               = "\(baseUrl)GetAllPaymentLedger"
    
    static let getReceiptDetailsApi:String              = "\(baseUrl)GetReceiptDetails"
    
    // MARK: Transport
    
    static let getTrasportChargesApi:String             = "\(baseUrl)GetTrasportCharges"
    static let getRoutePickUpPointDetail:String         = "\(baseUrl)GetRoutePickUpPointDetail"
    static let getVehicleDetail:String                  = "\(baseUrl)GetVehicleDetail"
    static let getVehicleToRouteDetail:String           = "\(baseUrl)GetVehicleToRouteDetail"
    
    // MARK: HR
    
    static let getPageListApi:String                    = "\(baseUrl)GetPageList"
    static let insertMenuPermissionApi:String           = "\(baseUrl)InsertMenuPermission"
    
    // MARK: Other
    
    static let getAbsentTodayApi:String                 = "\(baseUrl)GetAbsentToday"
    static let insertAbsentTodaySMSApi:String           = "\(baseUrl)InsertAbsentTodaySMS"
    
    static let getBulkSMSDataApi:String                 = "\(baseUrl)GetBulkSMSData"
    static let insertBulkSMSDataApi:String              = "\(baseUrl)InsertBulkSMSData"
    
    static let getStaffSMSDataApi:String                = "\(baseUrl)GetStaffSMSData"
    static let insertStaffSMSDataApi:String             = "\(baseUrl)InsertStaffSMSData"
    
    static let insertSingleSMSDataApi:String            = "\(baseUrl)InsertSingleSMSData"
    
    static let getAnnouncementDataApi:String            = "\(baseUrl)GetAnnouncementData"
    static let insertAnnouncementApi:String             = "\(baseUrl)InsertAnnouncement"
    
    static let teacherGetClassSubjectWiseStudentApi:String         = "\(baseUrl)TeacherGetClassSubjectWiseStudent"
    static let ptmTeacherStudentGetDetailApi:String                = "\(baseUrl)PTMTeacherStudentGetDetail"
    static let ptmTeacherStudentInsertDetailApi:String             = "\(baseUrl)PTMTeacherStudentInsertDetail"
    static let ptmDeleteMeeting:String                             = "\(baseUrl)PTMDeleteMeeting"
    
    static let getMonthlyCountApi:String                           = "\(baseUrl)GetMonthlyCount"
    static let getDateCountPerMonthApi:String                      = "\(baseUrl)GetDateCountPerMonth"
    static let getLoginDetailsDatewiseApi:String                   = "\(baseUrl)GetLoginDetailsDatewise"
    
    static let getHolidayApi:String                                = "\(baseUrl)GetHoliday"
    static let getHolidayCategoryApi:String                        = "\(baseUrl)GetHolidayCategory"
    static let insertHolidayApi:String                             = "\(baseUrl)InsertHoliday"
}

struct Constants {
    
    static let storyBoard              = UIStoryboard.init(name: "Main", bundle: nil)
    static let appDelegate             = UIApplication.shared.delegate as! AppDelegate
    static let window                  = UIApplication.shared.keyWindow
    static let studentPlaceholder      = UIImage.init(named: "person_placeholder")
    static let dropDownPlaceholder     = "-Please Select-"
    static let documentsDirectoryURL   = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
}

struct FontType {
    
    static let regularFont:UIFont      = FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
    static let mediumFont:UIFont       = FontHelper.medium(size: DeviceType.isIpad ? 16 : 13)
    static let boldFont:UIFont         = FontHelper.bold(size: DeviceType.isIpad ? 16 : 13)
}

struct DeviceType {
    
    static let isIphone5:Bool          = { return UIScreen.main.bounds.size.width <= 320 }()
    static let isIpad                  = UIDevice.current.userInterfaceIdiom == .pad
}

struct Message {
    
    // ----- Login -----
    
    static let userNameError:String           = "Please Enter Username"
    static let passwordError:String           = "Please Enter 6 digit Password"
    static let passwordValidationError:String = "Password must be 3-12 characters."
    static let userError:String               = "Invalid User"
    
    // ----- Api Failure Message -----
    
    static let timeOutError:String            = "Please try again later."
    static let internetFailure:String         = "Network unavailable. \(timeOutError)"
    static let somethingWrong:String          = "Something went Wrong."
    static let noRecordFound:String           = "No Records are found."
    static let noSectionSelect:String         = "Please select any one section"
    static let noGradeSelect:String           = "Please select any one grade"
    static let noTestSelect:String            = "Please select any one Test"
    static let msgSentSuccess:String          = "Message Sent Successfully."
    static let recordInsert:String            = "Record Inserted Successfully."
    static let recordUpdate:String            = "Record Updated Successfully."
    static let requestSentSuccess:String      = "Request Sent Sucessfully."
    static let cancelEnquiry:String           = "Are you sure you want to cancel Enquiry?"
    static let cancelEnquirySuccess:String    = "Enquiry Cancel Sucessfully."
    static let fromDate:String                = "Please Select FromDate before ToDate."
    static let toDate:String                  = "Please Select FromDate after ToDate."
    
    // ----- Updation Message -----
    
    static let appUpdateTitle:String          = "Update Available"
    static let appUpdateMsg:String            = "A new version of {} is available. Please update to version () now."
    
    // ----- Request -----
    
    static let mobileError:String             = "Please Enter MobileNo"
    static let incorrectNoError:String        = "Please Enter Valid MobileNo."
    static let msgError:String                = "Please Enter Message"
    static let subjectError:String            = "Please Enter Subject"
    static let descriptionError:String        = "Please Enter Description"
    static let orderError:String              = "Please Select Any Order"
}

struct GetColor {
    
    static var headerColor:UIColor = UIColor.rbg(r: 248, g: 150, b: 36)
    static var shadowColor:UIColor = UIColor.clear.withAlphaComponent(0.1)
    static var blue:UIColor        = UIColor.rbg(r: 28, g: 142, b: 202)
    static var green:UIColor       = UIColor.rbg(r: 107, g: 174, b: 24)
    static var red:UIColor         = UIColor.rbg(r: 255, g: 0, b: 0)
    static var orange:UIColor      = GetColor.headerColor
    
    static var darkBlue:UIColor    = UIColor.rbg(r: 53, g: 151, b: 211)
    static var yellow:UIColor      = UIColor.rbg(r: 230, g: 177, b: 46)
    static var lightBlue:UIColor   = UIColor.rbg(r: 72, g: 173, b: 222)
    static var greenGray:UIColor   = UIColor.rbg(r: 96, g: 125, b: 139)
}

struct FontHelper {
    
    static func regular(size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue", size: size)!
    }
    
    static func medium(size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue-Medium", size: size)!
    }
    
    static func bold(size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue-Bold", size: size)!
    }
    
    static func lato_bold(size: CGFloat) -> UIFont {
        return UIFont(name: "Lato-Bold", size: size)!
    }
}

// MARK: Store Data

var adminID: String?
{
    get {
        if let returnValue = UserDefaults.standard
            .object(forKey: "AdminID") as? String {
            return returnValue
        } else {
            return nil //Default value
        }
    }
    set {
        UserDefaults.standard.set(newValue, forKey: "AdminID")
        UserDefaults.standard.synchronize()
    }
}


// MARK: Function

func addBorderWithRadius(_ obj:AnyObject, _ borderColor:UIColor, _ radius:CGFloat, _ borderWidth:CGFloat)
{
    obj.layer.cornerRadius  = radius
    obj.layer.borderColor   = borderColor.cgColor
    obj.layer.borderWidth   = borderWidth
    obj.layer.masksToBounds = true
}

func add(asChildViewController viewController: UIViewController, _ selfVC:UIViewController) {
    
    selfVC.addChildViewController(viewController)
    selfVC.view.addSubview(viewController.view)
    viewController.view.frame = selfVC.view.bounds
    viewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    viewController.didMove(toParentViewController: selfVC)
}

func addCustomTableView(_ viewController: UIViewController?, _ subItem:AnyObject, _ addView:UIView) -> UITableView
{
    let table = UITableView()
    table.backgroundColor = UIColor.white
    table.layer.cornerRadius = 10.0
    table.layer.borderColor = UIColor.lightGray.cgColor
    table.layer.borderWidth = 1.0
    table.showsVerticalScrollIndicator = false
    table.rowHeight = 30
    table.delegate = viewController as? UITableViewDelegate
    table.dataSource = viewController as? UITableViewDataSource
    
    addView.addSubview(table)
    addView.bringSubview(toFront: table)
    
    table.translatesAutoresizingMaskIntoConstraints = false
    
    let leftConstraint = NSLayoutConstraint(item: table, attribute: .left, relatedBy: .equal, toItem: subItem, attribute: .left, multiplier: 1, constant: 0)
    let rightConstraint =  NSLayoutConstraint(item: table, attribute: .right, relatedBy: .equal, toItem: subItem, attribute: .right, multiplier: 1, constant: 0)
    let heightConstraint = NSLayoutConstraint(item: table, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 150)
    let topConstraint = NSLayoutConstraint(item: table, attribute: .top, relatedBy: .equal, toItem: subItem, attribute: .bottom, multiplier: 1, constant: 1)
    
    NSLayoutConstraint.activate([leftConstraint, rightConstraint, heightConstraint, topConstraint])
    
    return table
}

// MARK: Class

class RoundedImageView: UIImageView {
    
    override func awakeFromNib() {
        addBorderWithRadius(self, UIColor.white, self.frame.size.width/2, 2.0)
    }
}

class SquareButton: UIButton {
    
    override func awakeFromNib() {
        addBorderWithRadius(self, GetColor.blue, 3.0, 0.5)
    }
}

class ShadowButton: UIButton {
    
    @IBInspectable open var strImageName: String = "" {
        didSet {
            self.loadIconsFromLocal(strImageName)
        }
    }
    
    override func awakeFromNib() {
        self.addShadowWithRadius(3.0, 0, 0)
    }
}

class CustomButton: UIButton {
    
    @IBInspectable open var strImageName: String = "" {
        didSet {
            self.loadIconsFromLocal(strImageName)
        }
    }
}

class CustomImageView: UIImageView {
    
    @IBInspectable open var strImageName: String = "" {
        didSet {
            self.loadIconsFromLocal(strImageName)
        }
    }
}

class CustomTextView: UITextView {
    
    @IBInspectable open var width: CGFloat = 0.5 {
        didSet {
            addBorderWithRadius(self, GetColor.blue, 3.0, width)
        }
    }
}

class CustomTextField: UITextField {
    
    override func awakeFromNib() {
        addBorderWithRadius(self, GetColor.blue, 3.0, 0.5)
        self.setLeftPaddingPoints(10)
    }
}

class DropDownTextField: UITextField {
    var dropDownTableView: UITableView!
    
    override func awakeFromNib() {
        
        dropDownTableView = addCustomTableView(nil, self, self.superview!)
        self.setLeftPaddingPoints(10)
        addBorderWithRadius(self, GetColor.blue, 3.0, 0.5)
    }
}

class AnimatedButton: TransitionButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = GetColor.blue
        self.setTitle("LOGIN", for: .normal)
        self.setTitleColor(.white, for: .normal)
        self.titleLabel?.font = FontHelper.bold(size: 16)
        self.cornerRadius = 5.0
        self.spinnerColor = .white
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


// MARK: Extensions

extension Date {
    func toString( dateFormat format  : String ) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
}

extension UIColor{
    class func rbg(r: CGFloat, g: CGFloat, b: CGFloat) -> UIColor {
        let color = UIColor.init(red: r/255, green: g/255, blue: b/255, alpha: 1)
        return color
    }
}

extension UIView {
    func shake() {
        let animation = CAKeyframeAnimation(keyPath: "transform.translation.x")
        animation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
        animation.duration = 0.6
        animation.values = [-20.0, 20.0, -20.0, 20.0, -10.0, 10.0, -5.0, 5.0, 0.0 ]
        layer.add(animation, forKey: "shake")
    }
    
    func addShadowWithRadius(_ sRadius:CGFloat, _ cRadius:CGFloat, _ bRadius:CGFloat)
    {
        if cRadius > 0 {
            self.layer.cornerRadius = cRadius
        }
        if bRadius > 0 {
            self.layer.borderColor  = UIColor.lightGray.cgColor
            self.layer.borderWidth  = bRadius
        }
        
        self.layer.shadowColor = GetColor.shadowColor.cgColor
        self.layer.shadowRadius = sRadius
        self.layer.shadowOffset = CGSize(width:0.0,height:sRadius)
        self.layer.shadowOpacity = 1.0
    }
}

extension UIButton {
    func makeSemiCircle(){
        let circlePath = UIBezierPath.init(arcCenter: CGPoint(x:self.bounds.size.width / 2, y:0), radius: self.bounds.size.height, startAngle: 0.0, endAngle: 180, clockwise: true)
        let circleShape = CAShapeLayer()
        circleShape.path = circlePath.cgPath
        self.layer.mask = circleShape
    }
    
    func loadIconsFromLocal(_ iconName:String)
    {
        let fileURL = Constants.documentsDirectoryURL.appendingPathComponent("\(iconName).png")
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            self.setImage(UIImage.init(contentsOfFile: fileURL.path), for: .normal)
            return
        }
        
        let url:URL = URL.init(string: "\(API.iconsLinkUrl)\(iconName).png")!
        
        let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
        
        Alamofire.download(
            url,
            method: .get,
            parameters: nil,
            encoding: JSONEncoding.default,
            headers: nil,
            to: destination).downloadProgress(closure: { (progress) in
                
            }).response { response in
                
                if let localURL = response.destinationURL {
                    print(localURL)
                    self.setImage(UIImage.init(contentsOfFile: localURL.path), for: .normal)
                }
        }
    }
}

extension String {
    func isValidEmail() -> Bool {
        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: characters.count)) != nil
    }
    
    func toDate( dateFormat format  : String) -> Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        if let date = dateFormatter.date(from: self)
        {
            return date
        }
        return Date()
    }
    
    func getDate() -> String
    {
        let dateFormatter = DateFormatter()
        if(self.contains(".")) {
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSS"
        }else{
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        }
        
        let myDate = dateFormatter.date(from: self)!
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.string(from: myDate)
    }
    
    func formatAmount(number:NSNumber) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        return formatter.string(from: number)!.components(separatedBy: ".").first!
    }
    
    func getStatusMode() -> StatusMode {
        
        var mode = StatusMode.active
        switch self {
        case "Inactive":
            mode = StatusMode.inActive
        default:
            break
        }
        return mode
    }
    
    func stringFromHTML() -> NSAttributedString?
    {
        do{
            let attrStr:NSAttributedString = try NSAttributedString(
                data: self.data(using: String.Encoding.unicode, allowLossyConversion: true)!,
                options: [NSAttributedString.DocumentReadingOptionKey.documentType:NSAttributedString.DocumentType.html, NSAttributedString.DocumentReadingOptionKey("CharacterEncodi‌​ng"): String.Encoding.utf8.rawValue], documentAttributes: nil)
            
            let newStr:NSMutableAttributedString = attrStr.mutableCopy() as! NSMutableAttributedString
            
            var range:NSRange = (newStr.string as NSString).rangeOfCharacter(from: .whitespacesAndNewlines)
            
            // Trim leading characters from character set.
            while range.length != 0 && range.location == 0 {
                newStr.replaceCharacters(in: range, with: "")
                range = (newStr.string as NSString).rangeOfCharacter(from: .whitespacesAndNewlines)
            }
            
            // Trim trailing characters from character set.
            range = (newStr.string as NSString).rangeOfCharacter(from: .whitespacesAndNewlines, options: .backwards)
            while range.length != 0 && NSMaxRange(range) == newStr.length {
                newStr.replaceCharacters(in: range, with: "")
                range = (newStr.string as NSString).rangeOfCharacter(from: .whitespacesAndNewlines, options: .backwards)
            }
            return NSAttributedString.init(attributedString: newStr)
        } catch
        {
            print("html error\n",error)
        }
        return nil
    }
}

extension UIImageView {
    
    public func setImageWithFadeFromURL(url: URL, placeholderImage placeholder: UIImage? = nil, animationDuration: Double = 0.3, finish:@escaping ()->Void) {
        
        self.sd_setImage(with: url, placeholderImage: placeholder, options: .transformAnimatedImage){ (fetchedImage, error, cacheType, url) in
            if error != nil {
                print("Error loading Image from URL: \(String(describing: url))\n(error?.localizedDescription)")
                self.image = placeholder
                return
            }
            self.alpha = 0
            self.image = fetchedImage
            UIView.transition(with: self, duration: (cacheType == .none ? animationDuration : 0), options: .transitionCrossDissolve, animations: { () -> Void in
                self.alpha = 1
            }, completion: { (finished: Bool) in
                finish()
            })
        }
    }
    
    public func cancelImageLoad() {
        self.sd_cancelCurrentImageLoad()
    }
    
    func getImagesfromLocal(_ folderName:String, _ strImageName:String)
    {
        let fileURL = Constants.documentsDirectoryURL.appendingPathComponent("\(folderName)/")
        
        let strNewImageName:String = "\(strImageName.replacingOccurrences(of: "/", with: "_")).png"
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            if !FileManager.default.fileExists(atPath: fileURL.appendingPathComponent("\(strNewImageName)").path) {
                self.storeImages(folderName,fileURL,strNewImageName)
            }else{
                print("Image Is there")
                self.image = folderName == "SideMenu" ? UIImage.init(contentsOfFile: fileURL.appendingPathComponent("\(strNewImageName)").path)?.withRenderingMode(.alwaysTemplate) : UIImage.init(contentsOfFile: fileURL.appendingPathComponent("\(strNewImageName)").path)
            }
        }else{
            try! FileManager.default.createDirectory(atPath: fileURL.path,withIntermediateDirectories: false,attributes: nil)
            self.storeImages(folderName,fileURL,strNewImageName)
        }
    }
    
    func storeImages(_ imageFolderName:String, _ imageUrl:URL ,_ imageName:String)
    {
        let strImageLink:String = "\(API.imagesLinkUrl)\(imageFolderName)/\(imageName.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!)"
        
        self.sd_setImage(with: URL.init(string: strImageLink), completed: { (fetchedImage, error, _, _) in
            
            if(error != nil){
                return
            }
            
            do {
                try UIImagePNGRepresentation(fetchedImage!)!.write(to: imageUrl.appendingPathComponent("\(imageName)"))
                print("Image Added Successfully")
            } catch {
                print(error)
            }
        })
    }
    
    func loadIconsFromLocal(_ iconName:String)
    {
        let fileURL = Constants.documentsDirectoryURL.appendingPathComponent("\(iconName).png")
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            self.image = UIImage.init(contentsOfFile: fileURL.path)
            return
        }
        
        let url:URL = URL.init(string: "\(API.iconsLinkUrl)\(iconName).png")!
        
        let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
        
        Alamofire.download(
            url,
            method: .get,
            parameters: nil,
            encoding: JSONEncoding.default,
            headers: nil,
            to: destination).downloadProgress(closure: { (progress) in
                
            }).response { response in
                
                if let localURL = response.destinationURL {
                    print(localURL)
                    self.image = UIImage.init(contentsOfFile: localURL.path)
                }
        }
    }
}

extension UIViewController {
    func getDynamicFont()
    {
        var font:CGFont!
        var error: Unmanaged<CFError>?
        var success:Bool = false
        
        for fontName in ["Lato-Bold"] {
            
            let strFontName:String = "\(fontName).ttf"
            let url:URL = URL.init(string: "\(API.fontLinkUrl)\(strFontName)")!
            let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
            
            Alamofire.download(
                url,
                method: .get,
                parameters: nil,
                encoding: JSONEncoding.default,
                headers: nil,
                to: destination).downloadProgress(closure: { (progress) in
                    
                }).response { response in
                    
                    if let localURL = response.destinationURL {
                        //print(localURL)
                        
                        let data = try? Data(contentsOf: localURL)
                        font = CGFont(CGDataProvider(data: data! as CFData)!)
                        
                        success = CTFontManagerRegisterGraphicsFont(font, &error)
                        if !success {
                            print("Error loading font. Font is possibly already registered.")
                        }
                    }
            }
        }
    }
    
    func addToolbar() -> UIToolbar
    {
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(dismissPicker))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        return toolBar
    }
    
    @objc func dismissPicker() {
        self.view.endEditing(true)
    }
}

extension CustomViewController
{
    func addTermDropDown(_ subView:UIView)
    {
        //strTerm = (dicTerms.allKeys(for: strTermID) as! [String]).first!
        
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.tag = subView.tag
        dropDown.options = self.arrTerms as! [String]
        dropDown.tableHeight = (dicTerms.allKeys as! [String]).count > 5 ? CGFloat(5 * 35) : CGFloat(dicTerms.allKeys.count * 35)
        dropDown.selectedIndex = (self.arrTerms as! [String]).index(of: strTerm)
        dropDown.title.text = strTerm
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            
            self.strTerm = option
            strTermID = self.dicTerms.value(forKey: option) as! String
            NotificationCenter.default.post(name: .callApi, object: nil)
        }
        if(subView.tag == -1){
            view.insertSubview(dropDown, at: 0)
        }else{
            if self is StudentMarksVC {
                view.subviews[1].addSubview(dropDown)
            }else{
                view.addSubview(dropDown)
            }
        }
    }
    
    func addStandardDropDown(_ subView:UIView)
    {
        strStd = self.arrStandards[0]
        strStdID = strStd == "All" ? self is GRRegister_LeftDetailVC ? "0" : strStd : self.dicStandards.value(forKey: strStd) as! String
        
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.tag = subView.tag
        dropDown.options = self.arrStandards
        dropDown.tableHeight = self.arrStandards.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrStandards.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = strStd
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            
            self.strStd = option
            self.strStdID = self.dicStandards.value(forKey: option) as! String
            
            switch(self)
            {
            case is SMSVC:
                self.strStdID = self.strStd == "All" ? "All" : self.dicStandards.value(forKey: self.strStd) as! String
                self.addSectionDropDown(subView.tag)
                
            case is ImprestVC, is StudentDiscountVC, is DailyFeesCollectionVC:
                break
                
            case is ClassTeacherVC, is ViewLessonPlanVC:
                NotificationCenter.default.post(name: .callApi, object: nil)
                
            case is GRRegister_LeftDetailVC:
                self.strStdID = self.strStd == "All" ? "0" : self.strStd
                self.addSectionDropDown(subView.tag)
                
            default:
                self.addSectionDropDown(subView.tag+1)
            }
        }
        if self is StudentMarksVC {
            view.subviews[1].addSubview(dropDown)
        }else{
            view.addSubview(dropDown)
        }
    }
    
    func addSectionDropDown(_ tag:Int)
    {
        var dropDown:UIDropDown = UIDropDown(frame: (view.viewWithTag(tag)?.frame)!)
        dropDown.tag = 1000
        
        for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            if(view.tag == 1000){
                dropDown = view as! UIDropDown
            }
        }
        
        if strStd != "All" {
            let dict:NSMutableDictionary = self.dicStdSections[strStd] as! NSMutableDictionary
            arrSections = dict.sortedDictionary(dict).0
            
            dropDown.options = arrSections
            dropDown.tableHeight = arrSections.count > 5 ? CGFloat(5 * 35) : CGFloat(arrSections.count * 35)
            
            if (self is GRRegister_LeftDetailVC) || (self is SMSVC) {
                return
            }
            
            strClass = arrSections[0]
            strClassID = dict.value(forKey: strClass) as? String
            dropDown.title.text = strClass
            dropDown.selectedIndex = 0
            
        }else {
            strClass = strStdID
            strClassID = strClass
            
            dropDown.placeholder = "All"
            dropDown.options = []
            dropDown.tableHeight = 0
        }
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strClass = dropDown.tableHeight == 0 ? self.strStdID : option
            self.strClassID = dropDown.tableHeight == 0 ? self.strStdID : (self.dicStdSections[self.strStd] as! NSMutableDictionary).value(forKey: self.strClass) as? String
        }
        
        for dd in (self.view.subviews.flatMap{$0 as? UIDropDown}) {
            if(dd.tag == 1000){
                return
            }
        }
        if self is StudentMarksVC {
            view.subviews[1].addSubview(dropDown)
        }else{
            view.addSubview(dropDown)
        }
    }
}

extension NSMutableDictionary {
    func sortedDictionary(_ dict:NSMutableDictionary)->([String],[String]) {
        
        let values = (dict.allKeys as! [String]).sorted {
            (s1, s2) -> Bool in return s1.localizedStandardCompare(s2) == .orderedAscending
        }
        
        var sortedArray:[String] = []
        for item in values {
            sortedArray.append(item.components(separatedBy: "-").last!)
        }
        return (values, sortedArray)
    }
}

extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}

extension UINavigationController {
    func pushPopTransition(_ pushPopVC:UIViewController, _ isPush:Bool) {
        let transition = CATransition()
        transition.duration = 0.5
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionMoveIn
        switch arc4random()%4 {
        case 0:
            transition.subtype = kCATransitionFromTop
        case 1:
            transition.subtype = kCATransitionFromBottom
        case 2:
            transition.subtype = kCATransitionFromLeft
        default:
            transition.subtype = kCATransitionFromRight
        }
        self.view.layer.add(transition, forKey: nil)
        if isPush {
            self.pushViewController(pushPopVC, animated: false)
        }else{
            self.popToViewController(pushPopVC, animated: false)
        }
    }
}

extension NSTextAttachment {
    func setImageHeight(height: CGFloat) {
        guard let image = image else { return }
        let ratio = image.size.width / image.size.height
        
        bounds = CGRect(x: bounds.origin.x, y: bounds.origin.y, width: ratio * height, height: height)
    }
}

extension Notification.Name {
    static let callApi = Notification.Name(
        rawValue: "callApi")
}


// MARK: Enums

enum ErrorType {
    case userName, password, confirmPassword
}

enum VersionError: Error {
    case invalidResponse, invalidBundleInfo
}

enum StatusMode:String {
    case active = "Active"
    case inActive = "Inactive"
}

enum ButtonType:String {
    case add = "ADD"
    case update = "UPDATE"
}
