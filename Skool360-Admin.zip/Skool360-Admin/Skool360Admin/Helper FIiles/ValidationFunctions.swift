//
//  Validations.swift
//  FirebaseChat
//
//  Created by ADMS on 25/08/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class ValidationFunctions: NSObject {
    
    class func loginValidation(loginData:LoginData) -> (Bool,ErrorType?)
    {
//        if (loginData.userName?.isEmpty)! {
//            return ((UIApplication.shared.keyWindow?.rootViewController?.showErrorAlert(errorMsg: userNameError))!,.userName)
//            
//        }else if (loginData.password?.isEmpty)! {
//            return ((UIApplication.shared.keyWindow?.rootViewController?.showErrorAlert(errorMsg: passwordError))!,.password)
//            
//        }else if ((loginData.password?.count)! < 3 || (loginData.password?.count)! > 12) {
//            return ((UIApplication.shared.keyWindow?.rootViewController?.showErrorAlert(errorMsg: passwordValidationError))!,.password)
//        }
        return (true,nil)
    }
    
    class func sendValidation(requestData:RequestData) -> Bool
    {
        if (requestData.TxtMobileNo?.isEmpty)! {
            return Functions.showAlert(false, Message.mobileError)
        }else if((requestData.TxtMobileNo?.count)! < 10){
            return Functions.showAlert(false, Message.incorrectNoError)
        }else if (requestData.TxtMsg?.isEmpty)! {
            return Functions.showAlert(false, Message.msgError)
        }
        return true
    }
    
    class func requestValidation(requestData:RequestData) -> Bool
    {
        if (requestData.txtSubject?.isEmpty)! {
            return Functions.showAlert(false, Message.subjectError)
            
        }else if (requestData.txtDescription?.isEmpty)! {
            return Functions.showAlert(false, Message.descriptionError)
            
        }else if (requestData.txtOrder?.isEmpty)! {
            return Functions.showAlert(false, Message.orderError)
        }
        return true
    }
}
