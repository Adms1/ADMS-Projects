//
//  InputTextField.swift
//  Search Classes
//
//  Created by ADMS on 05/03/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var keyboardActualSize:CGSize = .zero
class InputTextField: UITextField {
    
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        if action == #selector(UIResponderStandardEditActions.paste(_:)) {
            return false
        }
        return super.canPerformAction(action, withSender: sender)
    }
    
    var activeTextField: UITextField?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        delegate = self
        self.inputAccessoryView = addToolbar()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func addToolbar() -> UIToolbar
    {
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(dismissPicker))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        return toolBar
    }
}

extension InputTextField
{
    @objc func keyboardWillShow(_ notification: NSNotification) {
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if((keyboardSize?.height)! > 0)
        {
            keyboardActualSize = keyboardSize!
        }
        
        if let activeField = self.activeTextField {
            if let scrollView = self.superview?.superview as? UIScrollView {
                let compareValue = (activeField.frame.origin.y) + activeField.frame.size.height
                if(compareValue > keyboardActualSize.height) {
                    scrollView.setContentOffset(CGPoint(x:0, y: compareValue - keyboardActualSize.height), animated: true)
                }
                else {
                    scrollView.setContentOffset(.zero, animated: true)
                }
            }
        }
    }
    
    @objc func dismissPicker() {
        let contentInsets = UIEdgeInsets.zero
        if let scrollView = self.superview?.superview as? UIScrollView {
            scrollView.contentInset = contentInsets
            scrollView.scrollIndicatorInsets = contentInsets
            scrollView.contentOffset = CGPoint.zero
            scrollView.endEditing(true)
        }
    }
}

extension InputTextField: UITextFieldDelegate
{
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if (textField.tag == 4 || textField.tag == 5) && textField.keyboardType != .phonePad
        {
            self.dismissPicker()
            NotificationCenter.default.post(name: .openDatePicker, object: nil, userInfo: ["txtfld" : textField])
            return false
        }
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextField = textField
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let newText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if(newText.count > 10 && textField.keyboardType == .numberPad){
            return false
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeTextField = nil
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let nextField = self.superview?.viewWithTag(self.tag + 1) as? UITextField {
            nextField.becomeFirstResponder()
        } else {
            self.dismissPicker()
        }
        return true
    }
}
