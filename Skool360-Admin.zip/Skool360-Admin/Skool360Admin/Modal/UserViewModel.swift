//
//  UserViewModels.swift
//  Chatt
//
//  Created by ADMS on 11/08/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class LoginData {
    
    var userName:String?
    var password:String?
    
    var staffName:String?
    var staffDesignation:String?
    var staffProfile:String?
    
    init(userName:String, password:String)
    {
        self.userName = userName
        self.password = password
    }
    
    init(staffName:String, staffDesignation:String, staffProfile:String)
    {
        self.staffName = staffName
        self.staffDesignation = staffDesignation
        self.staffProfile = staffProfile
    }
}

class RequestData {
    
    var TxtMobileNo:String?
    var TxtMsg:String?
    
    var txtSubject:String?
    var txtDescription:String?
    var txtOrder:String?

    init(txtMobile:String, txtMsg:String)
    {
        self.TxtMobileNo = txtMobile
        self.TxtMsg = txtMsg
    }
    
    init(txtSub:String, txtDes:String, txtOrd:String)
    {
        self.txtSubject = txtSub
        self.txtDescription = txtDes
        self.txtOrder = txtOrd
    }
}
