//
//  TableCell.swift
//  Skool360Admin
//
//  Created by ADMS on 09/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import AIFlatSwitch

extension UITableViewCell
{
    func displaySubViewData(_ subView:UIView, array:[String])
    {
        var i:Int = 0
        for lbl in (subView.subviews.flatMap{ $0 as? UILabel}) {
            
            lbl.font = FontType.regularFont
            if(lbl.tag == -1){
                lbl.text = array[i] == "" ? "-" : array[i]
                
                i += 1
            }
        }
    }
}

@objc protocol CustomCellDelegate {
    @objc func performAction(_ sender:UIButton)
}

class CustomCell:UITableViewCell
{
    var delegate:CustomCellDelegate!
    
    override func awakeFromNib() {
        self.contentView.subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
        self.contentView.subviews[0].layer.borderWidth  = 0.5
        
        for view in self.contentView.subviews {
            
            for sublbl in (view.subviews.flatMap{ $0 as? UILabel}) {
                sublbl.font = FontType.mediumFont
            }
            
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.font = FontType.mediumFont
            }
        }
        
        for view in self.contentView.subviews[0].subviews.filter({($0.isKind(of: VKCheckbox.classForCoder()))}) {
            
            let checkBox:VKCheckbox = view as! VKCheckbox
            checkBox.line             = .normal
            checkBox.bgColorSelected  = GetColor.blue
            checkBox.color            = .white
            checkBox.borderColor      = GetColor.blue
            checkBox.borderWidth      = 1.0
            checkBox.cornerRadius     = 5.0
        }
    }
}

class ProfileCell: UITableViewCell {
    @IBOutlet var imgProfile:UIImageView!
    @IBOutlet var lblName:UILabel!
    @IBOutlet var lblDesignation:UILabel!
}

class MenuCell: UITableViewCell {
    @IBOutlet var viewSelected:UIView!
    @IBOutlet var imgIcon:UIImageView!
    @IBOutlet var lblName:UILabel!
    @IBOutlet var btnExpand:UIButton!
    
    func displayMenuItems(_ str:String, _ selected:Bool) {
        lblName.text = str.uppercased()
        lblName.font = FontHelper.medium(size: DeviceType.isIpad ? 18 : 16)
        
        imgIcon.getImagesfromLocal("SideMenu", "Menu_\(str)")
        btnExpand.isHidden = str == "Other" ? false : true
        btnExpand.setImage(UIImage.init(named: "right")?.withRenderingMode(.alwaysTemplate), for: .normal)
        
        lblName.textColor = selected ? GetColor.orange : GetColor.blue
        imgIcon.tintColor = selected ? GetColor.orange : GetColor.blue
        btnExpand.tintColor = selected ? GetColor.orange : GetColor.blue
    }
}

class MenuSubItemCell: UITableViewCell {
    @IBOutlet var lblSubName:UILabel!
    
    func displaySubMenuItems(_ str:String) {
        lblSubName.font = FontHelper.regular(size: DeviceType.isIpad ? 18 : 16)
        lblSubName.text = str.uppercased()
    }
}

class SummaryItemCell: UITableViewCell {
    @IBOutlet var lblHeader:UILabel!
    @IBOutlet var viewBottom:NSLayoutConstraint!
    
    override func awakeFromNib() {
        self.contentView.subviews[0].addShadowWithRadius(3.0, 0, 0.5)
    }
    
    func displayAttendanceItemData(_ index:NSInteger, _ attendanceModal:AttendanceModal)
    {
        var color:UIColor!
        switch index {
        case 1:
            color = GetColor.red
        case 2:
            color = GetColor.orange
        case 3:
            color = GetColor.green
        default:
            color = GetColor.blue
        }
        
        let arr = [attendanceModal.StudentStatus,attendanceModal.Status,attendanceModal.Status]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{$0 as? UILabel}) {
            
            if(lbl.tag != -1) {
                lbl.text = arr[i] == "" ? "-" : arr[i]
                lbl.textColor = color
                lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 16 : 14)
                
                i += 1
            }
        }
    }
    
    func displayCollectionItemData(_ collectionModal:CollectionModal)
    {
        let arr = [collectionModal.AmountType, collectionModal.TotalAmount, collectionModal.StudentAmount]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{$0 as? UILabel}) {
            
            if(lbl.tag != -1) {
                let arrString:[String] = (arr[i]?.components(separatedBy: " "))!
                let strFirst:String = arrString.first!
                let strLast:String = arrString.last!
                
                lbl.text = i > 0 ? (strFirst != strLast ? "\(strFirst.formatAmount(number: NSNumber.init(value: Int(strFirst)!))) \(strLast)" : arr[i]?.formatAmount(number: NSNumber.init(value: Int((arr[i])!)!))) : arr[i]
                lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 16 : 14)
                
                i += 1
            }
        }
    }
    
    func displayStandardItemData(_ stdModal:StandardModal)
    {
        self.displaySubViewData(self.contentView.subviews[0].subviews[0], array: ["\(stdModal.Standard!) - \(stdModal.Class!) (\(stdModal.TotalStudent!))", stdModal.Present, stdModal.Absent, stdModal.Leave])
    }
    
    func displayAbsentItemData(_ absentModal:AbsentModal)
    {        
        self.displaySubViewData(self.contentView.subviews[0].subviews[0], array: [absentModal.Name, "\(absentModal.Standard!) - \(absentModal.Class!)", absentModal.Days])
    }
    
    func displayStandardCollectionItemData(_ stdModal:StandardCollectionModal)
    {
        let arr = [stdModal.Standard,stdModal.Total,stdModal.Received,stdModal.Dues]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            
            let arrString:[String] = (arr[i]?.components(separatedBy: " "))!
            let strFirst:String = arrString.first!
            let strLast:String = arrString.last!
            lbl.text = i > 0 ? "\(strFirst.formatAmount(number: NSNumber.init(value: Int(strFirst)!))) \(strLast)" : arr[i]
            lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 16 : 14)
            
            i += 1
        }
    }
}

class SearchStudentCell: CustomCell {
    
    func displayData(_ searchStudentData:SearchStudentsModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [searchStudentData.ParentName, searchStudentData.Modal.StudentName.capitalized as! String, searchStudentData.Modal.GRNO, searchStudentData.Modal.Grade])
    }
    
    func displayStudentData(_ searchStudentData:SearchStudentsModal, _ idx:NSInteger)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: ["\(idx)", (searchStudentData.StudentName.capitalized as! String).components(separatedBy: "|").first!, (searchStudentData.StudentName.capitalized as! String).components(separatedBy: "|").last!, searchStudentData.GRNO, searchStudentData.Grade])
    }
    
    func displayNewRegisterStudentData(_ searchStudentData:SearchStudentsModal, _ idx:NSInteger)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: ["\(idx)", searchStudentData.StudentName, searchStudentData.GRNO, searchStudentData.Grade])
    }
}

class StudentProfileCell: UITableViewCell {
    
    @IBOutlet var bottomSpace:NSLayoutConstraint!
    
    func displayHeaderData(_ strHeaderTitle:String, _ headerColor:UIColor, _ isSelected:Bool)
    {
        if(isSelected) {
            self.contentView.subviews[0].addShadowWithRadius(3.0, 0, 0.5)
        }
        
        var i:Int = 0
        for lbl in (self.contentView.subviews.flatMap{ $0 as? UILabel}) {
            
            lbl.backgroundColor = headerColor
            lbl.text = strHeaderTitle
            lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 18 : 15)
            
            i += 1
        }
    }
    
    func displayData(_ arr:[String], _ isSelected:Bool)
    {
        if(isSelected) {
            self.contentView.subviews[0].addShadowWithRadius(3.0, 0, 0.5)
        }
        
        var i:Int = 0
        for view in self.contentView.subviews[0].subviews{
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                if(lbl.tag != 1){
                    lbl.text = arr[i] == "" ? "-" : arr[i]
                    lbl.font = i == 0 ? FontType.mediumFont : FontType.regularFont
                    lbl.textColor = GetColor.blue
                    if(i != 0){
                        lbl.textColor = .black
                        if(arr[i] == "Active"){
                            lbl.textColor = GetColor.green
                        }else if(arr[i] == "InActive"){
                            lbl.textColor = GetColor.red
                        }
                    }
                    i += 1
                }
            }else{
                if let img:UIImageView = view as? UIImageView {
                    img.setImageWithFadeFromURL(url: URL.init(string: "\(API.imageUrl)\(arr[1].dropFirst())".addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!)!, placeholderImage: Constants.studentPlaceholder, animationDuration: 0.5, finish: {
                    })
                }
            }
        }
    }
    
    func displayRegisterLeftStudentData(_ arr:[String], _ isSelected:Bool)
    {
        if(isSelected) {
            self.contentView.subviews[0].addShadowWithRadius(3.0, 0, 0.5)
        }
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag != 1){
                lbl.text = arr[i] == "" ? "-" : arr[i]
                lbl.font = i == 0 ? FontType.mediumFont : FontType.regularFont
                lbl.textColor = GetColor.blue
                if(i != 0){
                    lbl.textColor = .black
                    if(arr[i] == "Active"){
                        lbl.textColor = GetColor.green
                    }else if(arr[i] == "InActive"){
                        lbl.textColor = GetColor.red
                    }
                }
                i += 1
            }
        }
    }
}

class FeeStructureCell: CustomCell {
    
    func displayHeaderData(_ feesModal:FeesStructureModal)
    {
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            lbl.text = feesModal.Standard.capitalized
        }
    }
    
    func displayData(_ feesModal:FeesStructureModal,_ isCurrency:Bool)
    {
        let arr = [feesModal.FeesType, feesModal.Term1Fees, feesModal.Term2Fees]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag != -1){
                lbl.text = i > 0 && isCurrency && arr[i] != "" ? arr[i].formatAmount(number: NSNumber.init(value: Int(arr[i])!)) : arr[i]
                
                i += 1
            }
        }
    }
}

class DailyFeesCollectionCell: CustomCell {
    
    @IBOutlet var lblDay:UILabel!
    @IBOutlet var headerHeight:NSLayoutConstraint!
    @IBOutlet var rowHeight:NSLayoutConstraint!
    @IBOutlet var topHeight:NSLayoutConstraint!
    @IBOutlet var lblOpeningBalance:UILabel!
    @IBOutlet var lblTotalFees:UILabel!
    @IBOutlet var lblStudentName:UILabel!
    
    func displayHeaderData(_ dailyFeesModal:DailyFeesCollectionModal)
    {
        let arr = [dailyFeesModal.StudentName.capitalized as! String, dailyFeesModal.GRNO, dailyFeesModal.Standard + " - " + dailyFeesModal.Class, dailyFeesModal.Amount == "" ? "" : "₹ \(dailyFeesModal.Amount)"]
        
        var i:Int = 0
        var id = 0
        
        while(id < 2){
            for lbl in (self.contentView.subviews[id].subviews.flatMap{ $0 as? UILabel}) {
                
                if(id == 1){
                    lbl.font = FontType.regularFont
                    if(lbl.tag == -1){
                        lbl.text = arr[i] == "" ? "-" : arr[i]
                    }
                    i += 1
                }else{
                    lbl.font = FontType.mediumFont
                }
            }
            id += 1
        }
    }
    
    func displayData(_ dailyCollectionModal:DailyFeesCollectionModal)
    {
        let dailyFeesModal = dailyCollectionModal
        let arr = [dailyFeesModal.PaymentMode, dailyFeesModal.CreateDate, dailyFeesModal.Term, dailyFeesModal.FeesAmount == "" ? "" : dailyFeesModal.FeesAmount.formatAmount(number: NSNumber.init(value: Int(dailyFeesModal.FeesAmount)!))]
        
        self.displaySubViewData(self.contentView.subviews[0], array: arr)
        
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 14 : 11)
        }
    }
    
    func displayHData(_ dailySelectedCollectionModal:DailyFeesCollectionModal)
    {
        lblStudentName.text = "\(dailySelectedCollectionModal.StudentName) (\(dailySelectedCollectionModal.GRNO))"
        lblTotalFees.text = dailySelectedCollectionModal.TotalAmt == "-" ? "" : "₹ \(dailySelectedCollectionModal.TotalAmt)"
        lblOpeningBalance.text = dailySelectedCollectionModal.OpeningBalance == "" ? "-" : "₹ \(dailySelectedCollectionModal.OpeningBalance)"
    }
}

class ImprestCell: CustomCell {
    
    @IBOutlet var lblDay:UILabel!
    @IBOutlet var headerHeight:NSLayoutConstraint!
    
    func displayHeaderData(_ imprestModal:ImprestModal, _ idx:NSInteger)
    {
        let arr = ["\(idx)", imprestModal.StudentName.capitalized as! String, imprestModal.GRNO,imprestModal.Standard]
        
        var i:Int = 0
        var id = 0
        
        while(id < 2){
            for lbl in (self.contentView.subviews[id].subviews.flatMap{ $0 as? UILabel}) {
                
                if(id == 1){
                    lbl.font = FontType.regularFont
                    if(lbl.tag == -1){
                        lbl.text = arr[i] == "" ? "-" : arr[i]?.capitalized
                    }
                    i += 1
                }else{
                    lbl.font = FontType.mediumFont
                }
            }
            id += 1
        }
    }
    
    func displayData(_ imprestModal:ImprestModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [imprestModal.TotalImprest, imprestModal.DeductImprest,imprestModal.RemainImprest])
    }
}

class StudentDiscountCell: CustomCell {
    
    @IBOutlet var lblDay:UILabel!
    @IBOutlet var headerHeight:NSLayoutConstraint!
    
    func displayHeaderData(_ stuDiscountModal:StudentDiscountModal, _ idx:NSInteger)
    {
        let arr = ["\(idx)", stuDiscountModal.StudentName.capitalized as! String, stuDiscountModal.GRNO,stuDiscountModal.Standard]
        
        var i:Int = 0
        var id = 0
        
        while(id < 2){
            for lbl in (self.contentView.subviews[id].subviews.flatMap{ $0 as? UILabel}) {
                
                if(id == 1){
                    lbl.font = FontType.regularFont
                    if(lbl.tag == -1){
                        lbl.text = arr[i] == "" ? "-" : arr[i]
                    }
                    i += 1
                }else{
                    lbl.font = FontType.mediumFont
                }
            }
            id += 1
        }
    }
    
    func displayData(_ stuDiscountModal:StudentDiscountModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [stuDiscountModal.TotalFees, stuDiscountModal.WaveOffAmt, stuDiscountModal.Discount, stuDiscountModal.PayableAmt])
    }
}

class TransportCell: CustomCell {
    
    func displayTransportChargesData(_ tsModal:TransportModal)
    {
        let arr = [tsModal.KMs, tsModal.Term1Fees, tsModal.Term2Fees]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag != -2 && !(arr[i]?.contains("Term"))!){
                lbl.text = i > 0 && arr[i] != "" ? arr[i]?.formatAmount(number: NSNumber.init(value: Int(arr[i]!)!)) : arr[i]
                
                i += 1
            }
        }
    }
    
    func displayPickupDetailData(_ tsModal:TransportModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [tsModal.Index, tsModal.PickupPoint, tsModal.Status])
    }
    
    func displayVehicleDetailData(_ tsModal:TransportModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [tsModal.Index, tsModal.VehicleName, tsModal.RegistrationNo, tsModal.PassngCapacity])
    }
    
    func displayVehicleRouteData(_ tsModal:TransportModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [tsModal.Index, tsModal.VehicleName, tsModal.RouteNm])
    }
}

class LedgerCell: CustomCell {
    
    func displayStudentData(_ ledgerModal:LedgerModal)
    {
        let arr = [ledgerModal.Term, ledgerModal.GRNO, ledgerModal.StudentName.capitalized as! String, ledgerModal.Grade, ledgerModal.SMSNo, ledgerModal.DOJ]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag == i+1){
                lbl.text = arr[i] == "" ? "-" : arr[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }else{
                lbl.font = FontType.mediumFont
            }
        }
    }
    
    func displayFeesData(_ ledgerModal:LedgerModal)
    {
        /*let arr = [ledgerModal.PreviousFees, ledgerModal.TuitionFee, ledgerModal.AdmissionFee, ledgerModal.CautionFee, ledgerModal.Transport, ledgerModal.ImprestFee, ledgerModal.LatesFee, ledgerModal.DiscountFee, ledgerModal.PayFees, ledgerModal.PayPaidFees, ledgerModal.CurrentOutstandingFees]
         
         var i:Int = 0
         for view in self.contentView.subviews[0].subviews.filter({($0.isKind(of: UILabel.classForCoder()))}) {
         let lbl:UILabel = view as! UILabel
         if(lbl.tag == i+1){
         lbl.text = arr[i] == "" ? "-" : arr[i]
         lbl.font = FontType.regularFont
         
         i += 1
         }else{
         lbl.font = FontType.mediumFont
         }
         }*/
    }
    
    func displayData()
    {
        (self.contentView.subviews[0].subviews[0] as! UILabel).font = FontHelper.medium(size: DeviceType.isIpad ? 20 : 17)
        self.contentView.subviews[0].layer.borderWidth  = 0
        self.contentView.subviews[0].subviews[1].layer.borderColor  =  UIColor.lightGray.withAlphaComponent(0.5).cgColor
        self.contentView.subviews[0].subviews[1].layer.borderWidth  = 0.5
    }
    
    func displayDetailsData(_ ledgerModal:LedgerModal)
    {
        self.contentView.subviews[0].layer.borderWidth  = 0
        self.contentView.subviews[0].subviews[1].layer.borderColor  =  UIColor.lightGray.withAlphaComponent(0.5).cgColor
        self.contentView.subviews[0].subviews[1].layer.borderWidth  = 0.5
        
        self.displaySubViewData(self.contentView.subviews[0].subviews[1], array: [ledgerModal.Date, ledgerModal.Paid])
    }
    
    func displayAccountData(_ ledgerModal:LedgerModal, _ feesType:String)
    {
        var arr = [feesType, "Receipt \(feesType)", "Remaining \(feesType)", ledgerModal.TotalFees, ledgerModal.ReceiptFees, ledgerModal.RemainingFees]
        
        if feesType == "Total Term Fees" {
            arr = [feesType, "Receipt Term Fees", "Remaining Term Fees", ledgerModal.TotalFees, ledgerModal.ReceiptFees, ledgerModal.RemainingFees]
        }
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag == i+1)
            {
                lbl.text = arr[i] == "" ? "-" : arr[i]
                i += 1
            }
            if(lbl.tag > 3){
                lbl.font = FontType.regularFont
            }else{
                lbl.font = FontType.mediumFont
            }
        }
    }
    
    func displayReceiptData(_ ledgerModal:LedgerModal)
    {
        let arr = [ledgerModal.ReceiptNo, ledgerModal.PayMode, ledgerModal.AdmissionFee, ledgerModal.TuitionFee, ledgerModal.Transport, ledgerModal.ImprestFee, ledgerModal.LatesFee, ledgerModal.DiscountFee, ledgerModal.PreviousFees, ledgerModal.PayPaidFees, ledgerModal.CurrentOutstandingFees]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag == i+1){
                lbl.text = arr[i] == "" ? "-" : arr[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }else{
                lbl.font = FontType.mediumFont
            }
        }
    }
}

class StudentTransportCell: CustomCell {
    
    @IBOutlet var lblView:UILabel!
    @IBOutlet var headerHeight:NSLayoutConstraint!
    
    func displayHeaderData(_ studentTransportData:StudentTransportModal, idx:NSInteger)
    {
        let arr = ["\(idx)", studentTransportData.StudentName.capitalized as! String, studentTransportData.GRNO, studentTransportData.Grade]
        
        var id = 0
        var i:Int = 0
        
        while(id < 2){
            for lbl in (self.contentView.subviews[id].subviews.flatMap{ $0 as? UILabel}) {
                
                if(id == 1){
                    lbl.font = FontType.regularFont
                    if(lbl.tag == -1){
                        lbl.text = arr[i] == "" ? "-" : arr[i]
                    }
                    i += 1
                }else{
                    lbl.font = FontType.mediumFont
                }
            }
            id += 1
        }
    }
    
    func displayData(_ studentTransportData:StudentTransportModal)
    {
        let arr = [studentTransportData.RouteName, studentTransportData.PickupPointName, studentTransportData.KM]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag == i+1){
                lbl.text = arr[i] == "" ? "-" : arr[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }else{
                lbl.font = FontType.mediumFont
            }
        }
    }
}

class ClassTeacherCell: CustomCell {
    
    func displayData(_ classTeacherData:ClassTeacherModal, _ idx:NSInteger)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [classTeacherData.Grade, classTeacherData.Section, classTeacherData.Name.capitalized as! String])
    }
}

class AssignSubjectCell: CustomCell {
    
    func displayData(_ assignSubjectData:AssignSubjectModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [assignSubjectData.Index, assignSubjectData.TeacherName.capitalized as! String, assignSubjectData.Subject])
    }
}

class ExamCell: CustomCell {
    
    func displayData(_ examData:ExamModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [examData.Index, examData.TestName, examData.Grade, examData.Subject, examData.TestDate])
    }
}

class TimeTableCell: UITableViewCell {
    
    @IBOutlet var lblDay:UILabel!
    @IBOutlet var collection:UICollectionView!
    @IBOutlet var btnAdd:UIButton!
    
    func displayData(timeTblData:TimeTableModel) {
        lblDay.text = timeTblData.Lecture?.stringValue
        //        var arrData = [timeTblData.Lecture?.stringValue,
        //                       timeTblData.Subject! == "" ? "-" : timeTblData.Subject!,
        //                       timeTblData.StandardClass == nil ? "-" :timeTblData.StandardClass]
        
        //        var i = 0
        //        for lbls in self.contentView.subviews {
        //            let lbl:UILabel = lbls as! UILabel
        //            lbl.text = timeTblData.Lecture?.stringValue
        //
        //            i += 1
        //        }
    }
}

class MenuPermissionCell: CustomCell {
    
    func displayData(_ menuPermissionData:MenuPermissionModel) {
        
        self.displaySubViewData(self.contentView.subviews[0], array: [menuPermissionData.Index, menuPermissionData.Page_Nam, menuPermissionData.Page_UnderName])
    }
}

class SMSCell: CustomCell {
    
    @IBOutlet var txtMobileNo:UITextField!
    @IBOutlet var lblView:UILabel!
    
    func displayData(_ absentData:SMSModel) {
        
        var arr = [absentData.Index, absentData.StudentName.capitalized as! String, absentData.FamilyName.capitalized as! String, absentData.Standard, absentData.SMSNo]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())) {
                let lbl:UILabel = view as! UILabel
                lbl.text = arr[i] == " " ? "-" : arr[i]
                
                i += 1
            }else if(view.isKind(of: UITextField.classForCoder())) {
                let txt:UITextField = view as! UITextField
                txt.text = arr[i] == "" ? "-" : arr[i]
                
                i += 1
            }
        }
    }
    
    func displayAppSMSData(_ appSMSData:SMSModel) {
        
        var arr = [appSMSData.Index, appSMSData.StudentName.capitalized as! String, appSMSData.GRNO, appSMSData.Standard + " - " + appSMSData.Class, appSMSData.Status, appSMSData.SMSNo]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())) {
                let lbl:UILabel = view as! UILabel
                lbl.text = arr[i] == " " ? "-" : arr[i]
                
                i += 1
            }else if(view.isKind(of: UITextField.classForCoder())) {
                let txt:UITextField = view as! UITextField
                txt.text = arr[i] == "" ? "-" : arr[i]
                
                i += 1
            }
        }
    }
    
    func displayStudentTransportData(_ studentTranportData:StudentTransportModal, _ idx:NSInteger) {
        
        var arr = ["\(idx)", studentTranportData.StudentName.capitalized as! String, studentTranportData.GRNO, studentTranportData.Grade, studentTranportData.SMSMobileNo]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())) {
                let lbl:UILabel = view as! UILabel
                lbl.text = arr[i] == " " ? "-" : arr[i]
                
                i += 1
            }else if(view.isKind(of: UITextField.classForCoder())) {
                let txt:UITextField = view as! UITextField
                txt.text = arr[i] == "" ? "-" : arr[i]
                
                i += 1
            }
        }
    }
    
    func displayEmployeeData(_ employeeData:SMSModel) {
        
        var arr = [employeeData.Index, employeeData.EmployeeName.capitalized as! String, employeeData.SMSNo]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())) {
                let lbl:UILabel = view as! UILabel
                lbl.text = arr[i] == " " ? "-" : arr[i]
                
                i += 1
            }else if(view.isKind(of: UITextField.classForCoder())) {
                let txt:UITextField = view as! UITextField
                txt.text = arr[i] == "" ? "-" : arr[i]
                
                i += 1
            }
        }
    }
    
    func displayStudentMarksSMSData(_ studentMarksData:SMSMarksModel) {
        
        var arr = [studentMarksData.StudentName.capitalized as! String, studentMarksData.Marks, studentMarksData.SMSNo]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())) {
                let lbl:UILabel = view as! UILabel
                lbl.text = arr[i] == "" ? "-" : arr[i]
                
                i += 1
            }else if(view.isKind(of: UITextField.classForCoder())) {
                let txt:UITextField = view as! UITextField
                txt.text = arr[i] == "" ? "-" : arr[i]
                
                i += 1
            }
        }
    }
    
    func displayAllSMSReportHeaderData(_ allSMSReportData:SMSModel) {
        
        var arr = [allSMSReportData.Index, allSMSReportData.MobileNo, allSMSReportData.Sendtime, allSMSReportData.Rectime, allSMSReportData.Deliverstatus]
        
        var id = 0
        var i:Int = 0
        
        while(id < 2){
            for lbl in (self.contentView.subviews[id].subviews.flatMap{ $0 as? UILabel}) {
                
                if(id == 1){
                    lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 15 : DeviceType.isIphone5 ? 10 : 12)
                    if(lbl.tag == -1){
                        lbl.text = arr[i] == "" ? "-" : arr[i]
                    }
                    if(allSMSReportData.Deliverstatus.caseInsensitiveCompare("Expired") == .orderedSame) {
                        lbl.textColor = .white
                        lbl.superview?.backgroundColor = GetColor.red
                    }else {
                        lbl.textColor =  lbl.tag != -1 ? .red : .black
                        lbl.superview?.backgroundColor = .white
                    }
                    i += 1
                }else{
                    lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 15 : DeviceType.isIphone5 ? 10 : 12)
                }
            }
            id += 1
        }
    }
    
    func displayAllSMSReportData(_ allSMSReportData:SMSModel) {
        
        if let lblMsg:UILabel = self.contentView.subviews[0].subviews[2] as? UILabel {
            lblMsg.font = FontHelper.regular(size: DeviceType.isIpad ? 15 : DeviceType.isIphone5 ? 10 : 12)
            lblMsg.text = allSMSReportData.Message
        }
    }
}

class CircularCell: UITableViewCell {
    
    override func awakeFromNib() {
        
        self.contentView.subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
        self.contentView.subviews[0].layer.borderWidth  = 0.5
        
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 15 : DeviceType.isIphone5 ? 10 : 12)
        }
    }
    
    func displayCircularData(_ circularData:CircularModel) {
        
        var arr = [circularData.Index, circularData.Cir_Date, circularData.Cir_Subject, circularData.Cir_Description, circularData.Cir_Order, circularData.Cir_Status]
        
        var i = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            lbl.text = arr[i] == "" ? "-" : arr[i]
            lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 15 : DeviceType.isIphone5 ? 10 : 12)
            
            i += 1
        }
    }
}

class AnnoucementCell: UITableViewCell {
    
    @IBOutlet var btnExpand:UIButton!
    @IBOutlet var btnEdit:UIButton!
    @IBOutlet var btnDelete:UIButton!
    @IBOutlet var btnViewPdf:UIButton!
    
    var editDeleteViewBlock:((UIButton) -> Void)?
    
    func displayAnnouncementData(_ annoucementData:AnnoucementModel)
    {
        var arrData:[String] = [annoucementData.strStandard, annoucementData.strDescription]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                if(arrData[i] == "") {
                    return
                }
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayAnnouncementHeaderDetails(_ annoucementData:AnnoucementModel)
    {
        var arrData:[String] = [annoucementData.strSubjectName, annoucementData.strCreateDate, annoucementData.strStatus, ""]
        
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontType.mediumFont
        }
        
        var i = 0
        for view in self.contentView.subviews[0].subviews[1].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                if(i == 2) {
                    lbl.layer.cornerRadius = 7.5
                    lbl.backgroundColor = arrData[i].caseInsensitiveCompare("No") == .orderedSame ? GetColor.red : GetColor.green
                }else {
                    lbl.text = arrData[i]
                    lbl.font = FontType.regularFont
                }
                i += 1
            }
        }
    }
    
    @IBAction func btnEditDeleteViewAction(_ sender:UIButton)
    {
        if editDeleteViewBlock != nil {
            self.editDeleteViewBlock!(sender)
        }
    }
}

class PermissionCell: CustomCell {
    
    @IBOutlet var btnEdit:UIButton!
    
    func displayData(_ permissionData:PermissionModel)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [permissionData.Index, permissionData.Term, permissionData.Standard, permissionData.Status, permissionData.TermDetail])
    }
    
    func displayProfileData(_ permissionData:PermissionModel)
    {
        self.displaySubViewData(self.contentView, array: [permissionData.Standard, permissionData.Class, permissionData.Status])
    }
    
    func displaySuggestionData(_ permissionData:PermissionModel)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [permissionData.Index, permissionData.EmployeeType, permissionData.EmployeeName])
    }
    
    func displayMSPermissionData(_ permissionData:PermissionModel)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [permissionData.Term, permissionData.strType, permissionData.Standard, permissionData.strTestName, permissionData.Status])
    }
    
    @IBAction func btnEditClikedAction(_ sender:UIButton)
    {
        self.delegate.performAction(sender)
    }
}

class EnquiryCell: CustomCell {
    
    @IBOutlet var lblView:UILabel!
    
    func displayEnquiryHeaderData(_ EnquiryData:EnquiryModel) {
        
        var arr = [EnquiryData.Index, EnquiryData.StudentName.capitalized as! String, EnquiryData.Grade, EnquiryData.Gender, EnquiryData.Status]
        
        var id = 0
        var i:Int = 0
        
        while(id < 2){
            for lbl in (self.contentView.subviews[id].subviews.flatMap{ $0 as? UILabel}) {
                
                if(id == 1){
                    lbl.font = FontType.regularFont
                    if(lbl.tag == -1){
                        lbl.text = arr[i] == "" ? "-" : arr[i]
                    }
                    i += 1
                }else{
                    lbl.font = FontType.mediumFont
                }
            }
            id += 1
        }
    }
    
    func displayEnquiryData(_ EnquiryData:EnquiryModel) {
        
        self.displaySubViewData(self.contentView.subviews[0], array: [EnquiryData.Status, EnquiryData.Date])
    }
    
    @IBAction func btnViewProfileAction(_ sender:UIButton)
    {
        delegate.performAction(sender)
    }
}

class AttendanceCell: UITableViewCell {
    
    @IBOutlet var imgProfile:UIImageView!
    @IBOutlet var lblTeacherName:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        lblTeacherName.font = FontType.regularFont
    }
    
    func displayData(attendanceData:StudentAttendanceModel) {
        
        self.layoutIfNeeded()
        
        lblTeacherName.text = attendanceData.StudentName?.capitalized
        imgProfile.setImageWithFadeFromURL(url: URL.init(string: (attendanceData.StudentImage)!.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!)!, placeholderImage: Constants.studentPlaceholder, animationDuration: 0.5, finish: {
        })
        
        var status:Int = Int(attendanceData.AttendanceStatus!)!
        if status == -2 {
            status = 1
        }
        
        for view in self.contentView.subviews {
            if(view.isKind(of: UIControl.classForCoder()) && view.tag != status){
                let control = view as! UIControl
                control.isSelected = false
            }else if(view.isKind(of: UIControl.classForCoder()) && view.tag == status) {
                let control = view as! UIControl
                control.isSelected = true
            }
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

class ChequePaymentCell: CustomCell {
    
    @IBOutlet var lblView:UILabel!
    
    func displayChequePaymentHeaderData(_ chequePaymentData:ChequePaymentModel) {
        
        var arr = [chequePaymentData.GRNO, chequePaymentData.Date, chequePaymentData.Status, chequePaymentData.Amount, chequePaymentData.ChequeNo]
        
        var id = 0
        var i:Int = 0
        
        while(id < 2){
            for lbl in (self.contentView.subviews[id].subviews.flatMap{ $0 as? UILabel}) {
                
                if(id == 1){
                    lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 16 : DeviceType.isIphone5 ? 12 : 13)
                    if(lbl.tag == -1){
                        lbl.text = arr[i] == "" ? "-" : arr[i]
                    }
                    i += 1
                }else{
                    lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 16 : DeviceType.isIphone5 ? 12 : 13)
                }
            }
            id += 1
        }
    }
    
    func displayChequePaymentData(_ chequePaymentData:ChequePaymentModel) {
        
        let arr = [chequePaymentData.Term, chequePaymentData.ReceiptNo, chequePaymentData.AdmissionFees, chequePaymentData.TuitionFees, chequePaymentData.TransportFees, chequePaymentData.Imprest, chequePaymentData.LateFees, chequePaymentData.Discount, chequePaymentData.PreviousFees, chequePaymentData.PayPaidFees, chequePaymentData.CurrentOutstandingFees]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{$0 as? UILabel}) {
            
            if(lbl.tag == i+1){
                lbl.text = arr[i] == "" ? "-" : arr[i]
                lbl.font = FontHelper.regular(size: DeviceType.isIpad ? 16 : DeviceType.isIphone5 ? 12 : 13)
                
                i += 1
            }else{
                lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 16 : DeviceType.isIphone5 ? 12 : 13)
            }
        }
    }
}

protocol RequestCellDelegate {
    func addStudentIds(_ modal:StudentModel, _ sender:VKCheckbox, _ previousID:String)
}

class RequestCell: UITableViewCell {
    
    @IBOutlet var checkBox:VKCheckbox!
    @IBOutlet var lblStudentName:UILabel!
    @IBOutlet var lblGRNO:UILabel!
    
    var delegate:RequestCellDelegate!
    
    override func awakeFromNib() {
        self.checkBox.line             = .normal
        self.checkBox.bgColorSelected  = GetColor.blue
        self.checkBox.color            = .white
        self.checkBox.borderColor      = GetColor.blue
        self.checkBox.borderWidth      = 1.0
        self.checkBox.cornerRadius     = 5.0
    }
    
    func displayData(stuData:StudentModel) {
        
        self.displaySubViewData(self.contentView, array: [stuData.StudentName?.capitalized as! String, stuData.GRNO!])
        
        if(stuData.Status == true){
            self.checkBox.setOn(true, animated: true)
        } else{
            self.checkBox.setOn(false, animated: false)
        }
        
        self.checkBox.checkboxValueChangedBlock = {
            isOn in
            print("Custom checkbox is \(isOn ? "ON" : "OFF")")
            let modal:StudentModel!
            modal = stuData
            modal.Status = isOn ? true : false
            self.delegate.addStudentIds(modal, self.checkBox, modal.StudentID!)
        }
    }
}

protocol SentInboxCellDelegate {
    func deleteRequest(_ sender:UIButton)
}

class SentInboxCell: UITableViewCell {
    
    @IBOutlet var lblUserName:UILabel!
    @IBOutlet var lblSubjectLine:UILabel!
    @IBOutlet var lblMeetingDate:UILabel!
    @IBOutlet var lblView:UILabel!
    @IBOutlet var viewHeight:NSLayoutConstraint!
    
    @IBOutlet var lblDescription:UILabel!
    @IBOutlet var btnDelete:UIButton!
    
    var delegate:SentInboxCellDelegate!
    
    func displayHeaderData(inboxSentModal:InboxSentModel) {
        
        lblUserName.text = inboxSentModal.UserName
        lblSubjectLine.text = inboxSentModal.SubjectLine
        lblMeetingDate.text = inboxSentModal.MeetingDate
        
        for lbls in self.contentView.subviews[0].subviews[0].subviews{
            let lbl:UILabel = lbls as! UILabel
            lbl.font = FontType.mediumFont
        }
        
        for lbls in self.contentView.subviews[0].subviews[1].subviews{
            let lbl:UILabel = lbls as! UILabel
            if(lbl.tag != 1) {
                if(inboxSentModal.ReadStatus == "Pending"){
                    lbl.font = FontType.mediumFont
                }else{
                    lbl.font = FontType.regularFont
                }
            }
        }
    }
    
    func displayData(inboxSentModal:InboxSentModel) {
        lblDescription.text = inboxSentModal.Description
    }
    
    @IBAction func btnDeleteClicked(_ sender:UIButton)
    {
        delegate.deleteRequest(sender)
    }
}

class UserCell: CustomCell {
    
    func displayUsersData(_ userData:UsersModel) {
        
        self.displaySubViewData(self.contentView, array: [userData.Name, userData.UserType, userData.Date])
    }
}

class HolidayCell: CustomCell {
    
    @IBOutlet var btnEdit:UIButton!
    @IBOutlet var btnDelete:UIButton!
    
    func displayData(_ holidayData:HolidayModel)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [holidayData.Holiday, holidayData.Description, holidayData.StartDate, holidayData.EndDate])
    }
    
    @IBAction func btnEditClikedAction(_ sender:UIButton)
    {
        self.delegate.performAction(sender)
    }
}

class ViewLessonPlanCell: CustomCell {
    
    @IBOutlet var btnWord:UIButton!
    @IBOutlet var lblView:UILabel!
    @IBOutlet var headerHeight:NSLayoutConstraint!
    
    func displayHeaderData(_ viewLessonPlanData:ViewLessonPlanModel)
    {
        let arr = [NSAttributedString.init(string: viewLessonPlanData.Index), NSAttributedString.init(string: viewLessonPlanData.ChapterNo), viewLessonPlanData.ChapterName]
        
        var i:Int = 0
        var id = 0
        
        while(id < 2){
            for lbl in (self.contentView.subviews[id].subviews.flatMap{ $0 as? UILabel}) {
                
                if(id == 1){
                    lbl.font = FontType.regularFont
                    if(lbl.tag == -1) {
                        lbl.attributedText = arr[i]?.string == "" ? NSAttributedString.init(string: "-") : arr[i]
                    }
                    i += 1
                }else{
                    lbl.font = FontType.mediumFont
                }
            }
            id += 1
        }
        btnWord.accessibilityValue = viewLessonPlanData.ID
    }
    
    func displayData(_ viewLessonPlanData:ViewLessonPlanModel)
    {
        let array = [viewLessonPlanData.Objective, viewLessonPlanData.KeyPoint, viewLessonPlanData.AssessmentQuestion]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag == -1)
            {
                lbl.attributedText = array[i]?.string == "" ? NSAttributedString.init(string: "-") : array[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    @IBAction func btnWordClikedAction(_ sender:UIButton)
    {
        self.delegate.performAction(sender)
    }
}

class LeaveCell: UITableViewCell {
    
    @IBOutlet var lblARDate:UILabel!
    @IBOutlet var lblARBy:UILabel!
    
    @IBOutlet var btnExpand:UIButton!
    @IBOutlet var btnEdit:UIButton!
    @IBOutlet var btnDelete:UIButton!
    
    var editDeleteBlock:((UIButton) -> Void)?
    var btnActionBlock:((UIButton) -> Void)?
    
    func displayLeaveData(_ leaveData:LeaveModel)
    {
        var arrData:[String] = [leaveData.Category, leaveData.Total, leaveData.Used, leaveData.Remaining]
        
        var i = 0
        for view in self.contentView.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayLeaveHeaderDetails(_ leaveData:LeaveModel)
    {
        var arrData:[String] = [leaveData.CreateDate, leaveData.LeaveDays, leaveData.Status]
        
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontType.mediumFont
        }
        
        var i = 0
        for view in self.contentView.subviews[0].subviews[1].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                lbl.textColor = .black
                
                if(i == arrData.count - 1){
                    switch(leaveData.Status.capitalized)
                    {
                    case "Approved":
                        lbl.textColor = GetColor.green
                    case "Pending":
                        lbl.textColor = GetColor.yellow
                    case "Rejected":
                        lbl.textColor = GetColor.red
                    default:
                        break
                    }
                }
                i += 1
            }
        }
    }
    
    func displayLeaveDetails(_ leaveData:LeaveModel)
    {
        var arrData:[String] = ["\(leaveData.LeaveStartDate!) - \(leaveData.LeaveEndDate!)", leaveData.Reason]
        
        //        btnEdit.isHidden = leaveData.Status.capitalized != "Pending"
        //        btnDelete.isHidden = btnEdit.isHidden
        
        if(leaveData.Status.capitalized != "Pending")
        {
            var status:String = leaveData.Status
            if(leaveData.Status.capitalized == "Approved"){
                status.removeLast()
            }else{
                status.removeLast(2)
            }
            
            lblARDate.text = "\(status) Date"
            lblARBy.text = "\(status) By"
            
            arrData.insert(leaveData.ApproveRejectDate, at: 1)
            arrData.insert("\(leaveData.ApproveRejectDays!) Days", at: 2)
            arrData.insert(leaveData.ApproveRejectBy, at: 3)
            arrData.insert(leaveData.CL, at: 4)
            arrData.insert(leaveData.PL, at: 5)
            
            let view:UIView = self.contentView.subviews[0].subviews.last!
            view.layer.cornerRadius = 5.0
            view.layer.borderColor  = GetColor.blue.cgColor
            view.layer.borderWidth  = 0.5
        }
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
        
        i = 4
        for view in (self.contentView.subviews[0].subviews.last?.subviews)! {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayLeaveRequestHeaderDetails(_ leaveData:LeaveModel)
    {
        var arrData:[String] = [leaveData.EmployeeName, leaveData.ApplicationDate, leaveData.LeaveDays]
        
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontType.mediumFont
        }
        
        var i = 0
        for view in self.contentView.subviews[0].subviews[1].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayLeaveRequestDetails(_ leaveData:LeaveModel)
    {
        var arrData:[String] = [leaveData.LeaveDate, leaveData.Reason, "-"]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayLeaveBalanceData(_ leaveBData:LeaveModel)
    {
        self.contentView.subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
        self.contentView.subviews[0].layer.borderWidth  = 0.5
        
        var arrData:[String] = ["\(leaveBData.EmployeeName!) (\(leaveBData.EmployeeID!))", "\(leaveBData.PLUsed!)/\(leaveBData.PLTotal!)", "\(leaveBData.CLUsed!)/\(leaveBData.CLTotal!)", "\(leaveBData.Used!)/\(leaveBData.Total!)"]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                if(i != 0)
                {
                    let attributedString = NSMutableAttributedString(
                        string: lbl.text!,
                        attributes: [:])
                    
                    let arrSubStr:[String] = (lbl.text?.components(separatedBy: "/"))!
                    
                    attributedString.addAttribute(
                        NSAttributedStringKey.foregroundColor,
                        value: GetColor.red,
                        range: (lbl.text! as NSString).range(of: arrSubStr[0]))
                    
                    attributedString.addAttribute(
                        NSAttributedStringKey.foregroundColor,
                        value: GetColor.green,
                        range: (lbl.text! as NSString).range(of: arrSubStr[1]))
                    
                    lbl.attributedText = attributedString
                }
                i += 1
            }
        }
    }
    
    @IBAction func btnEditDeleteAction(_ sender:UIButton)
    {
        if editDeleteBlock != nil {
            self.editDeleteBlock!(sender)
        }
    }
    
    @IBAction func btnActions(_ sender:UIButton)
    {
        if btnActionBlock != nil {
            self.btnActionBlock!(sender)
        }
    }
}

class TallyTransactionCell: UITableViewCell
{
    override func awakeFromNib() {
        self.contentView.subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
        self.contentView.subviews[0].layer.borderWidth  = 0.5
    }
    
    func displayTallyTransactionDetails(_ tallyTransactionData:TallyTransactionModel)
    {
        var arrData:[String] = [tallyTransactionData.strVoucherID, tallyTransactionData.strStudentName, tallyTransactionData.strGRNO, tallyTransactionData.strGrade, tallyTransactionData.strAmount.formatAmount(number: NSNumber.init(value: Int(tallyTransactionData.strAmount)!)), tallyTransactionData.strStatus, ""]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                if(i == 5) {
                    lbl.layer.cornerRadius = 7.5
                    lbl.backgroundColor = arrData[i].contains("Pending") ? GetColor.red : GetColor.green
                }else {
                    lbl.text = arrData[i]
                    lbl.font = FontType.regularFont
                }
                i += 1
            }
        }
    }
}

class OnlineTransactionCell: UITableViewCell
{
    @IBOutlet var imgStatus:UIImageView!
    @IBOutlet var btnExpand:UIButton!
    
    func displayOnlineTransactionHeaderDetails(_ onlineTransactionData:OnlineTransactionModel)
    {
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontType.mediumFont
        }
        
        var arrData:[String] = [onlineTransactionData.strTransactionID, onlineTransactionData.strDate.toDate(dateFormat: "dd/MM/yyyy h:mm:ss").toString(dateFormat: "dd MMM"), onlineTransactionData.strAmount.formatAmount(number: NSNumber.init(value: Int(onlineTransactionData.strAmount)!)), ""]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews[1].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
        imgStatus.image = UIImage.init(named: onlineTransactionData.strStatus.lowercased())?.withRenderingMode(.alwaysTemplate)
        imgStatus.tintColor = onlineTransactionData.strStatus.contains("Un") ? GetColor.red : GetColor.green
    }
    
    func displayOnlineTransactionDetails(_ onlineTransactionData:OnlineTransactionModel)
    {
        var arrData:[String] = [onlineTransactionData.strPaymentID, onlineTransactionData.strDate, onlineTransactionData.strStudentName.capitalized as! String, onlineTransactionData.strGrade]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
}

class DailyReportCell: UITableViewCell
{
    @IBOutlet var btnExpand:UIButton!
    
    func displayDailyReportHeaderDetails(_ drModal:DailyReportModel)
    {
        var arrData:[String] = [drModal.Index, drModal.strDate, drModal.strCreateBy]
        
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontType.mediumFont
        }
        
        var i = 0
        for view in self.contentView.subviews[0].subviews[1].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayTransportationData(_ drModal:DailyReportModel)
    {
        var arrData:[String] = [drModal.strRouteProblem, drModal.strDriverComplaint, drModal.strParentsComplaint, drModal.strTimingProblem, drModal.strVehicleProblem, drModal.strOther]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayAccountData(_ drModal:DailyReportModel)
    {
        var arrData:[String] = [drModal.strBankBalance, drModal.strPettyCash, drModal.strExpenses, drModal.strFeesReceived, drModal.strDepositedInBank, drModal.strOther]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayITData(_ drModal:DailyReportModel)
    {
        var arrData:[String] = [drModal.strLaptopIssued, drModal.strTabletIssued, drModal.strPrinting, drModal.strIT, drModal.strOther]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayHRHeadData(_ drModal:DailyReportModel)
    {
        var arrData:[String] = [drModal.strAdmissionInquiry, drModal.strTotalNewAdmission, drModal.strEventOftheYear, drModal.strFBUpdate, drModal.strMajorConcern, drModal.strOther]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayAdminData(_ drModal:DailyReportModel)
    {
        var arrData:[String] = [drModal.strTSOS, drModal.strNewAdmission, drModal.strWithdrawals, drModal.strSDU, drModal.strOverallAdmin, drModal.strNOTPA, drModal.strTNOV, drModal.strACOPBYPE, drModal.strSuggestion, drModal.strOther]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayHKData(_ drModal:DailyReportModel)
    {
        var arrData:[String] = [drModal.strRepainMaintenance, drModal.strToilets, drModal.strWashArea, drModal.strClassRoom, drModal.strTeacherComplain, drModal.strMaidsPA, drModal.strGardner, drModal.strSuggestion, drModal.strOther]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i+1){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
}

class InOutSummaryCell: UITableViewCell
{
    @IBOutlet var btnExpand:UIButton!
    
    func displayInOutSummaryHeaderDetails(_ inOutSummaryData:InOutSummaryModel, index:NSInteger)
    {
        var arrData:[String] = ["\(index)", inOutSummaryData.strTeacherName, inOutSummaryData.strDepartment]
        
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}) {
            lbl.font = FontType.mediumFont
        }
        
        var i = 0
        for view in self.contentView.subviews[0].subviews[1].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayInOutSummaryDetails(_ inOutSummaryData:InOutSummaryModel)
    {
        var arrData:[String] = ["\(inOutSummaryData.Day1!)", inOutSummaryData.strSun != "" ? inOutSummaryData.strSun.components(separatedBy: "-").first! : "", inOutSummaryData.strSun != "" ? inOutSummaryData.strSun.components(separatedBy: "-").last! : "", "\(inOutSummaryData.Day2!)", inOutSummaryData.strMon != "" ? inOutSummaryData.strMon.components(separatedBy: "-").first! : "", inOutSummaryData.strMon != "" ? inOutSummaryData.strMon.components(separatedBy: "-").last! : "", "\(inOutSummaryData.Day3!)", inOutSummaryData.strTue != "" ? inOutSummaryData.strTue.components(separatedBy: "-").first! : "", inOutSummaryData.strTue != "" ? inOutSummaryData.strTue.components(separatedBy: "-").last! : "", "\(inOutSummaryData.Day4!)", inOutSummaryData.strWed != "" ? inOutSummaryData.strWed.components(separatedBy: "-").first! : "", inOutSummaryData.strWed != "" ? inOutSummaryData.strWed.components(separatedBy: "-").last! : "", "\(inOutSummaryData.Day5!)", inOutSummaryData.strThu != "" ? inOutSummaryData.strThu.components(separatedBy: "-").first! : "", inOutSummaryData.strThu != "" ? inOutSummaryData.strThu.components(separatedBy: "-").last! : "", "\(inOutSummaryData.Day6!)", inOutSummaryData.strFri != "" ? inOutSummaryData.strFri.components(separatedBy: "-").first! : "", inOutSummaryData.strFri != "" ? inOutSummaryData.strFri.components(separatedBy: "-").last! : "", "\(inOutSummaryData.Day7!)", inOutSummaryData.strSat != "" ? inOutSummaryData.strSat.components(separatedBy: "-").first! : "", inOutSummaryData.strSat != "" ? inOutSummaryData.strSat.components(separatedBy: "-").last! : ""]
        
        var j = 0
        for i in 0...6 {
            for lbls in self.contentView.subviews[0].subviews[i].subviews {
                let lbl:UILabel = lbls as! UILabel
                lbl.text = (arrData[j] == "A" || arrData[j] == "W") ? "0:00" : arrData[j]
                lbl.isHidden = arrData[j] == "" || arrData[j] == "0"
                lbl.superview?.isHidden = lbl.isHidden
                if let lblDay:UILabel = lbl.superview?.viewWithTag(i+1) as? UILabel {
                    lblDay.textColor = arrData[j] == "A" ? GetColor.red : arrData[j] == "W" ? GetColor.orange : UIColor.black
                }
                j += 1
            }
        }
    }
}

class EmployeePresentCell: UITableViewCell
{
    override func awakeFromNib() {
        self.contentView.subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
        self.contentView.subviews[0].layer.borderWidth  = 0.5
    }
    
    func displayEmployeePresentData(_ employeePresentData:EmployeePresentModel)
    {
        var arrData:[String] = [employeePresentData.strDate, employeePresentData.strName, employeePresentData.strDepartment, employeePresentData.strDesignation]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
    
    func displayEmployeeInOutData(_ employeeInOutData:EmployeePresentModel)
    {
        var arrData:[String] = [employeeInOutData.strCode, employeeInOutData.strName, employeeInOutData.strDate, employeeInOutData.strInOutTime, employeeInOutData.strDuration]
        
        var i = 0
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.text = arrData[i]
                lbl.font = FontType.regularFont
                
                i += 1
            }
        }
    }
}

protocol HomeWorkStatusCellDelegate {
    func studentHomeWorkStatusUpdate(_ idx:NSInteger, _ superViewTag:NSInteger)
    func studentHomeWorkStatusUpdate(_ idx:NSInteger)
}

class HomeWorkStatusCell: UITableViewCell {
    
    var delegate:HomeWorkStatusCellDelegate!
    var isFromHeader:Bool = false
    
    override func awakeFromNib() {
        self.contentView.subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
        self.contentView.subviews[0].layer.borderWidth  = 0.5
    }
    
    func displayData(_ homeWorkStatusModal:HomeWorkStatusModel, _ isHeader:Bool, _ status:Int)
    {
        var homeWorkStatus = homeWorkStatusModal.HomeWorkStatus
        if homeWorkStatus == -1 {
            homeWorkStatus = 2
        }else{
            homeWorkStatus = homeWorkStatusModal.HomeWorkStatus! + 1
        }
        
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == -2){
                
                let lbl:UILabel = view as! UILabel
                lbl.font = FontHelper.regular(size: 14)
                
                if(isHeader) {
                    self.isFromHeader = isHeader
                    return
                }
                
                lbl.text = homeWorkStatusModal.StudentName?.capitalized
                
            }else if(view.isKind(of: LTHRadioButton.classForCoder())){
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                
                if(radioButton.tag == (isHeader ? status : homeWorkStatus)){
                    radioButton.select(animated: true)
                }else{
                    radioButton.deselect(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            }else if(view.isKind(of: UILabel.classForCoder())){
                
                let lbl:UILabel = view as! UILabel
                lbl.font = FontHelper.regular(size: 14)
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.addGestureRecognizer(tapGesture)
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in self.contentView.subviews[0].subviews {
            if(view.isKind(of: UILabel.classForCoder())){
                let lbl:UILabel = view as! UILabel
                lbl.font = FontHelper.regular(size: 14)
                
            }else if(view.isKind(of: LTHRadioButton.classForCoder())){
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.deselect(animated: true)
            }
        }
        
        let tag:NSInteger = gesture.view!.tag - 10 > 0 ? gesture.view!.tag - 10 : gesture.view!.tag
        let radioButton:LTHRadioButton = self.contentView.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        (self.contentView.viewWithTag(tag + 10) as! UILabel).font = FontHelper.medium(size: 14)
        
        if((self.tag/100) - 1 == -1){
            delegate.studentHomeWorkStatusUpdate(tag-1)
        }else {
            delegate.studentHomeWorkStatusUpdate(tag-1, (self.tag/100) - 1)
        }
    }
}

class GalleryCell: CustomCell {
    
    func displayData(_ galleryData:GalleryModel)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: [galleryData.strTitle, galleryData.strComment, galleryData.strDate])
    }
}

class SearchStaffCell: CustomCell {
    
    func displayData(_ searchStaffData:SearchStaffModal)
    {
        self.displaySubViewData(self.contentView.subviews[0], array: ["\(searchStaffData.Name.capitalized as! String) (\(searchStaffData.EmpCode!))", searchStaffData.FatherHusbandName.capitalized as! String, searchStaffData.DOB, searchStaffData.Department])
    }
}

class NotificationCell:CustomCell
{
    @IBOutlet var btnType:UIButton!
    var sendNotification:((UIButton) -> ())?
    
    func displayData(_ notificationData:NotificationModel)
    {
        self.contentView.subviews[0].backgroundColor = notificationData.Flag ? .groupTableViewBackground : .white
        //self.btnType.isHidden = notificationData.Flag
        
        let array = [notificationData.Name.capitalized as! String, "(\(notificationData.UserType!))", notificationData.Department]
        
        var i:Int = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{ $0 as? UILabel}) {
            
            if(lbl.tag == -1){
                lbl.text = array[i] == "" ? "-" : array[i]
                
                i += 1
            }
        }
        
        switch notificationData.NotificationType {
        case "BirthdayWish", "Suggestion":
            btnType.loadIconsFromLocal(notificationData.NotificationType)
        default:
            btnType.loadIconsFromLocal("Leave")
        }
        //        self.displaySubViewData(self.contentView.subviews[0], array: [notificationData.Name.capitalized as! String, "(\(notificationData.UserType!))", notificationData.Department])
        
        //        switch notificationData.NotificationType {
        //        case "BirthdayWish":
        //            btnType.setTitle("SEND WISHES", for: .normal)
        //        case "Suggestion":
        //            btnType.setTitle("GIVE REPLY", for: .normal)
        //        default:
        //            btnType.setTitle("VIEW", for: .normal)
        //        }
    }
    
    @IBAction func btnTypeAction(_ sender:UIButton)
    {
        if(self.sendNotification != nil) {
            self.sendNotification!(sender)
        }
    }
}

class SuggestionCell:CustomCell
{
    @IBOutlet var lblSubject:UILabel!
    @IBOutlet var lblRDate:UILabel!
    @IBOutlet var lblTime:UILabel!
    @IBOutlet var width:NSLayoutConstraint!
    @IBOutlet var lblSuggestion:UILabel!
    @IBOutlet var lblReply:UILabel!
    @IBOutlet var lblSDate:UILabel!
    @IBOutlet var lblName:UILabel!
    @IBOutlet var txtReply:UITextView!
    
    var btnSendTapped:((UIButton) -> ())?
    
    func displayHeaderData(_ suggestionData:SuggestionModel)
    {
        lblSubject.text = suggestionData.Subject
        lblSubject.font = FontHelper.medium(size: DeviceType.isIpad ? 18 : 15)
        
        width.constant = suggestionData.ReplyDate == "" ? 0 : 90
        
        lblRDate.text = suggestionData.ReplyDate.toDate(dateFormat: "dd MMM yyyy").toString(dateFormat: "dd MMM yyyy")
        lblRDate.font = FontType.regularFont
        
        lblTime.text = suggestionData.ReplyDate == "" ? "" : suggestionData.ReplyDate.toDate(dateFormat: "dd/MM/yyyy").getElapsedInterval()
        lblTime.font = FontHelper.regular(size: DeviceType.isIpad ? 13 : 12)
    }
    
    func displaySentInboxData(_ suggestionData:SuggestionModel, _ isReplyDone:Bool)
    {
        if isReplyDone {
            lblReply.text = suggestionData.Reply
            lblReply.font = FontHelper.medium(size: DeviceType.isIpad ? 18 : 15)
        }
        
        lblSuggestion.text = suggestionData.Comment
        lblSuggestion.font = FontType.regularFont
        
        lblName.text = "\(suggestionData.StudentName!), \(suggestionData.Standard!) - \(suggestionData.ClassName!)"
        lblName.font = FontType.regularFont
        
        lblSDate.text = suggestionData.Date.toDate(dateFormat: "dd MMM yyyy h:mm a").toString(dateFormat: "dd MMM yyyy h:mm a")
        lblSDate.font = FontType.regularFont
    }
    
    @IBAction func btnSendAction(_ sender:UIButton)
    {
        if(btnSendTapped != nil) {
            self.btnSendTapped!(sender)
        }
    }
}
