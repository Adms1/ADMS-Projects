//
//  CollectionCell.swift
//  Skool360Teacher
//
//  Created by ADMS on 13/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class DeshBoardCell: UICollectionViewCell {
    
    @IBOutlet var bgView:UIView!
    @IBOutlet var imgIcon:UIImageView!
    @IBOutlet var lblTitle:UILabel!
    
    func displayData(_ folderName:String, _ strImageName:String) {
        
        lblTitle.text = strImageName
        
        if folderName == "Main" {
            lblTitle.font = FontHelper.lato_bold(size: DeviceType.isIphone5 ? 15 : DeviceType.isIpad ? 24 : 18)
        }else {
            lblTitle.font = FontHelper.lato_bold(size: DeviceType.isIphone5 ? 13 : DeviceType.isIpad ? 22 : 16)
        }
        imgIcon.getImagesfromLocal(folderName, strImageName)
    }
}

class SectionCell: UICollectionViewCell {
    
    @IBOutlet var lblSection:UILabel!
    @IBOutlet var checkBox:VKCheckbox!
    
    override func awakeFromNib() {
        self.checkBox.line             = .normal
        self.checkBox.bgColorSelected  = GetColor.blue
        self.checkBox.color            = .white
        self.checkBox.borderColor      = GetColor.blue
        self.checkBox.borderWidth      = 1.0
        self.checkBox.cornerRadius     = 5.0
    }
}
